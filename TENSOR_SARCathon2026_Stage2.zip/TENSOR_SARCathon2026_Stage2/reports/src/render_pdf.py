#!/usr/bin/env python3
"""Render reports/src/report.html -> reports/TENSOR_Stage2_Technical_Report.pdf (headless Chromium)."""
import os, pathlib
from playwright.sync_api import sync_playwright
here = pathlib.Path(__file__).resolve().parent
out = here.parent / "TENSOR_Stage2_Technical_Report.pdf"
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page()
    pg.goto((here / "report.html").as_uri(), wait_until="networkidle")
    pg.pdf(path=str(out), format="A4", print_background=True, prefer_css_page_size=True,
           display_header_footer=True, header_template="<span></span>",
           footer_template='<div style="font-size:7pt;width:100%;text-align:center;color:#666">Team TENSOR — SARCathon 2026 Stage 2 — AXI4-Stream ⇄ PCIe-6-style link, RTL to GDSII — page <span class="pageNumber"></span> / <span class="totalPages"></span></div>')
    b.close()
print("wrote", out)
