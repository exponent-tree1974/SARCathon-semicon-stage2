# Verification Plan – `axis_pcie_link_top` (v4)

v4 adds three benches and a formal proof next to `tb_top`:

| Bench / flow | DUT | Purpose |
|---|---|---|
| `tb_top` (17 tests) | `axis_pcie_link_top` | the core datapath. v4 adds:<br>- random `tid` per packet<br>- `tid` forgery<br>- error CSRs and IRQ<br>- performance counters vs. a shadow model<br>- end-to-end safety checker<br>- `LANES` / `TID_W` overridable |
| `tb_arb` (8 tests) | `axis_pcie_link_mux2_top` | 2 sources through `axis_rr_arbiter`: fairness, starvation bound, atomicity, conservation, per-stream order under faults and reset |
| `tb_replay` (1 unit test) | `fiu_replay_buffer` | Go-Back-N storage/replay component against a cycle-level reference model |
| `bash sim/formal/run_formal.sh` | `axis_rr_arbiter` | Yosys k-induction proof of P1–P6, plus a reachability witness and 3 negative controls |

## 1. Environment architecture

```
                    +-------------------- tb_top -------------------------------------+
 axis_source_bfm --> s_axis --> [ DUT axis_pcie_link_top ] --> m_axis --> pkt_scoreboard
   (gaps, null/zlast,   |            |   tx_sym      ^ rx_sym     |   (FIU-level ref model,
    illegal tkeep,      |            v               |            |    byte-for-byte, order,
    abort on reset)     |      link_channel_model ---+            |    tlast/tuser, counters)
                        |      (delay, corruption, forgery,       +--> axis_sink_bfm (tready
 axis_protocol_checker -+       credit delay line)                     random / bursts, own RNG)
   (ingress, DUT=slave)        ^ credit return                    axis_protocol_checker
 axil_master_bfm --> s_axil --> csr_status                          (egress, DUT=master)
 axil_protocol_checker         dut_invariant_checker (white-box)  coverage_collector (110 bins) 
 deadlock monitor, timeouts, reset sequencer, test library (17 tests), summary/exit code; perf_shadow, link_safety_checker (v4)
```

All components are plain SystemVerilog modules and tasks. There are no classes, so the environment runs on Icarus Verilog as well as Verilator and commercial simulators.

## 2. Requirement traceability

| # | Requirement | Test(s) | How it is checked |
|---|---|---|---|
| 1 | Reset during idle | `reset_idle` | outputs idle in reset (R4, R5, L6, T9); all CSRs back to defaults after reset; traffic works afterwards |
| 1b | Reset during traffic | `reset_traffic` (ingress mid-packet, link mid-FIU, egress stalled with buffer full) | same as above, plus buffer empty and credits = DEPTH right after reset; fresh traffic checked byte for byte |
| 2 | 1, 63, 64, 65, 100, 255, 256 B packets | `sizes_directed` (these plus 17 boundary sizes, without and with stalls) | scoreboard S1–S6; coverage bins `len_exact_*` |
| 3 | Back-to-back packets | `back_to_back`, `sizes_directed` pass 0 | no-gap ingress; link occupancy ≥ 99 % required (measured); bins `ing_back_to_back_pkts`, `eg_back_to_back_pkts`, `link_fiu_back_to_back` |
| 4 | Random tvalid/tready stalls on both sides | `random_stalls`, `order_preservation`, `random_regression` | ingress gap 15–35 %, egress per-cycle or burst stalls (up to 60 cycles); R2/R3 stability checks |
| 5 | Malformed / non-contiguous tkeep | `tkeep_malformed` | **defined behavior**: beat forwarded whole, IN_PROTO_ERR +1, `tuser=1` on that packet's tlast, next packet clean. Patterns: partial non-last, hole in full beat, sparse, offset |
| 6 | CRC corruption, discard and error reporting | `crc_corruption` (directed + random) | expected drop, abort (`tlast`+`tuser`), or discard per FIU; RX_CRC_ERR, RX_DISCARD, RX_PKT_ERR counters |
| 7 | Lane corruption | `lane_corruption` | each of the 4 lanes: one word, the trailer word, a padding word, and a whole-FIU lane failure; plus random lane faults |
| 8 | Packet order preservation | all tests; stressed in `order_preservation` (1200 packets) | unique 32-bit tag in bytes 0..3 of every packet; S2 reports `ORDER VIOLATION` with the indices involved |
| 9 | Byte-for-byte scoreboarding | all tests | S1: every egress byte against the reference model's expected stream; S5: bytes outside `tkeep` must be 0 |
| 10 | Counter / status register validation | every test end (`idle_checks`) and `csr_access` | all 11 counters compared with the reference model; STATUS idle and credits; CSR R/W, strobes, SLVERR |
| 11 | Timeout / deadlock checks | all | T1 drain timeout, T2 deadlock monitor (5000 cycles without progress), T3 driver stall, T4 AXI-Lite timeout, T5 global watchdog |
| 12 | Randomized regression, fixed reproducible seed | `random_regression`; `--seeds`; `--repro-check` | per-test seed = base×1000 + index; the sink has its own RNG; a check proves identical results when run twice and when run alone |
| + | Header/framing robustness (beyond the list) | `header_forgery` | valid-CRC forged trailers reach frame, sequence, poison and discard paths |
| + | Waveform review | `wave_showcase` | one short deterministic scenario covering ingress, FIU, CRC, lanes, injection, discard and egress; verified from the VCD by `sim/verify_waves.py` (W1–W8) |
| + | Flow control | `credit_stress`, `link_enable` | TX stops without credits; no overflow (I1–I5); `link_en=0` backpressures ingress |
| v4-1 | 2-input arbiter, packet atomicity | `tb_arb` all tests; formal P4 | A1 (monitor), R9 (tid constant per packet at the arbiter output and egress), formal proof; mutations A1, A5 |
| v4-2 | Fairness / starvation | `arb_saturated_equal`, `arb_mixed_sizes`, `arb_starvation`, `arb_back_to_back_switch` | A3: a waiting source is passed by ≤ 1 packet (N−1); measured max wait ≤ one packet of the other source; 50/50 share under saturation; formal P5 (round-robin hand-over); mutation A2 |
| v4-3 | Sequence numbers and FIU header fields | all `tb_top` tests | golden model G5/G8 (seq, tid); safety S3 (TX seq consecutive), S4 (RX accepted seq increasing); `SEQ_STATUS` vs model; FK_SEQ / FK_TID forgeries |
| v4-4 | CRC status / error CSRs | `err_csr_perf` (hand-derived values) + every `idle_checks` (model) | ERR_STATUS sticky + W1C with strobes; ERR_IRQ_EN; `irq` and STATUS[16]; LAST_ERR reason / expected / received sequence for CRC, HDR, SOP, TID, SEQ; clear semantics; mutations M21–M26 |
| v4-5 | Replay buffer (component) | `tb_replay` | cycle-level reference model + data integrity + scenario checks; mutations R1–R5 (`docs/replay_architecture.md`) |
| v4-6 | Configurable lane count | `tb_top` full suite with `--lanes 1 2 8 16 32` | the DUT, the channel model and the golden model use the same `LANES`; lane-fault tests loop over all lanes; lane bins ≥ `LANES` reported N/A |
| v4-7 | FEC placeholder | every `tb_top` test | stubs are in the datapath (bypass identity); `PARAMS2.FEC_MODE = 0`; FEC_CORR / FEC_UNCORR = 0; FEC_MODE≠0 fails elaboration (`docs/fec_architecture.md` §5 for the real plan) |
| v4-8 | Performance counters | every `check_counters` | 9 new counters against `perf_shadow` (snapshot at the AR handshake, exact, including CYCLES); cross-checks OUT_BYTES = model bytes, TX_WORDS = 8 × TX_FIU; derived values in `err_csr_perf`; mutations M27–M31 |
| v4-9 | No output without valid input, no reordering | all `tb_top` and `tb_arb` tests; formal P1/P2 | `link_safety_checker` S1a–S1d, S2; `stream_scoreboard` per-stream order and origin; arbiter A2 conservation |

## 3. Checkers

| ID | Where | Rule |
|---|---|---|
| R1–R8 | `axis_protocol_checker` (×2) | no X on valid/ready; no valid retraction; payload stable while stalled; valid low in reset (DUT master); **tready low in reset (DUT slave)**; egress tkeep contiguous and non-zero; non-last beats full; tuser only with tlast |
| L1–L6 | `axil_protocol_checker` | no X; B/R held while stalled; B only after AW+W; R only after AR; no response in reset |
| I1–I5 | `dut_invariant_checker` | credits ≤ depth; buffer occupancy ≤ depth; FIU start only with credits and link_en; pop ≤ committed; ≤ 1 FIU of speculative words |
| S1–S6 | `pkt_scoreboard` | byte compare; order tag; tlast position; tuser; zero outside tkeep; no unexpected beat |
| T1–T9 | `tb_top` | drain timeout; deadlock; driver stall; AXI-Lite timeout; global watchdog; end-of-traffic idle and **credit-leak** check; counters; STATUS; tx_sym idle in reset |
| G1–G8 | `tb/model/check_fiu_stream.py` | independent decode of the TX symbol stream: CRC = zlib, magic, length rules, reserved bits zero, padding zero, sequence numbers, sop/eop framing, **tid** (≤ TID_W bits, constant per packet); `--lanes`, `--tid-w` |
| R9 | `axis_protocol_checker` (`HAS_TID`) | tid stable while stalled, constant from first to tlast beat |
| S1a–S4 | `link_safety_checker` | S1a every egress packet is an ingress packet (tag + tid); S1b egress beats ≤ ingress beats; S1c egress packets ≤ ingress packets started; S1d a new egress beat needs committed RX words; S2 strictly increasing ingress index (no reorder / duplicate), per stream and global; S3 TX FIU seq consecutive; S4 accepted RX seq increasing |
| P1–P2 | `perf_shadow` | each performance counter equals its port-level definition at the read handshake; FEC counters 0 |
| A1–A3 | `arb_fairness_monitor` (tb_arb) | atomicity; beat conservation (data/keep/last from source m_tid); starvation bound (≤ N−1 packets started past a waiting source) |
| Q1–Q4 | `stream_scoreboard` (tb_arb) | per stream: exact in-order delivery (clean); under faults only losses or whole-FIU prefixes with tuser; never a duplicate, reorder, wrong stream or invented packet |
| F-P1–P6 | `sim/formal/axis_rr_arbiter_props.sv` + embedded `ifdef FORMAL` | proved for all reachable states (k-induction): P1 output = selected valid input; P2 beat conservation; P3 output stability; P4 atomicity; P5 round-robin hand-over; P6 work conservation |

**SVA:** the R, L and I rules are also written as concurrent assertions plus cover properties under `` `ifdef SVA``. Icarus 12–14 cannot parse concurrent assertions, so under Icarus the identical immediate checks are the active ones. The Verilator flow (`sim/run_verilator.sh`) compiles with `+define+SVA --assert`.

## 4. Reference model (`pkt_scoreboard.build_expect`)
For every FIU in transmission order, the model:
1. reconstructs the transmitted trailer (sop, eop, len, err, seq);
2. applies the channel plan (CRC-detectable corruption, or a forged field with a valid CRC);
3. applies the documented RX decision table (CRC → header → sop-while-open → continuation-without-packet → accept);
4. tracks `in_pkt`, `discard` and the expected sequence number.

The result is the exact expected egress byte stream per packet, the tlast position, tuser, and the value of every counter. The model follows the specification; it does not copy RTL code.

## 5. Pass/fail policy
A test **passes** only if no component reports an error during its window, which includes its reset. The run passes only if every selected test passes and the global error total is zero. It prints `[SIM-RESULT] PASSED` and exits with code 0. Any failure prints `[SIM-RESULT] FAILED` and calls `$fatal(1)` (exit code 1). The runner additionally requires the golden-model check to pass and, with `--cov-strict`, zero coverage holes.

## 6. Known verification limitations
- The arbiter is proved formally; the rest of the datapath is verified by simulation only (seeded random + directed + mutation).
- FEC is a bypass placeholder. Replay is verified only as a standalone component; there is no system-level retry test because the datapath has no ACK/NAK channel.
- Corruption modes 1–5 assume CRC-32 detects the error (miss probability 2⁻³²). Runs are seeded and deterministic, so a miss would show up as a reproducible scoreboard mismatch.
- Not exercised: counter saturation (needs 2³² events), corruption of the `sof` sideband (documented to leak credits), lane-to-lane skew (not supported by the DUT).
- Coverage is functional (bins) only; code coverage needs Verilator `--coverage` or a commercial tool.
