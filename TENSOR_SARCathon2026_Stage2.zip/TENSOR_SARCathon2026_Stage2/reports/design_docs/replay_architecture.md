# Replay (ACK/NAK retry) — architecture stub and scope

## Scope in one paragraph
`rtl/placeholder/fiu_replay_buffer.sv` is a **complete, unit-verified storage and
replay-sequencing component** for a Go-Back-N retry protocol. It is **not
connected** to `axis_pcie_link_top`. Today the link recovers from a bad FIU by
**abort + discard**: the open packet is closed with `tuser = 1`, and FIUs are
dropped until the next start-of-packet FIU. Corrupted data is never delivered,
but it is not retransmitted either. `PARAMS2[16]` (replay integrated) reads 0.

## What exists and is verified
| Item | Status | Evidence |
|---|---|---|
| FIU sequence numbers (8 bit, consecutive from 0 after reset) in every trailer | **in the datapath** | golden model (`check_fiu_stream.py`), safety check S3 |
| RX expected-sequence tracking, `RX_SEQ_ERR` counter, `SEQ_STATUS` CSR, `LAST_ERR` capture | **in the datapath** | `tb_top` all tests, `err_csr_perf` |
| Storage of up to `N_FIU` transmitted FIUs, cumulative ACK, NAK → replay from a sequence number, window checks, back-pressure | **component only** | `tb/replay/tb_replay.sv` (cycle-level reference model + data integrity), mutations R1–R5 |
| ACK/NAK return channel, replay timer, TX replay multiplexer, RX Go-Back-N receive policy, credit interaction | **not implemented** | – |

## Component behaviour (`fiu_replay_buffer`)
- **Capture.** Every transmitted FIU word arrives on `in_*` (LINK_W bits,
  `in_sof` on word 0). Complete FIUs get consecutive sequence numbers
  (`next_seq`), matching `fiu_link_layer`.
- **Window.** At most `N_FIU` (default 4) unacknowledged FIUs are kept.
  `in_ready` falls at an FIU boundary when the window is full or a replay is
  pending or active, so the transmitter stalls new FIUs (Go-Back-N).
- **ACK(s)** (cumulative): frees every stored FIU up to and including s. It is
  accepted only if `(s − oldest) < limit`, where limit is `next − oldest`, or
  `rp_seq − oldest` while a replay is pending or active, so an FIU that is being
  replayed is never freed.
- **NAK(s):**
  - accepted only when no replay is pending or active, and only if s lies in
    the window;
  - frees the FIUs before s;
  - replays s … `next_seq − 1` on `rp_*`, starting at an FIU boundary of the
    capture side;
  - while a replay runs, further NAKs are ignored (`ev_nak_ignored`); a real
    link would retry with a replay timer.
- **Same cycle.** If an ACK and a NAK arrive together, the NAK is evaluated
  and the ACK is ignored.
- **Status:**
  - `occupancy`, `oldest_seq`, `next_seq`, `replaying`;
  - `ev_ack_ignored` / `ev_nak_ignored` for stale, out-of-window or blocked requests.

## How it would be integrated (Stage 2)
```
TX: fiu_link_layer ──► [ mux: new FIU | replay ] ──► FEC ──► lanes
          │                     ▲
          └──► fiu_replay_buffer┘  ◄── ACK/NAK from the partner (new return channel)
RX: lanes ──► FEC ──► fiu_link_layer ──(seq OK, CRC OK)──► ACK(seq) every k FIUs
                                    └─(CRC bad / seq gap)─► NAK(expected seq),
                                                           drop until seq == expected
```
Required changes, none of them in this design:
1. **ACK/NAK channel.** Add one, e.g. next to `rx_credit_return`, or in-band
   as a DLLP-like control FIU.
2. **RX policy.** Replace abort/discard with Go-Back-N: on an error, send a NAK
   for the expected sequence number and discard until that sequence number
   arrives again. With replay, the `tuser` abort is only a last resort after N
   failed replays.
3. **TX multiplexer and stall.** Select replay words while `replaying`, and
   stall the packetizer while `in_ready` = 0.
4. **Replay timer.** Retransmit from `oldest_seq` if no ACK arrives within T
   cycles (covers a lost NAK or ACK). Add a retry counter and a
   link-retrain/fatal indication after N retries.
5. **Credit accounting.** Credits are consumed by the original transmission
   only. The receiver must keep space for replayed FIUs, or return credits
   only for FIUs it accepted.
6. **Sequence space.** 8-bit sequence numbers support a window up to 127 FIUs;
   `N_FIU` must stay well below that.

## Verification already done (unit level)
`tb/replay/tb_replay.sv`, 200,000 cycles per seed:
- **Stimulus:**
  - random capture traffic with gaps;
  - random ACK and NAK requests, in window, stale and ahead of the window;
  - random replay back-pressure;
  - random resets.
- **Checks:**
  - an independent cycle-level reference model of the window rules predicts
    `in_ready`, every `rp_*` output, occupancy / oldest / next / replaying and
    both ignored-request flags, every cycle;
  - every replayed word equals the word captured for that sequence number,
    checked independently of the model;
  - a presented replay word stays stable until it is accepted.
- **Required scenarios** (the run fails if any is missing): full window, NAK
  mid-FIU, ACK accepted during replay, ACK and NAK ignored for every reason,
  ACK + NAK in the same cycle, sequence wrap-around.
- **Mutations R1–R5** (`sim/run_mutation_check.py`): each injected bug fails
  the unit test.

## Verification plan once integrated
| # | Check |
|---|---|
| P1 | every packet whose FIUs were corrupted is delivered **intact** (no `tuser`) after replay, within N retries |
| P2 | no duplicate delivery: an FIU replayed after it was already accepted is dropped by sequence number |
| P3 | lost NAK / lost ACK (channel faults on the return path) recovered by the replay timer |
| P4 | throughput under BER: occupancy and latency vs. injected error rate |
| P5 | credits: no leak, no overflow, across replays and resets |
| P6 | formal: RX accepts sequence numbers strictly in order (k-induction on the RX policy) |
