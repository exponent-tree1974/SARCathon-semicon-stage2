# Expected Results (specification, not tool output)

This file states what a **correct** run must show. Numbers marked *derived* are computed by hand from the test definition and do not depend on the seed. All other tests are randomized, so only their pass criteria are fixed. Actual tool output is kept separately: `reports/verification_results_actual.md` and `evidence_v4/` (final table: `evidence_v4/regression_summary.md`).

## Global
- Each test prints `[TEST-RESULT] <name> : PASS`.
- The simulation prints `[SIM-RESULT] PASSED tests=17 passed=17 failed=0 seed=<N>` and exits with code 0.
- The runner prints `golden model: PASS` for every seed and `REGRESSION RESULT: PASS`.
- Coverage: `110/110 bins` for any single full-suite seed with `LANES=4` (lane bins beyond `LANES` are N/A for `LANES<4`). `--cov-strict` must not fail.
- No `[ERROR]`, `[TIMEOUT]` or `[DEADLOCK]` line anywhere in the log.
- `--repro-check`: `REPRODUCIBILITY: PASS` (suite twice, and each test alone, identical).
- `sim/run_mutation_check.py`: `MUTATION CHECK PASS: 41/41 mutations killed` (16 v3 core + 15 v4 core + 5 arbiter + 5 replay).
- `bash sim/formal/run_formal.sh`: `FORMAL RESULT: PASS` (proof of P1–P6, witness found, 3/3 negative controls fail the proof).
- `python sim/run_regression.py --bench arb`: `[SIM-RESULT] PASSED tests=8`; `--bench replay`: `tests=1`.

## Per test
| Test | Pass criteria | Seed-independent values (derived) |
|---|---|---|
| reset_idle | all CSR reset values; outputs idle in reset; defaults restored after idle reset; 10 packets delivered | pkts_in = pkts_out = 10 |
| csr_access | strobes, SLVERR on RO/unmapped, link_en, counter clear | 4 packets |
| sizes_directed | 24 sizes × 2 passes delivered byte-exact | **48 in / 48 out, 36,924 bytes** |
| back_to_back | 174 packets; long-packet phase link occupancy ≥ 99 % | **456 FIUs, ≥ 3,648 cycles for that phase** |
| random_stalls | all 300 delivered | pkts_out = pkts_in = 300 (no corruption) |
| tkeep_malformed | IN_PROTO_ERR = number of illegal-tkeep packets; those packets end with tuser=1; empty packets dropped and counted | 82 packets in, 70 out (12 empty packets dropped) |
| crc_corruption | directed: FIU0 drop, packet-lost + discard, abort 224 B + tuser, …; counters equal model | pkts_out < pkts_in (seed-dependent random part) |
| symbol_errors | corrupted FIUs never delivered; counters equal model | — |
| lane_corruption | every lane: word, trailer, padding, whole-FIU faults detected | — |
| header_forgery | each forged field gives the documented decision | **16 in / 12 out, 3,192 bytes** (v4 adds 3 packets: tid change mid-packet → 224 B + tuser; forged tid on a first FIU → delivered under the forged tid, then 224 B + tuser; 100 B clean); 224 B delivered **without** tuser for the EOP-set forgery (documented limitation: CRC protects against noise, not against a wrong transmitter) |
| order_preservation | 0 order violations over 1200 packets | — |
| link_enable | no FIU and ingress backpressured while link_en=0; all delivered after | **6 in / 6 out, 3,000 bytes** |
| credit_stress | TX stops without credits; buffer never exceeds 32 entries | **10 in / 10 out, 30,000 bytes**; min credits < 7 |
| reset_traffic | 3 reset points; state and CSRs at defaults after each; fresh traffic clean | 75 in / 75 out (3 × 25 post-reset packets) |
| random_regression | everything above, mixed | — |
| wave_showcase | short waveform scenario: 5 packets, faults on F2 (lane 2 word), F3 (1 symbol), F4 (CRC field) | **5 in / 3 out, 388 bytes** (100 + 224 truncated with tuser + 64); P2 and P3 discarded |
| err_csr_perf (v4) | error CSRs, IRQ, SEQ_STATUS, perf counters with hand-derived values | SEQ_STATUS `0x01030404` after 4 FIUs; LAST_ERR `0x80010505` (CRC, FIU 5), `0x80020A0A` (HDR), `0x80030E0E` (SOP), `0x80051212` (TID), `0x80071641` (SEQ); ERR_STATUS `0x01`, then `0x1A`, then `0x08` after W1C of 0x12; irq follows ERR_IRQ_EN; after reset 4 × 1000 B: IN_BYTES = OUT_BYTES = **4000**, TX_WORDS = **160**; **18 in / 17 out, 6,228 bytes** |

## tb_arb (v4, `--bench arb`)
| Test | Pass criteria (in addition to protocol checkers, A1–A3, Q1–Q4, S1–S4) |
|---|---|
| arb_single_source | 40 + 40 packets, each source alone; grants = packets; CSR TX_PKT = RX_PKT = 80, IN_BYTES = OUT_BYTES |
| arb_saturated_equal | 200 + 200 × 256 B: grants 200/200, byte share 50.0 % ± 1 %, ≤ 1 packet started past a waiting source |
| arb_mixed_sizes | 30 × 4096 B vs 300 × 64 B: 64 B source waits ≤ one 4096 B packet (19 FIUs × 8 + 40 = 192 cycles); packet-fair, not byte-fair |
| arb_starvation | 250 × 1500 B saturating vs 50 sparse: sparse source waits ≤ 7 × 8 + 40 = 96 cycles and is passed by ≤ 1 packet |
| arb_random_stalls | 300 + 300 random packets, gaps and egress bursts: all delivered exactly, in order per stream |
| arb_link_errors | faults on ~4 % of FIUs: RX_CRC_ERR > 0; only losses or whole-FIU (k × 224 B) truncation with tuser; ≥ 450 of 600 delivered |
| arb_reset_traffic | reset while both sources are active and the arbiter is locked; then 60 packets clean |
| arb_back_to_back_switch | 400 single-beat packets alternating: ≤ 8.5 cycles per packet (link limit 8: zero-bubble hand-over) |

## tb_replay (v4, `--bench replay`)
`replay_buffer_unit` passes 200,000 cycles per seed with:
- 0 model mismatches;
- 0 data-integrity errors.

These scenario counts must also be reached:
- ≥ 100 FIUs captured, ≥ 20 replayed, ≥ 20 ACKs accepted, ≥ 5 ignored, ≥ 5 NAKs accepted;
- at least one each of: NAK mid-FIU, NAK ignored (busy), NAK ignored (window), full window, ACK accepted during a replay, sequence wrap, ACK + NAK in the same cycle.

## Synthesis / lint (RTL)
- `verilator --lint-only -Wall` on `sim/rtl_files.f` for each top (`axis_pcie_link_top`, `axis_pcie_link_mux2_top`, `fiu_replay_buffer`) and for `LANES` = 1/2/8/32, `TID_W` = 3/8: no warnings (exit code 0).
- `iverilog -g2012 -Wall`: no warnings.
