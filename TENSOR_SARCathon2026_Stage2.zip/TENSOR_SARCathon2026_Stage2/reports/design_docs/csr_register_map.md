# CSR register map (v4, `csr_status`, VERSION = 0x0002_0000)

- **Bus:** AXI4-Lite, 32-bit registers, byte addresses; `addr[1:0]` is ignored.
- **Responses:** OKAY, or SLVERR for unmapped addresses and for writes to
  read-only registers (no side effect).
- **Byte strobes:** WSTRB is honoured on RW and W1C registers.
- **Counters:** saturate at 2³²−1.
- **Reset:** every register returns to its reset value on `rst_n`.

## Control and identification
| Offset | Name | Access | Reset | Fields |
|---|---|---|---|---|
| 0x00 | ID | RO | 0x4158_5031 | "AXP1" |
| 0x04 | VERSION | RO | 0x0002_0000 | 2.0 = v4 register map |
| 0x08 | CTRL | RW | 0x1 | [0] `link_en`<br>[1] `clear`: write 1 to clear all counters, ERR_STATUS and LAST_ERR; self-clearing, reads 0 |
| 0x0C | STATUS | RO | 0x0000_2004 | [0] `rx_in_pkt`<br>[1] `rx_discard`<br>[2] `link_en`<br>[15:8] `tx_credits`<br>[16] `irq` (level of the `irq` output) |
| 0x10 | SCRATCH | RW | 0 | free |
| 0x14 | PARAMS | RO | – | [7:0] LANES<br>[23:8] FIU_BYTES<br>[31:24] LINK_W/8 |
| 0x18 | PARAMS2 | RO | – | [7:0] RX_BUF_DEPTH<br>[11:8] TID_W<br>[15:12] FEC_MODE (0 = no FEC)<br>[16] replay integrated (0) |
| 0x1C | SEQ_STATUS | RO | 0 | [7:0] TX next sequence number<br>[15:8] RX expected sequence number<br>[23:16] sequence number of the last accepted FIU<br>[24] at least one FIU accepted since reset |

## Counters (32-bit, saturating; cleared by reset and CTRL.clear)
| Offset | # | Name | Increments on |
|---|---|---|---|
| 0x20 | 0 | TX_PKT | packet fully segmented into FIUs |
| 0x24 | 1 | TX_FIU | FIU transmitted (trailer sent) |
| 0x28 | 2 | RX_FIU_GOOD | FIU accepted (committed) |
| 0x2C | 3 | RX_CRC_ERR | FIU with CRC mismatch |
| 0x30 | 4 | RX_FRAME_ERR | bad magic/length, sop while open, tid change, continuation without packet (not in discard mode), sof misalignment |
| 0x34 | 5 | RX_SEQ_ERR | FIU with a valid CRC whose sequence number ≠ expected |
| 0x38 | 6 | RX_DISCARD | continuation FIU dropped in discard mode |
| 0x3C | 7 | RX_PKT | packet delivered on m_axis (tlast) |
| 0x40 | 8 | RX_PKT_ERR | delivered packet with tuser=1 (aborted or poisoned) |
| 0x44 | 9 | IN_PROTO_ERR | ingress beat with an unsupported tkeep pattern |
| 0x48 | 10 | IN_EMPTY_DROP | zero-length packet dropped at ingress |
| 0x4C | 11 | IN_BYTES | Σ popcount(tkeep) of accepted s_axis beats |
| 0x50 | 12 | OUT_BYTES | Σ popcount(tkeep) of delivered m_axis beats |
| 0x54 | 13 | IN_STALL | cycles with s_axis_tvalid=1 and s_axis_tready=0 |
| 0x58 | 14 | OUT_STALL | cycles with m_axis_tvalid=1 and m_axis_tready=0 |
| 0x5C | 15 | CREDIT_STALL | cycles an FIU is ready to start, link enabled, credits < 7 |
| 0x60 | 16 | TX_WORDS | link words transmitted (link utilisation = TX_WORDS / CYCLES) |
| 0x64 | 17 | CYCLES | clock cycles since reset or clear |
| 0x68 | 18 | FEC_CORR | FEC corrections (placeholder: always 0) |
| 0x6C | 19 | FEC_UNCORR | FEC uncorrectable (placeholder: always 0) |

Events 11–15 are registered once before they are counted (1-cycle latency),
which keeps the 64-bit popcount off the AXIS handshake paths.

## Error reporting
| Offset | Name | Access | Reset | Fields |
|---|---|---|---|---|
| 0x70 | ERR_STATUS | W1C | 0 | sticky flags, each set by the counter event of the same name:<br>[0] RX_CRC_ERR<br>[1] RX_FRAME_ERR<br>[2] RX_SEQ_ERR<br>[3] RX_DISCARD<br>[4] RX_PKT_ERR<br>[5] IN_PROTO_ERR<br>[6] IN_EMPTY_DROP<br>[7] FEC_UNCORR<br>Write 1 to clear a bit; an event in the same cycle wins over the clear. |
| 0x74 | ERR_IRQ_EN | RW | 0 | [7:0] interrupt enable per ERR_STATUS bit |
| 0x78 | LAST_ERR | RO | 0 | most recent RX error:<br>[7:0] expected sequence number<br>[15:8] received sequence field<br>[18:16] reason<br>[31] valid |

`irq = |(ERR_STATUS & ERR_IRQ_EN)`, registered (one cycle after the flag).

**LAST_ERR reason codes:**
| Code | Name | Meaning |
|---|---|---|
| 1 | CRC | CRC mismatch. The received sequence field may itself be corrupted. |
| 2 | HDR | bad magic or illegal length (valid CRC) |
| 3 | SOP_IN_PKT | start-of-packet FIU while a packet is open |
| 4 | CONT | continuation FIU with no open packet, outside discard mode |
| 5 | TID | continuation FIU whose stream ID differs from the open packet |
| 6 | ALIGN | sof strobe not on word 0 |
| 7 | SEQ | sequence error only (the FIU was otherwise accepted, or dropped in discard mode) |

A trailer decision error takes priority over a sequence error on the same FIU.

## Worked examples (from `tb_top` test `err_csr_perf`, checked in simulation)
| Situation | Register read | Value |
|---|---|---|
| after 4 clean FIUs | SEQ_STATUS | 0x0103_0404 (any, last 3, expected 4, next 4) |
| CRC error on FIU 5 | LAST_ERR / ERR_STATUS | 0x8001_0505 / 0x01; `irq`=1 with ERR_IRQ_EN=0x01 |
| bad magic on FIU 10 (mid-packet) | LAST_ERR / ERR_STATUS | 0x8002_0A0A / 0x1A (FRAME, DISCARD, RX_PKT_ERR) |
| sop set on FIU 14 | LAST_ERR | 0x8003_0E0E |
| tid changed on FIU 18 | LAST_ERR | 0x8005_1212 |
| sequence forged on FIU 21, so FIU 22 mismatches too | LAST_ERR | 0x8007_1641 |
| 4 × 1000 B, no stalls (after reset) | IN_BYTES / OUT_BYTES / TX_WORDS | 4000 / 4000 / 160 |

## Software sequence (polling or interrupt)
1. Write ERR_IRQ_EN with the classes of interest (e.g. 0x07 = CRC, FRAME, SEQ).
2. On `irq` (or STATUS[16]):
   - read ERR_STATUS and LAST_ERR;
   - write the read ERR_STATUS value back to ERR_STATUS (W1C) to acknowledge.
3. Read the counters for rates. Use CTRL.clear to start a new measurement window:
   - link utilisation = TX_WORDS / CYCLES;
   - goodput = OUT_BYTES / CYCLES × f_clk.
