# Simulation Runbook – executing the real RTL simulation (Steps 1–7)

Run all commands from the **project root** (the folder that contains `rtl/`, `tb/`, `sim/`). Windows commands are for PowerShell; Linux and WSL commands are for bash. `python` means `py` on Windows and `python3` on Linux/WSL.

The author's actual v4 outputs are in `evidence_v4/` (index: `evidence_v4/README.md`). The v3 outputs referenced as `evidence/…` below are in the `stage1_v3` folder. Your own run is the authoritative one.

---

## Step 1 – Install or verify the tools

| | Windows | Linux (Ubuntu 24.04) / WSL |
|---|---|---|
| Icarus Verilog 12 | installer from <https://bleyer.org/icarus/>, tick *Add to PATH* | `sudo apt install -y iverilog` |
| Python 3.8+ | <https://www.python.org/downloads/>, tick *Add to PATH* | `sudo apt install -y python3 python3-matplotlib` |
| matplotlib (screenshots only) | `py -m pip install matplotlib` | included above |
| GTKWave (optional viewer) | same Icarus installer | `sudo apt install -y gtkwave` |
| Verilator ≥ 5.0 (optional) | use WSL | `sudo apt install -y verilator` (author tested 5.052) |

Check:
```
iverilog -V          # expect: Icarus Verilog version 12.0 (stable) ...
python --version     # (py --version on Windows)
verilator --version  # optional
```

## Step 2 – Compile all RTL and testbench files

```bash
# RTL only (lint-style compile, expect NO output)
iverilog -g2012 -Wall -s axis_pcie_link_top -o sim/rtl_only.vvp -f sim/rtl_files.f
# RTL + testbench (expect NO output)
iverilog -g2012 -Wall -I tb/env -s tb_top -o sim/simv.vvp -f sim/rtl_files.f -f sim/tb_files.f
# optional Verilator (Linux/WSL): strict lint of the RTL, expect exit code 0
verilator --lint-only -Wall --top-module axis_pcie_link_top -f sim/rtl_files.f
```
Author's result: both Icarus compiles produced zero lines of output (`evidence/logs/step2*.log`).

## Step 3 – If something fails: diagnosis table

The first four rows were actually observed in this project; the others are anticipated environment problems.

| Symptom | Root cause | Fix |
|---|---|---|
| `Could not find variable 'abort_drv' ... declaration after use` | Icarus needs declaration before use inside tasks | declare the variable earlier in the module (already fixed in `tb_top.sv`) |
| `R5 tready not low during reset` at time 5 ns | `rst_n` started at 0, so async-reset flops saw no falling edge | TB drives `rst_n` 1→0 at 1 ns (already fixed) |
| Same seed gives different cycle counts alone vs in suite | parallel process consuming the global `$urandom` | sink BFM uses its own seeded `$random(rng)` (already fixed) |
| Verilator stops at first SVA failure, no summary | default `$error` action terminates | SVA action blocks call the checker's `err()` (already fixed) |
| `iverilog: command not found` / `'iverilog' is not recognized` | not on PATH | reopen the terminal after install, or add `C:\iverilog\bin` to PATH |
| `syntax error` in `tb/env/*.sv` with Icarus 10/11 | SystemVerilog support too old | use Icarus ≥ 12 |
| `Include file cov_bins.svh not found` | missing include path | add `-I tb/env` |
| `Unknown module type: illegal_parameter_combination` | an illegal parameter set (deliberate elaboration guard) | use a legal combination (see spec Part B.2) |
| Verilator `%Error: ... requires --timing` | Verilator 4.x | use Verilator ≥ 5.0 |
| WSL: `/usr/bin/env: 'bash\r': No such file` | file got CRLF line endings | `sed -i 's/\r$//' sim/*.sh` |
| Very slow or locked files under OneDrive | sync client | copy the project to a local, non-synced folder |
| Verilator `--trace-fst`: `fatal error: lz4.h: No such file or directory` (**observed**) | Verilator's FST writer needs the LZ4 headers/library | `sudo apt install liblz4-dev`, or use VCD (`--vcd-test` without `--fst`) |
| `vvp: Unable to open input file -fst` | wrong argument order | `-fst` goes after the `.vvp` file: `vvp -n sim/simv.vvp -fst +plusargs` |

Any failure in the testbench itself prints `[ERROR] <time> <component>: ...` and ends with `[SIM-RESULT] FAILED` (exit code 1). Rerun a single test with the seed printed in its `[TEST-START]` line: `python sim/run_regression.py --test <name> --seeds <base seed> --vcd-test <name>`.

## Step 4 – Directed tests and randomized regression

```bash
# directed: every test as its own simulation, one simulation.log each
python sim/run_regression.py --each-test --seeds 1 --out evidence/step4a_directed
# randomized regression: full suite, 8 seeds, coverage closure, determinism check
python sim/run_regression.py --seeds 1 2 3 4 5 6 7 8 --cov-strict --repro-check --out evidence/step4b_random
# optional, Linux/WSL: Verilator with concurrent SVA
python3 sim/run_regression.py --sim verilator --seeds 1 2 --cov-strict --out evidence/step4b_random_verilator
```
Each run writes `regression_summary.md` (test, seed, result, evidence file) and `regression_summary.txt`. Each simulation writes its own `simulation.log`.

## Step 5 – Waveforms (VCD and FST)

```bash
python sim/run_regression.py --test wave_showcase --seeds 1 --vcd-test wave_showcase --out evidence/step5_waves_vcd
python sim/run_regression.py --test wave_showcase --seeds 1 --vcd-test wave_showcase --fst --out evidence/step5_waves_fst
# any other test, e.g. the full CRC test (≈ 50 MB VCD):
python sim/run_regression.py --test crc_corruption --seeds 1 --vcd-test crc_corruption
```
Raw equivalent: `vvp -n sim/simv.vvp +test=wave_showcase +seed=1 +vcd_test=wave_showcase +vcd_file=waves.vcd` (add `-fst` after `sim/simv.vvp` for FST). `+vcd_scope=all` dumps the whole testbench, which gives much larger files.

## Step 6 – simulation.log, regression_summary.md, screenshots

- `simulation.log`: written for every simulation by the runner. A clean run ends with `[SIM-RESULT] PASSED tests=N passed=N failed=0`.
- `regression_summary.md`: written for every runner invocation.
- Screenshots, rendered from the VCD:
  ```bash
  python sim/verify_waves.py evidence/step5_waves_vcd/seed_1/wave_showcase/waves.vcd --md evidence/step7_waveform_verification.md --json evidence/step7_markers.json
  python sim/render_waves.py evidence/step5_waves_vcd/seed_1/wave_showcase/waves.vcd evidence/step7_markers.json evidence/screenshots
  ```
- Real GTKWave screenshots: `gtkwave evidence/step5_waves_vcd/seed_1/wave_showcase/waves.vcd evidence/screenshots/05_crc_check_and_discard.gtkw`, then *File → Grab To File* (or any screen capture).

## Step 7 – Verify the key waveforms

`sim/verify_waves.py` checks eight mechanisms directly from the VCD. Each check prints PASS or FAIL, and the Markdown report lists times and values:

| Check | What is proven from the waveform | Screenshot |
|---|---|---|
| W1 AXI ingress | packets reconstructed from `s_axis` handshakes | 01 |
| W2 FIU formation | link-layer FIUs re-assembled == ingress packets; trailer fields, zero padding, sequence numbers | 01 |
| W3 CRC generation | trailer CRC == `zlib.crc32(FIU[0:252] + 4 zero bytes)` for every FIU | 02 |
| W4 Lane mapping | `tx_sym(n+1) == Gray(stripe(t_data(n)))` for every word | 03 |
| W5 Error injection | exact symbols changed between `tx_sym` and `rx_sym` | 04a, 04b |
| W6 RX CRC check | CRC recomputed on received words == DUT `crc_ok` | 05 |
| W7 Discard / abort | spec decision table == DUT `dec`, commit, rollback, abort | 05 |
| W8 AXI egress | expected egress (from W6/W7) == observed bytes, `tlast`, `tuser` | 06, 06b |

**Proof that the checker is not vacuous:** with a deliberately broken RTL it must fail.
- An RTL that ignores the CRC result fails W6, W7 and W8.
- A wrong Gray bit order fails W4.

Author's results: `evidence/step7_negative_crc.md` and `evidence/step7_negative_gray.md`.

---

## v4 additions (same steps, more benches)

Evidence for v4 is in `evidence_v4/`. The `evidence/…` paths in the steps above refer to
the v3 run (folder `stage1_v3`) and are kept for traceability.

| Step | v4 command | Expected |
|---|---|---|
| 2 | `iverilog -g2012 -Wall -I tb/env -s tb_arb -o arb.vvp $(cat sim/rtl_files.f) $(grep -v incdir sim/tb_arb_files.f)` (same for `tb_replay`) | no output |
| 2 | `verilator --lint-only -Wall --top-module axis_pcie_link_mux2_top $(cat sim/rtl_files.f)` (also `axis_pcie_link_top`, `fiu_replay_buffer`) | exit 0 |
| 4 | `python3 sim/run_regression.py --seeds 1 2 3 4 5 6 7 8 --cov-strict --repro-check` | 17 tests × 8 seeds PASS, 110/110 bins, REPRODUCIBILITY PASS |
| 4 | `python3 sim/run_regression.py --bench arb --seeds 1 2 3 4 --repro-check` | 8 tests × 4 seeds PASS |
| 4 | `python3 sim/run_regression.py --bench replay --seeds 1 2 3 4` | PASS |
| 4 | `for L in 1 2 8 16 32; do python3 sim/run_regression.py --lanes $L --cov-strict; done` | PASS for every lane count |
| 4 | `bash sim/formal/run_formal.sh` | `FORMAL RESULT: PASS` |
| 4 | `python3 sim/run_mutation_check.py` | `41/41 mutations killed` |
| 5–7 | `python3 sim/run_regression.py --bench arb --test arb_saturated_equal --vcd --out sim/out/aw` then `python3 sim/verify_arb_waves.py sim/out/aw/seed_1/arb_saturated_equal/waves.vcd sim/out/aw/views` | V1–V4 PASS, PNG + `.gtkw` written |
| 6 | `python3 sim/make_evidence_index.py evidence_v4` | final table `evidence_v4/regression_summary.md` |

**v4 failures seen during this work** (diagnosis → patch → rerun): see the failure table in
`evidence_v4/README.md` (F1–F12). The new diagnosis rules from them:

| Symptom | Likely cause | Fix |
|---|---|---|
| `link_channel_model: plan ... uses lane N, but LANES=M (test bug)` | a test plans a lane fault on a lane that does not exist for this `--lanes` | pick the lane with `% LANES` |
| `[ERROR] link_safety: S1a ... never entered the link` with no scoreboard error | checker sees an aborted packet leave before its own tlast entered (only in a modified checker) | record ingress packets at their first data beat (as delivered) |
| Yosys `sat` finds a base-case model that violates an `assume` | clocked `assume`/`$past` after `async2sync` | keep all formal checks combinational with explicit "previous-cycle" registers (as in `sim/formal/axis_rr_arbiter_props.sv`) |
| `MUTATION CHECK FAIL ... SURVIVED` | a checker never sees the scenario that exposes the bug | add the scenario to a test (example: M29 → `credit_stress` link-disable window) |
