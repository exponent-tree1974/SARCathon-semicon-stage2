# SARCathon 2026 – Stage 1 RTL Review and Redesign Specification
**Design:** AXI4-Stream ⇄ FIU link layer ⇄ 4-lane PAM4/Gray symbol interface ("PCIe 6.0-inspired", **not PCIe-compliant**)
**Top module:** `axis_pcie_link_top` · **Language:** SystemVerilog (IEEE 1800-2012 subset, Icarus/Yosys compatible)

---

## Part A – Line-by-line review of the original `rtl/axis_to_pcie_link.sv`

Method: every line was read. The original testbench was then run on Icarus Verilog 14 (it passes), and directed probe testbenches were run against the original RTL. Items marked **[SIM]** were reproduced in simulation. The others come from inspection.

### A.1 Compilation
| Line | Finding | Severity |
|---|---|---|
| — | Compiles cleanly with `iverilog -g2012 -Wall`; the original TB prints PASS. | info |
| 72 | `word_index` declared and never used (dead code). | low |
| 114–115 | Stale comment ("The preceding compact declaration cannot represent…") left in code; reads as unfinished. | low |
| all | No `` `default_nettype none `` – a typo in a port name would create an implicit wire silently. | medium |

### A.2 Multiple drivers
No multiply-driven nets were found. Every register is assigned in exactly one `always` block. ✔

### A.3 Width errors
| Line | Finding | Severity |
|---|---|---|
| 245 | `m_last = (out_beat == output_beats - 1'b1)`: when `output_beats == 0` (zero-byte packet) the 3-bit subtraction wraps to 7, so 8 beats are emitted **[SIM]**. | **high** |
| 262 | `(f_bytes + 9'd63) >> 6` – fits for ≤256 B (max 319 < 512), but only because packets are clipped at 256 B. | low |
| 131/138 | 9-bit byte counters – correct only for ≤ 256 B. | low |

### A.4 Reset
| Line | Finding | Severity |
|---|---|---|
| 121–124, 246–250 | Async reset applied to 4 × 2048-bit data registers (~8.2 k flops). Unnecessary, and costly in area and reset-tree fan-out. | medium |
| top | No reset synchronizer: an asynchronous de-assert can release different flops in different cycles. | medium |
| tb | Reset tested only at power-up; never during traffic. | medium |

### A.5 Handshakes / flow control
| Line | Finding | Severity |
|---|---|---|
| 109, 141 | `s_ready` is low for all 8 SEND cycles, so ingress and transmission never overlap. | high |
| 241 | `f_ready` is low for the whole OUTPUT phase. Measured result: 20 × 256 B take 233 cycles against a 160-cycle link limit, i.e. **69 % link utilization [SIM]**. | high |
| 196 | `assign f_ready = r_ready` through the "PHY": receiver backpressure travels combinationally through the lane layer. A real SerDes link cannot be backpressured; this needs credits. | high (architecture) |

### A.6 Unsafe variable part-selects
| Line | Expression | Finding |
|---|---|---|
| 105 | `captured_assembly[beat_index*512 +: 512]` | safe (2-bit index, 4 slots) |
| 117 | `payload[out_word_index*256 +: 256]` | safe (3-bit index, 8 slots) |
| 239 | `completed_assembly[word_index*256 +: 256]` | safe |
| **243** | `output_payload[out_beat*512 +: 512]` | **UNSAFE**: `out_beat` is 3 bits (0–7) but only 4 slots exist. Indices 4–7 read past bit 2047 and return X **[SIM: 4 all-X beats for a zero-byte packet]**. |

### A.7 Invalid AXI4-Stream behaviour
| Finding | Evidence |
|---|---|
| Null beat (`tkeep=0`, `tlast=0`) still occupies a 64-byte slot, so the null beat's garbage is delivered instead of the real data. | **[SIM]** one null beat followed by a beat of 0x11 bytes: egress byte0 = 0xEE (the null beat's data) |
| Non-contiguous `tkeep` is counted with popcount but treated as LSB-packed, so wrong bytes and wrong `tkeep` reach the egress. | **[SIM]** `tkeep=0xF0F0` comes out as `0x00FF` |
| Zero-byte packet (`tkeep=0`, `tlast=1`) produces 8 egress beats, 4 of them X. | **[SIM]** |
| Partial middle beat (non-last beat with `tkeep` ≠ all-ones) misaligns all following bytes. | inspection |
| No error indication on AXIS (no `tuser`); a bad packet silently disappears. | inspection |

### A.8 Packet-boundary bugs
| Line | Finding | Evidence |
|---|---|---|
| 128 | `if (s_last \|\| beat_index == 3)`: a packet longer than 256 B is split, and an **extra `tlast` is inserted** mid-packet. Every real Ethernet frame up to 1518 B and every ML tensor is broken. | **[SIM]** 384 B in → 2 packets out |
| 255 | `if (f_sop) word_index <= 0` does not realign the current word (`completed_assembly` uses the old index), so SOP resync is ineffective. | inspection |
| 112, 197 | Byte count is carried as unprotected sideband; it is never framed, CRC-checked or sent over the lanes. | inspection |

### A.9 CRC mismatch risks
| Finding |
|---|
| CRC and length travel **outside** the lanes and outside the CRC. Error injection can never hit them, and a corrupted length would truncate data silently. |
| Fault injection (line 191) flips bit 0 of lane 0 in **every** word of the packet, a trivially detectable pattern that barely exercises the CRC. |
| The CRC function is duplicated in two modules (lines 88 and 214), so the copies can diverge. |
| The CRC bit order (data bit *i* = byte *i*/8, LSB first) happens to match zlib, but no test proves the RTL CRC equals an independent reference. The "reference log" came from Python, not from the RTL. |

### A.10 Synthesizability and timing
| Line | Finding |
|---|---|
| 88–100, 214–225 | 2048-iteration CRC loop with a data-dependent `if`, evaluated in **one cycle**, instantiated twice. |
| 102–106 → 130 | TX CRC is computed from `s_axis_tdata` (an input port) combinationally into a register: the I/O-to-register path runs through the full 2048-bit CRC. |
| RX path | Payload register → 8:1 256-bit mux → Gray encode → error XOR → Gray decode → 2048-bit assembly mux → 2048-bit CRC → 32-bit compare → state register, all in one cycle. |
| area | About 8.3 k flops (four 2048-bit buffers) for a design that needs only one FIU of buffering per direction. |
| 21 | `inject_error` (a verification hook) is a port of the synthesizable top. |

### A.11 Unsupported or overstated claims (README and report)
| Claim | Reality |
|---|---|
| "Gray coding … binary-to-Gray" | The function maps bits to a PAM4 *level* (a Gray-to-binary relabelling). The mapping is correct, but the name is backwards. |
| "Flow Information Units" | A PCIe 6.0 flit is 256 B **including** 236 B TLP + 6 B DLP + 8 B CRC + 6 B FEC. The original FIU is 256 B of payload plus sideband metadata, so it is not a flit. |
| Diagram block "Error Correction (FEC & CRC)" | There is no FEC. CRC detects errors only; nothing corrects or replays. |
| "Four lane striping" | Contiguous 64-bit chunks per lane, not byte striping. No deskew, scrambling or precoding. |
| "Backpressure propagation from host output to ingress" | Achieved through a combinational ready across the "PHY", which is not physically meaningful. |
| Report: CRC error case "expects … zero output" | The original TB never checks this. |
| `reference_functional_trace.vcd` / `.log` | Produced by a Python model, not by the RTL. **Remove from the submission.** |

---

## Part B – Redesigned architecture

> **v4 update (this revision).** v4 adds the following to the architecture below:
> - a stream ID (`tid`) carried in the FIU trailer and delivered on `m_axis_tid`;
> - a packet-atomic 2-input round-robin arbiter (`axis_rr_arbiter`, wrapped by
>   `axis_pcie_link_mux2_top`);
> - error reporting: sticky `ERR_STATUS`, `ERR_IRQ_EN` + `irq`, `LAST_ERR` and `SEQ_STATUS`;
> - nine performance counters;
> - bypass FEC placeholders (`fec_encoder_stub` / `fec_decoder_stub`) in the lane path;
> - a standalone, unit-verified Go-Back-N replay-buffer component
>   (`fiu_replay_buffer`, not connected to the datapath).
>
> What was chosen and why, the results, and the remaining limits are in
> **`docs/stage1_v4_enhancements.md`**.

```
            ┌──────────────────────── axis_pcie_link_top ─────────────────────────┐
 s_axis ───►│ axis_packet_ingress ─► axis_packetizer ─► fiu_link_layer (TX) ─► lane_striper_gray_mapper │──► tx_sym[255:0]
 (512b)     │   skid + tkeep rules     512→256, segment     trailer, CRC-32, seq,      byte stripe ×4 lanes  │    tx_sym_valid/sof
            │                          into FIU payload     credits                    + PAM4 Gray map       │
            │                                                                                             │◄── tx_credit_return
 m_axis ◄───│ axis_depacketizer ◄─ fiu_rx_buffer ◄─ fiu_link_layer (RX) ◄─ lane_de_striper_gray_decoder   │◄── rx_sym[255:0]
 (512b)     │   256→512, lookahead   commit/rollback   CRC check, policy        Gray demap + destripe        │    rx_sym_valid/sof
 +tuser     │                                                                                             │──► rx_credit_return
 s_axil ───►│ csr_status (AXI4-Lite): ID, CTRL, STATUS, PARAMS(2), SEQ_STATUS, 20 cnt, ERR/IRQ│
            └─────────────────────────────────────────────────────────────────────────────────────────────┘
  v4: s0_axis, s1_axis ─► axis_rr_arbiter (packet-atomic RR, m_tid = source) ─► s_axis + s_axis_tid of the core
      (axis_pcie_link_mux2_top); FEC bypass stubs sit between fiu_link_layer and the lane mapper / demapper.
```
Helper modules: `axis_skid_buffer`, `reset_sync`, `crc32_engine` (instantiated in TX and RX), `fiu_rx_buffer`.

### B.1 FIU format (default `FIU_BYTES=256`, `LINK_W=256`, so 8 words of 32 B)
| Word | Content |
|---|---|
| 0 … PW-1 (0…6) | payload, 224 B max; unused bytes are **zero** |
| PW (7) = trailer | `[15:0]` len (1…224) · `[16]` sop · `[17]` eop · `[18]` err (poison) · `[23:19]` rsvd · `[31:24]` seq · `[39:32]` magic `0x5A` · **`[47:40]` tid (v4: stream ID, `TID_W` LSBs, rest 0)** · `[223:48]` reserved for future FEC/link control (22 B) · `[255:224]` CRC-32 |

v4 RX rule: a continuation FIU whose `tid` differs from the open packet's `tid` is a framing error (decision `TID`, code 5). The open packet is aborted (`tuser=1`) and RX discards until the next sop FIU. A forged `tid` on a *first* FIU with a valid CRC cannot be detected. Like the other valid-CRC forgeries, it is documented and tested in `header_forgery`.

CRC-32 uses the zlib/IEEE polynomial (reflected 0xEDB88320), init 0xFFFFFFFF, final XOR 0xFFFFFFFF. It covers all 256 bytes with the CRC field treated as zero, so **CRC = `zlib.crc32(fiu[0:252] + b'\0'*4)`**, independently verified by `tb/model/check_fiu_stream.py`.

Framing rules: a new packet always starts a new FIU (sop=1). A non-eop FIU must be full (len = 224). Payload efficiency is 224/256 = **87.5 %** for long packets. For comparison, PCIe 6.0 flits reach 236/256 = 92.2 %, but those figures are not comparable (PCIe includes FEC and DLP).

### B.2 Global parameters
| Parameter | Default | Constraint (checked at elaboration) |
|---|---|---|
| `AXIS_W` | 512 | multiple of `LINK_W` |
| `LINK_W` | 256 | ≥ 128, `LINK_W/8` a power of two |
| `FIU_BYTES` | 256 | multiple of `LINK_W/8`; `FIU_BYTES/(LINK_W/8)` a power of two, ≥ 2 |
| `LANES` | 4 | divides `LINK_W/8` |
| `RX_BUF_DEPTH` | 32 | power of two, ≤ 128, ≥ payload words per FIU |
| `AXIL_ADDR_W` | 8 | ≥ 8 (v4 map ends at 0x78) |
| `TID_W` (v4) | 1 (top) / 4 (tb_top) | 1 … 8 |
| `FEC_MODE` (v4) | 0 | 0 only (bypass placeholder; any other value stops elaboration) |

Illegal combinations fail elaboration by instantiating a non-existent module (`illegal_parameter_combination`).

### B.3 Module and interface specification

**`axis_pcie_link_top`** – single clock `clk`, `rst_n` asynchronous active-low (synchronized internally by `reset_sync`).

| Port group | Signals | Direction | Notes |
|---|---|---|---|
| AXIS slave | `s_axis_tdata[511:0] tkeep[63:0] tlast tid[TID_W-1:0] tvalid / tready` | in / out | `tready` is a flop output; `tid` (v4) sampled on the first beat of a packet |
| AXIS master | `m_axis_tdata tkeep tlast tuser tid tvalid / tready` | out / in | `tuser=1` on the tlast beat = packet aborted or carried an ingress protocol error; `tid` (v4) constant per packet |
| Interrupt (v4) | `irq` | out | `|(ERR_STATUS & ERR_IRQ_EN)`, registered level |
| PHY TX | `tx_sym[255:0] tx_sym_valid tx_sym_sof` | out | lane *l*, symbol *k*: `tx_sym[l*64 + 2k +: 2]` = PAM4 level 0…3; 32 symbols/lane/clock |
| PHY RX | `rx_sym[255:0] rx_sym_valid rx_sym_sof` | in | lanes assumed aligned |
| Credits | `rx_credit_return[7:0]` out, `tx_credit_return[7:0]` in | | units = receive-buffer words |
| CSR | AXI4-Lite `s_axil_*` (AW/W/B/AR/R, no PROT) | | see `csr_status` |

**`axis_packet_ingress`** (`DATA_W`, `KEEP_W`)
- In: AXIS slave. Out: `o_data, o_nbytes (1…64), o_last, o_err, o_valid / o_ready`. Events: `ev_proto_err`, `ev_empty_drop`.
- Structure: a skid buffer, then `tkeep` classification, then a one-beat **hold register** with lookahead.
- Rules:
  - A null beat is dropped.
  - A zero-length `tlast` beat sets `last` on the held beat. If no packet is open, it is counted as an empty packet and dropped.
  - Sparse `tkeep`, or a partial beat that turns out not to be last, is a **protocol error**: the beat is forwarded whole (64 B), `err` is set, and `tuser=1` appears at egress. Bytes are never compacted.

**`axis_rr_arbiter`** (v4; `N`, `DATA_W`, `KEEP_W`, `ID_W`) and **`axis_pcie_link_mux2_top`** (v4)
- N AXIS slaves → 1 AXIS master + `m_tid`. Combinational mux; state = lock, grant, last.
- The selection is frozen from the first presented beat until its tlast is accepted. This gives packet atomicity and AXIS stability while stalled.
- Round robin per packet, zero-bubble hand-over; `ev_pkt_start[i]` pulses per granted packet.
- Proved with Yosys k-induction: no output without input, beat conservation, stability, atomicity, round-robin hand-over, work conservation (`sim/formal/`).
- `axis_pcie_link_mux2_top` = arbiter (sources 0/1) + `axis_pcie_link_top` with `TID_W=1`.

**`axis_packetizer`** (`AXIS_W`, `LINK_W`, `FIU_BYTES`)
- In: normalized beats. Out: `p_data[255:0], p_nbytes, p_valid / p_ready, p_first, p_end`, plus `p_sop, p_eop, p_err, p_len[15:0]` (valid on `p_end`). Event: `ev_tx_pkt`.
- Splits each 512-bit beat into ≤ 2 link words and emits 7 payload words per FIU. After a packet ends, the rest of the FIU is zero-padded. Bytes beyond `nbytes` are zeroed.

**`crc32_engine`** (`DATA_W`) – combinational `crc_out = update(crc_in, data)` in AND/XOR form. TX and RX each instantiate one, shared between payload and trailer words.

**`fiu_link_layer`** (`LINK_W`, `FIU_BYTES`, `RX_BUF_DEPTH`)
- **TX:**
  - Starts an FIU only when `link_en=1` and credits ≥ 7.
  - Registers each payload word to `t_data`, accumulating the CRC.
  - Inserts the trailer in the cycle after `p_end` (CRC complemented into `[255:224]`).
  - Increments `seq`.
  - Credits update as `credits ← credits + tx_credit_return − 7·(FIU start)`.
- **RX:**
  - Tracks the word index and checks `r_sof` alignment.
  - Payload words go to `fiu_rx_buffer` speculatively.
  - On the trailer it checks CRC, magic, length rules and the sop/in-packet state, then commits or rolls back (decision table below).
  - Events: `ev_tx_fiu, ev_rx_fiu_good, ev_rx_crc_err, ev_rx_frame_err, ev_rx_seq_err, ev_rx_discard`.

| Trailer check | Action | rx_in_pkt / discard | Counter |
|---|---|---|---|
| CRC bad | rollback; **abort** open packet | 0 / 1 | RX_CRC_ERR |
| CRC ok, magic/len bad | rollback; abort | 0 / 1 | RX_FRAME_ERR |
| sop=1 while a packet is open | rollback; abort | 0 / 1 | RX_FRAME_ERR |
| sop=0, packet open, `tid` ≠ packet's `tid` (v4) | rollback; abort | 0 / 1 | RX_FRAME_ERR |
| sop=0 with no open packet | rollback | 0 / 1 | RX_DISCARD (if already discarding) else RX_FRAME_ERR |
| otherwise | **commit** `ceil(len/32)` words; patch last word {nb, eop, err} | !eop / 0 | RX_FIU_GOOD |
| seq ≠ expected (CRC ok) | — | — | RX_SEQ_ERR |

**`fiu_rx_buffer`** (`W`, `DEPTH`, `R`, `NB_W`, `FULL_NB`)
- Three pointers, rd ≤ cm ≤ wr. Supports speculative write, commit (with last-entry patch), rollback, and abort (patches the newest committed entry to last=1/err=1).
- Peek port exposes R entries. `freed` = pops + rolled-back entries, returned as credits.

**`lane_striper_gray_mapper` / `lane_de_striper_gray_decoder`** (`LINK_W`, `LANES`)
- Byte *b* of a word goes to lane *b* mod 4, lane byte ⌊*b*/4⌋.
- Symbol *s* of a lane byte *x* = bits {x[2s+1], x[2s]}. Gray mapping: 00→0, 01→1, 11→2, 10→3, i.e. `level = {msb, msb^lsb}`, its own inverse.
- One register stage each.

**`axis_depacketizer`** (`AXIS_W`, `LINK_W`, `PTR_W`)
- Takes the first `last` entry within the next 2 entries. Otherwise it takes 2 words **only if ≥ 3 are committed** (lookahead). This rule is what makes an abort-patch of the newest entry always possible.
- Registered AXIS master: `tkeep` contiguous, bytes outside `tkeep` zeroed, sticky packet error reported as `tuser` on the tlast beat. Events: `ev_rx_pkt`, `ev_rx_pkt_err`.

**`csr_status`** (AXI4-Lite)
- AW and W are accepted independently, in any order. One outstanding write and one outstanding read; B and R are registered.

| Offset | Name | Access | Content |
|---|---|---|---|
| 0x00 | ID | RO | `0x41585031` "AXP1" |
| 0x04 | VERSION | RO | `0x00020000` (v4) |
| 0x08 | CTRL | RW | [0] link_en (reset 1), [1] clear (write-1, self-clearing): counters, ERR_STATUS, LAST_ERR |
| 0x0C | STATUS | RO | [0] rx_in_pkt [1] rx_discard [2] link_en [15:8] tx_credits [16] irq (v4) |
| 0x10 | SCRATCH | RW | honours WSTRB |
| 0x14 | PARAMS | RO | [7:0] LANES, [23:8] FIU_BYTES, [31:24] LINK_W/8 |
| 0x18 | PARAMS2 (v4) | RO | [7:0] RX_BUF_DEPTH [11:8] TID_W [15:12] FEC_MODE (0) [16] replay integrated (0) |
| 0x1C | SEQ_STATUS (v4) | RO | [7:0] TX next seq [15:8] RX expected seq [23:16] RX last accepted seq [24] RX accepted any |
| 0x20–0x48 | counters 0–10 | RO | TX_PKT, TX_FIU, RX_FIU_GOOD, RX_CRC_ERR, RX_FRAME_ERR, RX_SEQ_ERR, RX_DISCARD, RX_PKT, RX_PKT_ERR, IN_PROTO_ERR, IN_EMPTY_DROP – 32-bit, saturating |
| 0x4C–0x6C | counters 11–19 (v4) | RO | IN_BYTES, OUT_BYTES, IN_STALL, OUT_STALL, CREDIT_STALL, TX_WORDS, CYCLES, FEC_CORR (0), FEC_UNCORR (0) |
| 0x70 | ERR_STATUS (v4) | W1C | sticky: [0] CRC [1] FRAME [2] SEQ [3] DISCARD [4] RX_PKT_ERR [5] IN_PROTO [6] IN_EMPTY [7] FEC_UNCORR |
| 0x74 | ERR_IRQ_EN (v4) | RW | [7:0] enable per ERR_STATUS bit; `irq = |(ERR_STATUS & ERR_IRQ_EN)` (registered) |
| 0x78 | LAST_ERR (v4) | RO | [7:0] expected seq [15:8] received seq [18:16] reason (1 CRC, 2 HDR, 3 SOP_IN_PKT, 4 CONT, 5 TID, 6 ALIGN, 7 SEQ) [31] valid |

Full v4 register reference with examples: `docs/csr_register_map.md`.

Responses: SLVERR for unmapped addresses and for writes to RO registers (no side effect).

---

## Part C – Transaction-level timing

Measured in simulation: 64 B packet, idle link, 1-cycle channel, `m_axis_tready=1`.

| Cycle | Event |
|---|---|
| 0 | `s_axis` handshake (captured by the skid buffer) |
| +2 | hold stage releases the beat (`last=1`); packetizer emits payload word 0 |
| +3 | packetizer emits word 1 (beat consumed); fiu_link_layer registers word 0 |
| +4 | `tx_sym_valid & tx_sym_sof` (mapper register) – FIU word 0 on the lanes |
| +4…+11 | 8 symbol words: 2 data, 5 zero-pad, 1 trailer (one FIU = 8 clocks) |
| +12 | (channel) |
| +13 | RX trailer checked → **commit** |
| +15 | first `m_axis` beat (`tlast=1`) |

- **Latency:** 15 cycles from ingress handshake to egress for a one-FIU packet. The design is store-and-forward per FIU on RX, because nothing is released before its CRC is checked.
- **Streaming:** within a packet a non-last 512-bit beat is released only when the next beat arrives (1-beat lookahead). The ingress supplies 2 link words per accepted beat while the link drains 1 per clock, so `s_axis_tready` settles at about a 50 % duty cycle under saturation; the link is the bottleneck.
- **Measured throughput (T4, 1 MiB in 64 × 16 KiB tensors, no backpressure):** 4736 FIUs in 37,888 cycles = **100 % link occupancy**. Payload efficiency is 86.5 % (≈ 87.5 % minus last-FIU padding), which is **22.1 Gb/s payload at 100 MHz** (256 bit × 100 MHz = 25.6 Gb/s raw).
- **Short packets:** each packet takes at least one FIU, so 64 B packets reach 64/256 = 25 % efficiency. Packing several packets into one FIU is a Stage 2 item.
- **Credits:** TX reserves 7 words per FIU; RX returns words as they are popped or rolled back. With `RX_BUF_DEPTH=32` and a 3-cycle return delay, the link stays at 100 % occupancy.
- **Error recovery:** a corrupted FIU is rolled back at its trailer cycle. If its packet was open, the newest committed word gets `last=1, err=1`, and the egress shows `tlast` + `tuser=1` after the bytes already verified. RX then discards until the next sop FIU.

---

## Part D – Compile order / file list (`sim/rtl_files.f`)
```
rtl/common/reset_sync.sv
rtl/common/axis_skid_buffer.sv
rtl/crc32_engine.sv
rtl/axis_packet_ingress.sv
rtl/axis_packetizer.sv
rtl/fiu_rx_buffer.sv
rtl/fiu_link_layer.sv
rtl/lane_striper_gray_mapper.sv
rtl/lane_de_striper_gray_decoder.sv
rtl/axis_depacketizer.sv
rtl/placeholder/fec_encoder_stub.sv      (v4, bypass placeholder)
rtl/placeholder/fec_decoder_stub.sv      (v4, bypass placeholder)
rtl/csr_status.sv
rtl/axis_pcie_link_top.sv
rtl/axis_rr_arbiter.sv                   (v4)
rtl/axis_pcie_link_mux2_top.sv           (v4, 2-source top)
rtl/placeholder/fiu_replay_buffer.sv     (v4, standalone component, not instantiated by the tops)
(testbenches: sim/tb_files.f -> tb_top, sim/tb_arb_files.f -> tb_arb, sim/tb_replay_files.f -> tb_replay)
```
No packages or include files. Leaf modules come first, so the order is also valid for tools that need definition before use.

Commands: see `docs/how_to_run.md` (`python sim/run_regression.py`, Icarus or Verilator). Testbench files: `sim/tb_files.f` (after `sim/rtl_files.f`). Synthesis: `yosys -s synthesis/run_yosys.ys`.

---

## Part E – Verification summary
Superseded by the structured environment in `tb/`. v4 has:
- `tb_top`: 17 tests; protocol checkers with SVA; FIU-level reference model; 110 functional coverage bins; deadlock/timeout monitors; performance-counter shadow; end-to-end safety checker;
- `tb_arb`: 8 tests;
- `tb_replay`;
- a formal proof of the arbiter;
- 41-mutation check.

See:
- `docs/verification_plan.md`: requirement traceability, checkers, reference model
- `docs/coverage_plan.md`: 110 coverage bins
- `docs/expected_results.md`: pass criteria (specification)
- `reports/verification_results_actual.md` and `evidence_v4/`: actual tool output (v4: Icarus 12.0, Verilator 5.052, Yosys 0.70)

The RTL was changed once as a result of this verification: `s_axis_tready` is now held low during reset (rule R5). It was also cleaned to pass `verilator --lint-only -Wall` with no warnings.

## Part E2 – Synthesis results (Yosys 0.70, generic gates)

**v4 update** (`synthesis/run_yosys.ys` now synthesizes `axis_pcie_link_mux2_top`; reports in `synthesis/reports/`; the v3 reports below are kept in `synthesis/reports/v3/`):
- `check -assert` passes and there are 0 latches.
- Totals: **56,162 cells / 12,656 flops** (v3: 45,293 / 12,122).
- New or changed blocks:

  | Block | Cells | Flops | Note |
  |---|---|---|---|
  | `axis_rr_arbiter` | 602 | 6 | |
  | `csr_status` | 5,633 | 790 | 9 new counters, error registers |
  | `axis_pcie_link_top` glue | 872 | 130 | popcounts, performance-event registers |
  | `fiu_rx_buffer` | 37,212 | 8,506 | tid storage |
  | `fiu_replay_buffer` (standalone, `run_yosys_replay.ys`) | 27,537 | 8,226 | flop RAM; an SRAM in a real implementation |

- No new longest-path analysis was run for v4. The arbiter adds a 2:1 data mux and the round-robin pick ahead of the ingress skid register; `s_axis_tready` is still a flop output.

v3 results (single-source top; re-run after the Verilator-lint width cleanup and the reset-gated `s_axis_tready`):
`check -assert` passes; **0 latches**; no undriven or multiply-driven nets. The only warnings are intentional (reset-initialized arrays converted to registers).

| Module | Generic cells | Flip-flops |
|---|---|---|
| axis_packet_ingress (incl. 577-bit skid buffer) | 894 + 1,743 | 524 + 1,157 |
| axis_packetizer | 955 | 25 |
| fiu_link_layer (+ 2 × crc32_engine, 2,657 cells each) | 1,230 + 5,314 | 377 |
| lane_striper_gray_mapper / lane_de_striper_gray_decoder | 387 / 387 | 258 / 258 |
| fiu_rx_buffer (32 × 256-bit) | 30,778 | 8,474 |
| axis_depacketizer | 835 | 582 |
| csr_status | 2,768 | 465 |
| **Total** | **45,293** | **12,122** |

The RX buffer is 68 % of the cells. Stage 2 options: an SRAM macro, or `RX_BUF_DEPTH=16`, which halves the area but must be re-checked for throughput.

**Timing findings from synthesis, fixed in this RTL:**
1. The naïve unrolled CRC loop synthesized to an **87-level XOR chain**. `crc32_engine` now computes an elaboration-time GF(2) matrix, so each output is one balanced XOR reduction: **9 levels**. Equivalence with the loop form was checked on 5,000 random vectors.
2. The ingress byte count used a 64-step popcount adder chain that sat on the valid/ready path (top-level worst path: 117 levels). The handshake now uses `|tkeep` only, and the byte count is a thermometer-to-binary OR-encode.

Worst-case flattened path is now **35 generic levels** (`synthesis/reports/longest_path.rpt`): RX word index → CRC → 32-bit compare → commit/rollback → credit-return adder. A pipeline register after the CRC compare is the next step if the sky130 target clock needs it. No frequency is claimed until OpenSTA runs with a liberty file.

## Part F – Assumptions
1. Single clock domain for AXIS, link and CSR. The "System-Synchronous 256-bit bus" of the block diagram is the internal link word.
2. "FIU" is interpreted as a fixed 256 B unit **including** its own header/CRC (flit-like), not 256 B of payload plus sideband.
3. v4: the two AXI4-Stream inputs of the diagram are served by `axis_pcie_link_mux2_top`. A packet-atomic round-robin arbiter merges them onto the single link, and `m_axis_tid` identifies each packet's source at the receiver. A full N×M crossbar (several links or several egress ports) is not implemented. A 1:2 demultiplexer on `m_axis_tid` restores the two streams.
4. Supported AXIS subset: packed streams (full `tkeep` on non-last data beats, contiguous LSB-aligned `tkeep` on the last data beat). Null beats and zero-length `tlast` are supported. Other patterns are flagged, never silently mis-delivered.
5. v4: `tid` is used (stream ID, `TID_W` bits, sampled on the first beat of a packet and carried in the FIU trailer). `tdest/tstrb` are not used. `tuser` exists only on egress (1 bit, error).
6. `rx_sym*` lanes arrive aligned. `tx/rx_sym_sof` is an error-free framing strobe that stands in for block alignment established during link training.
7. The credit wires stand in for credit-update messages a real link would carry in-band.
8. PAM4 level code 0…3 represents the amplitudes −3, −1, +1, +3; the analog PHY/SerDes is outside the digital design.
9. Bit-pair order within a byte (LSB pair first) and byte-striping order are design choices, documented here, and not claimed to match the PCIe specification bit-exactly.

## Part G – Limitations (explicitly NOT implemented; no PCIe compliance claimed)
- **No FEC.** v4 adds a bypass placeholder with a fixed interface (`docs/fec_architecture.md`); the trailer reserves 22 B for check bytes. CRC-32 detects errors only.
- **No replay/ACK-NAK in the datapath**, so corrupted packets are dropped or truncated with `tuser=1`. v4 adds a unit-verified replay-buffer component and an integration plan (`docs/replay_architecture.md`), but no return channel, timer or Go-Back-N receiver.
- No PCIe Transaction Layer (TLP headers, MWr/MRd/Cpl, ordering), no DLLPs, no PCIe flow-control credit types, no configuration space, no LTSSM / link training, no PIPE interface, no scrambling, no precoding, no lane deskew, no SerDes, no CDC.
- v4 has a 2:1 packet arbiter onto one link, not an N×M crossbar. Fairness is per packet, not per byte. There is no AXI4 memory-mapped master/slave (only AXI4-Lite CSRs).
- One packet per FIU (short-packet efficiency is low). Packet length itself is not limited (multi-FIU segmentation).
- Sideband `sof` corruption is detected (RX_FRAME_ERR) but leaks TX credits until reset.
- Counters saturate at 2³²−1. The CSR supports one outstanding transaction per channel.
- Data rate claim: `LINK_W × f_clk` (25.6 Gb/s raw at 100 MHz). Real PCIe 6.0 ×4 is 256 GT/s raw; the rate is reduced as the challenge allows.
