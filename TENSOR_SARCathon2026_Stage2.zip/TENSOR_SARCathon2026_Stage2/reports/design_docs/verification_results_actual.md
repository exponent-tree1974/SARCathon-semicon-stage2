# Verification Results — actual tool output (v4)

This report only points to files produced by the tools. Expected values are in
`docs/expected_results.md`; they are kept separate from the actual output on purpose.

- **Final table** (every test execution, seed, result and log file):
  `evidence_v4/regression_summary.md` — 338 executions, 338 PASS, 0 FAIL.
- **Index, measured fairness and performance numbers, failure log F1–F12:** `evidence_v4/README.md`.
- **Mutation check:** `evidence_v4/logs/mutation_check_final_icarus12.log` (final run),
  plus `mutation_check_run1_icarus12.log` and `mutation_check_M29_rerun.log` (history
  of failure F11).
- **Formal:** `evidence_v4/logs/formal_arbiter.log` and `evidence_v4/formal/`.
- **Waveforms:**
  - `evidence_v4/waveform_verification_core.md`, `waveform_verification_arb*.md`,
    `waveform_negative_controls_arb.md`;
  - screenshots in `evidence_v4/screenshots/`.
- **Synthesis:** `evidence_v4/logs/yosys_stat.rpt`, `yosys_stat_replay_buffer.rpt`.

The v3 results (16 tests, 92 coverage bins, 16 mutations) are kept in the `stage1_v3`
folder (`evidence/`, `reports/verification_results_actual.md`). v4 supersedes them.
Environment: Linux container, Icarus Verilog 12.0, Verilator 5.052, Yosys 0.70,
Python 3.13. A run on your own machine is the authoritative one.
