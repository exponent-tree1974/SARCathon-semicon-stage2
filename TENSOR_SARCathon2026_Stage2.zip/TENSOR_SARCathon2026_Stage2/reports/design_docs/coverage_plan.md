# Functional Coverage Plan

Bins are defined in `tb/env/cov_bins.svh` and implemented in `tb/env/coverage_collector.sv`. A bin is **COVERED** when hits ≥ goal.

Sources:
- **IF**: interface observation (ingress/egress AXIS, link symbols, DUT status taps)
- **SB**: scoreboard packet-complete events (error-free delivered packets, unless noted)
- **CH**: channel injection statistics
- **RM**: reference-model decisions (confirmed by DUT counters at test end)
- **T**: explicit hit by the test sequence

| ID | Bin | Goal | Src | Intent | Main test(s) |
|---|---|---|---|---|---|
| 0–6 | `len_exact_1/63/64/65/100/255/256` | 1 | SB | required sizes delivered intact | sizes_directed |
| 7–16 | `len_2_31` … `len_ge_4096`, `len_exact_32`, `len_exact_224_one_fiu` | 1–5 | SB | length classes incl. FIU (224 B) and beat (64 B) boundaries | sizes_directed, random_* |
| 17–21 | `last_beat_1B` … `last_beat_64B` | 1–5 | IF | final-beat tkeep widths | sizes_directed, random_* |
| 22 | `ing_tready_low_while_valid` | 10 | IF | DUT backpressures ingress | back_to_back, credit_stress |
| 23 | `ing_tvalid_gap_midpkt` | 10 | IF | source idles inside a packet | random_stalls |
| 24 | `ing_back_to_back_pkts` | 10 | IF | tlast immediately followed by next packet | back_to_back |
| 25–27 | `ing_null_beat`, `ing_zero_len_tlast`, `ing_empty_packet` | 2–3 | IF | legal but unusual AXIS | tkeep_malformed |
| 28–31 | `ing_partial_nonlast_beat`, `ing_sparse_tkeep`, `ing_offset_tkeep`, `ing_hole_in_full_beat` | 1 | IF | each unsupported tkeep class | tkeep_malformed |
| 32 | `eg_tvalid_while_not_ready` | 10 | IF | egress backpressure | random_stalls |
| 33 | `eg_back_to_back_pkts` | 10 | IF | egress tlast followed by next packet | back_to_back |
| 34 | `eg_tuser_error_packet` | 3 | IF | error packets reach egress | crc_corruption, tkeep_malformed |
| 35–36 | `eg_single_beat_pkt`, `eg_multi_beat_pkt` | 5 | IF | beat count classes | all |
| 37 | `eg_stall_ge_32_cycles` | 1 | IF | long egress stall | random_stalls, credit_stress |
| 38 | `link_fiu_back_to_back` | 10 | IF | FIUs every 8 cycles (saturated link) | back_to_back |
| 39 | `link_credit_exhausted` | 1 | IF | TX blocked for lack of credits | credit_stress |
| 40 | `rxbuf_high_watermark` | 1 | IF | RX buffer nearly full | credit_stress |
| 41 | `rx_discard_mode` | 1 | IF | receiver in discard-until-SOP state | crc_corruption |
| 42 | `link_idle_inside_fiu` | 1 | IF | TX FIU interrupted by source gaps | random_stalls |
| 43–51 | `inj_symbol_error`, `inj_symbol_burst`, `inj_lane0..3`, `inj_lane_fail_whole_fiu`, `inj_crc_field`, `inj_trailer_header` | 1–3 | CH | every corruption class actually injected | symbol_errors, lane_corruption, crc_corruption |
| 52–60 | `forge_*` (magic, len 0, len too big, eop clear/set, sop clear/set, seq, poison) | 1 | CH | every forged-header class | header_forgery |
| 61–67 | `rx_first_fiu_dropped`, `rx_abort_open_packet`, `rx_discard_good_fiu`, `rx_sop_while_open`, `rx_cont_without_open`, `rx_seq_error`, `rx_poison_propagated` | 1–2 | RM | every RX policy branch | crc_corruption, header_forgery |
| 68–72 | `reset_while_idle`, `reset_ingress_midpkt`, `reset_link_mid_fiu`, `reset_egress_stalled`, `reset_rxbuf_nonempty` | 1 | T | reset scenarios | reset_idle, reset_traffic |
| 73–88 | `csr_rd_*`, `csr_wr_partial_strobe`, `csr_wr_ro_slverr`, `csr_rd/wr_unmapped_slverr`, `csr_aw_before_w`, `csr_w_before_aw`, `csr_aw_w_same_cycle`, `csr_counter_clear`, `csr_link_en_off` | 1 | T | register map and AXI-Lite ordering | csr_access, reset_idle |
| 89 | `pkt_spanning_ge_8_fius` | 1 | SB | very long packet (> 7 FIUs) | sizes_directed (9000 B) |
| 90 | `order_checked_ge_1000_pkts` | 1 | T | order checked on ≥ 1000 packets in one test | order_preservation |
| 91 | `error_pkt_delivered_tuser` | 1 | SB | errored packet delivered and checked | crc_corruption |
| 92–93 | `tid_zero_delivered`, `tid_max_delivered` | 5 | SB | extreme stream-ID values delivered intact (v4) | all |
| 94 | `forge_tid` | 1 | CH | forged tid with valid CRC injected (v4) | header_forgery, err_csr_perf |
| 95 | `rx_tid_mismatch_abort` | 1 | RM | RX decision TID (continuation of another stream) (v4) | header_forgery |
| 96–98 | `csr_rd_params2`, `csr_rd_seq_status`, `csr_rd_perf_counters` | 1–3 | T | v4 registers read | reset_idle, err_csr_perf, all |
| 99 | `csr_err_status_w1c` | 2 | T | W1C clears selected bits only (v4) | err_csr_perf |
| 100–101 | `csr_irq_asserted`, `csr_irq_deasserted` | 1 | T | irq follows ERR_STATUS & ERR_IRQ_EN (v4) | err_csr_perf |
| 102–106 | `last_err_reason_crc/hdr/sop_in_pkt/tid/seq` | 1 | T | every LAST_ERR reason captured and checked (v4) | err_csr_perf, crc_corruption, header_forgery |
| 107–109 | `perf_credit_stall_nonzero`, `perf_in_stall_nonzero`, `perf_out_stall_nonzero` | 1 | T | stall counters exercised and matched to the shadow (v4) | credit_stress, random_stalls |

**N/A bins:** the lane bins `inj_lane1..3` are marked **N/A** when `LANES` < 4. They are excluded from the score and from `--cov-strict`, and the report prints N/A.

**Excluded (documented, not binned):** counter saturation, `sof` sideband corruption, lane skew, RX_FRAME_ERR from `sof` misalignment.

**Closure criterion (v4):** 110/110 bins COVERED in a full-suite run with `LANES=4` (fewer applicable bins for `LANES<4`) (`--cov-strict` enforces this). The merged report over several seeds goes to `sim/out/<run>/coverage_report.md`.
