# Stage 1 v4 — enhancements: evaluation, implementation, verification

Scope rule for this revision: implement only what can be **fully implemented and verified** in
hackathon time. Anything bigger becomes a documented placeholder with a fixed interface and a
verification plan, not a half-working feature. No PCIe compliance is claimed. The design remains
a *PCIe 6.0-inspired* FIU link (see `reports/stage1_rtl_review_and_spec.md`, Part G).

## 1. Evaluation of the candidate enhancements

| # | Candidate | Value for judging | Cost / risk | Decision | Result |
|---|---|---|---|---|---|
| 1 | 2-input AXI-Stream round-robin arbiter | high: the block diagram has 2 AXIS inputs; v3 had 1 | low: small RTL, provable | **implemented** | `axis_rr_arbiter` + `axis_pcie_link_mux2_top` |
| 1b | full crossbar | medium | high: needs several links or egress ports | **not done** | 2:1 mux + `m_axis_tid`, so a 1:2 demux restores the streams |
| 2 | packet atomicity under arbitration | high (correctness) | low | **implemented + formally proved** | selection frozen from first presented beat to accepted tlast |
| 3 | fairness / starvation tests | high | low | **implemented** | `tb_arb`: saturation, mixed sizes, starvation, back-to-back switch; measured wait bounds |
| 4 | sequence numbers and FIU header fields | high | low: seq already existed in v3 | **extended** | `tid` (stream ID) field in the trailer, RX `tid` consistency check, `SEQ_STATUS`, golden-model and safety checks |
| 5 | CRC status / error CSR | high (debuggability) | low | **implemented** | `ERR_STATUS` (W1C, sticky), `ERR_IRQ_EN` + `irq`, `LAST_ERR` (reason + sequence numbers) |
| 6 | replay buffer | high conceptually | high to integrate: needs return channel, timer, new RX policy | **component + documented stub** | `fiu_replay_buffer` fully unit-verified; integration plan in `docs/replay_architecture.md` |
| 7 | configurable lane count | medium | low (RTL was already generic) | **verified** | full core regression at `LANES` = 1, 2, 4, 8, 16, 32 |
| 8 | FEC | high conceptually | high: changes FIU layout, RX timing, CRC order | **placeholder only** | bypass `fec_*_stub` in the datapath, fixed interface; `docs/fec_architecture.md` with the code choice and verification plan |
| 9 | performance counters (packets, bytes, stalls, CRC failures) | high | low | **implemented** | 9 new counters (bytes in/out, in/out/credit stalls, link words, cycles, FEC placeholders), plus the existing packet/FIU/error counters |
| 10 | assertions: no output without valid input, no reordering | high | low–medium | **implemented** | `link_safety_checker` (S1a–S4), arbiter monitor (A1–A3), per-stream scoreboard; arbiter properties **proved** with Yosys k-induction |

## 2. What changed in the RTL
| File | Change |
|---|---|
| `rtl/axis_rr_arbiter.sv` (new) | N-input packet arbiter, round robin, zero-bubble hand-over, `m_tid`, `ev_pkt_start`; embedded `ifdef FORMAL` properties |
| `rtl/axis_pcie_link_mux2_top.sv` (new) | 2 sources → arbiter → `axis_pcie_link_top` (`TID_W=1`); exports per-source grant pulses |
| `rtl/axis_pcie_link_top.sv` | `TID_W`, `FEC_MODE` parameters; `s_axis_tid`, `m_axis_tid`, `irq` ports; FEC stubs in the lane path; registered performance events |
| `rtl/axis_packet_ingress.sv`, `rtl/axis_packetizer.sv` | carry `tid`; the packetizer samples it on the first beat of a packet |
| `rtl/fiu_link_layer.sv` | trailer `[47:40] = tid`; RX decision `TID` (continuation from another stream → abort); error capture (`err_*`); `SEQ_STATUS` outputs; credit-stall event |
| `rtl/fiu_rx_buffer.sv`, `rtl/axis_depacketizer.sv` | `tid` stored on the first entry of each FIU; `m_axis_tid` held for the whole packet |
| `rtl/csr_status.sv` | VERSION 2.0; PARAMS2, SEQ_STATUS, 20 counters with 8-bit increments, ERR_STATUS (W1C), ERR_IRQ_EN, LAST_ERR, `irq` (`docs/csr_register_map.md`) |
| `rtl/placeholder/fec_encoder_stub.sv`, `fec_decoder_stub.sv` (new) | bypass; any `FEC_MODE ≠ 0` stops elaboration |
| `rtl/placeholder/fiu_replay_buffer.sv` (new) | Go-Back-N storage and replay sequencing (standalone) |

Every RTL file passes `verilator --lint-only -Wall` with no warnings:
- each top: `axis_pcie_link_top`, `axis_pcie_link_mux2_top`, `fiu_replay_buffer`;
- every parameter variant tested: `LANES` 1/2/8/32 and `TID_W` 3/8 (core), `N=3` (arbiter),
  `N_FIU=8, W=64` (replay buffer).

## 3. Key design decisions
- **Arbiter lock point.** The selection is frozen as soon as a beat is *presented*,
  not only after the first beat is *accepted*. Otherwise a stalled output beat could
  change source when the other input becomes valid, which violates AXI-Stream
  (mutation A5 shows that the testbench catches it).
- **Fairness unit.** One packet per turn. This is packet-fair, not byte-fair: while
  both sources are busy, each turn moves 4096 B for one source and 64 B for the other
  (98.5 % / 1.5 % of the bytes). Over the whole test the totals are 122,880 B vs
  19,200 B, because 270 of the 64 B packets are sent after the long source has
  finished. The short-packet source still waits at most one large packet (measured
  ≤ 159 cycles; bound 192). A deficit-round-robin byte-fair variant is a Stage 2 option.
- **`tid` in the trailer, not in a header word.** It keeps the FIU layout and the
  87.5 % payload efficiency. The trailer is CRC-protected, and the receiver rejects
  a continuation FIU whose `tid` changed. A forged `tid` on a first FIU with a
  *valid* CRC is undetectable, like the other valid-CRC forgeries already
  documented. `header_forgery` tests both cases.
- **Counters off the critical path.** Byte counts use the 64-bit popcount of a
  *registered* copy of `tkeep`, so the AXIS handshake paths are unchanged
  (v3 finding D4).
- **`CTRL.clear`** clears counters, ERR_STATUS and LAST_ERR together, so software
  can start a clean measurement window with one write. W1C clears selected bits.

## 4. Verification added
| Item | Where | What it proves |
|---|---|---|
| `tid` end to end | `pkt_scoreboard` (+ random `tid` per packet in all 17 tests), golden model G8, protocol checker R9 | every packet leaves with the `tid` it entered with; `tid` constant within a packet; trailer field ≤ `TID_W` bits |
| `tid` forgery | `header_forgery` packets 13–15, random forgeries in `random_regression` | RX decision TID, abort and discard; undetectable first-FIU forgery documented |
| performance counters | `perf_shadow` (exact, at the read handshake), cross-checks, `err_csr_perf` | IN/OUT_BYTES, IN/OUT/CREDIT_STALL, TX_WORDS, CYCLES, FEC = 0 |
| error CSRs | `check_err_seq` after every traffic chunk (model) + `err_csr_perf` (hand-derived) | sticky/W1C, strobes, IRQ masking, STATUS.irq, LAST_ERR for 5 reasons, clear semantics |
| no output without valid input / no reordering | `link_safety_checker` S1a–S4 in `tb_top` and `tb_arb` | egress packets are ingress packets (tag+tid) in strictly increasing order; beats/packets never exceed ingress; TX seq consecutive; RX accepted seq increasing |
| arbiter | `tb_arb` 8 tests: `arb_fairness_monitor` A1–A3, `stream_scoreboard` Q1–Q4 | atomicity, conservation, starvation bound ≤ N−1 packets, per-stream exact delivery; under faults only losses or whole-FIU truncation |
| arbiter (formal) | `bash sim/formal/run_formal.sh` | P1–P6 for **all** reachable states (k-induction), plus a non-vacuity witness and 3 broken arbiters that must fail |
| replay buffer | `tb_replay` | cycle-level reference model + data integrity + scenario checks |
| lane count | `--lanes 1 2 8 16 32` full core regressions | DUT, channel model and golden model agree for every lane count |
| testbench strength | `sim/run_mutation_check.py` | 41 injected bugs (16 v3 + 25 v4) |

## 5. Results (actual tool output; files under `evidence_v4/`)
| Item | Result | Evidence (`evidence_v4/…`) |
|---|---|---|
| Lint (Verilator `-Wall`), 3 tops + 8 parameter variants | 11/11 clean | `logs/lint_verilator_all_tops.log` |
| Core bench, Icarus 12, seeds 1–8, `--cov-strict --repro-check` | **136/136 PASS**, coverage **110/110**, reproducibility PASS | `core_icarus12_s1-8/` |
| Core bench, Verilator 5.052 + concurrent SVA, seeds 1–2 | **34/34 PASS** | `core_verilator_s1-2/` |
| Lane / tid sweep: `LANES` 1, 2, 8, 16, 32 and `TID_W` 1, 8 | **119/119 PASS** (coverage 107/107, 108/108, 110/110) | `core_sweep_*/` |
| Arbiter bench, Icarus 12, seeds 1–4, `--repro-check` | **32/32 PASS**, reproducibility PASS | `arb_icarus12_s1-4/` |
| Arbiter bench, Verilator + SVA | **8/8 PASS** | `arb_verilator_s1/` |
| Replay unit test, Icarus seeds 1–4 + Verilator seeds 1–2 | **6/6 PASS** | `replay_*` |
| Formal: arbiter P1–P6 | **proved** (k-induction); witness reachable; 3/3 broken arbiters fail | `logs/formal_arbiter.log`, `formal/` |
| Waveform checks | core W1–W8 PASS; arbiter V1–V4 PASS (2 VCDs); negative controls FAIL as required | `waveform_*.md` |
| Mutation check | **41/41 killed** (16 v3 core + 15 v4 core + 5 arbiter + 5 replay); first run 40/41 (M29 survived → failure F11 → fixed) | `logs/mutation_check_*.log` |
| Synthesis (Yosys, generic) | exit 0, no latches, `check -assert` clean. 2-source top: 56,162 cells / 12,656 flops (v3 single-source: 45,293 / 12,122). Arbiter: 602 cells, 6 flops. CSR: 5,633 cells (v3: 2,768). The standalone replay buffer: 27,537 cells / 8,226 flops (flop RAM; would be an SRAM) | `logs/yosys_stat*.rpt` |
| **Final table** | **338 test executions, 338 PASS, 0 FAIL** | `regression_summary.md` |

Measured fairness (seeds 1–4):
- **Saturation:** 50.0 % / 50.0 % share.
- **4096 B vs 64 B:** the short-packet source waits ≤ 159 cycles (bound 192).
- **Sparse vs saturating:** ≤ 57 cycles (bound 96).
- **Starvation bound:** never more than 1 packet started past a waiting source (bound N−1 = 1).
- **Back-to-back 1-beat packets:** 7.93 cycles per packet with the link limit at 8 (zero-bubble hand-over).

Details: `evidence_v4/README.md`.

## 6. Failures found during this work (root cause → smallest fix → rerun)
Twelve failures were found and fixed during this work (F1–F12). The full table, with
the observed symptom, root cause, fix and rerun evidence, is in `evidence_v4/README.md`.
In summary:
- **Formal flow (F1, F2):** clocked assumptions under `async2sync`; no hierarchical
  references in Yosys. Fixed in the harness, without changing the RTL behaviour.
- **New RTL (F3):** the replay buffer's ACK window during a *pending* replay. Found
  in review; mutation R1 proves the unit test catches it.
- **Testbench and checkers (F4–F7, F9, F10):** two checker false positives, one
  coverage hole, two test-sequencing bugs, one hard-coded lane. Each was diagnosed
  from the log and fixed with the smallest change, then the affected tests were rerun.
- **Testbench gap found by mutation (F11):** M29 survived. A link-disable window
  was added to `credit_stress`, and the final mutation run was repeated in full.
- **Tooling (F8, F12):** runner variable collision; screenshot masking.

No functional bug in the v3 datapath was exposed by the new checks.

## 7. What is still not done (honest limits)
- **No FEC.** The bypass placeholder only fixes the interface; FEC_CORR / FEC_UNCORR are 0 by construction.
- **No retransmission.** The replay buffer is verified as a component but is not connected: there is no ACK/NAK channel, timer or Go-Back-N receiver. Errors still lead to drop or `tuser` truncation.
- **No crossbar.** Two sources share one link through a 2:1 arbiter; fairness is per packet.
- **Formal scope.** Only the arbiter is proved formally; the rest is verified by seeded simulation and mutation testing.
- **No timing sign-off.** Synthesis is generic (Yosys, no liberty), so no frequency is claimed.
- Unchanged from v3: no PCIe TLP/DLLP, no LTSSM, no PIPE/SerDes, no lane deskew, no scrambling.
