# FEC — architecture placeholder, interfaces and verification plan

**Status: not implemented.** The datapath contains two bypass modules,
`rtl/placeholder/fec_encoder_stub.sv` and `rtl/placeholder/fec_decoder_stub.sv`.
They fix *where* a forward-error-correction code sits and *which interface* it
must implement. They correct nothing. `FEC_MODE = 0` (bypass) is the only legal
value: any other value stops elaboration, so no build can claim FEC by accident.
The CSR register `PARAMS2.FEC_MODE` reads 0, and the counters `FEC_CORR` (0x68)
and `FEC_UNCORR` (0x6C) always read 0. The testbench checks all three.

## 1. Why FEC is not implemented in Stage 1
A real FIU-level FEC changes three things that are already verified end to end:
- the FIU byte layout (check bytes must go into the trailer),
- the RX timing (correction needs the whole FIU, about 8 cycles of extra latency,
  or a late write into the RX buffer),
- the CRC order (the CRC must be checked on the *corrected* FIU).

Doing that inside the hackathon window would have meant replacing a verified
error-detection path with an unverified one. The placeholder records the
decision and keeps the integration points stable.

## 2. Where it sits
```
TX: fiu_link_layer.t_* ──► fec_encoder_stub ──► lane_striper_gray_mapper ──► tx_sym
RX: rx_sym ──► lane_de_striper_gray_decoder ──► fec_decoder_stub ──► fiu_link_layer.r_*
```
The FEC protects the FIU as it appears on the lanes. Lane striping is done
after encoding, so an interleaved code can spread burst errors from a single
lane over several code words.

## 3. Interface contract (both stubs implement it today, in bypass form)
| Port | Encoder | Decoder | Meaning |
|---|---|---|---|
| `i_data[LINK_W-1:0]`, `i_valid`, `i_sof` | in | in | one FIU word per cycle; `i_sof` on word 0; a started FIU is never stalled |
| `o_data`, `o_valid`, `o_sof` | out | out | same framing; fixed latency (0 for bypass) |
| `ev_corrected` | – | out | 1-cycle pulse per FIU in which errors were corrected → CSR `FEC_CORR` |
| `ev_uncorrectable` | – | out | 1-cycle pulse per FIU with a detected uncorrectable error → CSR `FEC_UNCORR` and `ERR_STATUS[7]` |
| `FEC_MODE` parameter | | | 0 = bypass; future values select a code |

The link layer's CRC check stays authoritative. The FEC may only *improve*
the data; whether an FIU is accepted is still decided by CRC-32 on the
corrected FIU.

## 4. Intended code (for Stage 2, not implemented)
**Reference point (public descriptions of PCIe 6.0 FLIT mode):**
- a 256-byte flit carries 236 B TLP, 6 B DLP, an 8 B CRC and 6 B of FEC;
- the FEC is a lightweight, 3-way interleaved code that corrects one byte per
  interleave group;
- the interleaving spreads consecutive lane bytes across different groups;
- this FIU format is **not** that flit format, and no PCIe compatibility is claimed.

**Proposed for this FIU:** 3 interleaved Reed-Solomon-style groups over GF(2⁸),
2 check bytes each (6 B total), placed in reserved trailer bytes. Each group:
- syndromes S0 = Σbᵢ and S1 = Σbᵢαⁱ;
- single-byte correction at position log(S1/S0) with error value S0.

Group assignment: byte *b* belongs to group *b* mod 3. With the 4-lane striping
(byte *b* → lane *b* mod 4), consecutive bytes of one lane land in different
groups, so a short burst on one lane is spread over all three groups.

Datapath sketch:
- **TX:** accumulate two syndrome-like sums per group word by word (constant
  GF multipliers, XOR trees), then insert the check bytes into the trailer
  before the CRC is computed over the FIU.
- **RX:** compute syndromes while the words are written speculatively into
  `fiu_rx_buffer`. At the trailer, compute the error position and value per
  group, then apply at most 3 correction writes to the buffer (it gets one
  extra write port for this). Re-check CRC-32 on the corrected FIU before the
  commit (the CRC is linear, so the error contribution can be added), or
  delay the commit by one FIU.

## 5. Verification plan (ready for when the code is implemented)
| # | Check | How |
|---|---|---|
| F1 | bypass identity (today) | full `tb_top` regression with stubs in the path; `FEC_CORR = FEC_UNCORR = 0`; `PARAMS2.FEC_MODE = 0` |
| F2 | encoder against a Python reference | extend `tb/model/check_fiu_stream.py` with the GF(2⁸) code; every transmitted FIU's check bytes must match |
| F3 | exhaustive single-byte correction | for each of the 256 byte positions × 255 error values (or a seeded sample), the FIU is delivered intact and `FEC_CORR` += 1 |
| F4 | one error per group | 3 simultaneous byte errors in different groups → corrected |
| F5 | uncorrectable detection | 2 errors in one group → `ev_uncorrectable`, CRC-32 rejects, existing abort/discard policy unchanged |
| F6 | lane bursts | existing `MODE_LANE_WORD` (one lane, one word) must become correctable; `MODE_LANE_FIU` must stay detected |
| F7 | mis-correction safety | random multi-symbol errors: CRC-32 must reject every FIU the FEC mis-corrects (count and report) |
| F8 | latency / throughput | `back_to_back` link occupancy ≥ 99 % unchanged; RX latency increase measured and documented |
| F9 | mutation | flip one GF constant / one group mapping → F2/F3 must fail |

New channel-model modes needed: `MODE_BYTE` (single byte, arbitrary value) and
`MODE_BYTE_N_GROUP` (n bytes in chosen groups). New coverage bins:
corrected-per-group, uncorrectable, mis-correction caught by CRC.

Sources: [Synopsys — PCIe 6.0 Verification of FEC and CRC](https://www.synopsys.com/blogs/chip-design/pcie-6-verifaction-fec-crc.html)
