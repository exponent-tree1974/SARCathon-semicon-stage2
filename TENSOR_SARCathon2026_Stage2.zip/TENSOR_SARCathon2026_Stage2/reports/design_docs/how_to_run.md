# How to Run the Verification Environment

All flows go through one cross-platform runner, `sim/run_regression.py`. The `.sh` and `.ps1` files are thin wrappers around it. Run every command from the **project root** (the folder that contains `rtl/`, `tb/`, `sim/`).

## Tool requirements

| Tool | Required | Versions tested by the author | Notes |
|---|---|---|---|
| Icarus Verilog (`iverilog`, `vvp`) | yes | 12.0 (release) and 14.0-devel | needs `-g2012`; v11 is untested |
| Python | yes | 3.13 | 3.8+ should work; standard library only |
| GTKWave | optional | — | to view `.vcd` waveforms |
| Verilator | optional | 5.052 | ≥ 5.0 needed (`--timing`); enables concurrent SVA |
| Yosys | optional (formal proof of the arbiter, synthesis) | 0.70 | `bash sim/formal/run_formal.sh`; any Yosys with `sat -tempinduct` should work, older versions untested |

---

## Windows (native, PowerShell)

1. **Install Icarus Verilog 12.** Use the Windows installer from <https://bleyer.org/icarus/> and tick *"Add executable folder(s) to the user PATH"* (GTKWave can be installed from the same installer). Or, under MSYS2: `pacman -S mingw-w64-ucrt-x86_64-iverilog`.
2. **Install Python 3** from <https://www.python.org/downloads/> and tick *"Add python.exe to PATH"*.
3. Open a **new** PowerShell window and check:
   ```powershell
   iverilog -V
   py --version          # or: python --version
   ```
4. Run:
   ```powershell
   cd "C:\Users\ASUS\OneDrive\Documents\solve-this-problem-statement-to-the\stage1_v4"
   py sim\run_regression.py                        # all 17 core tests, seed 1
   py sim\run_regression.py --seeds 1 2 3 4 5 --cov-strict
   py sim\run_regression.py --test crc_corruption --seeds 7 --vcd-test crc_corruption
   py sim\run_regression.py --repro-check
   py sim\run_mutation_check.py                    # 41 injected RTL bugs must all be caught
   py sim\run_regression.py --bench arb --seeds 1 2   # 2-source arbiter bench (8 tests)
   py sim\run_regression.py --bench replay --seeds 1  # replay-buffer unit test
   py sim\run_regression.py --lanes 8                 # another lane count (1, 2, 4, 8, 16, 32)
   ```
   If you prefer the wrapper: `powershell -ExecutionPolicy Bypass -File .\sim\run_icarus.ps1 --seeds 1 2 3`. The bypass is only needed if script execution is disabled on the machine.
5. **Waveforms:** `gtkwave sim\out\<run>\seed_7\waves.vcd`

Verilator is not supported natively on Windows by this flow; use WSL (below).

## Linux (Ubuntu 24.04 or similar)

```bash
sudo apt update
sudo apt install -y iverilog gtkwave python3        # Ubuntu 24.04 ships Icarus 12
cd /path/to/stage1_v4
sim/run_icarus.sh                                   # == python3 sim/run_regression.py --sim icarus
sim/run_icarus.sh --seeds 1 2 3 4 5 --cov-strict
sim/run_icarus.sh --test lane_corruption --seeds 3 --vcd
python3 sim/run_mutation_check.py --jobs 4
```
Optional Verilator (≥ 5.0; `sudo apt install verilator` gives 5.020 on 24.04, which the author has **not** tested; 5.052 built from source was tested):
```bash
sim/run_verilator.sh --seeds 1                      # compiles with --timing --assert +define+SVA
```

## WSL (Windows Subsystem for Linux)

```powershell
wsl --install -d Ubuntu-24.04                       # once, from an administrator PowerShell; reboot if asked
```
Then inside the Ubuntu shell:
```bash
sudo apt update && sudo apt install -y iverilog gtkwave python3 verilator
# Your Windows folder is visible under /mnt/c. Copying it into the Linux file system is
# much faster than running directly on /mnt/c (and avoids OneDrive file-locking):
cp -r "/mnt/c/Users/ASUS/OneDrive/Documents/solve-this-problem-statement-to-the/stage1_v4" ~/stage1_v4
cd ~/stage1_v4
sim/run_icarus.sh --seeds 1 2 3
sim/run_verilator.sh --seeds 1
```
GTKWave in WSL needs WSLg (Windows 11) or an X server. Alternatively open the `.vcd` with Windows GTKWave via `\\wsl$\Ubuntu-24.04\home\<user>\stage1_v4\...`.

---

## Runner options

| Option | Meaning |
|---|---|
| `--sim icarus\|verilator` | simulator (default icarus) |
| `--bench core\|arb\|replay` | `core` = `tb_top` (17 tests, default); `arb` = `tb_arb` (8 tests, 2 sources + arbiter); `replay` = `tb_replay` (replay-buffer unit test) |
| `--lanes N`, `--tid-w N` | core bench only: DUT lane count (1, 2, 4, 8, 16, 32; default 4) and stream-ID width (1–8; default 4); passed to the DUT, the channel model and the golden model |
| `--replay-cycles N` | replay bench: cycles per run (default 200000) |
| `--seeds N [N ...]` | one full simulation per seed (default 1) |
| `--test NAME` | run a single test (names: see `docs/verification_plan.md`) |
| `--scale N` | multiply random packet counts (longer runs) |
| `--vcd` / `--vcd-test NAME` | waveform dump for all tests, or for one test only |
| `--vcd-scope dut\|all`, `--vcd-depth N` | `dut` (default): DUT ports + main DUT blocks, compact; `all`: whole testbench to depth N (0 = unlimited; can reach GBs) |
| `--cov-strict` | any coverage hole fails the regression (full suite only) |
| `--repro-check` | runs the suite twice and every test alone; results must be identical |
| `--no-golden` | skip the Python golden-model check |
| `--timeout S` | per-simulation timeout in seconds (default 3600) |
| `--out DIR` | output directory (default `sim/out/<sim>_<timestamp>`) |

Direct simulator plusargs (when running `vvp` / the Verilator binary yourself): `+seed= +test= +scale= +vcd +vcd_test= +vcd_file= +vcd_scope= +vcd_depth= +fiu_dump= +inj_log= +cov_file= +cov_strict +max_cycles=`.

## Output layout
```
sim/out/<sim>_<timestamp>/
  compile.log                 compiler output
  regression_summary.txt      per-seed, per-test PASS/FAIL table and final verdict
  coverage_merged.txt         bins summed over seeds
  coverage_report.md          filled-in docs/coverage_report_template.md
  seed_<N>/sim.log            full simulation log
  seed_<N>/coverage.txt       coverage for this seed
  seed_<N>/fiu_tx_dump.txt    TX symbol stream (input to the golden model)
  seed_<N>/golden_model.log   independent CRC/format check result
  seed_<N>/injections.log     every corrupted / forged FIU
  seed_<N>/waves.vcd          if --vcd / --vcd-test
```

## Reading the logs

| Marker | Meaning |
|---|---|
| `[TEST-START] name (test seed S)` | test begins; S reproduces it alone: `--test name --seeds <base>` |
| `[TEST-RESULT] name : PASS (...)` / `: FAIL (errors=N)` | per-test verdict |
| `[ERROR] <time> <component>: ...` | any check failure; first 20–40 per component are printed |
| `[TIMEOUT]`, `[DEADLOCK]`, `[STATE]` | liveness failure, with a dump of DUT state |
| `[SIM-RESULT] PASSED` / `[SIM-RESULT] FAILED` | final verdict of the simulation (exit code 0 / 1) |
| `REGRESSION RESULT: PASS` / `FAIL` | final verdict of the runner (exit code 0 / non-zero) |

**Seeds:** the same seed always reproduces the same run *on the same simulator*. Icarus and Verilator implement `$urandom` differently, so the same seed produces different (equally valid) stimulus on the two simulators.

---

## v4 flows: arbiter bench, replay unit test, formal proof, lane sweep

```bash
# 2 sources + round-robin arbiter (fairness, starvation, atomicity, faults, reset)
python3 sim/run_regression.py --bench arb --seeds 1 2 3
# replay-buffer component (Go-Back-N storage) against its reference model
python3 sim/run_regression.py --bench replay --seeds 1 2 3 4
# unbounded proof of the arbiter properties (Yosys); also runs a witness and 3 negative controls
bash sim/formal/run_formal.sh                      # or: bash sim/formal/run_formal.sh /path/to/yosys
# configurable lane count / stream-ID width
for L in 1 2 8 16 32; do python3 sim/run_regression.py --lanes $L --seeds 1 --cov-strict; done
python3 sim/run_regression.py --tid-w 1 --seeds 1 --cov-strict
# arbiter waveform: VCD, independent waveform check V1-V4 and a PNG + .gtkw view
python3 sim/run_regression.py --bench arb --test arb_saturated_equal --vcd --seeds 1 --out sim/out/arb_wave
python3 sim/verify_arb_waves.py sim/out/arb_wave/seed_1/arb_saturated_equal/waves.vcd sim/out/arb_wave/views
```
Windows: the Python commands work unchanged with `py`. `run_formal.sh` is a bash script: run it in WSL or Git Bash. Or install the OSS CAD Suite (it contains Yosys) and run the `yosys -p "..."` proof command contained in `sim/formal/run_formal.sh` (function `prove`) directly in PowerShell.

