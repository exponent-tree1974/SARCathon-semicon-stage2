# Evidence — v4 enhancements (actual tool output)

Everything in this folder was produced by running the tools on the v4 RTL and testbenches.
Nothing here is hand-written except this index, the failure log below and the
negative-control report header.

**Environment:**
- Linux container, Python 3.13;
- Icarus Verilog 12.0 (stable), Verilator 5.052 (concurrent SVA enabled), Yosys 0.70;
- versions recorded in `logs/step1_tool_versions.log`.

Repeat the runs with `docs/how_to_run.md` (v4 section) or `docs/simulation_runbook.md`. Your own run is the authoritative one.

## Result at a glance
| What | Command (summary) | Result | Evidence |
|---|---|---|---|
| Lint, every top and parameter variant | `verilator --lint-only -Wall` × 11 configurations | 11/11 exit 0, no warnings | `logs/lint_verilator_all_tops.log` |
| FEC placeholder cannot be enabled | `-GFEC_MODE=1` | elaboration fails, as intended | `logs/lint_fec_mode1_must_fail.log` |
| Compile, all 3 benches, Icarus `-Wall` | `iverilog -g2012 -Wall` | 0 warnings, exit 0 | `logs/compile_icarus12_all_benches.log` |
| Core bench (17 tests) × 8 seeds, coverage strict, reproducibility | `run_regression.py --seeds 1..8 --cov-strict --repro-check` | **136/136 PASS**, coverage **110/110**, REPRODUCIBILITY PASS | `core_icarus12_s1-8/` |
| Core bench, Verilator + concurrent SVA, 2 seeds | `--sim verilator --seeds 1 2 --cov-strict` | **34/34 PASS** | `core_verilator_s1-2/` |
| Lane count / stream-ID width sweep | `--lanes 1 2 8 16 32`, `--tid-w 1 8` | **7 × 17 = 119/119 PASS**, coverage 107/107 (L1), 108/108 (L2), 110/110 (others) | `core_sweep_L*_T*/` |
| Arbiter bench (8 tests) × 4 seeds + reproducibility | `--bench arb --seeds 1..4 --repro-check` | **32/32 PASS**, REPRODUCIBILITY PASS | `arb_icarus12_s1-4/` |
| Arbiter bench, Verilator + SVA | `--sim verilator --bench arb` | **8/8 PASS** | `arb_verilator_s1/` |
| Replay-buffer unit test | `--bench replay` Icarus seeds 1–4, Verilator seeds 1–2 | **6/6 PASS** (200,000 cycles each) | `replay_icarus12_s1-4/`, `replay_verilator_s1-2/` |
| Formal proof of the arbiter (P1–P6) | `bash sim/formal/run_formal.sh` | **PROVED** (k-induction), witness found, 3/3 broken arbiters fail the proof | `logs/formal_arbiter.log`, `formal/` |
| Waveform check, core (W1–W8) | `verify_waves.py` on the v4 `wave_showcase` VCD | all PASS | `waveform_verification_core.md` |
| Waveform check, arbiter (V1–V4) | `verify_arb_waves.py` on 2 arbiter VCDs | all PASS; negative controls FAIL as required | `waveform_verification_arb*.md`, `waveform_negative_controls_arb.md` |
| Mutation check | `run_mutation_check.py` | **41/41 killed** (16 v3 core + 15 v4 core + 5 arbiter + 5 replay); first run 40/41 (M29 survived → failure F11 → fixed) | `logs/mutation_check_final_icarus12.log` |
| Synthesis (generic, Yosys) | `yosys -s synthesis/run_yosys.ys` (+ `run_yosys_replay.ys`) | exit 0, `check -assert` clean, 0 latches | `logs/yosys_stat*.rpt`, `logs/synthesis_yosys_summary.log` |
| **Final table** | `sim/make_evidence_index.py evidence_v4` | **338 test executions, 338 PASS, 0 FAIL** | **`regression_summary.md`** |

Reproducibility re-runs (`*/repro/`, 29 logs) are not counted in the final table. The
`failures_before_fix_*` folders hold the failing runs of failure F10 below; they are
also not counted.

## Measured arbiter behaviour (Icarus 12, seeds 1–4; from the `[INFO]` lines of `arb_icarus12_s1-4/seed_*/simulation.log`)
| Test | Grants src0 / src1 | Max wait src0 / src1 (cycles) | Packets started past a waiting source (max; bound N−1 = 1) |
|---|---|---|---|
| arb_saturated_equal (256 B both) | 200 / 200 | 17 / 17 | 1 / 1 |
| arb_mixed_sizes (4096 B vs 64 B) | 30 / 300 | 3 / 159 (bound 192) | 1 / 1 |
| arb_starvation (1500 B saturating vs sparse) | 250 / 50 | 19 / 56–57 (bound 96) | 1 / ≤1 |
| arb_back_to_back_switch (1-beat packets) | 200 / 200 | 15 / 15 | 1 / 1 — 7.93 cycles per packet (link limit 8) |
| arb_random_stalls | 300 / 300 | 247–342 / 210–371 (egress back-pressure included) | 1 / 1 |

Byte share under equal saturation: 50.0 % / 50.0 %. With 4096 B vs 64 B packets the
byte share is 122,880 B vs 19,200 B. This is the documented packet-fair (not byte-fair) policy.

## Performance counters (core, seed 1, `err_csr_perf` and `back_to_back`)
- 4 × 1000 B without stalls: IN_BYTES = OUT_BYTES = 4000, TX_WORDS = 160 (= 4 packets × 5 FIUs × 8 words).
  IN_STALL = 88 cycles, because the 512-bit source waits for the 256-bit link.
- `back_to_back`: 456 FIUs in 3,649 cycles = 99.97 % link occupancy.
- `credit_stress`: credits reach 0 and the RX buffer reaches 32/32 without overflow.
  CREDIT_STALL matches the shadow model exactly, including a 200-cycle window with the link disabled.

## Screenshots (`screenshots/`, rendered from the VCDs by `sim/render_waves.py`; each has a `.gtkw` for GTKWave)
| File | Shows |
|---|---|
| `01`–`06b` | the core views of v3, regenerated from the v4 `wave_showcase` VCD (ingress/FIU, CRC, lanes, injection, CRC check/discard, egress) |
| `07_arbiter_round_robin_saturated.png` | both sources saturated: lock held per packet, grant alternates 0/1, tid carried to `m_axis_tid` |
| `08_arbiter_mixed_sizes.png` | 4096 B vs 64 B: the 64 B source gets exactly one packet after each long packet |

The arbiter VCDs are stored gzip-compressed (`arb_waves_*/seed_1/*/waves.vcd.gz`); GTKWave opens them directly.

## Failure log (this session): symptom → root cause → smallest fix → rerun
| # | Failure (as observed) | Root cause | Fix | Rerun / evidence |
|---|---|---|---|---|
| F1 | Yosys `sat` found a base-case "counterexample" in which a stalled source changed its data, although an assumption forbids it | clocked `assume`/`assert` with `$past` were not applied as intended after `async2sync` (formal harness problem, not RTL) | rewrote the harness with explicit previous-cycle registers; every check is combinational | `formal/proof.log`: base case and induction proven |
| F2 | Yosys: `dut.locked` "implicitly declared", induction could not use internal state | Yosys `read_verilog` has no hierarchical references | moved the strengthening invariants and P4/P6 into the arbiter under `` `ifdef FORMAL `` | proof PASS; negative controls FAIL |
| F3 | (review) the replay buffer could free, through an ACK, an FIU that a pending (not yet active) replay was about to resend | ACK window limit used `rp_active` instead of `rp_active ∥ nak_pend` | `ack_limit = (busy ? rp_seq : next) − oldest` | `tb_replay` PASS; mutation R1 (the old code) is killed |
| F4 | `tb_replay`: `in_sof=0 on word 0` after a random mid-run reset | testbench kept the pre-reset `in_sof` | stimulus sets `in_sof=1` after reset | seeds 1–4 PASS |
| F5 | `link_safety: S1a egress packet ... never entered the link` in `crc_corruption` (scoreboard clean) | checker recorded ingress packets at their tlast; an aborted packet's 224 B head legitimately leaves before its own tlast enters | record packets at their first data beat | `crc_corruption` PASS |
| F6 | same S1a error in `tkeep_malformed` | checker required ≥ 4 ingress bytes, but a sparse-tkeep beat (2 valid bytes) is forwarded whole by design | match on tag and order only | `tkeep_malformed` PASS |
| F7 | coverage hole `csr_err_status_w1c` (1 of 2) | only one W1C in the test | added a selective W1C (clears FRAME and RX_PKT_ERR, DISCARD stays set) | 110/110 |
| F8 | runner crash `ValueError: not enough values to unpack` after a full-suite run | variable `rows` reused for the coverage template table | renamed to `bin_rows` | runner completes |
| F9 | `tb_arb arb_single_source`: `[TIMEOUT] 40 packets not delivered` | test added source-1 packets before draining source 0 | add them after the first drain | 8/8 PASS |
| F10 | `--lanes 1` and `--lanes 2`: `wave_showcase` FAIL (scoreboard expected an abort that never happened) | the test plans a fault on lane 2, which does not exist; the channel model silently ignored it | lane = `LANES>2 ? 2 : LANES−1`; the channel model now stops (`$fatal`) on any out-of-range lane | `failures_before_fix_L1/L2/` → `core_sweep_L1_T4/`, `core_sweep_L2_T4/` PASS |
| F11 | mutation M29 (CREDIT_STALL ignores link_en) **SURVIVED** | no test disabled the link while credits were exhausted | `credit_stress` disables the link for 200 cycles in that state; `perf_shadow` checks the counter exactly | `logs/mutation_check_run1_icarus12.log` (40/41) → `logs/mutation_check_M29_rerun.log` (killed) → final run |
| F12 | arbiter screenshot showed tid/tag values while `tvalid=0` | renderer drew idle bus values | masked while `tvalid=0` | `screenshots/07`, `08` |
| – | Verilator `-Wall` warnings during development (WIDTHEXPAND, UNUSEDPARAM, UNUSEDSIGNAL, SYNCASYNCNET) | width / unused-signal hygiene in the new RTL | explicit casts, removed unused parameter, local index variable, waiver on the sim-only check | `logs/lint_verilator_all_tops.log` 11/11 clean |

No functional RTL bug in the existing datapath was found by simulation. F3 was a
design bug in a new component, found in review before its test ran; the mutation
check (R1) shows the unit test catches it.

## Not included (size), and how to regenerate
- `fiu_tx_dump.txt` (TX symbol streams, about 5 MB per seed): add `--out` and rerun. The runner rewrites them and runs the golden model on them; every `golden_model.log` is included.
- Simulator binaries (`*.vvp`, `obj_verilator/`).
- Uncompressed arbiter VCDs. They are included gzip-compressed.
