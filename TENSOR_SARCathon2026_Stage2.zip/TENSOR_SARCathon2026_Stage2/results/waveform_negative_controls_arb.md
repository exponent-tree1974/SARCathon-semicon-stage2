# Negative controls for `sim/verify_arb_waves.py`

Broken arbiter RTL, run with `tb_arb +test=arb_saturated_equal +vcd` (Icarus 12): the testbench and the independent waveform checker must both FAIL.

## fixed_priority

Mutation: `last <= grant` replaced by `last <= N-1` (source 0 always wins)

Testbench: `[SIM-RESULT] FAILED  tests=1 passed=0 failed=1 seed=1`

| Check | Description | Checked | Failed | Result |
|---|---|---|---|---|
| V1 | beat conservation at the arbiter (data/keep/last, source = tid) | 6478 | 0 | PASS |
| V2 | packet atomicity (tid constant inside a packet) | 1200 | 0 | PASS |
| V3 | round-robin hand-over after every packet end with the other source waiting | 200 | 199 | FAIL |
| V4 | end-to-end order and tid: link input packets == m_axis packets | 400 | 0 | PASS |

**Overall: FAIL**

## unlock_any_beat

Mutation: the lock is released on any accepted beat instead of the tlast beat (packets interleave)

Testbench: `[SIM-RESULT] FAILED  tests=1 passed=0 failed=1 seed=1`

| Check | Description | Checked | Failed | Result |
|---|---|---|---|---|
| V1 | beat conservation at the arbiter (data/keep/last, source = tid) | 64860 | 0 | PASS |
| V2 | packet atomicity (tid constant inside a packet) | 1200 | 1198 | FAIL |
| V3 | round-robin hand-over after every packet end with the other source waiting | 399 | 0 | PASS |
| V4 | end-to-end order and tid: link input packets == m_axis packets | 400 | 0 | PASS |

**Overall: FAIL**

