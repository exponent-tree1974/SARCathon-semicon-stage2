#!/usr/bin/env python3
"""Add a caption panel to each recorded waveform render (results/waveforms_raw ->
results/waveforms_annotated). The waveforms themselves are unchanged; captions
quote the automated VCD checks (sim/verify_waves.py, sim/verify_arb_waves.py),
whose outputs are results/waveform_verification_*.md."""
from PIL import Image, ImageDraw, ImageFont
import os, textwrap
D = os.path.dirname(os.path.abspath(__file__))
F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
CAP = {
 "01_axi_ingress_and_fiu_formation": ("Fig. W1/W2 - AXI4-Stream ingress -> 256-byte FIU formation",
   ["5 ingress packets (100, 300, 64, 300, 64 B) accepted on s_axis handshakes.",
    "Packetizer emits 7 FIUs: each FIU trailer carries sop/eop, length and sequence number 0..6; padding is zero.",
    "Check W1 + W2 (sim/verify_waves.py, from the VCD): payload re-assembled from FIUs == ingress bytes - PASS."]),
 "02_crc_generation": ("Fig. W3 - CRC-32 generation in the FIU trailer",
   ["The CRC field of every trailer word is compared with Python zlib.crc32 over the same FIU bytes.",
    "7/7 FIUs match (e.g. F0 = 0xF367AFD8).  Check W3 - PASS."]),
 "03_lane_mapping": ("Fig. W4 - 4-lane striping + Gray-coded PAM4 mapping (2 bits -> 1 symbol)",
   ["Byte b goes to lane b mod 4; each 2-bit pair is Gray-mapped to one PAM4 level; one-cycle mapper latency.",
    "56 transmitted words checked: tx_sym(n+1) == Gray(stripe(t_data(n))), 0 mismatches.  Check W4 - PASS."]),
 "04a_error_injection_lane2_word": ("Fig. W5a - channel fault injection: whole lane-2 word corrupted",
   ["The testbench channel model (2-cycle delay) corrupts 3 words, in FIUs 2, 3 and 4; this view shows a whole lane-2 word.",
    "Check W5 locates every changed symbol from tx vs rx in the VCD - PASS."]),
 "04b_error_injection_single_symbol": ("Fig. W5b - single PAM4 symbol error",
   ["A single symbol change on one lane is enough to make the receiver's CRC fail (see Fig. W6/W7)."]),
 "05_crc_check_and_discard": ("Fig. W6/W7 - receiver CRC check, abort and discard",
   ["crc_ok / dec are evaluated on trailer words: F1 ACCEPT (commit), F2-F4 CRC error (rollback; F2 also aborts the open packet),",
    "F5 continuation-without-packet (discarded), F6 ACCEPT.  ev_rx_crc_err pulses once per bad FIU.",
    "Checks W6 (CRC recomputed from received words) and W7 (decision table vs DUT dec/commit/rollback/abort) - PASS."]),
 "06_axi_egress": ("Fig. W8 - AXI4-Stream egress after errors",
   ["Exactly the expected 3 packets leave m_axis: P0 complete, P1 truncated to 224 B with tuser=1 (error flag), P4 complete.",
    "P2 and P3 (hit by injected errors) are discarded, never delivered as good data.  Check W8 - PASS."]),
 "06b_axi_egress_truncated_packet_zoom": ("Fig. W8 (zoom) - truncated packet is flagged, not silently delivered",
   ["The last beat of the 224-byte fragment of P1 carries tlast=1 and tuser=1, so the consumer can drop it."]),
 "07_arbiter_round_robin_saturated": ("Fig. A1 - 2:1 round-robin arbiter, both sources saturated",
   ["Grants alternate after every packet end; tid identifies the source; packets are never interleaved.",
    "VCD checks: V1 beat conservation 6478/0 fail, V2 atomicity 1200/0, V3 hand-over 399/0, V4 end-to-end order 400/400 - PASS.",
    "Measured share: 50.0 % per source."]),
 "08_arbiter_mixed_sizes": ("Fig. A2 - arbiter fairness with mixed packet sizes (4096 B vs 64 B)",
   ["Packet-fair round robin: the small-packet source waits at most one large packet (max wait 159 cycles, bound 192).",
    "VCD checks: V1 7040/0 fail, V2 1890/0, V3 59/0, V4 330/330 - PASS."]),
}
for name, (title, lines) in CAP.items():
    im = Image.open(os.path.join(D, "waveforms_raw", name + ".png")).convert("RGB")
    W = im.width
    ft, fb = ImageFont.truetype(FB, 26), ImageFont.truetype(F, 21)
    wrapped = []
    for l in lines:
        wrapped += textwrap.wrap(l, 150) or [""]
    h = 30 + 36 + 28 * len(wrapped) + 20
    out = Image.new("RGB", (W, im.height + h), "white")
    out.paste(im, (0, 0))
    d = ImageDraw.Draw(out)
    y0 = im.height
    d.rectangle([0, y0, W, y0 + h], fill="#f3f6fb")
    d.line([0, y0, W, y0], fill="#3b5998", width=4)
    d.text((24, y0 + 20), title, font=ft, fill="#1a2a4a")
    y = y0 + 62
    for l in wrapped:
        d.text((40, y), l, font=fb, fill="#222222"); y += 28
    out.save(os.path.join(D, "waveforms_annotated", name + "_annotated.png"), optimize=True)
    print("annotated", name)
