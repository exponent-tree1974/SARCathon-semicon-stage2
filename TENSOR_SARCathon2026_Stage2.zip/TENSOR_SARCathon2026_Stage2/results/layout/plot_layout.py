#!/usr/bin/env python3
"""Placement view of the final routed design, drawn from 6_final.def (cell origins,
coloured by cell class) - a faithful plot of the DEF, not a GDS render."""
import re, sys, gzip, collections
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
src, out = sys.argv[1], sys.argv[2]
op = gzip.open if src.endswith(".gz") else open
cls = collections.defaultdict(lambda: ([], []))
pins = ([], [])
unit = 1000.0; sec = None
pat = re.compile(r"^\s*-\s+(\S+)\s+(\S+).*?(?:PLACED|FIXED)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)")
for line in op(src, "rt"):
    if line.startswith("UNITS DISTANCE MICRONS"): unit = float(line.split()[3])
    if line.startswith("COMPONENTS"): sec = "c"; continue
    if line.startswith("END COMPONENTS"): sec = None
    if line.startswith("PINS"): sec = "p"; continue
    if line.startswith("END PINS"): sec = None
    if sec == "c":
        m = pat.match(line)
        if not m: continue
        cell = m.group(2)
        if re.search(r"__(fill|tapvpwrvgnd|decap)", cell): continue
        k = ("flip-flop" if re.search(r"__(e?df|dfx|dfr|dfs)", cell) else
             "antenna diode" if "diode" in cell else
             "clock buffer" if "clkbuf" in cell else
             "buffer / repair" if re.search(r"__(buf|dlygate|clkdly)", cell) else "logic")
        cls[k][0].append(int(m.group(3))/unit); cls[k][1].append(int(m.group(4))/unit)
    if sec == "p":
        m = re.search(r"(?:PLACED|FIXED)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)", line)
        if m: pins[0].append(int(m.group(1))/unit); pins[1].append(int(m.group(2))/unit)
col = {"flip-flop": "#1f77b4", "logic": "#9aa5b1", "buffer / repair": "#ff7f0e",
       "clock buffer": "#d62728", "antenna diode": "#2ca02c"}
fig, ax = plt.subplots(figsize=(9, 9), dpi=130)
for k in ["logic", "flip-flop", "buffer / repair", "clock buffer", "antenna diode"]:
    xs, ys = cls[k]
    ax.scatter(xs, ys, s=0.25 if k in ("logic", "flip-flop") else 1.2, c=col[k], label=f"{k} ({len(xs):,})", linewidths=0)
ax.scatter(*pins, s=2, c="k", marker="s", label=f"I/O pins ({len(pins[0]):,})")
ax.plot([0, 1300, 1300, 0, 0], [0, 0, 1300, 1300, 0], "k-", lw=0.8)
ax.set_xlim(-20, 1320); ax.set_ylim(-20, 1320); ax.set_aspect("equal")
ax.set_xlabel("µm"); ax.set_ylabel("µm")
ax.set_title("axis_pcie_link_mux2_top - final placement (Sky130 HD, 1300 x 1300 µm)\n"
             "plotted from 6_final.def; fill / tap / decap cells omitted", fontsize=10)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.07), ncol=3, fontsize=8, markerscale=8, frameon=False)
fig.tight_layout(); fig.savefig(out)
print({k: len(v[0]) for k, v in cls.items()}, "pins", len(pins[0]))
