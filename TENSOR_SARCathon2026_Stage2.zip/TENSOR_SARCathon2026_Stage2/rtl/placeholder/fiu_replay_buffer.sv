`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// fiu_replay_buffer   Go-Back-N replay storage for transmitted FIUs
//
// SCOPE (read this first)
//   This is a complete, unit-verified STORAGE AND REPLAY-SEQUENCING component
//   for a future ACK/NAK retry protocol. It is NOT connected to the datapath of
//   axis_pcie_link_top: the link has no ACK/NAK return channel, no replay timer
//   and no TX-side replay multiplexer, and the receiver's recovery policy is
//   still "abort + discard" (see fiu_link_layer). docs/replay_architecture.md
//   describes the missing pieces and how this block would be integrated.
//
// Function
//   * Captures every FIU the transmitter sends (in_*), one LINK_W word per
//     cycle, and numbers complete FIUs with consecutive sequence numbers
//     (next_seq), starting at 0 after reset like fiu_link_layer.
//   * Holds up to N_FIU unacknowledged FIUs. in_ready falls at an FIU start
//     when the buffer is full or a replay is pending/active (the TX would
//     stall new FIUs - Go-Back-N).
//   * ACK(s): cumulative - frees every stored FIU up to and including s.
//   * NAK(s): requests a retransmission starting at s; frees FIUs before s and
//     replays s, s+1, ... next_seq-1 on rp_* (AXI-Stream-like valid/ready,
//     rp_sof on word 0, rp_seq = sequence number of the FIU being replayed).
//     A replay starts at an FIU boundary of the capture side.
//
// Window rules (sequence arithmetic modulo 2^SEQ_W, window <= N_FIU << 2^SEQ_W)
//   ACK s accepted iff (s - oldest) < limit, limit = (replaying ? rp_seq : next_seq) - oldest
//                      (an FIU that is being replayed, or not yet replayed, is never freed)
//   NAK s accepted iff no replay is pending/active and (s - oldest) < (next_seq - oldest)
//   Otherwise the request is ignored and ev_ack_ignored / ev_nak_ignored pulses
//   (a real protocol recovers from a lost or stale NAK with a replay timer).
//   ACK and NAK in the same cycle: the NAK is evaluated, the ACK is ignored.
//
// Implementation note: storage is a flop array with a combinational read
// (N_FIU*FIU_WORDS words); an FPGA/ASIC version would use a RAM with a
// registered read and one extra pipeline stage on rp_*.
// -----------------------------------------------------------------------------
module fiu_replay_buffer #(
    parameter int W         = 256,
    parameter int FIU_WORDS = 8,
    parameter int N_FIU     = 4,         // power of two
    parameter int SEQ_W     = 8
) (
    input  wire                       clk,
    input  wire                       rst_n,
    // capture of transmitted FIUs
    input  wire                       in_valid,
    input  wire [W-1:0]               in_data,
    input  wire                       in_sof,        // must be 1 exactly on word 0 of an FIU
    output wire                       in_ready,
    // acknowledgements from the link partner
    input  wire                       ack_valid,
    input  wire [SEQ_W-1:0]           ack_seq,
    input  wire                       nak_valid,
    input  wire [SEQ_W-1:0]           nak_seq,
    // replay stream
    output wire                       rp_valid,
    output wire [W-1:0]               rp_data,
    output wire                       rp_sof,
    output wire [SEQ_W-1:0]           rp_seq,
    input  wire                       rp_ready,
    // status
    output wire [$clog2(N_FIU+1)-1:0] occupancy,     // stored complete FIUs
    output wire [SEQ_W-1:0]           oldest_seq,
    output wire [SEQ_W-1:0]           next_seq,
    output wire                       replaying,     // replay pending or active
    output logic                      ev_ack_ignored,
    output logic                      ev_nak_ignored
);
    localparam int SA = $clog2(N_FIU);
    localparam int WA = $clog2(FIU_WORDS);
    localparam int OW = $clog2(N_FIU + 1);

    generate
        if ((1 << SA) != N_FIU || (1 << WA) != FIU_WORDS || N_FIU < 2 || SEQ_W <= SA + 1)
            begin : g_bad_param
                illegal_parameter_combination u_illegal ();
            end
    endgenerate

    logic [W-1:0]       mem [0:N_FIU*FIU_WORDS-1];
    logic [SEQ_W-1:0]   oldest, nxt, rseq;
    logic [WA-1:0]      widx, rword;
    logic               rp_active, nak_pend;

    wire [SEQ_W-1:0] count   = nxt - oldest;                    // complete FIUs stored
    wire             full    = (count == SEQ_W'(N_FIU));
    wire             busy    = rp_active || nak_pend;

    assign in_ready   = (widx != '0) || (!busy && !full);
    wire   in_fire    = in_valid && in_ready;
    assign occupancy  = OW'(count);
    assign oldest_seq = oldest;
    assign next_seq   = nxt;
    assign replaying  = busy;

    assign rp_valid = rp_active;
    assign rp_data  = mem[{rseq[SA-1:0], rword}];
    assign rp_sof   = (rword == '0);
    assign rp_seq   = rseq;
    wire   rp_fire  = rp_active && rp_ready;
    wire   rp_last_word = (rword == WA'(FIU_WORDS - 1));

    // request acceptance
    wire [SEQ_W-1:0] ack_d     = ack_seq - oldest;
    wire [SEQ_W-1:0] ack_limit = (busy ? rseq : nxt) - oldest;    // never free a pending/replayed FIU
    wire [SEQ_W-1:0] nak_d     = nak_seq - oldest;
    wire nak_ok = nak_valid && !busy && (nak_d < count);
    wire ack_ok = ack_valid && !nak_valid && (ack_d < ack_limit);

    always_ff @(posedge clk) begin
        if (in_fire) mem[{nxt[SA-1:0], widx}] <= in_data;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            oldest         <= '0;
            nxt            <= '0;
            widx           <= '0;
            rseq           <= '0;
            rword          <= '0;
            rp_active      <= 1'b0;
            nak_pend       <= 1'b0;
            ev_ack_ignored <= 1'b0;
            ev_nak_ignored <= 1'b0;
        end else begin
            ev_ack_ignored <= ack_valid && !ack_ok;
            ev_nak_ignored <= nak_valid && !nak_ok;

            // capture
            if (in_fire) begin
                widx <= widx + 1'b1;                          // wraps at FIU_WORDS (power of two)
                if (widx == WA'(FIU_WORDS - 1)) nxt <= nxt + 1'b1;
            end

            // acknowledgements
            if (nak_ok) begin
                oldest   <= nak_seq;                          // FIUs before nak_seq are acknowledged
                rseq     <= nak_seq;
                rword    <= '0;
                nak_pend <= 1'b1;
            end else if (ack_ok) begin
                oldest   <= ack_seq + 1'b1;
            end

            // replay sequencing (starts at a capture-side FIU boundary)
            if (nak_pend && (widx == '0) && !in_fire) begin
                nak_pend  <= 1'b0;
                rp_active <= 1'b1;
            end
            if (rp_fire) begin
                rword <= rword + 1'b1;
                if (rp_last_word) begin
                    rseq <= rseq + 1'b1;
                    if (rseq + 1'b1 == nxt) rp_active <= 1'b0;   // replayed up to the newest FIU
                end
            end
        end
    end

`ifndef SYNTHESIS
    /* verilator lint_off SYNCASYNCNET */
    always @(posedge clk) begin
        if (rst_n && in_valid && in_ready && (in_sof != (widx == '0)))
            $error("fiu_replay_buffer: in_sof=%0d on word %0d of an FIU", in_sof, widx);
    end
    /* verilator lint_on SYNCASYNCNET */
`endif
endmodule
`default_nettype wire
