#!/usr/bin/env python3
"""
verify_waves.py - independent, waveform-level verification of a VCD dump.

Reads a VCD written by tb_top (+vcd_scope=dut, the default) and checks, cycle by
cycle at every rising clock edge, the seven key mechanisms of the design using
only the written specification (no simulator, no RTL code):

  W1 AXI ingress       packets reconstructed from s_axis handshakes (tkeep/tlast)
  W2 FIU formation     FIUs rebuilt from the link-layer output (u_link.t_*); payload
                       concatenation per packet == ingress packets; trailer fields,
                       padding = 0, sequence numbers, magic
  W3 CRC generation    trailer CRC field == zlib.crc32(FIU bytes 0..251 + 4 zero bytes)
  W4 Lane mapping      tx_sym(n+1) == Gray(stripe(t_data(n))) for every transmitted word
  W5 Error injection   every symbol that differs between tx_sym and rx_sym (channel delay
                       auto-detected), with FIU / word / lane / symbol positions
  W6 CRC check (RX)    CRC recomputed on the RECEIVED words; must equal DUT crc_ok
  W7 Discard / abort   expected RX decision per FIU (spec decision table) vs DUT
                       dec / b_commit_en / b_rollback_en / b_abort_en
  W8 AXI egress        expected egress packets (from W6/W7) vs actual m_axis bytes,
                       tlast, tuser, order; every egress packet is a prefix of its
                       ingress packet

Usage: python sim/verify_waves.py <waves.vcd> [--md report.md] [--json markers.json]
Exit code 0 only if all checks pass.
"""
import argparse
import bisect
import json
import sys
import zlib
from collections import defaultdict

LINK_W, LANES, AXIS_W = 256, 4, 512
LB, KB = LINK_W // 8, AXIS_W // 8
BPL = LB // LANES
LANE_BITS = LINK_W // LANES
FIU_WORDS = 8
PAYLOAD = (FIU_WORDS - 1) * LB
MAGIC = 0x5A
DEC = {0: "ACCEPT", 1: "CRC", 2: "HDR", 3: "SOP_IN_PKT", 4: "CONT_NO_PKT"}


# --------------------------------------------------------------------------- VCD
class VCD:
    def __init__(self, path):
        self.codes, self.width, self.chg = {}, {}, defaultdict(list)
        self.ts_ps = 1
        scopes, t, in_hdr = [], 0, True
        with open(path, "r", errors="replace") as f:
            hdr_buf = []
            for line in f:
                if in_hdr:
                    hdr_buf.append(line)
                    tok = line.split()
                    if not tok:
                        continue
                    if tok[0] == "$scope":
                        scopes.append(tok[2])
                    elif tok[0] == "$upscope":
                        scopes.pop()
                    elif tok[0] == "$var":
                        w, code, ref = int(tok[2]), tok[3], tok[4]
                        sc = scopes[1:] if scopes and scopes[0] == "TOP" else scopes   # Verilator wraps in TOP
                        name = ".".join(sc + [ref])
                        self.codes[name] = code
                        self.width[code] = w
                    elif tok[0] == "$enddefinitions":
                        in_hdr = False
                        txt = " ".join(hdr_buf)
                        if "$timescale" in txt:
                            ts = txt.split("$timescale")[1].split("$end")[0].strip()
                            num = int("".join(c for c in ts if c.isdigit()) or 1)
                            unit = ts.lstrip("0123456789 ").strip()
                            self.ts_ps = num * {"s": 10**12, "ms": 10**9, "us": 10**6, "ns": 1000,
                                                "ps": 1, "fs": 0.001}.get(unit, 1)
                    continue
                c = line[0] if line else ""
                if c == "#":
                    t = int(line[1:])
                elif c in "bBrR":
                    val, code = line[1:].split()
                    self.chg[code].append((t, val))
                elif c in "01xXzZ":
                    self.chg[line[1:].strip()].append((t, c))
        self.times = {k: [x[0] for x in v] for k, v in self.chg.items()}

    def code(self, name):
        if name not in self.codes:
            raise KeyError(f"signal {name} not in VCD")
        return self.codes[name]

    def before(self, name, t):
        """value (int or None for x/z) strictly before time t (pre-edge sample)."""
        c = self.code(name)
        i = bisect.bisect_left(self.times[c], t) - 1
        if i < 0:
            return None
        v = self.chg[c][i][1]
        if any(ch in v for ch in "xXzZ"):
            return None
        return int(v, 2)

    def rising_edges(self, clk):
        c = self.code(clk)
        out, prev = [], None
        for t, v in self.chg[c]:
            if v == "1" and prev == "0":
                out.append(t)
            prev = v
        return out


# ------------------------------------------------------------- spec re-implementation
def encode_word(word: int) -> int:
    """32-byte link word -> tx_sym (byte striping, then PAM4 Gray level per bit pair)."""
    b = word.to_bytes(LB, "little")
    lane_bytes = bytearray(LB)
    for byte in range(LB):
        lane, j = byte % LANES, byte // LANES
        lane_bytes[lane * BPL + j] = b[byte]
    bits = int.from_bytes(bytes(lane_bytes), "little")
    sym = 0
    for k in range(LINK_W // 2):
        pair = (bits >> (2 * k)) & 3
        msb, lsb = pair >> 1, pair & 1
        sym |= ((msb << 1) | (msb ^ lsb)) << (2 * k)
    return sym


def trailer(word: int):
    return dict(len=word & 0xFFFF, sop=(word >> 16) & 1, eop=(word >> 17) & 1, err=(word >> 18) & 1,
                seq=(word >> 24) & 0xFF, magic=(word >> 32) & 0xFF, crc=word >> (LINK_W - 32))


def fiu_crc(words):
    raw = b"".join(w.to_bytes(LB, "little") for w in words)
    return zlib.crc32(raw[:-4] + b"\x00" * 4) & 0xFFFFFFFF


# ------------------------------------------------------------------------- checks
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("vcd")
    ap.add_argument("--md", help="write a Markdown report")
    ap.add_argument("--json", help="write event times (ns) for waveform rendering")
    a = ap.parse_args()
    v = VCD(a.vcd)
    T = "tb_top."
    L = "tb_top.dut.u_link."
    edges = v.rising_edges(T + "clk")
    ns = lambda t: t * v.ts_ps / 1000.0
    S = lambda name, t: v.before(name, t)
    res, md, ev = [], [], {}

    def report(cid, title, ok, lines):
        res.append((cid, title, ok))
        md.append(f"\n## {cid} {title}: **{'PASS' if ok else 'FAIL'}**\n")
        md.extend(lines)

    # ---- per-edge samples of everything we need
    rows = []
    for t in edges:
        r = {"t": t}
        for n in ("s_tvalid", "s_tready", "s_tlast", "s_tkeep", "s_tdata", "m_tvalid", "m_tready",
                  "m_tlast", "m_tuser", "m_tkeep", "m_tdata", "tx_sym", "tx_sym_valid", "tx_sym_sof",
                  "rx_sym", "rx_sym_valid", "rx_sym_sof", "rst_n"):
            r[n] = S(T + n, t)
        for n in ("t_data", "t_valid", "t_sof", "r_data", "r_valid", "r_sof", "crc_ok", "dec",
                  "b_commit_en", "b_rollback_en", "b_abort_en", "rx_in_pkt", "rx_discard"):
            r[n] = S(L + n, t)
        rows.append(r)
    act = [r for r in rows if r["rst_n"] == 1]

    # ---- W1 ingress
    ing, cur, cur_t0 = [], bytearray(), None
    for r in act:
        if r["s_tvalid"] == 1 and r["s_tready"] == 1:
            keep, data = r["s_tkeep"] or 0, r["s_tdata"] or 0
            if cur_t0 is None and keep:
                cur_t0 = r["t"]
            db = data.to_bytes(KB, "little")
            cur += bytes(db[i] for i in range(KB) if (keep >> i) & 1)
            if r["s_tlast"] == 1:
                if cur:
                    ing.append({"t0": cur_t0, "t1": r["t"], "bytes": bytes(cur)})
                cur, cur_t0 = bytearray(), None
    report("W1", "AXI ingress", len(ing) > 0,
           [f"{len(ing)} ingress packets reconstructed from s_axis handshakes:", "",
            "| pkt | first beat (ns) | last beat (ns) | bytes | first 4 bytes (order tag) |", "|---|---|---|---|---|"] +
           [f"| P{i} | {ns(p['t0']):.0f} | {ns(p['t1']):.0f} | {len(p['bytes'])} | {p['bytes'][:4].hex()} |"
            for i, p in enumerate(ing)])
    ev["ingress"] = [(ns(p["t0"]), ns(p["t1"])) for p in ing]

    # ---- W2 / W3 FIU formation and CRC generation (link-layer TX output)
    tx_fius, cur = [], None
    for i, r in enumerate(act):
        if r["t_valid"] == 1:
            if r["t_sof"] == 1:
                cur = {"t0": r["t"], "idx": i, "words": []}
                tx_fius.append(cur)
            if cur is not None:
                cur["words"].append(r["t_data"] or 0)
                cur["t1"] = r["t"]
    ok2, ok3, lines2, lines3 = True, True, [], []
    tx_pkts, building, exp_seq = [], None, 0
    lines2 += ["| FIU | t_sof (ns) | sop | eop | len | seq | magic | padding zero |", "|---|---|---|---|---|---|---|---|"]
    lines3 += ["| FIU | trailer (ns) | CRC field | zlib.crc32 | match |", "|---|---|---|---|---|"]
    for k, f in enumerate(tx_fius):
        if len(f["words"]) != FIU_WORDS:
            ok2 = False; lines2.append(f"| F{k} | {ns(f['t0']):.0f} | incomplete FIU ({len(f['words'])} words) |||||| "); continue
        tr = trailer(f["words"][-1])
        payload = b"".join(w.to_bytes(LB, "little") for w in f["words"][:-1])
        pad0 = not any(payload[tr["len"]:])
        good = tr["magic"] == MAGIC and 1 <= tr["len"] <= PAYLOAD and pad0 and tr["seq"] == exp_seq % 256
        exp_seq += 1
        if tr["sop"]:
            building = bytearray()
        if building is not None:
            building += payload[:tr["len"]]
        if tr["eop"] and building is not None:
            tx_pkts.append(bytes(building)); building = None
        ok2 &= good
        lines2.append(f"| F{k} | {ns(f['t0']):.0f} | {tr['sop']} | {tr['eop']} | {tr['len']} | {tr['seq']} | "
                      f"0x{tr['magic']:02X} | {'yes' if pad0 else 'NO'} |")
        calc = fiu_crc(f["words"])
        ok3 &= calc == tr["crc"]
        lines3.append(f"| F{k} | {ns(f['t1']):.0f} | 0x{tr['crc']:08X} | 0x{calc:08X} | {'yes' if calc == tr['crc'] else '**NO**'} |")
    same = tx_pkts == [p["bytes"] for p in ing]
    ok2 &= same
    lines2.insert(0, f"{len(tx_fius)} FIUs on the link-layer output; payload re-assembled per packet "
                     f"{'==' if same else '!='} ingress packets ({len(tx_pkts)} vs {len(ing)}).\n")
    report("W2", "FIU formation", ok2, lines2)
    report("W3", "CRC generation", ok3, lines3)
    ev["fius"] = [(ns(f["t0"]), ns(f.get("t1", f["t0"]))) for f in tx_fius]

    # ---- W4 lane mapping
    nmap, bad4, first4 = 0, [], None
    for i, r in enumerate(act[:-1]):
        if r["t_valid"] == 1:
            nxt = act[i + 1]
            nmap += 1
            exp = encode_word(r["t_data"] or 0)
            if not (nxt["tx_sym_valid"] == 1 and nxt["tx_sym"] == exp and nxt["tx_sym_sof"] == r["t_sof"]):
                bad4.append(ns(nxt["t"]))
            elif first4 is None:
                first4 = (ns(r["t"]), ns(nxt["t"]), r["t_data"], exp)
    l4 = [f"{nmap} transmitted words checked: tx_sym(n+1) == Gray(stripe(t_data(n))), sof and valid aligned. "
          f"Mismatches: {len(bad4)}."]
    if first4:
        w = first4[2]; s = first4[3]
        l4 += ["", f"Example at {first4[0]:.0f} ns -> {first4[1]:.0f} ns:",
               f"- t_data bytes 0..7 = `{w.to_bytes(LB, 'little')[:8].hex(' ')}` (byte b goes to lane b%4)"] + \
              [f"- lane {ln} symbols (64 bits, 32 PAM4 levels) = `0x{(s >> (ln * LANE_BITS)) & ((1 << LANE_BITS) - 1):016X}`"
               for ln in range(LANES)]
    report("W4", "Lane striping + PAM4 Gray mapping", not bad4 and nmap > 0, l4)

    # ---- W5 error injection (tx_sym vs rx_sym)
    txw = [(i, r) for i, r in enumerate(act) if r["tx_sym_valid"] == 1]
    rxw = [(i, r) for i, r in enumerate(act) if r["rx_sym_valid"] == 1]
    dly = (rxw[0][0] - txw[0][0]) if txw and rxw else 0
    inj, fiu_no, word_no = [], -1, 0
    for (i, r) in txw:
        if r["tx_sym_sof"] == 1:
            fiu_no += 1; word_no = 0
        else:
            word_no += 1
        j = i + dly
        if j < len(act) and act[j]["rx_sym_valid"] == 1:
            d = (r["tx_sym"] or 0) ^ (act[j]["rx_sym"] or 0)
            if d:
                syms = [k for k in range(LINK_W // 2) if (d >> (2 * k)) & 3]
                lanes = sorted({k // (LANE_BITS // 2) for k in syms})
                inj.append({"fiu": fiu_no, "word": word_no, "t_tx": ns(r["t"]), "t_rx": ns(act[j]["t"]),
                            "nsym": len(syms), "lanes": lanes, "first": syms[0] % (LANE_BITS // 2)})
    corrupted_fius = sorted({x["fiu"] for x in inj})
    report("W5", "Error injection (channel)", True,
           [f"channel delay detected: {dly} cycles. {len(inj)} corrupted words in FIUs {corrupted_fius}.", "",
            "| FIU | word | tx time (ns) | rx time (ns) | symbols changed | lanes | first symbol in lane |",
            "|---|---|---|---|---|---|---|"] +
           [f"| F{x['fiu']} | {x['word']} | {x['t_tx']:.0f} | {x['t_rx']:.0f} | {x['nsym']} | {x['lanes']} | {x['first']} |"
            for x in inj])
    ev["injections"] = [(x["t_tx"], x["t_rx"], x["fiu"], x["word"], x["lanes"]) for x in inj]

    # ---- W6 / W7 RX CRC check + decisions
    rx_fius, cur = [], None
    for i, r in enumerate(act):
        if r["r_valid"] == 1:
            if r["r_sof"] == 1:
                cur = {"words": [], "rows": []}
                rx_fius.append(cur)
            if cur is not None:
                cur["words"].append(r["r_data"] or 0)
                cur["rows"].append(r)
    ok6, ok7, l6, l7 = True, True, [], []
    l6 += ["| FIU | trailer at RX (ns) | CRC field | recomputed | expected crc_ok | DUT crc_ok |", "|---|---|---|---|---|---|"]
    l7 += ["| FIU | expected decision | DUT dec | commit | rollback | abort | check |", "|---|---|---|---|---|---|---|"]
    in_pkt, discard, exp_egress, curpkt = 0, 0, [], None
    for k, f in enumerate(rx_fius):
        if len(f["words"]) != FIU_WORDS:
            continue
        trow = f["rows"][-1]
        tr = trailer(f["words"][-1])
        calc = fiu_crc(f["words"])
        crc_exp = int(calc == tr["crc"])
        ok6 &= (trow["crc_ok"] == crc_exp)
        l6.append(f"| F{k} | {ns(trow['t']):.0f} | 0x{tr['crc']:08X} | 0x{calc:08X} | {crc_exp} | {trow['crc_ok']} |")
        # spec decision table
        hdr_ok = tr["magic"] == MAGIC and 1 <= tr["len"] <= PAYLOAD and (tr["eop"] or tr["len"] == PAYLOAD)
        if not crc_exp:                         dec = 1
        elif not hdr_ok:                        dec = 2
        elif tr["sop"] and in_pkt:              dec = 3
        elif not tr["sop"] and not in_pkt:      dec = 4
        else:                                   dec = 0
        exp_abort = int(dec in (1, 2, 3) and in_pkt)
        exp_commit, exp_rb = int(dec == 0), int(dec != 0)
        if exp_abort and curpkt is not None:
            curpkt["err"] = 1; curpkt["closed"] = True
        if dec == 0:
            pay = b"".join(w.to_bytes(LB, "little") for w in f["words"][:-1])[:tr["len"]]
            if tr["sop"]:
                curpkt = {"bytes": bytearray(), "err": 0, "closed": False}
                exp_egress.append(curpkt)
            curpkt["bytes"] += pay
            curpkt["err"] |= tr["err"]
            if tr["eop"]:
                curpkt["closed"] = True
            in_pkt, discard = int(not tr["eop"]), 0
        else:
            in_pkt, discard = 0, 1
        good = (trow["dec"] == dec and trow["b_commit_en"] == exp_commit and
                trow["b_rollback_en"] == exp_rb and trow["b_abort_en"] == exp_abort)
        ok7 &= good
        l7.append(f"| F{k} | {DEC[dec]}{' + abort open packet' if exp_abort else ''}"
                  f"{' (discard mode)' if dec == 4 and discard else ''} | {DEC.get(trow['dec'], trow['dec'])} | "
                  f"{trow['b_commit_en']} | {trow['b_rollback_en']} | {trow['b_abort_en']} | {'ok' if good else '**MISMATCH**'} |")
        ev.setdefault("rx_trailers", []).append((ns(trow["t"]), k, DEC[dec]))
    report("W6", "CRC check at the receiver", ok6 and len(rx_fius) > 0,
           [f"{len(rx_fius)} received FIUs; CRC recomputed from the received (possibly corrupted) words.", ""] + l6)
    report("W7", "Packet discard / abort decisions", ok7 and len(rx_fius) > 0,
           ["Expected decision from the spec table (CRC -> header -> sop-while-open -> continuation-without-packet -> accept), "
            "compared with DUT `dec`, `b_commit_en`, `b_rollback_en`, `b_abort_en` at each trailer cycle.", ""] + l7)

    # ---- W8 egress
    eg, cur, t0 = [], bytearray(), None
    for r in act:
        if r["m_tvalid"] == 1 and r["m_tready"] == 1:
            if t0 is None:
                t0 = r["t"]
            keep, data = r["m_tkeep"] or 0, r["m_tdata"] or 0
            db = data.to_bytes(KB, "little")
            cur += bytes(db[i] for i in range(KB) if (keep >> i) & 1)
            if r["m_tlast"] == 1:
                eg.append({"t0": t0, "t1": r["t"], "bytes": bytes(cur), "tuser": r["m_tuser"]})
                cur, t0 = bytearray(), None
    exp = [(bytes(p["bytes"]), p["err"]) for p in exp_egress]
    got = [(p["bytes"], p["tuser"]) for p in eg]
    ok8 = exp == got
    l8 = [f"expected {len(exp)} egress packets (derived from W6/W7), observed {len(got)}: "
          f"{'identical bytes, tlast and tuser' if ok8 else 'MISMATCH'}.", "",
          "| egress pkt | first beat (ns) | tlast (ns) | bytes | tuser | matches ingress packet |", "|---|---|---|---|---|---|"]
    for i, p in enumerate(eg):
        src = next((j for j, q in enumerate(ing) if q["bytes"].startswith(p["bytes"])), None)
        full = src is not None and len(ing[src]["bytes"]) == len(p["bytes"])
        rel = "-" if src is None else (f"P{src} (complete)" if full else f"P{src} (first {len(p['bytes'])} B, truncated)")
        ok8 &= src is not None and (full or p["tuser"] == 1)
        l8.append(f"| E{i} | {ns(p['t0']):.0f} | {ns(p['t1']):.0f} | {len(p['bytes'])} | {p['tuser']} | {rel} |")
    dropped = [f"P{j}" for j, q in enumerate(ing) if not any(q["bytes"].startswith(p["bytes"]) for p in eg)]
    l8.append(f"\nIngress packets with no egress packet (discarded): {', '.join(dropped) if dropped else 'none'}.")
    report("W8", "AXI egress", ok8, l8)
    ev["egress"] = [(ns(p["t0"]), ns(p["t1"]), p["tuser"]) for p in eg]

    allok = all(x[2] for x in res)
    head = [f"# Waveform verification — `{a.vcd}`", "",
            "Generated by `sim/verify_waves.py` directly from the VCD (pre-edge samples at every rising edge of "
            "`tb_top.clk`). Expected values are recomputed from the specification in Python.", "",
            "| Check | Mechanism | Result |", "|---|---|---|"] + \
           [f"| {c} | {t} | **{'PASS' if o else 'FAIL'}** |" for c, t, o in res] + \
           ["", f"**Overall: {'PASS' if allok else 'FAIL'}**"]
    text = "\n".join(head + md) + "\n"
    print("\n".join(f"{c} {t}: {'PASS' if o else 'FAIL'}" for c, t, o in res))
    print(f"WAVEFORM VERIFICATION {'PASS' if allok else 'FAIL'}")
    if a.md:
        open(a.md, "w").write(text)
    if a.json:
        json.dump(ev, open(a.json, "w"), indent=1)
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
