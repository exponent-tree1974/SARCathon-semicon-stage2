#!/usr/bin/env python3
"""
render_waves.py - draw waveform "screenshots" (PNG) directly from a VCD, and
write matching GTKWave save files (.gtkw) so the same views can be opened in GTKWave.

The pictures are rendered from the simulator's VCD values (no re-simulation):
1-bit signals as logic traces, buses as hex-labelled segments, the clock as a
square wave, and event markers from verify_waves.py (--json) as dashed lines.

Usage: python sim/render_waves.py <waves.vcd> <markers.json> <out_dir>
"""
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                     # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from verify_waves import VCD                        # noqa: E402

T, D, L, P = "tb_top.", "tb_top.dut.", "tb_top.dut.u_link.", "tb_top.dut.u_packetizer."
DEC = {0: "ACC", 1: "CRC", 2: "HDR", 3: "SOP", 4: "CONT"}   # ACCept, CRC err, HDR err, SOP-while-open, CONTinuation w/o packet

# (label, vcd signal, [hi:lo] slice or None, format)   format: bit | hex | dec | enum
VIEWS = {
    "01_axi_ingress_and_fiu_formation": dict(
        title="AXI ingress -> FIU formation (P0 100 B = 2 beats -> 4 link words + 3 pad + trailer)",
        win=("ingress", 0, -5, "fius", 1, 0), marks=["fius"],
        sigs=[("clk", T + "clk", None, "bit"),
              ("s_axis_tvalid", T + "s_tvalid", None, "bit"),
              ("s_axis_tready", T + "s_tready", None, "bit"),
              ("s_axis_tlast", T + "s_tlast", None, "bit"),
              ("s_axis_tkeep", T + "s_tkeep", None, "hex"),
              ("s_axis_tdata[31:0]", T + "s_tdata", (31, 0), "hex"),
              ("pktz.p_valid", P + "p_valid", None, "bit"),
              ("pktz.p_first", P + "p_first", None, "bit"),
              ("pktz.p_end", P + "p_end", None, "bit"),
              ("pktz.widx", P + "widx", None, "dec"),
              ("pktz.p_nbytes", P + "p_nbytes", None, "dec"),
              ("link.t_valid", L + "t_valid", None, "bit"),
              ("link.t_sof", L + "t_sof", None, "bit"),
              ("link.t_data[31:0]", L + "t_data", (31, 0), "hex")]),
    "02_crc_generation": dict(
        title="CRC-32 generation and trailer insertion (FIU F0; trailer fields shown only on the trailer word)",
        win=("fius", 0, -15, "fius", 0, 25), marks=[],
        sigs=[("clk", T + "clk", None, "bit"),
              ("link.t_valid", L + "t_valid", None, "bit"),
              ("link.t_sof", L + "t_sof", None, "bit"),
              ("link.trl_pend", L + "trl_pend", None, "bit"),
              ("link.tx_crc (running)", L + "tx_crc", None, "hex"),
              ("link.tx_crc_next", L + "tx_crc_next", None, "hex"),
              ("trailer [255:224] CRC", L + "t_data", (255, 224), "hex", (L + "trl_pend", 10)),
              ("trailer [39:32] magic", L + "t_data", (39, 32), "hex", (L + "trl_pend", 10)),
              ("trailer [31:24] seq", L + "t_data", (31, 24), "dec", (L + "trl_pend", 10)),
              ("trailer [17:16] eop,sop", L + "t_data", (17, 16), "hex", (L + "trl_pend", 10)),
              ("trailer [15:0] len", L + "t_data", (15, 0), "dec", (L + "trl_pend", 10))]),
    "03_lane_mapping": dict(
        title="Byte striping (byte b -> lane b%4) + PAM4 Gray mapping: t_data(n) -> tx_sym(n+1), first FIU words",
        win=("fius", 0, -12, "fius", 0, 52), marks=[],
        sigs=[("clk", T + "clk", None, "bit"),
              ("link.t_valid", L + "t_valid", None, "bit"),
              ("link.t_sof", L + "t_sof", None, "bit"),
              ("link.t_data[63:0]", L + "t_data", (63, 0), "hex"),
              ("tx_sym_valid", T + "tx_sym_valid", None, "bit"),
              ("tx_sym_sof", T + "tx_sym_sof", None, "bit"),
              ("lane0 tx_sym[63:0]", T + "tx_sym", (63, 0), "hex"),
              ("lane1 tx_sym[127:64]", T + "tx_sym", (127, 64), "hex"),
              ("lane2 tx_sym[191:128]", T + "tx_sym", (191, 128), "hex"),
              ("lane3 tx_sym[255:192]", T + "tx_sym", (255, 192), "hex")]),
    "04a_error_injection_lane2_word": dict(
        title="Error injection: every PAM4 symbol of lane 2 in F2 word 1 moved one level (rx = tx + 2 cycles)",
        win=("injections", 0, -25, "injections", 0, 25), marks=["injections"],
        sigs=[("clk", T + "clk", None, "bit"),
              ("tx_sym_valid", T + "tx_sym_valid", None, "bit"),
              ("tx lane2 [191:128]", T + "tx_sym", (191, 128), "hex"),
              ("rx lane2 [191:128]", T + "rx_sym", (191, 128), "hex"),
              ("tx lane1 [127:64]", T + "tx_sym", (127, 64), "hex"),
              ("rx lane1 [127:64]", T + "rx_sym", (127, 64), "hex"),
              ("rx_sym_valid", T + "rx_sym_valid", None, "bit")]),
    "04b_error_injection_single_symbol": dict(
        title="Error injection: one PAM4 symbol (lane 0, symbol 10) in F3 word 1",
        win=("injections", 1, -25, "injections", 1, 25), marks=["injections"],
        sigs=[("clk", T + "clk", None, "bit"),
              ("tx_sym_valid", T + "tx_sym_valid", None, "bit"),
              ("tx lane0 [63:0]", T + "tx_sym", (63, 0), "hex"),
              ("rx lane0 [63:0]", T + "rx_sym", (63, 0), "hex"),
              ("rx_sym_valid", T + "rx_sym_valid", None, "bit")]),
    "05_crc_check_and_discard": dict(
        title="RX CRC check, abort and discard (crc_ok/dec shown only on trailer words, where they are evaluated)",
        win=("rx_trailers", 1, -75, "rx_trailers", 6, 15), marks=["rx_trailers"],
        sigs=[("clk", T + "clk", None, "bit"),
              ("link.r_valid", L + "r_valid", None, "bit"),
              ("link.r_sof", L + "r_sof", None, "bit"),
              ("link.ridx", L + "ridx", None, "dec"),
              ("link.trl_word", L + "trl_word", None, "bit"),
              ("link.crc_ok", L + "crc_ok", None, "hex", (L + "trl_word", 0)),
              ("link.dec", L + "dec", None, "enum", (L + "trl_word", 0)),
              ("b_commit_en", L + "b_commit_en", None, "bit"),
              ("b_rollback_en", L + "b_rollback_en", None, "bit"),
              ("b_abort_en", L + "b_abort_en", None, "bit"),
              ("rx_in_pkt", L + "rx_in_pkt", None, "bit"),
              ("rx_discard", L + "rx_discard", None, "bit"),
              ("ev_rx_crc_err", L + "ev_rx_crc_err", None, "bit"),
              ("ev_rx_discard", L + "ev_rx_discard", None, "bit")]),
    "06_axi_egress": dict(
        title="AXI egress: P0 complete, P1 truncated with tuser=1, P4 complete (P2, P3 discarded); payload shown only while tvalid=1",
        win=("egress", 0, -20, "egress", 2, 20), marks=["egress"],
        sigs=[("clk", T + "clk", None, "bit"),
              ("m_axis_tvalid", T + "m_tvalid", None, "bit"),
              ("m_axis_tready", T + "m_tready", None, "bit"),
              ("m_axis_tlast", T + "m_tlast", None, "hex", (T + "m_tvalid", 0)),
              ("m_axis_tuser", T + "m_tuser", None, "hex", (T + "m_tvalid", 0)),
              ("m_axis_tkeep", T + "m_tkeep", None, "hex", (T + "m_tvalid", 0)),
              ("m_axis_tdata[31:0]", T + "m_tdata", (31, 0), "hex", (T + "m_tvalid", 0)),
              ("rxbuf.count", D + "u_rxbuf.count", None, "dec"),
              ("rx_credit_return", T + "rx_credit_return", None, "dec")]),
    "06b_axi_egress_truncated_packet_zoom": dict(
        title="AXI egress zoom: P1 aborted after F1 -> 224 B delivered (3.5 beats), tlast with tuser=1",
        win=("egress", 1, -15, "egress", 1, 15), marks=["egress"],
        sigs=[("clk", T + "clk", None, "bit"),
              ("m_axis_tvalid", T + "m_tvalid", None, "bit"),
              ("m_axis_tready", T + "m_tready", None, "bit"),
              ("m_axis_tlast", T + "m_tlast", None, "hex", (T + "m_tvalid", 0)),
              ("m_axis_tuser", T + "m_tuser", None, "hex", (T + "m_tvalid", 0)),
              ("m_axis_tkeep", T + "m_tkeep", None, "hex", (T + "m_tvalid", 0)),
              ("m_axis_tdata[31:0]", T + "m_tdata", (31, 0), "hex", (T + "m_tvalid", 0)),
              ("link.b_abort_en", L + "b_abort_en", None, "bit"),
              ("rxbuf.count", D + "u_rxbuf.count", None, "dec")]),
}


def window(ev, spec):
    k0, i0, o0, k1, i1, o1 = spec
    t0 = ev[k0][i0][0] + o0
    e1 = ev[k1][i1]
    t1 = (e1[1] if isinstance(e1[1], (int, float)) and k1 != "rx_trailers" else e1[0]) + o1
    return t0, t1


def series(v, name, sl, t0_ps, t1_ps):
    c = v.code(name)
    pts, last = [], None
    for t, val in v.chg[c]:
        if t < t0_ps:
            last = val
            continue
        if t > t1_ps:
            break
        pts.append((t, val))
    if last is not None:
        pts.insert(0, (t0_ps, last))
    out = []
    for t, val in pts:
        if any(ch in val for ch in "xXzZ"):
            out.append((t, None))
        else:
            x = int(val, 2)
            if sl:
                x = (x >> sl[1]) & ((1 << (sl[0] - sl[1] + 1)) - 1)
            out.append((t, x))
    # drop repeats
    ded = []
    for t, x in out:
        if not ded or ded[-1][1] != x:
            ded.append((t, x))
    return ded


def fmt(x, f, width):
    if x is None:
        return "x"
    if f == "dec":
        return str(x)
    if f == "enum":
        return DEC.get(x, str(x))
    digits = max(1, (width + 3) // 4)
    s = f"{x:0{digits}X}"
    return s if len(s) <= 16 else s[:6] + ".." + s[-6:]


def render(v, view_name, spec, ev, out_dir, vcd_path):
    t0, t1 = window(ev, spec["win"])
    sc = 1000.0 / v.ts_ps                         # ns -> VCD ticks
    t0p, t1p = int(t0 * sc), int(t1 * sc)
    sigs = spec["sigs"]
    h = 0.42 * len(sigs) + 1.6
    fig, ax = plt.subplots(figsize=(15, h))
    ax.set_xlim(t0, t1)
    for row, sig in enumerate(sigs):
        label, name, sl, f = sig[:4]
        qual = sig[4] if len(sig) > 4 else None
        y = row
        try:
            pts = series(v, name, sl, t0p, t1p)
        except KeyError:
            ax.text(t0, y, f"  {label}: not in VCD", va="center", fontsize=8, color="red")
            continue
        width = (sl[0] - sl[1] + 1) if sl else v.width[v.code(name)]
        pts = [(t / sc, x) for t, x in pts] + [(t1, None if not pts else pts[-1][1])]
        if qual:   # mask values while the qualifier (shifted by qual[1] ns) is 0 -> shown as "-"
            qs = [(t / sc + qual[1], x) for t, x in series(v, qual[0], None, t0p - int(qual[1] * sc), t1p)]
            def qv(tm):
                val = 0
                for tq, xq in qs:
                    if tq <= tm + 1e-9:
                        val = xq
                return val
            cuts = sorted({t for t, _ in pts} | {t for t, _ in qs if t0 <= t <= t1})
            raw = pts
            def rv(tm):
                val = None
                for tr, xr in raw:
                    if tr <= tm + 1e-9:
                        val = xr
                return val
            pts = [(tc, rv(tc) if qv(tc) == 1 else "masked") for tc in cuts if tc <= t1]
            pts.append((t1, None))
        if f == "bit":
            xs, ys = [], []
            for (ta, xa), (tb, _) in zip(pts, pts[1:]):
                level = 0.3 if xa == 1 else (-0.3 if xa == 0 else 0.0)
                xs += [ta, tb]; ys += [y - level, y - level]
                if xa is None:
                    ax.fill_between([ta, tb], y - 0.3, y + 0.3, color="#d33", alpha=0.25, lw=0)
            ax.plot(xs, ys, color="#1a7f37" if "clk" not in label else "#555", lw=1.3, drawstyle="default")
        else:
            for (ta, xa), (tb, _) in zip(pts, pts[1:]):
                if tb <= ta:
                    continue
                d = min(1.2, (tb - ta) * 0.15)
                if xa == "masked":
                    ax.plot([ta, tb], [y, y], color="#bbb", lw=0.8)
                    continue
                ax.fill([ta, ta + d, tb - d, tb, tb - d, ta + d], [y, y - 0.3, y - 0.3, y, y + 0.3, y + 0.3],
                        color="#e8f0fe" if xa else "#f4f4f4", ec="#1f4e9d", lw=0.8)
                txt = fmt(xa, f, width)
                if (tb - ta) > len(txt) * (t1 - t0) / 260:
                    ax.text((ta + tb) / 2, y, txt, ha="center", va="center", fontsize=7, family="monospace")
    ax.set_yticks(range(len(sigs)))
    ax.set_yticklabels([s[0] for s in sigs], fontsize=8, family="monospace")
    ax.set_xlabel("time (ns)")
    ax.grid(axis="x", color="#ddd", lw=0.5)
    # event markers, drawn mid-cycle (the sampled value is held during the cycle before the edge)
    half = 5.0
    ax.set_ylim(len(sigs) - 0.2, -1.25)
    for key in spec.get("marks", []):
        for e in ev.get(key, []):
            if key == "injections":
                for tm, txt, yl in ((e[0] - half, f"inject F{e[2]} w{e[3]} lane{e[4]} (tx)", -1.0),
                                    (e[1] - half, "(rx)", -1.0)):
                    if t0 <= tm <= t1:
                        ax.axvline(tm, color="#c00", ls="--", lw=0.8, alpha=0.6)
                        ax.text(tm, yl, txt, fontsize=7, color="#c00", ha="center")
            elif key == "rx_trailers":
                tm = e[0] - half
                if t0 <= tm <= t1:
                    ax.axvline(tm, color="#b26b00", ls="--", lw=0.8, alpha=0.6)
                    ax.text(tm, -0.6, f"F{e[1]}: {e[2]}", fontsize=7, color="#b26b00", ha="center")
            elif key == "egress":
                tm = e[1] - half
                if t0 <= tm <= t1:
                    ax.axvline(tm, color="#1f4e9d", ls="--", lw=0.8, alpha=0.6)
                    ax.text(tm, -0.6, f"tlast tuser={e[2]}", fontsize=7, color="#1f4e9d", ha="center")
            elif key == "fius":
                tm = e[0] - half
                if t0 <= tm <= t1:
                    ax.axvline(tm, color="#6a1b9a", ls="--", lw=0.8, alpha=0.6)
                    ax.text(tm, -0.6, "FIU start (t_sof)", fontsize=7, color="#6a1b9a", ha="center")
    ax.set_title(f"{spec['title']}\nrendered from {os.path.basename(os.path.dirname(vcd_path))}/"
                 f"{os.path.basename(vcd_path)} (Icarus simulation) — window {t0:.0f}–{t1:.0f} ns",
                 fontsize=10, loc="left")
    fig.tight_layout()
    png = os.path.join(out_dir, view_name + ".png")
    fig.savefig(png, dpi=120)
    plt.close(fig)
    # matching GTKWave save file
    gtkw = os.path.join(out_dir, view_name + ".gtkw")
    seen = []
    with open(gtkw, "w") as g:
        g.write(f'[*] view "{spec["title"]}" generated by sim/render_waves.py\n')
        g.write(f'[dumpfile] "{os.path.relpath(os.path.abspath(vcd_path)).replace(os.sep, "/")}"\n'
                f'[timestart] {int(t0 * sc)}\n')
        g.write("[*] open with: gtkwave <waves.vcd> <this .gtkw>  (run from the project root)\n")
        g.write(f"[size] 1600 900\n")
        for sig in sigs:
            name = sig[1]
            if name in seen:
                continue
            seen.append(name)
            w = v.width[v.code(name)]
            g.write(("@28\n" if w == 1 else "@22\n") + (name if w == 1 else f"{name}[{w - 1}:0]") + "\n")
    return png, gtkw, (t0, t1)


def main():
    vcd_path, markers, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    os.makedirs(out_dir, exist_ok=True)
    v = VCD(vcd_path)
    ev = json.load(open(markers))
    for name, spec in VIEWS.items():
        png, gtkw, (t0, t1) = render(v, name, spec, ev, out_dir, vcd_path)
        print(f"{png}  ({t0:.0f}-{t1:.0f} ns)   GTKWave view: {gtkw}")


if __name__ == "__main__":
    main()
