#!/usr/bin/env python3
"""
Mutation check: proves the testbenches can detect real RTL bugs.

Each mutation injects one deliberate bug into a temporary copy of rtl/, then
compiles and runs a testbench. A mutation is "killed" if the testbench reports
FAILED (or times out). Every mutation must be killed.

  M1..M16   core datapath (v3)               bench core,   full tb_top suite
  M17..M31  v4 features: stream ID, error/IRQ CSRs, performance counters
                                             bench core,   listed tests
  A1..A5    axis_rr_arbiter / mux top        bench arb,    listed tests
  R1..R5    fiu_replay_buffer                bench replay, unit test
A mutant with a test list stops at the first test that fails (that test
"kills" it); the tests are run one simulation each, in the order given.

Usage (from project root):  python sim/run_mutation_check.py [--seed N] [--jobs N] [--only M17 A1 ...]
Requires iverilog/vvp on PATH.
"""
import argparse
import concurrent.futures as cf
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BENCH = {"core": ("tb_top", "sim/tb_files.f"), "arb": ("tb_arb", "sim/tb_arb_files.f"),
         "replay": ("tb_replay", "sim/tb_replay_files.f")}

MUTATIONS = [
    ("M1 RX ignores CRC result",
     "rtl/fiu_link_layer.sv",
     "wire crc_ok = (~rx_crc_next == rt_crc);", "wire crc_ok = 1'b1;"),
    ("M2 depacketizer lookahead removed",
     "rtl/axis_depacketizer.sv",
     "if (!found && (b_count > PTR_W'(R))) take = POP_W'(R);",
     "if (!found && (b_count >= PTR_W'(R))) take = POP_W'(R);"),
    ("M3 zero-length tlast not merged",
     "rtl/axis_packet_ingress.sv",
     "h_last  <= 1'b1;                    // merge zero-length tlast",
     "h_last  <= 1'b0;"),
    ("M4 TX Gray map uses wrong bit order",
     "rtl/lane_striper_gray_mapper.sv",
     "mapped[2*k +: 2] = {striped[2*k+1], striped[2*k+1] ^ striped[2*k]};",
     "mapped[2*k +: 2] = {striped[2*k], striped[2*k+1] ^ striped[2*k]};"),
    ("M5 packetizer drops padding phase",
     "rtl/axis_packetizer.sv",
     "if (pkt_end_here) pad <= 1'b1;", "if (pkt_end_here) pad <= 1'b0;"),
    ("M6 skid buffer loses parked beat",
     "rtl/common/axis_skid_buffer.sv",
     "if (skid_valid)  out_data <= skid_data;", "if (skid_valid)  out_data <= s_data;"),
    ("M7 RX buffer abort patch disabled",
     "rtl/fiu_rx_buffer.sv",
     "m_last[abort_idx] <= 1'b1;", "m_last[abort_idx] <= 1'b0;"),
    ("M8 CSR SLVERR replaced by OKAY",
     "rtl/csr_status.sv",
     "s_axil_bresp <= SLVERR;          // RO or unmapped", "s_axil_bresp <= OKAY;"),
    ("M9 RX ignores trailer magic",
     "rtl/fiu_link_layer.sv",
     "wire hdr_ok = (rt_magic == MAGIC) && len_ok;", "wire hdr_ok = len_ok;"),
    ("M10 credits not returned on rollback (leak)",
     "rtl/fiu_rx_buffer.sv",
     "+ (rollback_en ? 8'(spec_all)          : 8'd0);", "+ 8'd0;"),
    ("M11 sequence-error counter stuck at 0",
     "rtl/fiu_link_layer.sv",
     "ev_rx_seq_err   <= trl_word && crc_ok && (rt_seq != rx_exp_seq);", "ev_rx_seq_err   <= 1'b0;"),
    ("M12 ingress tready high during reset",
     "rtl/common/axis_skid_buffer.sv",
     "assign s_ready = rdy_en & ~skid_valid;", "assign s_ready = ~skid_valid;"),
    ("M13 packet error not sticky across beats",
     "rtl/axis_depacketizer.sv",
     "pkt_err   <= beat_last ? 1'b0 : (pkt_err || beat_err);", "pkt_err   <= 1'b0;"),
    ("M14 partial non-last beat not flagged",
     "rtl/axis_packet_ingress.sv",
     "wire   h_partial_mid = (h_nb != FULL_NB) && !h_last;", "wire   h_partial_mid = 1'b0;"),
    ("M15 egress tkeep off by one",
     "rtl/axis_depacketizer.sv",
     "beat_keep[k*LB + b] = (LNB_W'(b) < b_nb[k*LNB_W +: LNB_W]);",
     "beat_keep[k*LB + b] = (LNB_W'(b) <= b_nb[k*LNB_W +: LNB_W]);"),
    ("M16 RX accepts continuation without open packet",
     "rtl/fiu_link_layer.sv",
     "else if (!rt_sop && !rx_in_pkt)        dec = D_CONT_NO_PKT;   // incl. discard mode",
     "else if (1'b0)                         dec = D_CONT_NO_PKT;"),
]


CORE_FULL = None   # full suite

V4 = [
    # ---------------- core: stream ID ----------------
    ("M17 tid not written into the FIU trailer", "rtl/fiu_link_layer.sv",
     "build_trailer[40 +: TID_W] = tid;", "build_trailer[40 +: TID_W] = '0;",
     "core", ["sizes_directed"]),
    ("M18 RX ignores a tid change inside a packet", "rtl/fiu_link_layer.sv",
     "else if (!rt_sop && rx_in_pkt && (rt_tid != rx_tid)) dec = D_TID;",
     "else if (1'b0) dec = D_TID;", "core", ["header_forgery"]),
    ("M19 egress tid not held for the whole packet", "rtl/axis_depacketizer.sv",
     "wire  [TID_W-1:0]    beat_tid = in_pkt ? pkt_tid : b_tid;",
     "wire  [TID_W-1:0]    beat_tid = b_tid;", "core", ["sizes_directed", "random_stalls"]),
    ("M20 RX buffer stores tid on the wrong entry", "rtl/fiu_rx_buffer.sv",
     "if (commit_en && !wr_en) m_tid[cm_ptr[AW-1:0]] <= commit_tid;",
     "if (commit_en && !wr_en) m_tid[patch_idx] <= commit_tid;", "core", ["sizes_directed", "random_stalls"]),
    # ---------------- core: error reporting ----------------
    ("M21 ERR_STATUS not sticky", "rtl/csr_status.sv",
     "else           err_status <= (err_status & ~err_clr) | err_set;",
     "else           err_status <= err_set;", "core", ["err_csr_perf"]),
    ("M22 ERR_STATUS W1C ignores byte strobes", "rtl/csr_status.sv",
     "wire [31:0] w1c_mask  = apply_strb(32'h0, w_data, w_strb);",
     "wire [31:0] w1c_mask  = w_data;", "core", ["err_csr_perf"]),
    ("M23 irq ignores ERR_IRQ_EN", "rtl/csr_status.sv",
     "irq        <= |(err_status & irq_en);", "irq        <= |err_status;", "core", ["err_csr_perf"]),
    ("M24 LAST_ERR records the wrong expected sequence", "rtl/fiu_link_layer.sv",
     "err_valid <= 1'b1; err_reason <= 3'(dec);\n                err_exp_seq <= rx_exp_seq;",
     "err_valid <= 1'b1; err_reason <= 3'(dec);\n                err_exp_seq <= rx_exp_seq + 1'b1;",
     "core", ["err_csr_perf"]),
    ("M25 sequence errors not captured in LAST_ERR", "rtl/fiu_link_layer.sv",
     "end else if (trl_word && crc_ok && (rt_seq != rx_exp_seq)) begin\n                err_valid <= 1'b1; err_reason <= 3'd7;",
     "end else if (1'b0) begin\n                err_valid <= 1'b1; err_reason <= 3'd7;",
     "core", ["err_csr_perf"]),
    ("M26 counter clear does not clear LAST_ERR", "rtl/csr_status.sv",
     "if (clear_req)      last_err <= '0;", "if (1'b0)           last_err <= '0;", "core", ["err_csr_perf"]),
    # ---------------- core: performance counters ----------------
    ("M27 IN_BYTES counts whole beats", "rtl/axis_pcie_link_top.sv",
     "assign cnt_inc[11*8 +: 8] = popcount(in_keep_q);      // IN_BYTES",
     "assign cnt_inc[11*8 +: 8] = (in_keep_q != '0) ? 8'd64 : 8'd0;", "core", ["sizes_directed"]),
    ("M28 OUT_STALL counts every valid cycle", "rtl/axis_pcie_link_top.sv",
     "out_stall_q <= m_axis_tvalid && !m_axis_tready;", "out_stall_q <= m_axis_tvalid;",
     "core", ["sizes_directed"]),
    ("M29 CREDIT_STALL ignores link_en", "rtl/fiu_link_layer.sv",
     "ev_credit_stall <= p_valid && p_first && !tx_in_fiu && !trl_pend && link_en && !credit_ok;",
     "ev_credit_stall <= p_valid && p_first && !tx_in_fiu && !trl_pend && !credit_ok;",
     "core", ["link_enable", "credit_stress"]),
    ("M30 TX_WORDS counts FIU starts only", "rtl/axis_pcie_link_top.sv",
     "assign cnt_inc[16*8 +: 8] = {7'b0, t_valid};          // TX_WORDS",
     "assign cnt_inc[16*8 +: 8] = {7'b0, t_valid && t_sof};", "core", ["sizes_directed"]),
    ("M31 counter saturation replaced by wrap-around at 16 bits", "rtl/csr_status.sv",
     "else                cnt[c] <= sum[c][31:0];", "else                cnt[c] <= {16'h0, sum[c][15:0]};",
     "core", ["random_stalls"]),
    # ---------------- arbiter ----------------
    ("A1 arbiter releases the lock on any beat", "rtl/axis_rr_arbiter.sv",
     "end else if (m_fire && m_tlast) begin\n            locked <= 1'b0;",
     "end else if (m_fire) begin\n            locked <= 1'b0;", "arb", ["arb_saturated_equal", "arb_random_stalls"]),
    ("A2 fixed priority instead of round robin", "rtl/axis_rr_arbiter.sv",
     "            last   <= grant;", "            last   <= ID_W'(N - 1);", "arb", ["arb_saturated_equal", "arb_starvation"]),
    ("A3 s_tready not gated by the selection", "rtl/axis_rr_arbiter.sv",
     "s_tready[i] = m_tready && (sel == ID_W'(i));", "s_tready[i] = m_tready;",
     "arb", ["arb_saturated_equal"]),
    ("A4 mux top drops the stream ID", "rtl/axis_pcie_link_mux2_top.sv",
     ".s_axis_tid(a_tid),", ".s_axis_tid(1'b0),", "arb", ["arb_saturated_equal"]),
    ("A5 selection not frozen while the output is stalled", "rtl/axis_rr_arbiter.sv",
     "else                   locked <= 1'b1;     // hold until tlast accepted",
     "else if (m_fire)       locked <= 1'b1;", "arb", ["arb_random_stalls", "arb_saturated_equal"]),
    # ---------------- replay buffer ----------------
    ("R1 ACK frees FIUs of a pending replay", "rtl/placeholder/fiu_replay_buffer.sv",
     "(busy ? rseq : nxt) - oldest", "(rp_active ? rseq : nxt) - oldest", "replay", ["replay_buffer_unit"]),
    ("R2 replay stops one FIU early", "rtl/placeholder/fiu_replay_buffer.sv",
     "if (rseq + 1'b1 == nxt) rp_active <= 1'b0;", "if (rseq + 2'd2 == nxt) rp_active <= 1'b0;",
     "replay", ["replay_buffer_unit"]),
    ("R3 NAK window off by one", "rtl/placeholder/fiu_replay_buffer.sv",
     "(nak_d < count)", "(nak_d <= count)", "replay", ["replay_buffer_unit"]),
    ("R4 full threshold off by one", "rtl/placeholder/fiu_replay_buffer.sv",
     "wire             full    = (count == SEQ_W'(N_FIU));",
     "wire             full    = (count == SEQ_W'(N_FIU + 1));", "replay", ["replay_buffer_unit"]),
    ("R5 replay may start in the middle of a captured FIU", "rtl/placeholder/fiu_replay_buffer.sv",
     "if (nak_pend && (widx == '0) && !in_fire) begin", "if (nak_pend) begin", "replay", ["replay_buffer_unit"]),
]
MUTATIONS = [m + ("core", CORE_FULL) for m in MUTATIONS] + V4


def run_one(mut, seed):
    name, rel, old, new, bench, tests = mut
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        shutil.copytree(ROOT / "rtl", tmp / "rtl")
        shutil.copytree(ROOT / "tb", tmp / "tb")
        (tmp / "results").mkdir()
        src = (tmp / rel).read_text()
        if src.count(old) != 1:
            return name, "SETUP-ERROR (pattern not found exactly once)"
        (tmp / rel).write_text(src.replace(old, new))
        top, tbf = BENCH[bench]
        files = []
        for fl in ("sim/rtl_files.f", tbf):
            files += [l.strip() for l in (ROOT / fl).read_text().splitlines()
                      if l.strip() and not l.strip().startswith("+incdir")]
        comp = subprocess.run(["iverilog", "-g2012", "-I", "tb/env", "-s", top, "-o", "simv", *files],
                              cwd=tmp, capture_output=True, text=True)
        if comp.returncode != 0:
            return name, "INVALID MUTANT (compile error) - fix the mutation"
        for tst in (tests or [None]):
            plus = [f"+seed={seed}"] + ([f"+test={tst}"] if tst and bench != "replay" else []) + \
                   (["+cycles=100000"] if bench == "replay" else [])
            try:
                sim = subprocess.run(["vvp", "-n", "simv", *plus], cwd=tmp,
                                     capture_output=True, text=True, timeout=2400)
                out = sim.stdout
            except subprocess.TimeoutExpired:
                return name, f"KILLED (timeout{' in ' + tst if tst else ''})"
            if "[SIM-RESULT] PASSED" not in out:
                failing = [l.split()[1] for l in out.splitlines() if l.startswith("[TEST-RESULT]") and ": FAIL" in l]
                return name, "KILLED by " + (", ".join(failing) if failing else (tst or "watchdog/other"))
        return name, "SURVIVED  <-- testbench gap"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--only", nargs="+", help="run only these mutation ids, e.g. --only M10 M12")
    args = ap.parse_args()
    global MUTATIONS
    if args.only:
        MUTATIONS = [m for m in MUTATIONS if m[0].split()[0] in args.only]
    with cf.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        results = list(ex.map(lambda m: run_one(m, args.seed), MUTATIONS))
    survived = 0
    for name, res in results:
        print(f"{name:58s} {res}")
        survived += not res.startswith("KILLED")
    print(f"MUTATION CHECK {'PASS' if survived == 0 else 'FAIL'}: "
          f"{len(results) - survived}/{len(results)} mutations killed")
    return 0 if survived == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
