#!/usr/bin/env bash
# Icarus Verilog regression (Linux / macOS / WSL). All arguments are passed to
# sim/run_regression.py, e.g.:
#   sim/run_icarus.sh                          # seed 1, all tests
#   sim/run_icarus.sh --seeds 1 2 3 4 5        # multi-seed
#   sim/run_icarus.sh --test lane_corruption --seeds 9 --vcd
#   sim/run_icarus.sh --repro-check            # determinism check
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PYTHON:-python3}
exec "$PY" sim/run_regression.py --sim icarus "$@"
