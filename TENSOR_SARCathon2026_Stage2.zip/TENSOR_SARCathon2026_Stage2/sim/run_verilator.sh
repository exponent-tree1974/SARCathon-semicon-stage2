#!/usr/bin/env bash
# OPTIONAL Verilator (>= 5.0, needs --timing) regression, Linux / WSL.
# Enables the concurrent SVA (+define+SVA, --assert). Same options as run_icarus.sh.
#   sim/run_verilator.sh --seeds 1
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PYTHON:-python3}
exec "$PY" sim/run_regression.py --sim verilator "$@"
