// -----------------------------------------------------------------------------
// Formal property harness for axis_rr_arbiter (N=2, narrow data).
// Run: bash sim/formal/run_formal.sh   (Yosys "sat -tempinduct": base case + k-induction)
//
// Assumptions (environment):
//   A0  reset is asserted in the first cycle
//   A1  every source obeys AXI4-Stream: once tvalid is high it stays high with
//       stable tdata/tkeep/tlast until the beat is accepted
// Properties (all proved for every reachable state, unbounded):
//   P1  no output without valid input: m_tvalid == s_tvalid[m_tid], and the
//       output beat equals the selected input beat (data, keep, last)
//   P2  beat conservation: an input beat is accepted iff it is the output beat
//       accepted in the same cycle (no beat lost, duplicated or invented)
//   P3  output stability: a presented, not accepted beat stays unchanged
//   P4  packet atomicity: between the first and the tlast beat of a packet,
//       every accepted beat comes from the same source (no interleaving)
//   P5  round-robin hand-over: after a packet of source k ends, if the other
//       source is valid it owns the next packet (wait <= 1 packet: no starvation)
//   P6  work conservation: outside a packet, a valid input is always presented
// -----------------------------------------------------------------------------
module axis_rr_arbiter_props (
    input wire       clk,
    input wire       rst_n,
    input wire [7:0] s_tdata,      // 2 x 4 bits
    input wire [1:0] s_tkeep,      // 2 x 1 bit
    input wire [1:0] s_tlast,
    input wire [1:0] s_tvalid,
    input wire       m_tready,
    output wire      cov_ok        // reachability witness (see run_formal.sh)
);
    wire [1:0] s_tready;
    wire [3:0] m_tdata;
    wire       m_tkeep, m_tlast, m_tid, m_tvalid;
    wire [1:0] ev_pkt_start;

    axis_rr_arbiter #(.N(2), .DATA_W(4), .KEEP_W(1), .ID_W(1)) dut (
        .clk(clk), .rst_n(rst_n),
        .s_tdata(s_tdata), .s_tkeep(s_tkeep), .s_tlast(s_tlast), .s_tvalid(s_tvalid),
        .s_tready(s_tready),
        .m_tdata(m_tdata), .m_tkeep(m_tkeep), .m_tlast(m_tlast), .m_tid(m_tid),
        .m_tvalid(m_tvalid), .m_tready(m_tready), .ev_pkt_start(ev_pkt_start));

    wire m_fire = m_tvalid && m_tready;

    // registered copies of the previous cycle (explicit instead of $past, so
    // that every assumption/assertion is a combinational check of one step)
    reg       past_valid = 1'b0;
    reg       p_rst, p_mvalid, p_mready, p_mtlast, p_mkeep, p_mtid;
    reg [3:0] p_mdata;
    reg [7:0] p_sdata;
    reg [1:0] p_skeep, p_slast, p_stall;
    always @(posedge clk) begin
        past_valid <= 1'b1;
        p_rst    <= rst_n;
        p_mvalid <= m_tvalid;  p_mready <= m_tready;  p_mtlast <= m_tlast;
        p_mkeep  <= m_tkeep;   p_mtid   <= m_tid;     p_mdata  <= m_tdata;
        p_sdata  <= s_tdata;   p_skeep  <= s_tkeep;   p_slast  <= s_tlast;
        p_stall  <= s_tvalid & ~s_tready;
    end
    wire step_ok = past_valid && p_rst && rst_n;     // previous and current cycle out of reset

    // non-vacuity witness: both sources completed a packet, one of them a
    // multi-beat packet, and the output was stalled at least once
    reg c_done0 = 1'b0, c_done1 = 1'b0, c_multi = 1'b0, c_stall = 1'b0, c_mid = 1'b0;
    always @(posedge clk) if (rst_n) begin
        if (m_fire) c_mid <= !m_tlast;
        if (m_fire && m_tlast && m_tid == 1'b0) c_done0 <= 1'b1;
        if (m_fire && m_tlast && m_tid == 1'b1) c_done1 <= 1'b1;
        if (m_fire && m_tlast && c_mid)         c_multi <= 1'b1;
        if (m_tvalid && !m_tready)              c_stall <= 1'b1;
    end
    assign cov_ok = c_done0 && c_done1 && c_multi && c_stall;

    // ---------------- assumptions ----------------
    always @(*) begin
        if (!past_valid) assume (!rst_n);                                   // A0
        if (step_ok) begin                                                  // A1
            if (p_stall[0]) begin
                assume (s_tvalid[0]);
                assume (s_tdata[3:0] == p_sdata[3:0]);
                assume (s_tkeep[0] == p_skeep[0]);
                assume (s_tlast[0] == p_slast[0]);
            end
            if (p_stall[1]) begin
                assume (s_tvalid[1]);
                assume (s_tdata[7:4] == p_sdata[7:4]);
                assume (s_tkeep[1] == p_skeep[1]);
                assume (s_tlast[1] == p_slast[1]);
            end
        end
    end

    // ---------------- properties ----------------
    always @(*) begin
        if (past_valid && rst_n) begin
            // P1 no output without valid input; output = selected input beat
            assert (m_tvalid == s_tvalid[m_tid]);
            assert (m_tdata  == (m_tid ? s_tdata[7:4] : s_tdata[3:0]));
            assert (m_tkeep  == s_tkeep[m_tid]);
            assert (m_tlast  == s_tlast[m_tid]);
            // P2 beat conservation
            assert ((s_tvalid[0] && s_tready[0]) == (m_fire && m_tid == 1'b0));
            assert ((s_tvalid[1] && s_tready[1]) == (m_fire && m_tid == 1'b1));
            // P4 (packet atomicity) and P6 (work conservation) are embedded in
            // axis_rr_arbiter under `ifdef FORMAL, next to the state they constrain
        end
        if (step_ok) begin
            // P3 output stability
            if (p_mvalid && !p_mready) begin
                assert (m_tvalid);
                assert (m_tid   == p_mtid);
                assert (m_tdata == p_mdata);
                assert (m_tkeep == p_mkeep);
                assert (m_tlast == p_mtlast);
            end
            // P5 round-robin hand-over: the other source owns the next packet
            if (p_mvalid && p_mready && p_mtlast && s_tvalid[!p_mtid])
                assert (m_tid == !p_mtid);
        end
    end
endmodule
