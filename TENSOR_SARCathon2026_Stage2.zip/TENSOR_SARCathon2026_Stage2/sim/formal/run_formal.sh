#!/usr/bin/env bash
# Formal verification of axis_rr_arbiter with Yosys (no other tools needed).
#   1. PROOF     : unbounded proof (base case + k-induction) of properties P1..P6
#   2. WITNESS   : the assumptions allow real traffic (a trace in which both
#                  sources complete packets, one multi-beat, with a stall)
#   3. NEGATIVE  : three deliberately broken arbiters must FAIL the proof
# Usage (from anywhere): bash sim/formal/run_formal.sh [yosys-binary]
# Exit code 0 only if 1, 2 and 3 all behave as required.
set -uo pipefail
YOSYS=${1:-yosys}
cd "$(dirname "$0")/../.."
OUT=sim/formal/out; mkdir -p "$OUT"
SUMMARY=sim/formal/formal_summary.log; : > "$SUMMARY"
say() { echo "$*" | tee -a "$SUMMARY"; }

prove() {   # $1 = arbiter source, $2 = log
  "$YOSYS" -q -l "$2" -p "
    read_verilog -formal -sv $1 sim/formal/axis_rr_arbiter_props.sv
    prep -flatten -top axis_rr_arbiter_props
    async2sync
    dffunmap
    sat -tempinduct -prove-asserts -set-assumes -seq 1 -maxsteps 12
  " >/dev/null 2>&1
  grep -q "Induction step proven: SUCCESS" "$2" && ! grep -q "FAIL" "$2"
}

ok=1
say "Yosys: $("$YOSYS" -V)"
if prove rtl/axis_rr_arbiter.sv "$OUT/proof.log"; then
  say "PROOF    axis_rr_arbiter P1..P6 : PROVED (base case + induction, see $OUT/proof.log)"
else
  say "PROOF    axis_rr_arbiter P1..P6 : FAILED (see $OUT/proof.log)"; ok=0
fi

"$YOSYS" -q -l "$OUT/witness.log" -p "
  read_verilog -formal -sv rtl/axis_rr_arbiter.sv sim/formal/axis_rr_arbiter_props.sv
  prep -flatten -top axis_rr_arbiter_props
  async2sync
  dffunmap
  sat -seq 12 -set-assumes -set-at 12 cov_ok 1 -show-inputs -show-outputs
" >/dev/null 2>&1
if grep -q "SAT solving finished - model found" "$OUT/witness.log"; then
  say "WITNESS  traffic reachable under the assumptions (12-cycle trace in $OUT/witness.log)"
else
  say "WITNESS  NOT FOUND - assumptions may be vacuous"; ok=0
fi

# negative controls: name | sed expression applied to a copy of the arbiter
neg() {
  local name=$1 expr=$2 f="$OUT/mut_$1.sv"
  sed -e "$expr" rtl/axis_rr_arbiter.sv > "$f"
  if cmp -s "$f" rtl/axis_rr_arbiter.sv; then say "NEGATIVE $name : mutation did not apply"; ok=0; return; fi
  if prove "$f" "$OUT/mut_$name.log"; then
    say "NEGATIVE $name : proof PASSED on broken RTL - properties too weak"; ok=0
  else
    say "NEGATIVE $name : proof fails as required"
  fi
}
neg unlock_any_beat   's/end else if (m_fire \&\& m_tlast) begin/end else if (m_fire) begin/'
neg no_rr_update      's/            last   <= grant;/            last   <= last;/'
neg ready_not_gated   's/s_tready\[i\] = m_tready \&\& (sel == ID_W.(i));/s_tready[i] = m_tready;/'

[ $ok -eq 1 ] && say "FORMAL RESULT: PASS" || say "FORMAL RESULT: FAIL"
[ $ok -eq 1 ]
