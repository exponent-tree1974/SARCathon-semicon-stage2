# Icarus Verilog regression for Windows PowerShell. Arguments are passed through
# to sim/run_regression.py, e.g.:
#   .\sim\run_icarus.ps1
#   .\sim\run_icarus.ps1 --seeds 1 2 3 4 5
#   .\sim\run_icarus.ps1 --test crc_corruption --seeds 7 --vcd
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    $py = if ($env:PYTHON) { $env:PYTHON } elseif (Get-Command py -ErrorAction SilentlyContinue) { 'py' } else { 'python' }
    & $py sim/run_regression.py --sim icarus @args
    exit $LASTEXITCODE
} finally { Pop-Location }
