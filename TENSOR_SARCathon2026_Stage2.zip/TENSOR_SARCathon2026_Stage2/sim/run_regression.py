#!/usr/bin/env python3
"""
Cross-platform regression runner (Windows / Linux / WSL / macOS).

  python sim/run_regression.py                       # Icarus, seed 1, all 17 tests
  python sim/run_regression.py --lanes 8 --tid-w 2   # other DUT configuration
  python sim/run_regression.py --bench arb --seeds 1 2 3     # 2-source arbiter bench (tb_arb)
  python sim/run_regression.py --bench replay --seeds 1 2    # replay-buffer unit bench (tb_replay)
  python sim/run_regression.py --seeds 1 2 3 4 5     # multi-seed regression
  python sim/run_regression.py --test crc_corruption --seeds 7 --vcd
  python sim/run_regression.py --sim verilator --seeds 1      # optional Verilator flow
  python sim/run_regression.py --repro-check         # determinism check (see below)

Flow:  tool check -> compile -> one simulation per seed -> parse PASS/FAIL markers ->
       Python golden-model check of the TX symbol stream -> merged coverage report ->
       sim/out/<run>/regression_summary.txt.  Exit code 0 only if everything passed.

--repro-check (first seed): runs the full suite twice and every test alone, and
requires identical [TEST-RESULT] lines (cycles, packets, bytes) in all cases.
"""
import argparse
import datetime as dt
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = ["reset_idle", "csr_access", "sizes_directed", "back_to_back", "random_stalls",
         "tkeep_malformed", "crc_corruption", "symbol_errors", "lane_corruption",
         "header_forgery", "order_preservation", "link_enable", "credit_stress",
         "reset_traffic", "random_regression", "wave_showcase", "err_csr_perf"]
BENCH_TESTS = {
    "core":   TESTS,
    "arb":    ["arb_single_source", "arb_saturated_equal", "arb_mixed_sizes", "arb_starvation",
               "arb_random_stalls", "arb_link_errors", "arb_reset_traffic", "arb_back_to_back_switch"],
    "replay": ["replay_buffer_unit"],
}
BENCH_TOP = {"core": ("tb_top", "sim/tb_files.f"), "arb": ("tb_arb", "sim/tb_arb_files.f"),
             "replay": ("tb_replay", "sim/tb_replay_files.f")}
RE_TEST = re.compile(r"^\[TEST-RESULT\]\s+(\S+)\s+:\s+(PASS|FAIL)(.*)$")
RE_SIM = re.compile(r"^\[SIM-RESULT\]\s+(PASSED|FAILED)(.*)$")
RE_COV = re.compile(r"^(\d+)\s+(\S+)\s+(\d+)\s+(\d+)\s+(COVERED|HOLE)\s*$")


def log_print(fh, msg=""):
    print(msg)
    fh.write(msg + "\n")
    fh.flush()


def run(cmd, cwd, log_path, timeout=None):
    with open(log_path, "w", encoding="utf-8", errors="replace") as f:
        f.write("$ " + " ".join(str(c) for c in cmd) + "\n")
        f.flush()
        try:
            p = subprocess.run([str(c) for c in cmd], cwd=cwd, stdout=f, stderr=subprocess.STDOUT,
                               timeout=timeout)
            return p.returncode
        except subprocess.TimeoutExpired:
            f.write("\n[RUNNER] TIMEOUT: process killed\n")
            return 124
        except FileNotFoundError as e:
            f.write(f"\n[RUNNER] tool not found: {e}\n")
            return 127


def tool_version(cmd):
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return (out.stdout + out.stderr).strip().splitlines()[0]
    except Exception:
        return "NOT FOUND"


def files_from(fl):
    items = []
    for line in (ROOT / fl).read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("//") and not line.startswith("#"):
            items.append(line)
    return items


def compile_design(sim, out, args):
    top, tbf = BENCH_TOP[args.bench]
    rtl, tb = files_from("sim/rtl_files.f"), files_from(tbf)
    srcs = [x for x in rtl + tb if not x.startswith("+incdir+")]
    params = ([f"-Ptb_top.LANES={args.lanes}", f"-Ptb_top.TID_W={args.tid_w}"] if args.bench == "core" else [])
    if sim == "icarus":
        exe = out / "simv.vvp"
        cmd = (["iverilog", "-g2012", "-Wall", "-I", "tb/env", "-s", top, "-o", exe] + params + srcs)
        rc = run(cmd, ROOT, out / "compile.log")
        # "-fst" is a vvp extended argument: $dumpfile then writes FST instead of VCD
        return rc, ((["vvp", "-n", exe] + (["-fst"] if args.fst else [])) if rc == 0 else None)
    # verilator
    mdir = out / "obj_verilator"
    cmd = ["verilator", "--binary", "--timing", "--assert", "-j", "0", "-Wno-fatal",
           "-Wno-lint", "-Wno-style", "+define+SVA", "-Itb/env", "--top-module", top,
           "--Mdir", mdir, "-o", "Vtb_top"]
    if args.bench == "core":
        cmd += [f"-GLANES={args.lanes}", f"-GTID_W={args.tid_w}"]
    if args.vcd or args.vcd_test:
        cmd.append("--trace-fst" if args.fst else "--trace")
    cmd += srcs
    rc = run(cmd, ROOT, out / "compile.log", timeout=7200)
    return rc, ([mdir / "Vtb_top"] if rc == 0 else None)


def simulate(sim_cmd, out_dir, seed, args, test=None, tag="simulation"):
    out_dir.mkdir(parents=True, exist_ok=True)
    rel = lambda p: os.path.relpath(p, ROOT).replace("\\", "/")
    plus = [f"+seed={seed}", f"+scale={args.scale}",
            f"+cov_file={rel(out_dir / 'coverage.txt')}",
            f"+fiu_dump={rel(out_dir / 'fiu_tx_dump.txt')}",
            f"+inj_log={rel(out_dir / 'injections.log')}"]
    if test:
        plus.append(f"+test={test}")
    if args.bench == "replay":
        plus.append(f"+cycles={args.replay_cycles}")
    wave = out_dir / ("waves.fst" if args.fst else "waves.vcd")
    if args.vcd:
        plus += ["+vcd", f"+vcd_file={rel(wave)}", f"+vcd_depth={args.vcd_depth}",
                 f"+vcd_scope={args.vcd_scope}"]
    elif args.vcd_test and (test is None or test == args.vcd_test):
        plus += [f"+vcd_test={args.vcd_test}", f"+vcd_file={rel(wave)}",
                 f"+vcd_depth={args.vcd_depth}", f"+vcd_scope={args.vcd_scope}"]
    if args.cov_strict and not test:
        plus.append("+cov_strict")
    log = out_dir / f"{tag}.log"
    rc = run(list(sim_cmd) + plus, ROOT, log, timeout=args.timeout)
    text = log.read_text(errors="replace")
    tests = [(m.group(1), m.group(2), m.group(3).strip()) for m in
             (RE_TEST.match(l) for l in text.splitlines()) if m]
    simres = [m.group(1) for m in (RE_SIM.match(l) for l in text.splitlines()) if m]
    passed = rc == 0 and simres == ["PASSED"] and tests and all(t[1] == "PASS" for t in tests)
    return passed, rc, tests, (simres[0] if simres else "NO-RESULT"), log


def golden(out_dir, args):
    if args.bench == "replay":
        return True, "n/a (no link traffic)"
    dump = out_dir / "fiu_tx_dump.txt"
    if not dump.exists():
        return False, "no dump"
    p = subprocess.run([sys.executable, str(ROOT / "tb/model/check_fiu_stream.py"), str(dump),
                        "--lanes", str(args.lanes), "--tid-w", str(args.tid_w if args.bench == "core" else 1)],
                       capture_output=True, text=True)
    (out_dir / "golden_model.log").write_text(p.stdout + p.stderr)
    return p.returncode == 0, (p.stdout.strip().splitlines() or ["?"])[0]


def merge_coverage(cov_files):
    bins = {}
    for cf in cov_files:
        if not cf.exists():
            continue
        for line in cf.read_text().splitlines():
            m = RE_COV.match(line.strip())
            if m:
                i, name, hits, goal = int(m.group(1)), m.group(2), int(m.group(3)), int(m.group(4))
                b = bins.setdefault(i, [name, 0, goal])
                b[1] += hits
    return bins


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sim", choices=["icarus", "verilator"], default="icarus")
    ap.add_argument("--bench", choices=["core", "arb", "replay"], default="core",
                    help="core: tb_top (default); arb: tb_arb 2-source arbiter; replay: tb_replay unit test")
    ap.add_argument("--replay-cycles", type=int, default=200000, help="cycles per tb_replay run")
    ap.add_argument("--seeds", type=int, nargs="+", default=[1])
    all_tests = sorted(set(sum(BENCH_TESTS.values(), [])))
    ap.add_argument("--test", choices=all_tests, help="run one test")
    ap.add_argument("--tests", choices=all_tests, nargs="+", help="run these tests, each as its own simulation")
    ap.add_argument("--each-test", action="store_true",
                    help="run every test as its own simulation (one simulation.log per test and seed)")
    ap.add_argument("--fst", action="store_true", help="write FST instead of VCD waveforms")
    ap.add_argument("--scale", type=int, default=1, help="multiply random packet counts")
    ap.add_argument("--lanes", type=int, default=4, help="DUT/channel lane count (1,2,4,8,16,32)")
    ap.add_argument("--tid-w", type=int, default=4, help="stream-ID width of the DUT (1..8)")
    ap.add_argument("--vcd", action="store_true", help="dump waves for every test")
    ap.add_argument("--vcd-test", choices=all_tests, help="dump waves only for this test")
    ap.add_argument("--vcd-depth", type=int, default=0, help="hierarchy depth with --vcd-scope all")
    ap.add_argument("--vcd-scope", choices=["dut", "all"], default="dut",
                    help="dut: DUT ports + main blocks (default, small); all: whole testbench (large)")
    ap.add_argument("--cov-strict", action="store_true", help="coverage holes fail the run")
    ap.add_argument("--repro-check", action="store_true")
    ap.add_argument("--no-golden", action="store_true")
    ap.add_argument("--timeout", type=int, default=3600, help="per simulation, seconds")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    bench_tests = BENCH_TESTS[args.bench]

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(args.out) if args.out else ROOT / "sim" / "out" / f"{args.sim}_{stamp}"
    out.mkdir(parents=True, exist_ok=True)
    fh = open(out / "regression_summary.txt", "w", encoding="utf-8")
    log_print(fh, "=" * 78)
    log_print(fh, f" REGRESSION  {stamp}   bench={args.bench}   simulator={args.sim}   host={platform.system()} {platform.release()}")
    log_print(fh, f" python {platform.python_version()}")
    if args.sim == "icarus":
        log_print(fh, f" iverilog: {tool_version(['iverilog', '-V'])}")
    else:
        log_print(fh, f" verilator: {tool_version(['verilator', '--version'])}")
    log_print(fh, f" seeds={args.seeds} test={args.test or 'ALL'} scale={args.scale} LANES={args.lanes} TID_W={args.tid_w} output={out}")
    log_print(fh, "=" * 78)

    rc, sim_cmd = compile_design(args.sim, out, args)
    if rc != 0:
        log_print(fh, f"COMPILE FAILED (exit {rc}) - see {out / 'compile.log'}")
        log_print(fh, "REGRESSION RESULT: FAIL")
        return 2
    clog = (out / "compile.log").read_text(errors="replace").splitlines()[1:]
    warn = [l for l in clog if l.strip()]
    log_print(fh, f"compile: OK ({len(warn)} diagnostic lines, see compile.log)")

    all_ok = True
    cov_files = []
    rows = []          # evidence table: (test, seed, result, info, log, golden, wave)
    test_list = args.tests or ([args.test] if args.test else (bench_tests if args.each_test else [None]))
    for seed in args.seeds:
        for tst in test_list:
            sd = out / f"seed_{seed}" / (tst if tst else "")
            ok, rc, tests, simres, log = simulate(sim_cmd, sd, seed, args, test=tst)
            g_ok, g_msg = (True, "skipped") if args.no_golden else golden(sd, args)
            cov_files.append(sd / "coverage.txt")
            label = f"seed {seed}" + (f" test {tst}" if tst else " (full suite)")
            log_print(fh, f"\n{label}: simulator exit={rc} {simres}   golden model: {'PASS' if g_ok else 'FAIL'} ({g_msg})")
            for name, res, info in tests:
                log_print(fh, f"   {name:22s} {res}  {info}")
            if not tests:
                log_print(fh, f"   no [TEST-RESULT] lines - see {log}")
                rows.append((tst or "ALL", seed, "FAIL (no result)", "", log, g_ok, None))
            wave = next((w for w in (sd / "waves.vcd", sd / "waves.fst") if w.exists()), None)
            for name, res, info in tests:
                rows.append((name, seed, res if ok or res == "FAIL" else f"{res} (sim {simres})",
                             info, log, g_ok, wave if (wave and (args.vcd or args.vcd_test in (None, name))) else None))
            all_ok &= ok and g_ok

    # merged coverage
    bins = merge_coverage(cov_files) if test_list == [None] else {}   # merged coverage only for full-suite runs
    if bins:
        covered = sum(1 for b in bins.values() if b[1] >= b[2])
        lines = [f"{'id':>3} {'bin':30s} {'hits':>10} {'goal':>6}  status"]
        for i in sorted(bins):
            n, h, g = bins[i]
            lines.append(f"{i:>3} {n:30s} {h:>10} {g:>6}  {'COVERED' if h >= g else 'HOLE'}")
        lines.append(f"MERGED COVERAGE: {covered}/{len(bins)} bins ({100.0 * covered / len(bins):.1f}%) over seeds {args.seeds}")
        (out / "coverage_merged.txt").write_text("\n".join(lines) + "\n")
        log_print(fh, "\n" + lines[-1])
        holes = [bins[i][0] for i in sorted(bins) if bins[i][1] < bins[i][2]]
        if holes:
            log_print(fh, "coverage holes: " + ", ".join(holes))
            if args.cov_strict and not args.test:
                all_ok = False
        tpl = ROOT / "docs" / "coverage_report_template.md"
        if tpl.exists():
            bin_rows = "\n".join(f"| {i} | `{bins[i][0]}` | {bins[i][1]} | {bins[i][2]} | "
                             f"{'COVERED' if bins[i][1] >= bins[i][2] else '**HOLE**'} |" for i in sorted(bins))
            txt = tpl.read_text()
            for k, v in {"{{DATE}}": stamp, "{{SIMULATOR}}": f"{args.sim}",
                         "{{SEEDS}}": " ".join(map(str, args.seeds)),
                         "{{RESULT}}": "PASS" if all_ok else "FAIL",
                         "{{BINS_COVERED}}": str(covered), "{{BINS_TOTAL}}": str(len(bins)),
                         "{{BIN_TABLE}}": bin_rows,
                         "{{HOLES}}": ", ".join(holes) if holes else "none"}.items():
                txt = txt.replace(k, v)
            (out / "coverage_report.md").write_text(txt)

    # reproducibility
    if args.repro_check:
        seed = args.seeds[0]
        log_print(fh, f"\nREPRODUCIBILITY CHECK (seed {seed})")
        ref = {t[0]: t for t in simulate(sim_cmd, out / "repro" / "suite_a", seed, args)[2]}
        again = {t[0]: t for t in simulate(sim_cmd, out / "repro" / "suite_b", seed, args)[2]}
        rep_ok = ref == again and len(ref) == len(bench_tests)
        log_print(fh, f"   suite run twice -> identical results: {'YES' if ref == again else 'NO'}")
        for t in bench_tests:
            alone = simulate(sim_cmd, out / "repro" / t, seed, args, test=t)[2]
            same = len(alone) == 1 and t in ref and alone[0] == ref[t]
            rep_ok &= same
            log_print(fh, f"   {t:22s} alone == in suite: {'YES' if same else 'NO'}"
                          + ("" if same else f"   suite={ref.get(t)} alone={alone}"))
        log_print(fh, f"REPRODUCIBILITY: {'PASS' if rep_ok else 'FAIL'}")
        all_ok &= rep_ok

    log_print(fh, "\n" + "=" * 78)
    log_print(fh, f"REGRESSION RESULT: {'PASS' if all_ok else 'FAIL'}")
    log_print(fh, "=" * 78)
    fh.close()
    write_md_summary(out, args, stamp, rows, bins if bins else {}, all_ok)
    return 0 if all_ok else 1


def write_md_summary(out, args, stamp, rows, bins, all_ok):
    """regression_summary.md: one row per (test, seed) with the evidence files."""
    rel = lambda p: os.path.relpath(p, ROOT).replace("\\", "/") if p else "-"
    tool = tool_version(["iverilog", "-V"] if args.sim == "icarus" else ["verilator", "--version"])
    covered = sum(1 for b in bins.values() if b[1] >= b[2])
    L = [f"# Regression Summary — {stamp}", "",
         "Generated by `sim/run_regression.py` from simulator output. Do not edit by hand.", "",
         f"- Command: `python {' '.join(sys.argv)}`",
         f"- Simulator: {tool}",
         f"- Host: {platform.system()} {platform.release()}, Python {platform.python_version()}",
         f"- Seeds: {' '.join(map(str, args.seeds))}",
         f"- Bench: {args.bench} ({BENCH_TOP[args.bench][0]})",
         f"- DUT configuration: LANES={args.lanes}, TID_W={args.tid_w}" if args.bench == "core" else "- DUT configuration: default (LANES=4)",
         f"- Functional coverage (merged): {covered}/{len(bins)} bins" if bins else "- Functional coverage: n/a",
         f"- **Overall result: {'PASS' if all_ok else 'FAIL'}**", "",
         "| # | Test | Seed | Result | Cycles / packets / bytes checked | Simulation log | Golden model | Waveform |",
         "|---|---|---|---|---|---|---|---|"]
    for i, (name, seed, res, info, log, g_ok, wave) in enumerate(rows, 1):
        L.append(f"| {i} | `{name}` | {seed} | **{res}** | {info.strip('()')} | `{rel(log)}` | "
                 f"{'PASS' if g_ok else 'FAIL'} | {('`' + rel(wave) + '`') if wave else '-'} |")
    (out / "regression_summary.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
