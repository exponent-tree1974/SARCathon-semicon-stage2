# SARCathon 2026, Stage 2 (Grand Finale): AXI4-Stream ⇄ PCIe-6-style link, RTL to GDSII

**Team TENSOR:** Devank Saini, Aditya Ranjan, Krishnansu Mohanty

The design is a synthesizable SystemVerilog link datapath following the challenge block diagram:

1. 2 × 512-bit AXI4-Stream sources feed a packet-atomic round-robin arbiter.
2. The packetizer splits packets into 256-byte Flow Information Units (FIUs) with CRC-32, sequence numbers and credit flow control.
3. Each 256-bit word is striped over 4 lanes as Gray-coded PAM4 symbols.
4. The receive path checks and discards errored FIUs and returns the data on a 512-bit AXI4-Stream master.
5. An AXI4-Lite CSR block holds 20 counters, an error status register and an IRQ.

The design was then implemented on **SkyWater Sky130 HD with open-source tools** (Yosys, OpenROAD, OpenSTA, KLayout, Magic, Verilator).

> **Not PCIe-compliant, and no such claim is made.** There is no TLP/DLLP, FLIT, LTSSM, PIPE or SerDes, and FEC is a bypass stub. The data ports are AXI4-Stream; full AXI4 memory-mapped master/slave is not implemented.
> **Physical sign-off is not complete:** KLayout DRC reports 1,522 violations (root cause identified) and LVS was not finished. See the report, section 8.

## Key results (all copied from tool reports in this ZIP)

| Area | Result |
|---|---|
| RTL verification | **338/338** test runs PASS (Icarus 12 + Verilator 5.052 with SVA); coverage **110/110**; **41/41** mutants killed; arbiter **formally proved** |
| Synthesis, Sky130 HD TT | 594,554 µm², 44,969 cells, 12,590 flip-flops; mapping equivalence **EQUIVALENT** (negative control fails, as it must) |
| Gate-level simulation | **16/16** synthesised netlist, **16/16** routed netlist |
| Place and route | die 1300 × 1300 µm; detailed route **0** violations; antenna **0** |
| Post-route timing, 100 MHz | TT setup **+0.026 ns** / hold **+0.096 ns**; FF met; SS stress corner violated |
| Electrical rules at TT | 0 slew, 0 cap, 20 fanout (attempt 1 had 147 / 19 / 26) |
| GDSII | `physical_design/outputs/axis_pcie_link_mux2_top.gds.gz` |
| KLayout DRC | **1,522 violations** (met3 minimum area at stacked vias); **open** |
| LVS | **not completed** |

## Folder structure (as recommended in the challenge PDF)

```
README.md
rtl/                 17 SystemVerilog files (top: rtl/axis_pcie_link_mux2_top.sv)
tb/                  testbenches (core, 2-source arbiter, replay), BFMs, scoreboards, checkers, reference model
sim/                 run_regression.py (single runner), Icarus/Verilator wrappers, mutation check,
                     VCD waveform checkers, formal/ (arbiter proof)
synthesis/
  sky130_yosys/      Sky130 synthesis script (synth.ys), stats, check, mapping-equivalence reports,
                     pre-layout STA
  generic_yosys/     technology-independent synthesis used in Stage 1
physical_design/
  flow/              the complete flow: Makefile, flow/ (Yosys/OpenROAD/OpenSTA/KLayout/Magic/Netgen
                     scripts, SDC, pin constraints, LibreLane + ORFS configs), tools/build_from_source.sh
  outputs/           final GDSII (.gds.gz), routed netlists (logical + power-pin), SDC
  reports/           summary.md (every step with its evidence), metrics, STA, DRC, XOR, GLS, PnR logs
  flow_debug_log.md  every failure met during bring-up: root cause and fix
  technology_assumptions.md, floorplan_assumptions.md
reports/
  TENSOR_Stage2_Technical_Report.pdf    the technical report (8 pages)
  src/                                  report source + renderer
  design_docs/                          specification, verification/coverage plans, CSR map, FEC/replay notes
results/
  diagrams/          architecture and module-level diagrams
  layout/            final placement plot (from the routed DEF) + script
  waveforms_annotated/, waveforms_raw/   10 waveform figures (VCD renders) with explanations
  sim_logs/          logs of every recorded simulation run
  regression_summary.md  338-row result table, each row linked to its log
```

The tables cite logs as `evidence_v4/<run>/...`; in this ZIP the same files are in `results/sim_logs/<run>/...`.

## How to reproduce

**RTL verification** needs Icarus Verilog 12 and Python 3. Verilator 5.x is optional. Run from this folder:

```bash
python3 sim/run_regression.py --seeds 1 2 3 4 5 6 7 8 --cov-strict   # core: 17 tests x 8 seeds + coverage
python3 sim/run_regression.py --bench arb --seeds 1 2 3 4             # 2-source arbiter
python3 sim/run_regression.py --bench replay --seeds 1                # replay-buffer unit test
python3 sim/run_regression.py --sim verilator --seeds 1               # Verilator + SVA
python3 sim/run_mutation_check.py --jobs 4                            # 41 injected bugs must be caught
bash sim/formal/run_formal.sh                                         # arbiter proof (Yosys)
```

**ASIC flow** needs Yosys, OpenROAD, OpenSTA, KLayout, Verilator, and Magic + Netgen. All of them are built at pinned commits by `physical_design/flow/tools/build_from_source.sh`.

```bash
cd physical_design/flow
make platform pdk check-env
make synth lec gls sta-pre                      # synthesis, equivalence, gate-level sim, pre-layout STA
make floorplan place cts grt route antenna finish
make sta-post gls-post                          # post-route STA (3 corners), routed-netlist GLS
make gds drc lvs signoff-magic drc-selftest     # sign-off; run heavy steps one at a time
make collect                                    # reports/<tag>/summary.md
```

The recorded run used a 2-core Linux host with a 6.27 GB memory limit:

- Detailed routing took about 2 h and peaked at about 4.4 GB.
- Full-chip KLayout DRC took about 13 min.
- On that host, heavy steps must not run at the same time.

## Open items (also in report sections 8–9)

1. **DRC.** 1,520 met3 minimum-area violations: the router stacks M2M3 and M3M4 vias 0.23 µm apart, leaving about 0.19 µm² of met3 against a 0.24 µm² rule. The fix is to add met3 patches or restrict stacked vias, re-route incrementally, then re-run DRC.
2. **LVS.** Not completed: the run was interrupted by a host restart.
3. **SS-corner timing.** The flow optimises at TT only.
4. **Scope.** No crossbar, no real FEC, replay not integrated, no named use-case workloads.
