`timescale 1ns/1ps
// =============================================================================
// tb_replay - unit testbench for fiu_replay_buffer (standalone component)
//
//  * Random capture traffic (gaps), random ACK and NAK requests (in-window,
//    stale and out-of-window), random replay back-pressure, mid-run resets.
//  * Reference model: an independent cycle-level model of the documented
//    window rules (no RTL signals used) predicts in_ready, every rp_* output,
//    occupancy / oldest / next / replaying and the ignored-request flags.
//  * Data integrity, independent of the model: every replayed word must equal
//    the word captured for that sequence number.
//  * Stability: a presented replay word does not change until accepted.
//  * Scenario checks (must all occur): full back-pressure, NAK arriving
//    mid-FIU (replay waits for the FIU boundary), ACK accepted during replay,
//    ACK/NAK ignored for every reason, sequence-number wrap-around.
//  Plusargs: +seed=<n> +cycles=<n>     Result: [SIM-RESULT] PASSED / FAILED
// =============================================================================
module tb_replay;
    localparam int W = 64, FW = 8, NF = 4, SW = 8;

    reg clk = 0; always #5 clk = ~clk;
    reg rst_n = 1;
    initial #1 rst_n = 0;

    reg          in_valid = 0, in_sof = 0, ack_valid = 0, nak_valid = 0, rp_ready = 0;
    reg  [W-1:0] in_data = 0;
    reg  [SW-1:0] ack_seq = 0, nak_seq = 0;
    wire         in_ready, rp_valid, rp_sof, replaying, ev_ack_ign, ev_nak_ign;
    wire [W-1:0] rp_data;
    wire [SW-1:0] rp_seq, oldest_seq, next_seq;
    wire [2:0]   occupancy;

    fiu_replay_buffer #(.W(W), .FIU_WORDS(FW), .N_FIU(NF), .SEQ_W(SW)) dut (
        .clk(clk), .rst_n(rst_n),
        .in_valid(in_valid), .in_data(in_data), .in_sof(in_sof), .in_ready(in_ready),
        .ack_valid(ack_valid), .ack_seq(ack_seq), .nak_valid(nak_valid), .nak_seq(nak_seq),
        .rp_valid(rp_valid), .rp_data(rp_data), .rp_sof(rp_sof), .rp_seq(rp_seq), .rp_ready(rp_ready),
        .occupancy(occupancy), .oldest_seq(oldest_seq), .next_seq(next_seq), .replaying(replaying),
        .ev_ack_ignored(ev_ack_ign), .ev_nak_ignored(ev_nak_ign));

    integer errors = 0;
    task automatic fail(input [8*160-1:0] m);
        begin errors = errors + 1; if (errors <= 30) $display("[ERROR] %0t %0s", $time, m); end
    endtask

    // ---------------- reference model (spec-level) ----------------
    integer m_old, m_nxt, m_widx, m_rseq, m_rword, m_act, m_pend, m_ign_a, m_ign_n;
    reg [W-1:0] gold [0:255][0:FW-1];    // captured words by sequence number (independent record)
    integer wr_seq;                      // writer-side FIU counter (independent of the model)

    function automatic integer md(input integer x); md = ((x % 256) + 256) % 256; endfunction
    function automatic integer m_count(); m_count = md(m_nxt - m_old); endfunction
    function automatic integer m_busy();  m_busy = m_act || m_pend; endfunction
    function automatic integer m_in_ready();
        m_in_ready = (m_widx != 0) || (!m_busy() && m_count() < NF);
    endfunction

    task automatic model_reset();
        begin m_old = 0; m_nxt = 0; m_widx = 0; m_rseq = 0; m_rword = 0; m_act = 0; m_pend = 0;
              m_ign_a = 0; m_ign_n = 0; wr_seq = 0; end
    endtask

    // ---------------- statistics / scenario coverage ----------------
    integer n_fiu_in = 0, n_ack_ok = 0, n_ack_ign = 0, n_nak_ok = 0, n_nak_ign_busy = 0,
            n_nak_ign_win = 0, n_rp_fiu = 0, n_rp_words = 0, n_full = 0, n_nak_midfiu = 0,
            n_ack_in_replay = 0, n_wrap = 0, n_resets = 0, n_both = 0, cyc = 0;

    // ---------------- check + model update at every clock edge ----------------
    reg [W-1:0] p_data; reg p_rpv = 0, p_rpr = 0, p_sof; reg [SW-1:0] p_seq;
    reg [8*160-1:0] msg;
    integer ok_nak, ok_ack, d, lim;
    always @(posedge clk) begin
        cyc = cyc + 1;
        if (rst_n !== 1'b1) begin
            model_reset(); p_rpv = 0;
        end else begin
            // ---- compare DUT outputs with the model (pre-edge values) ----
            if (in_ready !== (m_in_ready() != 0)) begin $sformat(msg, "in_ready=%0d model=%0d", in_ready, m_in_ready()); fail(msg); end
            if (rp_valid !== m_act[0])        begin $sformat(msg, "rp_valid=%0d model=%0d", rp_valid, m_act); fail(msg); end
            if (occupancy !== m_count())      begin $sformat(msg, "occupancy=%0d model=%0d", occupancy, m_count()); fail(msg); end
            if (oldest_seq !== m_old[7:0] || next_seq !== m_nxt[7:0]) begin
                $sformat(msg, "oldest/next=%0d/%0d model=%0d/%0d", oldest_seq, next_seq, m_old, m_nxt); fail(msg); end
            if (replaying !== (m_busy() != 0))    fail("replaying flag differs from model");
            if (ev_ack_ign !== m_ign_a[0] || ev_nak_ign !== m_ign_n[0]) fail("ignored-request flag differs from model");
            if (m_act) begin
                if (rp_seq !== m_rseq[7:0] || rp_sof !== (m_rword == 0)) begin
                    $sformat(msg, "replay seq/sof %0d/%0d model %0d/%0d", rp_seq, rp_sof, m_rseq, m_rword == 0); fail(msg); end
                if (rp_data !== gold[m_rseq][m_rword]) begin
                    $sformat(msg, "replay data seq %0d word %0d: %h expected %h", m_rseq, m_rword, rp_data, gold[m_rseq][m_rword]); fail(msg); end
            end
            // stability of a presented, not accepted replay word
            if (p_rpv && !p_rpr && (!rp_valid || rp_data !== p_data || rp_seq !== p_seq || rp_sof !== p_sof))
                fail("replay output changed while stalled");
            p_rpv = rp_valid; p_rpr = rp_ready; p_data = rp_data; p_seq = rp_seq; p_sof = rp_sof;

            // ---- model update with the sampled inputs ----
            ok_nak = 0; ok_ack = 0;
            if (nak_valid) begin
                d = md(nak_seq - m_old);
                ok_nak = !m_busy() && d < m_count();
                if (!ok_nak) begin if (m_busy()) n_nak_ign_busy = n_nak_ign_busy + 1; else n_nak_ign_win = n_nak_ign_win + 1; end
            end
            if (ack_valid) begin
                d = md(ack_seq - m_old);
                lim = m_busy() ? md(m_rseq - m_old) : m_count();
                ok_ack = !nak_valid && d < lim;
                if (ack_valid && nak_valid) n_both = n_both + 1;
                if (ok_ack) begin n_ack_ok = n_ack_ok + 1; if (m_act) n_ack_in_replay = n_ack_in_replay + 1; end
                else n_ack_ign = n_ack_ign + 1;
            end
            if (!m_in_ready() && m_widx == 0 && !m_busy()) n_full = n_full + 1;
            // capture
            if (in_valid && m_in_ready()) begin
                if (in_sof !== (m_widx == 0)) fail("TB bug: sof misaligned");
                gold[md(m_nxt)][m_widx] = in_data;
                m_widx = m_widx + 1;
                if (m_widx == FW) begin
                    m_widx = 0; m_nxt = md(m_nxt + 1); n_fiu_in = n_fiu_in + 1;
                    if (m_nxt == 0) n_wrap = n_wrap + 1;
                end
            end
            // next state from a snapshot of the pre-edge state (widx_pre = capture
            // word index before this edge)
            begin : upd
                integer o_pend, o_act, o_rseq, o_rword;
                o_pend = m_pend; o_act = m_act; o_rseq = m_rseq; o_rword = m_rword;
                if (ok_nak) begin
                    m_old = nak_seq; m_rseq = nak_seq; m_rword = 0; m_pend = 1; n_nak_ok = n_nak_ok + 1;
                    if (widx_pre != 0) n_nak_midfiu = n_nak_midfiu + 1;
                end else if (ok_ack) begin
                    m_old = md(ack_seq + 1);
                end
                if (o_pend && widx_pre == 0) begin m_pend = 0; m_act = 1; end
                if (o_act && rp_ready) begin
                    n_rp_words = n_rp_words + 1;
                    m_rword = o_rword + 1;
                    if (o_rword == FW - 1) begin
                        m_rword = 0; m_rseq = md(o_rseq + 1); n_rp_fiu = n_rp_fiu + 1;
                        if (md(o_rseq + 1) == m_nxt) m_act = 0;
                    end
                end
            end
            m_ign_a = ack_valid && !ok_ack;
            m_ign_n = nak_valid && !ok_nak;
        end
    end
    // pre-edge capture word index (the model's m_widx is updated in the block above)
    integer widx_pre = 0;
    always @(negedge clk) widx_pre = m_widx;

    // ---------------- stimulus (drives on the falling edge) ----------------
    integer seed = 1, cycles = 200000, k, wword = 0, wseq = 0, pin, pack, pnak, prdy, mode_t = 0;
    initial begin
        if (!$value$plusargs("seed=%d", seed)) seed = 1;
        if (!$value$plusargs("cycles=%d", cycles)) cycles = 200000;
        k = seed; k = $urandom(k);
        model_reset();
        $display("[TEST-START] replay_buffer_unit  seed=%0d cycles=%0d", seed, cycles);
        repeat (3) @(negedge clk);
        rst_n = 1;
        while (cyc < cycles) begin
            @(negedge clk);
            // traffic phases change the mix every 5000 cycles
            if ((cyc % 5000) == 0) mode_t = $urandom % 4;
            pin  = (mode_t == 0) ? 90 : (mode_t == 1) ? 40 : (mode_t == 2) ? 95 : 70;
            pack = (mode_t == 2) ? 2 : 12;
            pnak = (mode_t == 3) ? 6 : 2;
            prdy = (mode_t == 1) ? 30 : 80;
            in_valid  = (($urandom % 100) < pin) || (in_valid && !in_ready);   // valid stays until accepted
            in_sof    = (m_widx == 0);
            in_data   = {$urandom, $urandom};
            ack_valid = (($urandom % 100) < pack);
            ack_seq   = md(m_old + ($urandom % (m_count() + 4)) - 2);           // mostly in window, some stale/ahead
            nak_valid = (($urandom % 100) < pnak);
            nak_seq   = md(m_old + ($urandom % (m_count() + 3)) - 1);
            rp_ready  = (($urandom % 100) < prdy);
            // occasional reset in the middle of traffic
            if (($urandom % 40000) == 0) begin
                rst_n = 0; in_valid = 0; ack_valid = 0; nak_valid = 0; n_resets = n_resets + 1;
                @(negedge clk); @(negedge clk);
                rst_n = 1; in_sof = 1'b1;          // capture restarts at word 0
            end
        end
        @(negedge clk);
        in_valid = 0; ack_valid = 0; nak_valid = 0;
        $display("[INFO] FIUs captured=%0d replayed FIUs=%0d words=%0d | ACK ok=%0d ignored=%0d (ok during replay=%0d) | NAK ok=%0d mid-FIU=%0d ignored busy=%0d window=%0d | full cycles=%0d | seq wraps=%0d | ACK+NAK same cycle=%0d | resets=%0d",
                 n_fiu_in, n_rp_fiu, n_rp_words, n_ack_ok, n_ack_ign, n_ack_in_replay, n_nak_ok, n_nak_midfiu,
                 n_nak_ign_busy, n_nak_ign_win, n_full, n_wrap, n_both, n_resets);
        if (n_fiu_in < 100 || n_rp_fiu < 20 || n_ack_ok < 20 || n_ack_ign < 5 || n_nak_ok < 5 ||
            n_nak_midfiu < 1 || n_nak_ign_busy < 1 || n_nak_ign_win < 1 || n_full < 1 ||
            n_ack_in_replay < 1 || n_wrap < 1 || n_both < 1)
            fail("scenario coverage incomplete (see [INFO] counts)");
        if (errors == 0) begin
            $display("[TEST-RESULT] replay_buffer_unit : PASS  (cycles=%0d fius=%0d replayed=%0d)", cyc, n_fiu_in, n_rp_fiu);
            $display("[SIM-RESULT] PASSED  tests=1 passed=1 failed=0 seed=%0d", seed);
            $finish;
        end else begin
            $display("[TEST-RESULT] replay_buffer_unit : FAIL  (errors=%0d)", errors);
            $display("[SIM-RESULT] FAILED  tests=1 passed=0 failed=1 seed=%0d", seed);
            $fatal(1, "replay unit test failed");
        end
    end
endmodule
