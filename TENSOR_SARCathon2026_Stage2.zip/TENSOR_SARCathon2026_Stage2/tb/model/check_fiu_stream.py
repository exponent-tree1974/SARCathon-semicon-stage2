#!/usr/bin/env python3
"""
Independent golden-model check of the TX symbol stream.

Input: results/fiu_tx_dump.txt written by the testbench (+ dump of tx_sym before
channel errors), one line per clock with tx_sym_valid=1:  "<sof> <64 hex digits>"

The checker re-implements, from the written specification only:
  * PAM4 Gray de-mapping   level {l1,l0} -> bits {msb=l1, lsb=l1^l0}
  * lane de-striping       lane l byte j -> word byte j*LANES + l
  * FIU trailer layout and CRC-32 (zlib.crc32 over the FIU with CRC field = 0)
and checks every FIU:  CRC, magic, length rules, reserved bits, zero padding,
sequence numbers, sop/eop packet framing, and the stream ID (tid, trailer bits
[47:40]): only the TID_W low bits may be set and it is constant for all FIUs
of one packet.  Exit code 0 = all checks pass.

Usage: check_fiu_stream.py <dump> [--lanes N] [--tid-w N]
"""
import argparse
import sys
import zlib
from pathlib import Path

LINK_W, LANES, FIU_BYTES, TID_W = 256, 4, 256, 4
LB = LINK_W // 8
BPL = LB // LANES
FIU_WORDS = FIU_BYTES // LB
PAYLOAD = FIU_BYTES - LB
MAGIC = 0x5A


def decode_word(sym: int) -> bytes:
    """tx_sym (LINK_W bits) -> 32 link-word bytes."""
    demapped = 0
    for k in range(LINK_W // 2):
        lv = (sym >> (2 * k)) & 3
        msb = lv >> 1
        lsb = msb ^ (lv & 1)
        demapped |= ((msb << 1) | lsb) << (2 * k)
    lane_bytes = demapped.to_bytes(LB, "little")      # lane l occupies bytes [l*BPL, (l+1)*BPL)
    word = bytearray(LB)
    for lane in range(LANES):
        for j in range(BPL):
            word[j * LANES + lane] = lane_bytes[lane * BPL + j]
    return bytes(word)


def main(path: str) -> int:
    """Lines: '<sof> <hex>' per transmitted word, or '# test <name>' / '# reset'
    markers. Sequence numbers and packet state restart at every marker; an FIU
    cut short by a reset is reported as truncated, not as an error."""
    segments, cur_seg, cur, truncated = [], [], None, 0
    for raw in Path(path).read_text().splitlines():
        ln = raw.strip()
        if not ln:
            continue
        if ln.startswith("#"):
            if cur is not None:
                if len(cur) == FIU_WORDS:
                    cur_seg.append(cur)
                else:
                    truncated += 1
            cur = None
            if cur_seg:
                segments.append(cur_seg)
            cur_seg = []
            continue
        sof, hx = ln.split()
        w = decode_word(int(hx, 16))
        if sof == "1":
            if cur is not None:
                cur_seg.append(cur)
            cur = [w]
        else:
            if cur is None:
                print("FAIL: data word before first sof"); return 1
            cur.append(w)
    if cur is not None:
        cur_seg.append(cur)
    if cur_seg:
        segments.append(cur_seg)
    fius = []
    for seg in segments:
        fius.append(None)            # segment boundary marker
        fius.extend(seg)

    errors = 0
    exp_seq, in_pkt, pkts, n_fiu, pkt_tid = None, False, 0, 0, None
    for n, words in enumerate(fius):
        if words is None:
            exp_seq, in_pkt, pkt_tid = None, False, None
            continue
        n_fiu += 1
        if len(words) != FIU_WORDS:
            print(f"FAIL fiu {n}: {len(words)} words"); errors += 1; continue
        fiu = b"".join(words)
        trl = int.from_bytes(fiu[PAYLOAD:], "little")
        length = trl & 0xFFFF
        sop, eop, err = (trl >> 16) & 1, (trl >> 17) & 1, (trl >> 18) & 1
        seq, magic = (trl >> 24) & 0xFF, (trl >> 32) & 0xFF
        tid = (trl >> 40) & 0xFF
        rsvd = ((trl >> 19) & 0x1F) | (((trl >> 48) & ((1 << (LINK_W - 80)) - 1)) << 5)
        crc_field = int.from_bytes(fiu[-4:], "little")
        crc_calc = zlib.crc32(fiu[:-4] + b"\x00" * 4) & 0xFFFFFFFF

        def bad(msg):
            nonlocal errors
            errors += 1
            if errors <= 20:
                print(f"FAIL fiu {n}: {msg}")

        if crc_calc != crc_field: bad(f"CRC field {crc_field:08x} != zlib {crc_calc:08x}")
        if magic != MAGIC:        bad(f"magic {magic:02x}")
        if rsvd != 0:             bad("reserved trailer bits not zero")
        if not (1 <= length <= PAYLOAD): bad(f"len {length}")
        if not eop and length != PAYLOAD: bad("non-eop FIU not full")
        if any(fiu[length:PAYLOAD]):      bad("padding not zero")
        if exp_seq is not None and seq != exp_seq: bad(f"seq {seq} expected {exp_seq}")
        exp_seq = (seq + 1) & 0xFF
        if bool(sop) == in_pkt:   bad(f"framing: sop={sop} while in_pkt={in_pkt}")
        if tid >> TID_W:          bad(f"tid {tid:#x} wider than TID_W={TID_W}")
        if sop:
            pkt_tid = tid
        elif pkt_tid is not None and tid != pkt_tid:
            bad(f"tid {tid} changed inside a packet (sop FIU had {pkt_tid})")
        in_pkt = not eop
        pkts += eop
    print(f"[LANES={LANES} TID_W={TID_W}] checked {n_fiu} FIUs in {len(segments)} reset segments, {pkts} packet ends, "
          f"{truncated} FIUs truncated by reset, {errors} errors")
    print("GOLDEN MODEL CHECK PASS" if errors == 0 else "GOLDEN MODEL CHECK FAIL")
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("dump", nargs="?", default="results/fiu_tx_dump.txt")
    ap.add_argument("--lanes", type=int, default=4)
    ap.add_argument("--tid-w", type=int, default=4)
    a = ap.parse_args()
    LANES, TID_W = a.lanes, a.tid_w
    BPL = LB // LANES
    sys.exit(main(a.dump))
