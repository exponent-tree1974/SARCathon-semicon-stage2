`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// arb_fairness_monitor - observes the 2 arbiter inputs and the arbiter output
// (the stream entering axis_pcie_link_top) and checks, every cycle:
//
//   A1 atomicity    : between the first and the tlast beat of an output packet,
//                     every accepted beat has the same tid (no interleaving)
//   A2 conservation : an output beat is accepted iff exactly one input beat is
//                     accepted in the same cycle, from source m_tid, with
//                     identical tdata/tkeep/tlast (nothing lost, duplicated
//                     or invented by the arbiter)
//   A3 starvation bound (round robin, N = 2): while a source waits with the
//                     first beat of a packet presented, the other source starts
//                     at most N-1 = 1 packet
// Measures per source: packets granted, maximum and mean wait (cycles from the
// first beat being presented to its acceptance), and the largest number of
// packets the other source started during one wait.
// -----------------------------------------------------------------------------
module arb_fairness_monitor #(
    parameter int DATA_W = 512,
    parameter int KEEP_W = DATA_W / 8
) (
    input wire                  clk,
    input wire                  rst_n,
    input wire [2*DATA_W-1:0]   s_tdata,
    input wire [2*KEEP_W-1:0]   s_tkeep,
    input wire [1:0]            s_tlast,
    input wire [1:0]            s_tvalid,
    input wire [1:0]            s_tready,
    input wire [DATA_W-1:0]     a_tdata,
    input wire [KEEP_W-1:0]     a_tkeep,
    input wire                  a_tlast,
    input wire                  a_tid,
    input wire                  a_tvalid,
    input wire                  a_tready
);
    integer errors = 0;
    integer grants [0:1], max_wait [0:1], waits [0:1], max_other [0:1];
    longint sum_wait [0:1];
    integer cycle = 0, beats_out = 0;

    reg     a_mid = 1'b0, a_src = 1'b0;
    reg     s_mid [0:1];
    reg     waiting [0:1];
    integer wait_start [0:1], started_other [0:1];
    integer i, nfire, fsrc;
    reg [8*120-1:0] msg;

    task automatic err(input [8*120-1:0] m);
        begin errors = errors + 1; if (errors <= 20) $display("[ERROR] %0t arb_monitor: %0s", $time, m); end
    endtask

    task automatic clear_stats();
        begin
            for (i = 0; i < 2; i = i + 1) begin
                grants[i] = 0; max_wait[i] = 0; waits[i] = 0; max_other[i] = 0; sum_wait[i] = 0;
            end
            beats_out = 0;
        end
    endtask

    initial begin
        clear_stats();
        for (i = 0; i < 2; i = i + 1) begin s_mid[i] = 0; waiting[i] = 0; wait_start[i] = 0; started_other[i] = 0; end
    end

    wire a_fire = a_tvalid && a_tready;

    always @(posedge clk) begin
        cycle = cycle + 1;
        if (rst_n !== 1'b1) begin
            a_mid = 0;
            for (i = 0; i < 2; i = i + 1) begin s_mid[i] = 0; waiting[i] = 0; started_other[i] = 0; end
        end else begin
            // A2 conservation
            nfire = 0; fsrc = -1;
            for (i = 0; i < 2; i = i + 1) if (s_tvalid[i] === 1'b1 && s_tready[i] === 1'b1) begin nfire = nfire + 1; fsrc = i; end
            if (a_fire !== (nfire == 1) || nfire > 1) begin
                $sformat(msg, "A2 output handshake=%0d with %0d input handshakes", a_fire, nfire); err(msg);
            end else if (a_fire) begin
                if (fsrc != a_tid) err("A2 accepted input beat is not from source m_tid");
                else if (a_tdata !== s_tdata[fsrc*DATA_W +: DATA_W] || a_tkeep !== s_tkeep[fsrc*KEEP_W +: KEEP_W] ||
                         a_tlast !== s_tlast[fsrc])
                    err("A2 output beat differs from the accepted input beat");
            end
            // A1 atomicity + packet starts
            if (a_fire) begin
                beats_out = beats_out + 1;
                if (a_mid && a_tid !== a_src) err("A1 packets interleaved on the arbiter output");
                if (!a_mid) begin
                    grants[a_tid] = grants[a_tid] + 1;
                    // A3: the other source is waiting -> one more packet started past it
                    if (waiting[!a_tid]) begin
                        started_other[!a_tid] = started_other[!a_tid] + 1;
                        if (started_other[!a_tid] > max_other[!a_tid]) max_other[!a_tid] = started_other[!a_tid];
                        if (started_other[!a_tid] > 1) begin
                            $sformat(msg, "A3 source %0d waited while source %0d started %0d packets (bound N-1 = 1)",
                                     !a_tid, a_tid, started_other[!a_tid]);
                            err(msg);
                        end
                    end
                end
                a_mid = !a_tlast; a_src = a_tid;
            end
            // per-source waiting state
            for (i = 0; i < 2; i = i + 1) begin
                if (s_tvalid[i] === 1'b1 && s_tready[i] === 1'b1) begin
                    if (!s_mid[i]) begin               // first beat accepted: wait ends
                        if (!waiting[i]) wait_start[i] = cycle;
                        waits[i] = waits[i] + 1;
                        sum_wait[i] = sum_wait[i] + (cycle - wait_start[i]);
                        if (cycle - wait_start[i] > max_wait[i]) max_wait[i] = cycle - wait_start[i];
                        waiting[i] = 0; started_other[i] = 0;
                    end
                    s_mid[i] = (s_tlast[i] !== 1'b1);
                end else if (s_tvalid[i] === 1'b1 && !s_mid[i] && !waiting[i]) begin
                    waiting[i] = 1; wait_start[i] = cycle; started_other[i] = 0;
                end
            end
        end
    end
endmodule
