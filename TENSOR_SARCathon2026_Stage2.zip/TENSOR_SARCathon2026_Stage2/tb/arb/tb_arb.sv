`timescale 1ns/1ps
// =============================================================================
// tb_arb - two AXI-Stream sources sharing one link through axis_rr_arbiter
//          (DUT: axis_pcie_link_mux2_top)
//
//  Components
//    2 x axis_source_bfm, axis_sink_bfm, link_channel_model (loopback + faults)
//    axis_protocol_checker x4  (both inputs, arbiter output, egress incl. tid)
//    arb_fairness_monitor      atomicity, beat conservation, starvation bound
//    stream_scoreboard         per-stream byte-exact delivery and ordering
//    link_safety_checker       end-to-end safety on the merged stream
//    axil_master_bfm (+checker) CSR counters checked against the scoreboard
//
//  Tests (seed per test = seed*1000 + index, as in tb_top)
//    1 arb_single_source     each source alone; tid identifies the source
//    2 arb_saturated_equal   both saturated, equal sizes: strict alternation,
//                            packet and byte share 50/50 (+-1 packet)
//    3 arb_mixed_sizes       4096 B vs 64 B packets: packet-fair (not byte-fair);
//                            short-packet source waits at most one long packet
//    4 arb_starvation        saturated source vs sparse source: sparse packets
//                            wait at most one packet of the busy source
//    5 arb_random_stalls     random gaps, sizes and egress back-pressure
//    6 arb_link_errors       random channel faults: only losses / whole-FIU
//                            truncation (tuser), never reordering or mixing
//    7 arb_reset_traffic     reset with both sources mid-packet, then clean traffic
//    8 arb_back_to_back_switch  1-beat packets from both sources back to back:
//                            zero-bubble hand-over between sources
//  Plusargs: +seed=<n> +test=<name> +vcd +vcd_file=<f> +max_cycles=<n>
//  Markers:  [TEST-RESULT] <name> : PASS|FAIL ...   [SIM-RESULT] PASSED|FAILED
// =============================================================================
module tb_arb;
    localparam int AXIS_W = 512, KB = 64, LINK_W = 256, FIU_BYTES = 256, LANES = 4, DEPTH = 32;
    localparam int FIU_WORDS = 8, PW = 7, PAYLOAD = 224, NTESTS = 8;

    reg clk = 1'b0; always #5 clk = ~clk;
    reg rst_n = 1'b1; initial #1 rst_n = 1'b0;
    integer cycle = 0; always @(posedge clk) cycle <= cycle + 1;

    // ---------------- DUT ----------------
    wire [AXIS_W-1:0] s0_tdata, s1_tdata, m_tdata;
    wire [KB-1:0]     s0_tkeep, s1_tkeep, m_tkeep;
    wire s0_tlast, s0_tvalid, s0_tready, s1_tlast, s1_tvalid, s1_tready;
    wire m_tlast, m_tuser, m_tid, m_tvalid, m_tready;
    wire [LINK_W-1:0] tx_sym, rx_sym;
    wire tx_sym_valid, tx_sym_sof, rx_sym_valid, rx_sym_sof, irq;
    wire [7:0] rx_credit_return, tx_credit_return;
    wire [7:0] awaddr, araddr;  wire awvalid, awready, wvalid, wready, bvalid, bready;
    wire arvalid, arready, rvalid, rready;  wire [31:0] wdata, rdata;  wire [3:0] wstrb;
    wire [1:0] bresp, rresp, ev_arb;

    axis_pcie_link_mux2_top #(.AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .LANES(LANES),
                              .RX_BUF_DEPTH(DEPTH), .AXIL_ADDR_W(8)) dut (
        .clk(clk), .rst_n(rst_n),
        .s0_axis_tdata(s0_tdata), .s0_axis_tkeep(s0_tkeep), .s0_axis_tlast(s0_tlast),
        .s0_axis_tvalid(s0_tvalid), .s0_axis_tready(s0_tready),
        .s1_axis_tdata(s1_tdata), .s1_axis_tkeep(s1_tkeep), .s1_axis_tlast(s1_tlast),
        .s1_axis_tvalid(s1_tvalid), .s1_axis_tready(s1_tready),
        .m_axis_tdata(m_tdata), .m_axis_tkeep(m_tkeep), .m_axis_tlast(m_tlast), .m_axis_tuser(m_tuser),
        .m_axis_tid(m_tid), .m_axis_tvalid(m_tvalid), .m_axis_tready(m_tready),
        .tx_sym(tx_sym), .tx_sym_valid(tx_sym_valid), .tx_sym_sof(tx_sym_sof),
        .rx_sym(rx_sym), .rx_sym_valid(rx_sym_valid), .rx_sym_sof(rx_sym_sof),
        .rx_credit_return(rx_credit_return), .tx_credit_return(tx_credit_return),
        .s_axil_awaddr(awaddr), .s_axil_awvalid(awvalid), .s_axil_awready(awready),
        .s_axil_wdata(wdata), .s_axil_wstrb(wstrb), .s_axil_wvalid(wvalid), .s_axil_wready(wready),
        .s_axil_bresp(bresp), .s_axil_bvalid(bvalid), .s_axil_bready(bready),
        .s_axil_araddr(araddr), .s_axil_arvalid(arvalid), .s_axil_arready(arready),
        .s_axil_rdata(rdata), .s_axil_rresp(rresp), .s_axil_rvalid(rvalid), .s_axil_rready(rready),
        .irq(irq), .ev_arb_pkt_start(ev_arb));

    // arbiter output = stream entering the link (white-box taps)
    wire [AXIS_W-1:0] a_tdata = dut.a_tdata;
    wire [KB-1:0]     a_tkeep = dut.a_tkeep;
    wire a_tlast = dut.a_tlast, a_tid = dut.a_tid, a_tvalid = dut.a_tvalid, a_tready = dut.a_tready;

    // ---------------- environment ----------------
    axis_source_bfm #(.DATA_W(AXIS_W), .NAME("src0")) u_src0 (.clk(clk), .rst_n(rst_n), .tdata(s0_tdata),
        .tkeep(s0_tkeep), .tlast(s0_tlast), .tvalid(s0_tvalid), .tready(s0_tready));
    axis_source_bfm #(.DATA_W(AXIS_W), .NAME("src1")) u_src1 (.clk(clk), .rst_n(rst_n), .tdata(s1_tdata),
        .tkeep(s1_tkeep), .tlast(s1_tlast), .tvalid(s1_tvalid), .tready(s1_tready));
    axis_sink_bfm #(.NAME("sink")) u_sink (.clk(clk), .rst_n(rst_n), .tready(m_tready));

    axis_protocol_checker #(.DATA_W(AXIS_W), .NAME("chk_in0"), .DUT_IS_MASTER(1'b0)) u_chk_in0 (
        .clk(clk), .rst_n(rst_n), .tdata(s0_tdata), .tkeep(s0_tkeep), .tlast(s0_tlast), .tuser(1'b0),
        .tid(8'd0), .tvalid(s0_tvalid), .tready(s0_tready));
    axis_protocol_checker #(.DATA_W(AXIS_W), .NAME("chk_in1"), .DUT_IS_MASTER(1'b0)) u_chk_in1 (
        .clk(clk), .rst_n(rst_n), .tdata(s1_tdata), .tkeep(s1_tkeep), .tlast(s1_tlast), .tuser(1'b0),
        .tid(8'd0), .tvalid(s1_tvalid), .tready(s1_tready));
    axis_protocol_checker #(.DATA_W(AXIS_W), .NAME("chk_arb_out"), .DUT_IS_MASTER(1'b1), .HAS_TID(1'b1)) u_chk_arb (
        .clk(clk), .rst_n(rst_n), .tdata(a_tdata), .tkeep(a_tkeep), .tlast(a_tlast), .tuser(1'b0),
        .tid({7'b0, a_tid}), .tvalid(a_tvalid), .tready(a_tready));
    axis_protocol_checker #(.DATA_W(AXIS_W), .NAME("chk_egress"), .DUT_IS_MASTER(1'b1), .CHECK_KEEP(1'b1),
                            .HAS_USER(1'b1), .HAS_TID(1'b1)) u_chk_eg (
        .clk(clk), .rst_n(rst_n), .tdata(m_tdata), .tkeep(m_tkeep), .tlast(m_tlast), .tuser(m_tuser),
        .tid({7'b0, m_tid}), .tvalid(m_tvalid), .tready(m_tready));

    axil_master_bfm #(.ADDR_W(8), .NAME("axil")) u_axil (.clk(clk), .rst_n(rst_n), .awaddr(awaddr),
        .awvalid(awvalid), .awready(awready), .wdata(wdata), .wstrb(wstrb), .wvalid(wvalid), .wready(wready),
        .bresp(bresp), .bvalid(bvalid), .bready(bready), .araddr(araddr), .arvalid(arvalid), .arready(arready),
        .rdata(rdata), .rresp(rresp), .rvalid(rvalid), .rready(rready));
    axil_protocol_checker #(.NAME("chk_axil")) u_chk_axil (.clk(clk), .rst_n(rst_n), .awvalid(awvalid),
        .awready(awready), .wvalid(wvalid), .wready(wready), .bvalid(bvalid), .bready(bready), .bresp(bresp),
        .arvalid(arvalid), .arready(arready), .rvalid(rvalid), .rready(rready), .rdata(rdata), .rresp(rresp));

    link_channel_model #(.LINK_W(LINK_W), .LANES(LANES), .FIU_WORDS(FIU_WORDS), .CH_DLY(2), .CR_DLY(3)) u_ch (
        .clk(clk), .rst_n(rst_n), .tx_sym(tx_sym), .tx_valid(tx_sym_valid), .tx_sof(tx_sym_sof),
        .rx_sym(rx_sym), .rx_valid(rx_sym_valid), .rx_sof(rx_sym_sof),
        .credit_from_rx(rx_credit_return), .credit_to_tx(tx_credit_return));

    stream_scoreboard #(.AXIS_W(AXIS_W), .PAYLOAD(PAYLOAD)) u_sb (.clk(clk), .rst_n(rst_n),
        .m_tdata(m_tdata), .m_tkeep(m_tkeep), .m_tlast(m_tlast), .m_tuser(m_tuser), .m_tid(m_tid),
        .m_tvalid(m_tvalid), .m_tready(m_tready));

    arb_fairness_monitor #(.DATA_W(AXIS_W)) u_mon (.clk(clk), .rst_n(rst_n),
        .s_tdata({s1_tdata, s0_tdata}), .s_tkeep({s1_tkeep, s0_tkeep}), .s_tlast({s1_tlast, s0_tlast}),
        .s_tvalid({s1_tvalid, s0_tvalid}), .s_tready({s1_tready, s0_tready}),
        .a_tdata(a_tdata), .a_tkeep(a_tkeep), .a_tlast(a_tlast), .a_tid(a_tid),
        .a_tvalid(a_tvalid), .a_tready(a_tready));

    link_safety_checker #(.KB(KB)) u_safe (.clk(clk), .rst_n(rst_n),
        .s_tvalid(a_tvalid), .s_tready(a_tready), .s_tkeep(a_tkeep), .s_tlast(a_tlast),
        .s_tdata32(a_tdata[31:0]), .s_tid({7'b0, a_tid}),
        .m_tvalid(m_tvalid), .m_tready(m_tready), .m_tkeep(m_tkeep), .m_tlast(m_tlast),
        .m_tdata32(m_tdata[31:0]), .m_tid({7'b0, m_tid}),
        .tx_valid(tx_sym_valid), .tx_sof(tx_sym_sof),
        .t_valid(dut.u_link.t_valid), .t_sof(dut.u_link.t_sof), .t_seq(dut.u_link.u_link.tx_seq),
        .acc_ev(dut.u_link.u_link.b_commit_en), .acc_seq(dut.u_link.u_link.rt_seq),
        .rxbuf_count(8'(dut.u_link.u_rxbuf.count)));

    // ---------------- error accounting ----------------
    integer tb_errors = 0;
    task automatic tb_fail(input [8*140-1:0] m);
        begin tb_errors = tb_errors + 1; if (tb_errors <= 30) $display("[ERROR] %0t tb_arb: %0s", $time, m); end
    endtask
    function automatic integer total_errors();
        total_errors = tb_errors + u_src0.errors + u_src1.errors + u_chk_in0.errors + u_chk_in1.errors +
                       u_chk_arb.errors + u_chk_eg.errors + u_axil.errors + u_chk_axil.errors +
                       u_sb.errors + u_mon.errors + u_safe.errors;
    endfunction

    // ---------------- reset ----------------
    task automatic do_reset(input integer n);
        begin
            u_src0.abort = 1'b1; u_src1.abort = 1'b1;
            @(negedge clk);
            u_src0.idle(); u_src1.idle();
            rst_n = 1'b0;
            if (u_ch.dump_fd != 0) $fdisplay(u_ch.dump_fd, "# reset");
            repeat (n) @(negedge clk);
            rst_n = 1'b1;
            u_src0.abort = 1'b0; u_src1.abort = 1'b0;
            repeat (4) @(negedge clk);
        end
    endtask

    // ---------------- packet driving ----------------
    task automatic send_pkt(input integer src, input integer p);
        integer nb, bt, i, L; reg ok; reg [AXIS_W-1:0] d; reg [KB-1:0] kp;
        begin
            L = u_sb.pk_len[src][p];
            nb = (L + KB - 1) / KB;
            for (bt = 0; bt < nb; bt = bt + 1) begin
                for (i = 0; i < KB; i = i + 1)
                    d[i*8 +: 8] = (bt*KB + i < L) ? u_sb.mem[u_sb.pk_off[src][p] + bt*KB + i] : 8'h00;
                kp = (bt*KB + KB <= L) ? {KB{1'b1}} : ({KB{1'b1}} >> (KB - (L - bt*KB)));
                if (src == 0) u_src0.send_beat(d, kp, bt == nb - 1, ok);
                else          u_src1.send_beat(d, kp, bt == nb - 1, ok);
            end
        end
    endtask

    // send packets [p0, p1) of a source; idle cycles between packets: lo..hi
    task automatic send_stream(input integer src, input integer p0, input integer p1,
                               input integer idle_lo, input integer idle_hi);
        integer p, g;
        begin
            @(negedge clk);
            for (p = p0; p < p1; p = p + 1) begin
                if ((src == 0 && u_src0.abort) || (src == 1 && u_src1.abort)) p = p1;
                else begin
                    send_pkt(src, p);
                    g = idle_lo + ((idle_hi > idle_lo) ? ($urandom % (idle_hi - idle_lo + 1)) : 0);
                    if (g > 0) begin
                        if (src == 0) u_src0.idle(); else u_src1.idle();
                        repeat (g) @(negedge clk);
                    end
                end
            end
            if (src == 0) u_src0.idle(); else u_src1.idle();
        end
    endtask

    function automatic integer rnd(input integer lo, input integer hi);
        rnd = lo + ($urandom % (hi - lo + 1));
    endfunction

    task automatic add(input integer src, input integer len);
        integer idx; begin u_sb.add_packet(src, len, idx); end
    endtask

    // wait for delivery; in loss mode wait until the link has been idle
    task automatic drain(input integer max_wait);
        integer t0, idle; reg [8*140-1:0] m;
        begin
            t0 = cycle; idle = 0;
            if (!u_sb.allow_loss) begin
                while (u_sb.outstanding() > 0 && cycle - t0 < max_wait) @(posedge clk);
                if (u_sb.outstanding() > 0) begin
                    $sformat(m, "[TIMEOUT] %0d packets not delivered after %0d cycles", u_sb.outstanding(), max_wait);
                    tb_fail(m);
                end
            end else begin
                while (idle < 400 && cycle - t0 < max_wait) begin
                    @(posedge clk);
                    if (tx_sym_valid || m_tvalid || s0_tvalid || s1_tvalid) idle = 0; else idle = idle + 1;
                end
                u_sb.lost[0] = u_sb.lost[0] + (u_sb.n[0] - u_sb.nxt[0]);   // tail losses
                u_sb.lost[1] = u_sb.lost[1] + (u_sb.n[1] - u_sb.nxt[1]);
            end
            repeat (40) @(posedge clk);
        end
    endtask

    // CSR counters against the scoreboard (clean traffic since reset)
    task automatic check_csr_clean(input [8*40-1:0] where);
        reg [31:0] d; reg [1:0] r; reg [8*140-1:0] m; integer np, nb;
        begin
            np = u_sb.n[0] + u_sb.n[1]; nb = u_sb.bytes_in[0] + u_sb.bytes_in[1];
            u_axil.read(8'h20, d, r); if (d != np) begin $sformat(m, "%0s: TX_PKT=%0d expected %0d", where, d, np); tb_fail(m); end
            u_axil.read(8'h3C, d, r); if (d != np) begin $sformat(m, "%0s: RX_PKT=%0d expected %0d", where, d, np); tb_fail(m); end
            u_axil.read(8'h2C, d, r); if (d != 0)  begin $sformat(m, "%0s: RX_CRC_ERR=%0d expected 0", where, d); tb_fail(m); end
            u_axil.read(8'h4C, d, r); if (d != nb) begin $sformat(m, "%0s: IN_BYTES=%0d expected %0d", where, d, nb); tb_fail(m); end
            u_axil.read(8'h50, d, r); if (d != nb) begin $sformat(m, "%0s: OUT_BYTES=%0d expected %0d", where, d, nb); tb_fail(m); end
            u_axil.read(8'h70, d, r); if (d != 0)  begin $sformat(m, "%0s: ERR_STATUS=%02h expected 0", where, d); tb_fail(m); end
        end
    endtask

    // ---------------- test framework ----------------
    integer base_seed = 1, max_cycles = 6000000, dummy, has_sel = 0, cur_idx = 0, err0, cyc0;
    reg [8*40-1:0] test_sel = "", cur_test;
    reg [8*200-1:0] vcd_file = "results/waves_arb.vcd", dump_file;
    integer r_ran [1:NTESTS], r_err [1:NTESTS];
    reg [8*40-1:0] r_name [1:NTESTS];
    reg [8*200-1:0] r_info [1:NTESTS];

    task automatic test_begin(input [8*40-1:0] name, input integer idx);
        integer s;
        begin
            cur_test = name; cur_idx = idx;
            s = base_seed * 1000 + idx; dummy = $urandom(s);
            $display(""); $display("[TEST-START] %0s  (test seed %0d)", name, s);
            u_src0.gap_pct = 0; u_src1.gap_pct = 0;
            u_sink.ready_pct = 100; u_sink.burst_mode = 0; u_sink.max_off = 40;
            u_sink.rng = s ^ 32'h5EED_5EED; u_sink.burst_left = 0;
            err0 = total_errors(); cyc0 = cycle;
            do_reset(5);
            u_sb.clear(); u_sb.allow_loss = 1'b0; u_sb.tag_base = 32'hA000_0000 | (idx << 20);
            if (u_ch.dump_fd != 0) $fdisplay(u_ch.dump_fd, "# test %0s", name);
            u_ch.clear_plan(); u_mon.clear_stats();
        end
    endtask

    task automatic test_end(input [8*200-1:0] info);
        integer e;
        begin
            e = total_errors() - err0;
            r_name[cur_idx] = cur_test; r_ran[cur_idx] = 1; r_err[cur_idx] = e; r_info[cur_idx] = info;
            $display("[INFO] %0s: grants src0=%0d src1=%0d | max wait src0=%0d src1=%0d cycles | max packets started past a waiting source: src0=%0d src1=%0d",
                     cur_test, u_mon.grants[0], u_mon.grants[1], u_mon.max_wait[0], u_mon.max_wait[1],
                     u_mon.max_other[0], u_mon.max_other[1]);
            $display("[INFO] %0s: delivered src0=%0d/%0d (%0d B) src1=%0d/%0d (%0d B) truncated=%0d/%0d lost=%0d/%0d",
                     cur_test, u_sb.delivered[0], u_sb.n[0], u_sb.bytes_out[0], u_sb.delivered[1], u_sb.n[1],
                     u_sb.bytes_out[1], u_sb.truncated[0], u_sb.truncated[1], u_sb.lost[0], u_sb.lost[1]);
            if (e == 0) $display("[TEST-RESULT] %-24s : PASS  (cycles=%0d pkts_in=%0d pkts_out=%0d %0s)", cur_test,
                                 cycle - cyc0, u_sb.n[0] + u_sb.n[1], u_sb.delivered[0] + u_sb.delivered[1], info);
            else        $display("[TEST-RESULT] %-24s : FAIL  (errors=%0d)", cur_test, e);
        end
    endtask

    // =========================================================================
    // 1 arb_single_source
    task automatic t_single_source();
        integer i;
        begin
            u_src0.gap_pct = 10; u_src1.gap_pct = 10;
            for (i = 0; i < 40; i = i + 1) add(0, rnd(4, 1500));
            send_stream(0, 0, 40, 0, 3);
            drain(40000);
            if (u_mon.grants[1] != 0) tb_fail("source 1 granted while idle");
            for (i = 0; i < 40; i = i + 1) add(1, rnd(4, 1500));
            send_stream(1, 0, 40, 0, 3);
            drain(40000);
            if (u_mon.grants[0] != 40 || u_mon.grants[1] != 40) tb_fail("grant count differs from packets sent");
            check_csr_clean("arb_single_source");
            test_end("each source alone, tid = source");
        end
    endtask

    // 2 arb_saturated_equal
    task automatic t_saturated_equal();
        integer i, t0, b0, b1; real share; reg [8*200-1:0] info; reg [8*140-1:0] m;
        begin
            for (i = 0; i < 200; i = i + 1) begin add(0, 256); add(1, 256); end
            t0 = cycle;
            fork
                send_stream(0, 0, 200, 0, 0);
                send_stream(1, 0, 200, 0, 0);
            join
            drain(60000);
            if (u_mon.grants[0] != 200 || u_mon.grants[1] != 200) tb_fail("grant counts differ");
            if (u_mon.max_other[0] > 1 || u_mon.max_other[1] > 1) tb_fail("alternation broken");
            b0 = u_sb.bytes_out[0]; b1 = u_sb.bytes_out[1];
            share = 100.0 * b0 / (b0 + b1);
            if (share < 49.0 || share > 51.0) begin $sformat(m, "byte share src0 %0.1f%% not 50%%", share); tb_fail(m); end
            check_csr_clean("arb_saturated_equal");
            $sformat(info, "share src0=%0.1f%% bytes, max wait %0d/%0d cycles", share, u_mon.max_wait[0], u_mon.max_wait[1]);
            test_end(info);
        end
    endtask

    // 3 arb_mixed_sizes: packet fairness (not byte fairness)
    task automatic t_mixed_sizes();
        integer i, bound; reg [8*200-1:0] info; reg [8*140-1:0] m;
        begin
            for (i = 0; i < 30; i = i + 1)  add(0, 4096);
            for (i = 0; i < 300; i = i + 1) add(1, 64);
            fork
                send_stream(0, 0, 30, 0, 0);
                send_stream(1, 0, 300, 0, 0);
            join
            drain(80000);
            // while both request, packets alternate: src1 waits at most one 4096 B packet
            // (19 FIUs x 8 link cycles) plus a small pipeline margin
            bound = ((4096 + PAYLOAD - 1) / PAYLOAD) * FIU_WORDS + 40;
            if (u_mon.max_wait[1] > bound) begin
                $sformat(m, "64 B source waited %0d cycles, bound one 4096 B packet = %0d", u_mon.max_wait[1], bound); tb_fail(m); end
            if (u_mon.max_other[0] > 1 || u_mon.max_other[1] > 1) tb_fail("starvation bound violated");
            check_csr_clean("arb_mixed_sizes");
            $sformat(info, "src1 max wait %0d <= %0d cycles; bytes src0=%0d src1=%0d (packet-fair)",
                     u_mon.max_wait[1], bound, u_sb.bytes_out[0], u_sb.bytes_out[1]);
            test_end(info);
        end
    endtask

    // 4 arb_starvation
    task automatic t_starvation();
        integer i, bound; reg [8*200-1:0] info; reg [8*140-1:0] m;
        begin
            for (i = 0; i < 250; i = i + 1) add(0, 1500);
            for (i = 0; i < 50; i = i + 1)  add(1, rnd(4, 400));
            fork
                send_stream(0, 0, 250, 0, 0);          // saturating source
                send_stream(1, 0, 50, 50, 300);        // sparse source
            join
            drain(80000);
            bound = ((1500 + PAYLOAD - 1) / PAYLOAD) * FIU_WORDS + 40;
            if (u_mon.max_wait[1] > bound) begin
                $sformat(m, "sparse source waited %0d cycles, bound %0d", u_mon.max_wait[1], bound); tb_fail(m); end
            if (u_mon.max_other[1] > 1) tb_fail("sparse source passed by more than one packet");
            if (u_mon.grants[1] != 50) tb_fail("sparse source not fully served");
            check_csr_clean("arb_starvation");
            $sformat(info, "sparse src1 max wait %0d <= %0d cycles, passed by <= %0d packet", u_mon.max_wait[1], bound, u_mon.max_other[1]);
            test_end(info);
        end
    endtask

    // 5 arb_random_stalls
    task automatic t_random_stalls();
        integer i;
        begin
            u_src0.gap_pct = 25; u_src1.gap_pct = 40;
            u_sink.burst_mode = 1; u_sink.ready_pct = 55; u_sink.max_off = 50;
            for (i = 0; i < 300; i = i + 1) begin add(0, rnd(4, 3000)); add(1, rnd(4, 3000)); end
            fork
                send_stream(0, 0, 300, 0, 20);
                send_stream(1, 0, 300, 0, 60);
            join
            drain(400000);
            if (u_mon.max_other[0] > 1 || u_mon.max_other[1] > 1) tb_fail("starvation bound violated");
            check_csr_clean("arb_random_stalls");
            test_end("random gaps, sizes 4..3000 B, burst back-pressure");
        end
    endtask

    // 6 arb_link_errors
    task automatic t_link_errors();
        integer i, f, nf; reg [31:0] d; reg [1:0] r; reg [8*200-1:0] info; reg [8*140-1:0] m;
        begin
            u_src0.gap_pct = 10; u_src1.gap_pct = 10; u_sink.ready_pct = 80;
            u_sb.allow_loss = 1'b1;
            for (i = 0; i < 300; i = i + 1) begin add(0, rnd(4, 1500)); add(1, rnd(4, 1500)); end
            nf = 0;
            for (f = 0; f < 3000; f = f + 1)
                if (($urandom % 100) < 4) begin
                    case ($urandom % 4)
                        0: u_ch.set_plan(f, 1, $urandom % FIU_WORDS, $urandom % 128, 1 + ($urandom % 3), 0, 0);   // symbols
                        1: u_ch.set_plan(f, 2, $urandom % FIU_WORDS, 0, 0, $urandom % LANES, 0);              // lane word
                        2: u_ch.set_plan(f, 4, 7, $urandom % 16, 1, 0, 0);                                     // CRC field
                        default: u_ch.set_plan(f, 3, 0, 0, 0, $urandom % LANES, 0);                           // lane failure
                    endcase
                    nf = nf + 1;
                end
            fork
                send_stream(0, 0, 300, 0, 4);
                send_stream(1, 0, 300, 0, 4);
            join
            drain(200000);
            u_axil.read(8'h2C, d, r);
            if (d == 0) tb_fail("no CRC errors counted although faults were injected");
            if (u_sb.delivered[0] + u_sb.delivered[1] < 450) tb_fail("too few packets delivered");
            if (u_sb.lost[0] + u_sb.lost[1] + u_sb.truncated[0] + u_sb.truncated[1] == 0) tb_fail("faults had no effect");
            $sformat(info, "faults planned on %0d FIUs, RX_CRC_ERR=%0d, lost %0d, truncated %0d", nf, d,
                     u_sb.lost[0] + u_sb.lost[1], u_sb.truncated[0] + u_sb.truncated[1]);
            test_end(info);
        end
    endtask

    // 7 arb_reset_traffic
    task automatic t_reset_traffic();
        integer i, t0; reg hit;
        begin
            u_sink.ready_pct = 60;
            for (i = 0; i < 40; i = i + 1) begin add(0, rnd(300, 1500)); add(1, rnd(300, 1500)); end
            u_sb.allow_loss = 1'b1;                      // packets in flight at the reset are lost
            fork
                send_stream(0, 0, 40, 0, 0);
                send_stream(1, 0, 40, 0, 0);
                begin
                    hit = 0; t0 = cycle;
                    while (!hit && cycle - t0 < 20000) begin
                        @(posedge clk);
                        hit = (cycle - t0 > 300) && s0_tvalid && s1_tvalid && dut.u_arb.locked;
                    end
                    if (!hit) tb_fail("reset condition (both sources active, arbiter locked) not reached");
                    do_reset(3);
                end
            join
            if (dut.u_arb.locked !== 1'b0 || m_tvalid !== 1'b0) tb_fail("arbiter/link not idle after reset");
            // fresh clean traffic
            u_sb.clear(); u_sb.allow_loss = 1'b0; u_sink.ready_pct = 90; u_mon.clear_stats();
            for (i = 0; i < 30; i = i + 1) begin add(0, rnd(4, 1200)); add(1, rnd(4, 1200)); end
            fork
                send_stream(0, 0, 30, 0, 2);
                send_stream(1, 0, 30, 0, 2);
            join
            drain(60000);
            test_end("reset with both sources mid-packet, then 60 clean packets");
        end
    endtask

    // 8 arb_back_to_back_switch: single-beat packets, zero-bubble hand-over
    task automatic t_b2b_switch();
        integer i, t0, t1, beats; real rate; reg [8*200-1:0] info; reg [8*140-1:0] m;
        begin
            for (i = 0; i < 200; i = i + 1) begin add(0, 64); add(1, 64); end
            t0 = cycle;
            fork
                send_stream(0, 0, 200, 0, 0);
                send_stream(1, 0, 200, 0, 0);
            join
            t1 = cycle;
            drain(40000);
            // every 64 B packet is one FIU (8 link cycles): the link, not the arbiter, limits the rate.
            // The arbiter must alternate on every packet with no lost cycle.
            if (u_mon.max_other[0] > 1 || u_mon.max_other[1] > 1) tb_fail("alternation broken");
            rate = 1.0 * (t1 - t0) / 400;
            if (rate > FIU_WORDS + 0.5) begin $sformat(m, "%0.2f cycles per packet, link limit %0d", rate, FIU_WORDS); tb_fail(m); end
            check_csr_clean("arb_back_to_back_switch");
            $sformat(info, "%0.2f cycles per 1-beat packet (link limit %0d)", rate, FIU_WORDS);
            test_end(info);
        end
    endtask

    // =========================================================================
    integer t, n_run, n_fail;
    reg [8*40-1:0] tname;
    task automatic run_test(input integer idx);
        begin
            case (idx)
                1: tname = "arb_single_source";   2: tname = "arb_saturated_equal";
                3: tname = "arb_mixed_sizes";     4: tname = "arb_starvation";
                5: tname = "arb_random_stalls";   6: tname = "arb_link_errors";
                7: tname = "arb_reset_traffic";   default: tname = "arb_back_to_back_switch";
            endcase
            r_ran[idx] = 0;
            if (!has_sel || test_sel == tname) begin
                test_begin(tname, idx);
                case (idx)
                    1: t_single_source();  2: t_saturated_equal();  3: t_mixed_sizes();  4: t_starvation();
                    5: t_random_stalls();  6: t_link_errors();      7: t_reset_traffic(); default: t_b2b_switch();
                endcase
            end
        end
    endtask

    initial begin
        if (!$value$plusargs("seed=%d", base_seed)) base_seed = 1;
        if ($value$plusargs("test=%s", test_sel)) has_sel = 1;
        if (!$value$plusargs("max_cycles=%d", max_cycles)) max_cycles = 6000000;
        void'($value$plusargs("vcd_file=%s", vcd_file));
        if ($value$plusargs("fiu_dump=%s", dump_file)) begin u_ch.dump_fd = $fopen(dump_file, "w"); u_ch.dump_en = 1'b1; end
        if ($test$plusargs("vcd")) begin
            $dumpfile(vcd_file);
            $dumpvars(1, tb_arb); $dumpvars(1, dut); $dumpvars(1, dut.u_arb);
        end
        $display("==============================================================================");
        $display(" tb_arb : axis_pcie_link_mux2_top (2 sources, round-robin arbiter)  seed=%0d test=%0s",
                 base_seed, has_sel ? test_sel : "ALL");
        $display("==============================================================================");
        for (t = 1; t <= NTESTS; t = t + 1) run_test(t);
        n_run = 0; n_fail = 0;
        $display("");
        $display("========================= ARBITER REGRESSION SUMMARY (seed=%0d) =========================", base_seed);
        for (t = 1; t <= NTESTS; t = t + 1) if (r_ran[t]) begin
            n_run = n_run + 1; if (r_err[t] != 0) n_fail = n_fail + 1;
            $display("%-26s %-5s errors=%0d  %0s", r_name[t], r_err[t] ? "FAIL" : "PASS", r_err[t], r_info[t]);
        end
        $display("component errors: tb=%0d src0=%0d src1=%0d chk_in0=%0d chk_in1=%0d chk_arb=%0d chk_egress=%0d axil=%0d stream_sb=%0d arb_monitor=%0d safety=%0d",
                 tb_errors, u_src0.errors, u_src1.errors, u_chk_in0.errors, u_chk_in1.errors, u_chk_arb.errors,
                 u_chk_eg.errors, u_axil.errors + u_chk_axil.errors, u_sb.errors, u_mon.errors, u_safe.errors);
        if (u_ch.dump_fd != 0) $fclose(u_ch.dump_fd);
        if (n_run == 0) begin $display("[SIM-RESULT] FAILED  no test matched +test=%0s", test_sel); $fatal(1, "no test"); end
        else if (n_fail == 0 && total_errors() == 0) begin
            $display("[SIM-RESULT] PASSED  tests=%0d passed=%0d failed=0 seed=%0d", n_run, n_run, base_seed); $finish;
        end else begin
            $display("[SIM-RESULT] FAILED  tests=%0d passed=%0d failed=%0d seed=%0d", n_run, n_run - n_fail, n_fail, base_seed);
            $fatal(1, "simulation failed");
        end
    end

    initial begin
        #1; while (cycle < max_cycles) @(posedge clk);
        $display("[TIMEOUT] global watchdog in test %0s", cur_test);
        $display("[SIM-RESULT] FAILED  global watchdog seed=%0d", base_seed);
        $fatal(1, "watchdog");
    end
endmodule
