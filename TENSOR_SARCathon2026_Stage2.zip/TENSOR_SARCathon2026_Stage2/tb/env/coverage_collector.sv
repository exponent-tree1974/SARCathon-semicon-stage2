`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// coverage_collector - functional coverage with explicit bins (Icarus has no
// covergroups; this works in every simulator). Bin IDs are listed in
// docs/coverage_plan.md. Sources:
//   * interface observation (ingress/egress AXIS, link symbols, DUT status)
//   * scoreboard packet-complete events (length, error)
//   * test-level hits (reset scenarios, CSR accesses, injected error types)
// report(fd) prints every bin with hits / goal / status and the overall score.
// -----------------------------------------------------------------------------
module coverage_collector #(
    parameter int AXIS_W = 512,
    parameter int PW     = 7,      // payload words per FIU (credit unit)
    parameter int DEPTH  = 32      // RX buffer depth
) (
    input wire                 clk,
    input wire                 rst_n,
    // ingress AXIS
    input wire [AXIS_W/8-1:0]  s_tkeep,
    input wire                 s_tlast,
    input wire                 s_tvalid,
    input wire                 s_tready,
    // egress AXIS
    input wire                 m_tlast,
    input wire                 m_tuser,
    input wire                 m_tvalid,
    input wire                 m_tready,
    // link
    input wire                 tx_sym_valid,
    input wire                 tx_sym_sof,
    // DUT status (white-box)
    input wire [7:0]           tx_credits,
    input wire                 fiu_start_pending,   // packetizer offers FIU word 0
    input wire [7:0]           rxbuf_used,
    input wire                 rx_discard,
    // scoreboard events
    input wire                 ev_pkt,
    input wire [31:0]          ev_pkt_len,
    input wire                 ev_pkt_err
);
    localparam int KB = AXIS_W / 8;
    localparam int NB = 112;

    `include "cov_bins.svh"

    integer hits [0:NB-1];
    integer goal [0:NB-1];
    reg     na   [0:NB-1];          // not applicable for this configuration (e.g. lane >= LANES)
    reg [8*28-1:0] name [0:NB-1];

    task automatic def(input integer id, input [8*28-1:0] n, input integer g);
        begin name[id] = n; goal[id] = g; hits[id] = 0; na[id] = 1'b0; end
    endtask
    task automatic set_na(input integer id);
        begin na[id] = 1'b1; end
    endtask
    task automatic hit(input integer id);
        begin hits[id] = hits[id] + 1; end
    endtask
    task automatic add(input integer id, input integer n);
        begin hits[id] = hits[id] + n; end
    endtask

    initial begin
        def(L_1,"len_exact_1",1); def(L_63,"len_exact_63",1); def(L_64,"len_exact_64",1);
        def(L_65,"len_exact_65",1); def(L_100,"len_exact_100",1); def(L_255,"len_exact_255",1);
        def(L_256,"len_exact_256",1); def(L_2_31,"len_2_31",5); def(L_32,"len_exact_32",1);
        def(L_33_62,"len_33_62",5); def(L_66_127,"len_66_127",5); def(L_128_223,"len_128_223",5);
        def(L_224,"len_exact_224_one_fiu",1); def(L_225_447,"len_225_447",5);
        def(L_448_1023,"len_448_1023",5); def(L_1024_4095,"len_1024_4095",5); def(L_GE_4096,"len_ge_4096",1);
        def(KB_1,"last_beat_1B",1); def(KB_2_31,"last_beat_2_31B",5); def(KB_32,"last_beat_32B",1);
        def(KB_33_63,"last_beat_33_63B",5); def(KB_64,"last_beat_64B",5);
        def(ING_DUT_STALL,"ing_tready_low_while_valid",10); def(ING_IDLE_MIDPKT,"ing_tvalid_gap_midpkt",10);
        def(ING_B2B,"ing_back_to_back_pkts",10); def(ING_NULL_BEAT,"ing_null_beat",3);
        def(ING_ZLAST,"ing_zero_len_tlast",3); def(ING_EMPTY_PKT,"ing_empty_packet",2);
        def(ING_ILL_PARTIAL_MID,"ing_partial_nonlast_beat",1); def(ING_ILL_SPARSE,"ing_sparse_tkeep",1);
        def(ING_ILL_OFFSET,"ing_offset_tkeep",1); def(ING_ILL_HOLE,"ing_hole_in_full_beat",1);
        def(EG_BACKPRESSURE,"eg_tvalid_while_not_ready",10); def(EG_B2B,"eg_back_to_back_pkts",10);
        def(EG_TUSER,"eg_tuser_error_packet",3); def(EG_SINGLE_BEAT,"eg_single_beat_pkt",5);
        def(EG_MULTI_BEAT,"eg_multi_beat_pkt",5); def(EG_LONG_STALL,"eg_stall_ge_32_cycles",1);
        def(LNK_FIU_B2B,"link_fiu_back_to_back",10); def(LNK_CREDIT_EXHAUSTED,"link_credit_exhausted",1);
        def(LNK_RXBUF_HIGH,"rxbuf_high_watermark",1); def(LNK_RX_DISCARD,"rx_discard_mode",1);
        def(LNK_IDLE_GAP,"link_idle_inside_fiu",1);
        def(ERR_SYM,"inj_symbol_error",3); def(ERR_SYM_BURST,"inj_symbol_burst",1);
        def(ERR_LANE0,"inj_lane0",1); def(ERR_LANE1,"inj_lane1",1); def(ERR_LANE2,"inj_lane2",1);
        def(ERR_LANE3,"inj_lane3",1); def(ERR_LANE_FIU,"inj_lane_fail_whole_fiu",1);
        def(ERR_CRC_FIELD,"inj_crc_field",2); def(ERR_TRAILER_HDR,"inj_trailer_header",1);
        def(FG_MAGIC,"forge_magic",1); def(FG_LEN0,"forge_len_zero",1); def(FG_LENBIG,"forge_len_too_big",1);
        def(FG_EOP_CLR,"forge_eop_clear",1); def(FG_SOP_CLR,"forge_sop_clear",1); def(FG_SOP_SET,"forge_sop_set",1);
        def(FG_SEQ,"forge_seq",1); def(FG_ERR_SET,"forge_poison",1); def(FG_EOP_SET,"forge_eop_set",1);
        def(RXP_FIRST_FIU_LOST,"rx_first_fiu_dropped",1); def(RXP_ABORT_MIDPKT,"rx_abort_open_packet",2);
        def(RXP_DISCARD_GOOD,"rx_discard_good_fiu",1); def(RXP_SOP_IN_PKT,"rx_sop_while_open",1);
        def(RXP_CONT_NO_PKT,"rx_cont_without_open",1); def(RXP_SEQ_ERR,"rx_seq_error",1);
        def(RXP_POISON,"rx_poison_propagated",1);
        def(RST_IDLE,"reset_while_idle",1); def(RST_ING_MIDPKT,"reset_ingress_midpkt",1);
        def(RST_LINK_MIDFIU,"reset_link_mid_fiu",1); def(RST_EG_BACKPRESSURED,"reset_egress_stalled",1);
        def(RST_RXBUF_NONEMPTY,"reset_rxbuf_nonempty",1);
        def(CSR_RD_ID,"csr_rd_id",1); def(CSR_RD_VERSION,"csr_rd_version",1); def(CSR_RD_CTRL,"csr_rd_ctrl",1);
        def(CSR_RD_STATUS,"csr_rd_status",1); def(CSR_RD_SCRATCH,"csr_rd_scratch",1); def(CSR_RD_PARAMS,"csr_rd_params",1);
        def(CSR_RD_COUNTERS,"csr_rd_all_counters",1); def(CSR_WR_STRB_PARTIAL,"csr_wr_partial_strobe",1);
        def(CSR_WR_RO_SLVERR,"csr_wr_ro_slverr",1); def(CSR_RD_UNMAPPED_SLVERR,"csr_rd_unmapped_slverr",1);
        def(CSR_WR_UNMAPPED_SLVERR,"csr_wr_unmapped_slverr",1); def(CSR_AW_FIRST,"csr_aw_before_w",1);
        def(CSR_W_FIRST,"csr_w_before_aw",1); def(CSR_AW_W_TOGETHER,"csr_aw_w_same_cycle",1);
        def(CSR_CNT_CLEAR,"csr_counter_clear",1); def(CSR_LINK_EN_OFF,"csr_link_en_off",1);
        def(TR_PKT_GE_8_FIU,"pkt_spanning_ge_8_fius",1); def(TR_ORDER_1000,"order_checked_ge_1000_pkts",1);
        def(TR_ERR_PKT_DELIVERED,"error_pkt_delivered_tuser",1);
        def(TID_ZERO_DELIVERED,"tid_zero_delivered",5); def(TID_MAX_DELIVERED,"tid_max_delivered",5);
        def(FG_TID,"forge_tid",1); def(RXP_TID_MISMATCH,"rx_tid_mismatch_abort",1);
        def(CSR_RD_PARAMS2,"csr_rd_params2",1); def(CSR_RD_SEQ_STATUS,"csr_rd_seq_status",3);
        def(CSR_RD_PERF,"csr_rd_perf_counters",3); def(CSR_ERR_W1C,"csr_err_status_w1c",2);
        def(CSR_IRQ_ASSERT,"csr_irq_asserted",1); def(CSR_IRQ_DEASSERT,"csr_irq_deasserted",1);
        def(CSR_LAST_ERR_CRC,"last_err_reason_crc",1); def(CSR_LAST_ERR_HDR,"last_err_reason_hdr",1);
        def(CSR_LAST_ERR_SOPIN,"last_err_reason_sop_in_pkt",1); def(CSR_LAST_ERR_TID,"last_err_reason_tid",1);
        def(CSR_LAST_ERR_SEQ,"last_err_reason_seq",1);
        def(PERF_CREDIT_STALL,"perf_credit_stall_nonzero",1); def(PERF_IN_STALL,"perf_in_stall_nonzero",1);
        def(PERF_OUT_STALL,"perf_out_stall_nonzero",1);
    end

    // ---------------- interface sampling ---------------------------------------------
    reg     pend_partial = 0;
    reg     in_pkt_i = 0, has_data_i = 0, last_hs_i = 0, last_hs_e = 0, in_fiu = 0;
    integer eg_beats = 0, eg_stall = 0, since_sof = 0;
    reg     s_hs, m_hs;
    integer nbk;

    function automatic integer ones(input [KB-1:0] k);
        integer q; begin ones = 0; for (q = 0; q < KB; q = q + 1) ones = ones + k[q]; end
    endfunction
    function automatic bit contig(input [KB-1:0] k);
        contig = ((k & (k + 1'b1)) == '0);
    endfunction

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            in_pkt_i = 0; has_data_i = 0; last_hs_i = 0; last_hs_e = 0; eg_beats = 0; pend_partial = 0;
            eg_stall = 0; in_fiu = 0; since_sof = 0;
        end else begin
            s_hs = (s_tvalid === 1'b1) && (s_tready === 1'b1);
            m_hs = (m_tvalid === 1'b1) && (m_tready === 1'b1);
            // ---- ingress
            if (s_tvalid === 1'b1 && s_tready !== 1'b1) hit(ING_DUT_STALL);
            if (in_pkt_i && s_tvalid !== 1'b1) hit(ING_IDLE_MIDPKT);
            if (s_hs) begin
                if (last_hs_i) hit(ING_B2B);
                nbk = ones(s_tkeep);
                if (s_tkeep == '0) begin
                    if (s_tlast) begin
                        hit(ING_ZLAST);
                        if (!has_data_i) hit(ING_EMPTY_PKT);
                        pend_partial = 0;                  // legal: zero-length tlast after partial
                    end else hit(ING_NULL_BEAT);
                end else begin
                    if (pend_partial) hit(ING_ILL_PARTIAL_MID);   // partial beat was not the last
                    pend_partial = 0;
                    has_data_i = 1;
                    if (!contig(s_tkeep)) begin
                        if (s_tkeep[0] == 1'b0)  hit(ING_ILL_OFFSET);   // does not start at byte 0
                        else if (nbk < KB/2)     hit(ING_ILL_SPARSE);   // scattered bytes
                        else                     hit(ING_ILL_HOLE);     // mostly full with holes
                    end else if (!s_tlast && nbk != KB) begin
                        pend_partial = 1;
                    end
                    if (s_tlast && contig(s_tkeep)) begin
                        if (nbk == 1) hit(KB_1); else if (nbk < 32) hit(KB_2_31);
                        else if (nbk == 32) hit(KB_32); else if (nbk < KB) hit(KB_33_63); else hit(KB_64);
                    end
                end
                in_pkt_i  = !s_tlast;
                if (s_tlast) has_data_i = 0;
                last_hs_i = s_tlast;
            end else begin
                last_hs_i = 0;
            end
            // ---- egress
            if (m_tvalid === 1'b1 && m_tready !== 1'b1) begin
                hit(EG_BACKPRESSURE);
                eg_stall = eg_stall + 1;
                if (eg_stall == 32) hit(EG_LONG_STALL);
            end else eg_stall = 0;
            if (m_hs) begin
                if (last_hs_e) hit(EG_B2B);
                eg_beats = eg_beats + 1;
                if (m_tlast) begin
                    if (m_tuser) hit(EG_TUSER);
                    if (eg_beats == 1) hit(EG_SINGLE_BEAT); else hit(EG_MULTI_BEAT);
                    eg_beats = 0;
                end
                last_hs_e = m_tlast;
            end else last_hs_e = 0;
            // ---- link
            if (tx_sym_valid === 1'b1 && tx_sym_sof === 1'b1) begin
                if (since_sof == 8) hit(LNK_FIU_B2B);
                since_sof = 0; in_fiu = 1;
            end
            if (in_fiu) begin
                since_sof = since_sof + 1;
                if (tx_sym_valid !== 1'b1 && since_sof < 8) hit(LNK_IDLE_GAP);
                if (since_sof >= 8) in_fiu = 0;
            end else if (since_sof > 0) since_sof = since_sof + 1;
            if (fiu_start_pending === 1'b1 && tx_credits < PW) hit(LNK_CREDIT_EXHAUSTED);
            if (rxbuf_used >= DEPTH - PW) hit(LNK_RXBUF_HIGH);
            if (rx_discard === 1'b1) hit(LNK_RX_DISCARD);
        end
        // ---- scoreboard packet events
        if (ev_pkt) begin
            if (ev_pkt_err) hit(TR_ERR_PKT_DELIVERED);
            else begin
                case (ev_pkt_len)
                    1: hit(L_1); 63: hit(L_63); 64: hit(L_64); 65: hit(L_65); 100: hit(L_100);
                    255: hit(L_255); 256: hit(L_256); 32: hit(L_32); 224: hit(L_224);
                    default: ;
                endcase
                if (ev_pkt_len >= 2 && ev_pkt_len <= 31) hit(L_2_31);
                if (ev_pkt_len >= 33 && ev_pkt_len <= 62) hit(L_33_62);
                if (ev_pkt_len >= 66 && ev_pkt_len <= 127) hit(L_66_127);
                if (ev_pkt_len >= 128 && ev_pkt_len <= 223) hit(L_128_223);
                if (ev_pkt_len >= 225 && ev_pkt_len <= 447) hit(L_225_447);
                if (ev_pkt_len >= 448 && ev_pkt_len <= 1023) hit(L_448_1023);
                if (ev_pkt_len >= 1024 && ev_pkt_len <= 4095) hit(L_1024_4095);
                if (ev_pkt_len >= 4096) hit(L_GE_4096);
                if (ev_pkt_len > 7 * 224) hit(TR_PKT_GE_8_FIU);
            end
        end
    end

    // ---------------- report --------------------------------------------------------------
    task automatic report(input integer fd);
        integer k, covered, napp;
        real pct;
        begin
            covered = 0; napp = 0;
            for (k = 0; k < NBINS; k = k + 1)
                if (na[k]) napp = napp + 1;
                else if (hits[k] >= goal[k]) covered = covered + 1;
            pct = 100.0 * covered / (NBINS - napp);
            $fdisplay(fd, "FUNCTIONAL COVERAGE REPORT");
            $fdisplay(fd, "%-4s %-30s %10s %6s %s", "id", "bin", "hits", "goal", "status");
            for (k = 0; k < NBINS; k = k + 1)
                $fdisplay(fd, "%-4d %-30s %10d %6d %s", k, name[k], hits[k], goal[k],
                          na[k] ? "N/A" : (hits[k] >= goal[k]) ? "COVERED" : "HOLE");
            $fdisplay(fd, "COVERAGE SUMMARY: %0d / %0d bins covered (%0.1f%%)%0s", covered, NBINS - napp, pct,
                      napp ? " (bins marked N/A excluded)" : "");
        end
    endtask

    function automatic integer holes();
        integer k;
        begin
            holes = 0;
            for (k = 0; k < NBINS; k = k + 1) if (!na[k] && hits[k] < goal[k]) holes = holes + 1;
        end
    endfunction
endmodule
