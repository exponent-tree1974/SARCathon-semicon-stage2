`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// pkt_scoreboard - packet database, reference model and egress checker
//
// 1. Packet database: add_packet() creates a packet (random bytes, unique 32-bit
//    order tag in bytes 0..3) and records how it must be driven (flags).
// 2. build_fiu_map(): assigns global FIU numbers (FIU n = n-th FIU after reset).
// 3. Plan mirror: mark_fiu(f, mode, forge_kind) mirrors the channel plan.
// 4. build_expect(): FIU-level reference model of the documented RX policy
//    (spec Part B, decision table) -> expected egress packets (exact bytes,
//    tlast position, tuser, tid) and expected values of all 11 CSR event
//    counters, the expected LAST_ERR capture, SEQ_STATUS fields and the
//    total delivered bytes.
// 5. Egress monitor: byte-for-byte compare, packet-order check via the tag,
//    tlast/tuser/tid check, unexpected/extra beat detection.
// Every packet gets a random stream ID (pk_tid, TID_W bits) that must come
// out unchanged on m_axis_tid.
// The model is independent of the RTL implementation: it only uses the FIU
// format and policy from the specification.
// -----------------------------------------------------------------------------
module pkt_scoreboard #(
    parameter int AXIS_W    = 512,
    parameter int LINK_W    = 256,
    parameter int FIU_BYTES = 256,
    parameter int MAXP      = 8192,
    parameter int MAXFIU    = 16384,
    parameter int MEMSZ     = 1 << 22,
    parameter int TID_W     = 4
) (
    input wire                 clk,
    input wire                 rst_n,
    input wire [AXIS_W-1:0]    m_tdata,
    input wire [AXIS_W/8-1:0]  m_tkeep,
    input wire                 m_tlast,
    input wire                 m_tuser,
    input wire [7:0]           m_tid,
    input wire                 m_tvalid,
    input wire                 m_tready,
    // coverage event (1-cycle pulse when a complete egress packet was checked)
    output reg                 ev_pkt,
    output reg [31:0]          ev_pkt_len,
    output reg                 ev_pkt_err
);
    localparam int KB      = AXIS_W / 8;
    localparam int LB      = LINK_W / 8;
    localparam int PAYLOAD = FIU_BYTES - LB;

    // flags (how a packet is driven on AXIS)
    localparam int F_ZLAST = 1, F_NULLS = 2, F_ILL_MID = 4, F_ILL_SPR = 8, F_EMPTY = 16,
                   F_ILL_HOLE = 32, F_ILL_OFS = 64;
    localparam int F_ILLEGAL = F_ILL_MID | F_ILL_SPR | F_ILL_HOLE | F_ILL_OFS;
    // counter indices (CSR 0x20 + 4*i)
    localparam int C_TX_PKT = 0, C_TX_FIU = 1, C_RX_GOOD = 2, C_RX_CRC = 3, C_RX_FRAME = 4,
                   C_RX_SEQ = 5, C_RX_DISC = 6, C_RX_PKT = 7, C_RX_PKT_ERR = 8,
                   C_IN_PROTO = 9, C_IN_EMPTY = 10, NCNT = 11;
    localparam int MODE_FORGE = 6;
    localparam int FK_MAGIC = 1, FK_LEN0 = 2, FK_LENBIG = 3, FK_EOP_CLR = 4, FK_SOP_CLR = 5,
                   FK_SOP_SET = 6, FK_SEQ = 7, FK_ERR_SET = 8, FK_EOP_SET = 9, FK_TID = 10;
    localparam int MODE_CRC_FIELD = 4;

    // ---------------- packet database ------------------------------------------------
    reg [7:0] mem [0:MEMSZ-1];
    integer pk_len [0:MAXP-1];
    integer pk_off [0:MAXP-1];
    integer pk_flg [0:MAXP-1];
    integer pk_err [0:MAXP-1];
    integer pk_nfiu[0:MAXP-1];
    integer pk_fiu0[0:MAXP-1];
    integer pk_tid [0:MAXP-1];
    integer np = 0, mem_ptr = 0, total_fiu = 0;
    integer tag_base = 0;

    // plan mirror
    reg [3:0] sb_mode [0:MAXFIU-1];
    integer   sb_fk   [0:MAXFIU-1];

    // expected egress
    reg [7:0] exp_mem [0:MEMSZ-1];
    integer ex_off [0:MAXP-1];
    integer ex_len [0:MAXP-1];
    integer ex_err [0:MAXP-1];
    integer ex_tag [0:MAXP-1];
    integer ex_src [0:MAXP-1];
    integer ex_tid [0:MAXP-1];
    integer n_exp = 0, exp_ptr = 0;
    integer exp_cnt [0:NCNT-1];
    reg     model_open_at_end = 1'b0;
    // expected CSR state beyond the counters
    integer m_le_valid = 0, m_le_reason = 0, m_le_exp = 0, m_le_rx = 0, m_le_rx_known = 0;
    integer m_rx_exp_seq = 0, m_last_acc_seq = 0, m_any_acc = 0, m_out_bytes = 0;

    // model decision statistics (for coverage / reporting)
    integer m_dec_crc = 0, m_dec_hdr = 0, m_dec_sopin = 0, m_dec_cont = 0, m_dec_acc = 0;
    integer m_aborts = 0, m_first_fiu_lost = 0, m_seq_err = 0, m_poison = 0, m_dec_tid = 0;
    integer m_tid_zero = 0, m_tid_max = 0;

    // monitor state / results
    reg     mon_en = 1'b1;
    integer ep = 0, eoff = 0;
    integer errors = 0;
    integer pkts_ok = 0, pkts_bad = 0, bytes_checked = 0, beats_seen = 0;
    integer order_violations = 0, extra_beats = 0;
    reg     cur_pkt_bad = 1'b0;
    integer max_print = 25;

    integer i;
    initial begin
        for (i = 0; i < MAXFIU; i = i + 1) begin sb_mode[i] = 0; sb_fk[i] = 0; end
        for (i = 0; i < NCNT; i = i + 1) exp_cnt[i] = 0;
        ev_pkt = 1'b0; ev_pkt_len = 0; ev_pkt_err = 1'b0;
    end

    task automatic err(input [8*120-1:0] msg);
        begin
            errors = errors + 1;
            if (errors <= max_print) $display("[ERROR] %0t scoreboard: %0s", $time, msg);
        end
    endtask

    // ---------------- database API ----------------------------------------------------
    task automatic clear();
        integer k;
        begin
            np = 0; mem_ptr = 0; total_fiu = 0; n_exp = 0; exp_ptr = 0;
            ep = 0; eoff = 0; cur_pkt_bad = 0;
            pkts_ok = 0; pkts_bad = 0; bytes_checked = 0; beats_seen = 0;
            order_violations = 0; extra_beats = 0; model_open_at_end = 0;
            m_dec_crc = 0; m_dec_hdr = 0; m_dec_sopin = 0; m_dec_cont = 0; m_dec_acc = 0;
            m_aborts = 0; m_first_fiu_lost = 0; m_seq_err = 0; m_poison = 0; m_dec_tid = 0;
            m_le_valid = 0; m_le_reason = 0; m_le_exp = 0; m_le_rx = 0; m_le_rx_known = 0;
            m_rx_exp_seq = 0; m_last_acc_seq = 0; m_any_acc = 0; m_out_bytes = 0;
            m_tid_zero = 0; m_tid_max = 0;
            for (k = 0; k < MAXFIU; k = k + 1) begin sb_mode[k] = 0; sb_fk[k] = 0; end
            for (k = 0; k < NCNT; k = k + 1) exp_cnt[k] = 0;
        end
    endtask

    // len = number of bytes that must appear at egress (for illegal-tkeep packets
    // this includes the whole illegal beat, which the DUT forwards unmodified)
    task automatic add_packet(input integer len, input integer flags, output integer idx);
        integer k, tag;
        begin
            idx = np;
            if (np >= MAXP || mem_ptr + len >= MEMSZ) $fatal(1, "scoreboard: packet database full");
            pk_len[np] = len; pk_flg[np] = flags; pk_off[np] = mem_ptr;
            pk_err[np] = ((flags & F_ILLEGAL) != 0);
            pk_tid[np] = $urandom % (1 << TID_W);
            for (k = 0; k < len; k = k + 1) mem[mem_ptr + k] = $urandom;
            tag = tag_base + np;
            for (k = 0; k < 4 && k < len; k = k + 1) mem[mem_ptr + k] = tag >> (8*k);
            mem_ptr = mem_ptr + len;
            np = np + 1;
        end
    endtask

    task automatic build_fiu_map();
        integer p;
        begin
            total_fiu = 0;
            for (p = 0; p < np; p = p + 1) begin
                pk_fiu0[p] = total_fiu;
                pk_nfiu[p] = (pk_flg[p] & F_EMPTY) ? 0 : (pk_len[p] + PAYLOAD - 1) / PAYLOAD;
                total_fiu  = total_fiu + pk_nfiu[p];
            end
            if (total_fiu > MAXFIU) $fatal(1, "scoreboard: MAXFIU exceeded");
        end
    endtask

    task automatic mark_fiu(input integer f, input integer mode, input integer fk);
        begin
            if (f < MAXFIU) begin sb_mode[f] = mode; sb_fk[f] = fk; end
        end
    endtask

    // ---------------- reference model --------------------------------------------------
    integer r_in_pkt, r_discard, r_seq, r_cur, r_tid;
    // LAST_ERR capture (spec: decision error first, else sequence error)
    task automatic m_capture(input integer reason, input integer exp_s, input integer rx_s, input integer known);
        begin
            m_le_valid = 1; m_le_reason = reason; m_le_exp = exp_s; m_le_rx = rx_s; m_le_rx_known = known;
        end
    endtask
    task automatic m_abort();
        begin
            if (r_in_pkt) begin
                ex_err[r_cur] = 1;               // closed with tlast + tuser
                m_aborts = m_aborts + 1;
            end
            r_in_pkt = 0;
        end
    endtask

    task automatic build_expect();
        integer p, j, f, L, nf, k;
        integer sop, eop, len, perr, seq, magic_ok, crc_ok, hdr_ok, mode, fk, tid, seq_bad, exp_s, known;
        begin
            n_exp = 0; exp_ptr = 0;
            for (k = 0; k < NCNT; k = k + 1) exp_cnt[k] = 0;
            r_in_pkt = 0; r_discard = 0; r_seq = 0; r_cur = -1; r_tid = 0;
            m_le_valid = 0; m_le_reason = 0; m_le_exp = 0; m_le_rx = 0; m_le_rx_known = 0;
            m_last_acc_seq = 0; m_any_acc = 0;
            for (p = 0; p < np; p = p + 1) begin
                if (pk_flg[p] & F_ILLEGAL) exp_cnt[C_IN_PROTO] = exp_cnt[C_IN_PROTO] + 1;
                if (pk_flg[p] & F_EMPTY) begin
                    exp_cnt[C_IN_EMPTY] = exp_cnt[C_IN_EMPTY] + 1;
                end else begin
                    L = pk_len[p]; nf = pk_nfiu[p];
                    exp_cnt[C_TX_PKT] = exp_cnt[C_TX_PKT] + 1;
                    exp_cnt[C_TX_FIU] = exp_cnt[C_TX_FIU] + nf;
                    for (j = 0; j < nf; j = j + 1) begin
                        f = pk_fiu0[p] + j;
                        // fields as transmitted
                        sop = (j == 0); eop = (j == nf - 1);
                        len = eop ? L - PAYLOAD * (nf - 1) : PAYLOAD;
                        perr = pk_err[p]; seq = f % 256; magic_ok = 1; tid = pk_tid[p];
                        mode = sb_mode[f]; fk = sb_fk[f];
                        // fields as received
                        crc_ok = (mode == 0 || mode == MODE_FORGE);
                        if (mode == MODE_FORGE) begin
                            case (fk)
                                FK_MAGIC:   magic_ok = 0;
                                FK_LEN0:    len = 0;
                                FK_LENBIG:  len = PAYLOAD + 1;
                                FK_EOP_CLR: eop = 0;
                                FK_SOP_CLR: sop = 0;
                                FK_SOP_SET: sop = 1;
                                FK_SEQ:     seq = seq ^ 8'h55;
                                FK_ERR_SET: perr = 1;
                                FK_EOP_SET: eop = 1;
                                FK_TID:     tid = tid ^ 1;
                                default: ;
                            endcase
                        end
                        // sequence tracking
                        exp_s = r_seq; seq_bad = crc_ok && (seq != r_seq);
                        known = (mode == 0 || mode == MODE_CRC_FIELD || mode == MODE_FORGE);
                        if (crc_ok) begin
                            if (seq != r_seq) begin exp_cnt[C_RX_SEQ] = exp_cnt[C_RX_SEQ] + 1; m_seq_err = m_seq_err + 1; end
                            r_seq = (seq + 1) % 256;
                        end else begin
                            r_seq = (r_seq + 1) % 256;
                        end
                        hdr_ok = magic_ok && len >= 1 && len <= PAYLOAD && (eop || len == PAYLOAD);
                        if (!crc_ok) begin
                            exp_cnt[C_RX_CRC] = exp_cnt[C_RX_CRC] + 1; m_dec_crc = m_dec_crc + 1;
                            if (j == 0) m_first_fiu_lost = m_first_fiu_lost + 1;
                            m_capture(1, exp_s, seq, known && mode == MODE_CRC_FIELD);
                            m_abort(); r_discard = 1;
                        end else if (!hdr_ok) begin
                            exp_cnt[C_RX_FRAME] = exp_cnt[C_RX_FRAME] + 1; m_dec_hdr = m_dec_hdr + 1;
                            m_capture(2, exp_s, seq, known);
                            m_abort(); r_discard = 1;
                        end else if (sop && r_in_pkt) begin
                            exp_cnt[C_RX_FRAME] = exp_cnt[C_RX_FRAME] + 1; m_dec_sopin = m_dec_sopin + 1;
                            m_capture(3, exp_s, seq, known);
                            m_abort(); r_discard = 1;
                        end else if (!sop && r_in_pkt && tid != r_tid) begin
                            exp_cnt[C_RX_FRAME] = exp_cnt[C_RX_FRAME] + 1; m_dec_tid = m_dec_tid + 1;
                            m_capture(5, exp_s, seq, known);
                            m_abort(); r_discard = 1;
                        end else if (!sop && !r_in_pkt) begin
                            if (r_discard) begin
                                exp_cnt[C_RX_DISC] = exp_cnt[C_RX_DISC] + 1;
                                if (seq_bad) m_capture(7, exp_s, seq, known);
                            end else begin
                                exp_cnt[C_RX_FRAME] = exp_cnt[C_RX_FRAME] + 1;
                                m_capture(4, exp_s, seq, known);
                            end
                            m_dec_cont = m_dec_cont + 1;
                            r_discard = 1;
                        end else begin
                            if (seq_bad) m_capture(7, exp_s, seq, known);
                            m_last_acc_seq = seq; m_any_acc = 1;
                            if (sop) r_tid = tid;
                            exp_cnt[C_RX_GOOD] = exp_cnt[C_RX_GOOD] + 1; m_dec_acc = m_dec_acc + 1;
                            if (sop) begin
                                r_cur = n_exp; n_exp = n_exp + 1;
                                ex_off[r_cur] = exp_ptr; ex_len[r_cur] = 0; ex_err[r_cur] = 0;
                                ex_src[r_cur] = p;
                                ex_tid[r_cur] = tid;
                                ex_tag[r_cur] = (L >= 4) ? (tag_base + p) : -1;
                            end
                            for (k = 0; k < len; k = k + 1)
                                exp_mem[exp_ptr + k] = mem[pk_off[p] + j * PAYLOAD + k];
                            exp_ptr = exp_ptr + len;
                            ex_len[r_cur] = ex_len[r_cur] + len;
                            if (perr) begin ex_err[r_cur] = 1; if (!pk_err[p]) m_poison = m_poison + 1; end
                            r_in_pkt = !eop; r_discard = 0;
                        end
                    end
                end
            end
            model_open_at_end = r_in_pkt;
            m_rx_exp_seq = r_seq; m_out_bytes = exp_ptr;
            exp_cnt[C_RX_PKT] = n_exp;
            for (k = 0; k < n_exp; k = k + 1)
                if (ex_err[k]) exp_cnt[C_RX_PKT_ERR] = exp_cnt[C_RX_PKT_ERR] + 1;
        end
    endtask

    // ---------------- egress monitor -------------------------------------------------------
    integer b, nk, tag_got, q;
    reg [8*120-1:0] msg;
    always @(posedge clk) begin
        ev_pkt <= 1'b0;
        if (rst_n === 1'b1 && mon_en && m_tvalid === 1'b1 && m_tready === 1'b1) begin
            beats_seen = beats_seen + 1;
            if (ep >= n_exp) begin
                extra_beats = extra_beats + 1;
                err("unexpected egress beat (no packet outstanding)");
            end else begin
                // order check on the first beat of a packet
                if (eoff == 0 && ex_tag[ep] >= 0 && ex_len[ep] >= 4) begin
                    tag_got = m_tdata[31:0];
                    if (tag_got != ex_tag[ep]) begin
                        q = -1;
                        for (b = 0; b < n_exp; b = b + 1) if (ex_tag[b] == tag_got && q < 0) q = b;
                        order_violations = order_violations + 1;
                        if (q >= 0) $sformat(msg, "ORDER VIOLATION: received packet #%0d (tag %08h) while expecting #%0d (tag %08h)",
                                             q, tag_got, ep, ex_tag[ep]);
                        else        $sformat(msg, "unknown packet tag %08h, expected #%0d (tag %08h)", tag_got, ep, ex_tag[ep]);
                        err(msg);
                    end
                end
                if (m_tid !== 8'(ex_tid[ep])) begin
                    if (!cur_pkt_bad) begin
                        $sformat(msg, "pkt #%0d: m_axis_tid=%0d expected %0d", ep, m_tid, ex_tid[ep]); err(msg);
                    end
                    cur_pkt_bad = 1;
                end
                nk = 0;
                for (b = 0; b < KB; b = b + 1) begin
                    if (m_tkeep[b]) begin
                        nk = nk + 1;
                        if (eoff >= ex_len[ep]) begin
                            if (!cur_pkt_bad) begin
                                $sformat(msg, "pkt #%0d: more bytes than expected (%0d)", ep, ex_len[ep]); err(msg);
                            end
                            cur_pkt_bad = 1;
                        end else if (m_tdata[b*8 +: 8] !== exp_mem[ex_off[ep] + eoff]) begin
                            if (!cur_pkt_bad) begin
                                $sformat(msg, "pkt #%0d byte %0d: got %02h expected %02h", ep, eoff,
                                         m_tdata[b*8 +: 8], exp_mem[ex_off[ep] + eoff]);
                                err(msg);
                            end
                            cur_pkt_bad = 1;
                        end else begin
                            bytes_checked = bytes_checked + 1;
                        end
                        eoff = eoff + 1;
                    end else if (m_tdata[b*8 +: 8] !== 8'h00) begin
                        err("data byte outside tkeep is not zero");
                    end
                end
                if (m_tlast === 1'b1) begin
                    if (eoff != ex_len[ep]) begin
                        $sformat(msg, "pkt #%0d: tlast after %0d bytes, expected %0d", ep, eoff, ex_len[ep]);
                        err(msg); cur_pkt_bad = 1;
                    end
                    if (m_tuser !== ex_err[ep][0]) begin
                        $sformat(msg, "pkt #%0d: tuser=%0d expected %0d", ep, m_tuser, ex_err[ep]);
                        err(msg); cur_pkt_bad = 1;
                    end
                    if (cur_pkt_bad) pkts_bad = pkts_bad + 1; else pkts_ok = pkts_ok + 1;
                    if (ex_tid[ep] == 0) m_tid_zero = m_tid_zero + 1;
                    if (ex_tid[ep] == (1 << TID_W) - 1) m_tid_max = m_tid_max + 1;
                    ev_pkt <= 1'b1; ev_pkt_len <= eoff; ev_pkt_err <= m_tuser;
                    ep = ep + 1; eoff = 0; cur_pkt_bad = 0;
                end
            end
        end
    end

    function automatic integer outstanding();
        outstanding = n_exp - ep;
    endfunction
endmodule
