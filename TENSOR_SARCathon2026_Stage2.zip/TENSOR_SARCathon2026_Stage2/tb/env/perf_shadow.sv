`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// perf_shadow - reference implementation of the performance counters
// (CSR counters 11..19), written from their definitions in csr_status.sv:
//
//   11 IN_BYTES     tkeep bytes accepted on s_axis        (popcount, port level)
//   12 OUT_BYTES    tkeep bytes delivered on m_axis       (popcount, port level)
//   13 IN_STALL     cycles s_axis_tvalid=1 && s_axis_tready=0   (port level)
//   14 OUT_STALL    cycles m_axis_tvalid=1 && m_axis_tready=0   (port level)
//   15 CREDIT_STALL cycles an FIU is ready to start, link enabled, credits < PW
//   16 TX_WORDS     cycles the link layer transmits a word
//   17 CYCLES       clock cycles
//   18 FEC_CORR, 19 FEC_UNCORR   (placeholder: must stay 0)
//
// Counting window: from release of the DUT's synchronised reset; a CTRL
// cnt_clear zeroes every counter. Events 11..15 are registered once in the
// RTL before they are counted, so the shadow keeps one "pending" stage for
// them; 16..19 are counted in the cycle they occur.
// The shadow snapshots its values on every AXI-Lite AR handshake, exactly
// when the CSR samples its read data, so live counters (CYCLES) compare
// exactly too: tb_top compares each counter read with rd_snap.
// -----------------------------------------------------------------------------
module perf_shadow #(
    parameter int KB = 64,
    parameter int PW = 7
) (
    input wire          clk,
    input wire          rst_s,            // DUT synchronised reset (active low)
    input wire          clear,            // CSR cnt_clear request
    input wire          s_tvalid, s_tready,
    input wire [KB-1:0] s_tkeep,
    input wire          m_tvalid, m_tready,
    input wire [KB-1:0] m_tkeep,
    input wire          fiu_waiting,      // FIU word 0 offered, no FIU/trailer in progress
    input wire          link_en,
    input wire [7:0]    credits,
    input wire          t_valid,
    input wire          ar_fire,
    input wire [7:0]    araddr
);
    integer sh   [11:19];
    integer pend [11:15];
    integer rd_snap = 0;           // shadow value of the counter at the last AR handshake
    integer rd_idx  = -1;          // counter index of that read (-1 = not a perf counter)
    integer k;

    function automatic integer ones(input [KB-1:0] v);
        integer b;
        begin ones = 0; for (b = 0; b < KB; b = b + 1) ones = ones + v[b]; end
    endfunction

    function automatic integer sat_add(input integer a, input integer b);
        reg [32:0] t;
        begin t = {1'b0, a[31:0]} + {1'b0, b[31:0]}; sat_add = t[32] ? 32'hFFFF_FFFF : t[31:0]; end
    endfunction

    initial begin
        for (k = 11; k <= 19; k = k + 1) sh[k] = 0;
        for (k = 11; k <= 15; k = k + 1) pend[k] = 0;
    end

    always @(posedge clk) begin
        // snapshot first: the CSR samples rd_val (pre-edge counter values) at this edge
        if (rst_s === 1'b1 && ar_fire) begin
            rd_idx = (araddr >> 2) - 8;
            if (rd_idx >= 11 && rd_idx <= 19) rd_snap = sh[rd_idx];
            else rd_idx = -1;
        end
        if (rst_s !== 1'b1) begin
            for (k = 11; k <= 19; k = k + 1) sh[k] = 0;
            for (k = 11; k <= 15; k = k + 1) pend[k] = 0;
        end else begin
            if (clear) begin
                for (k = 11; k <= 19; k = k + 1) sh[k] = 0;
            end else begin
                for (k = 11; k <= 15; k = k + 1) sh[k] = sat_add(sh[k], pend[k]);
                sh[16] = sat_add(sh[16], t_valid === 1'b1);
                sh[17] = sat_add(sh[17], 1);
            end
            pend[11] = (s_tvalid === 1'b1 && s_tready === 1'b1) ? ones(s_tkeep) : 0;
            pend[12] = (m_tvalid === 1'b1 && m_tready === 1'b1) ? ones(m_tkeep) : 0;
            pend[13] = (s_tvalid === 1'b1 && s_tready !== 1'b1);
            pend[14] = (m_tvalid === 1'b1 && m_tready !== 1'b1);
            pend[15] = (fiu_waiting === 1'b1 && link_en === 1'b1 && credits < PW);
        end
    end
endmodule
