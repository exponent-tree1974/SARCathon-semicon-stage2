`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// dut_invariant_checker - white-box invariants on DUT-internal signals
// (connected through hierarchical references in tb_top)
//   I1  0 <= tx_credits <= RX_BUF_DEPTH              (no credit over/underflow)
//   I2  rxbuf_count <= rxbuf_used <= RX_BUF_DEPTH    (no buffer overflow)
//   I3  an FIU is started only with link_en=1 and tx_credits >= PW
//   I4  rxbuf pop never exceeds committed entries
//   I5  speculative words never exceed one FIU payload (PW)
// Concurrent SVA equivalents under `ifdef SVA.
// -----------------------------------------------------------------------------
module dut_invariant_checker #(
    parameter int DEPTH = 32,
    parameter int PW    = 7
) (
    input wire       clk,
    input wire       rst_n,
    input wire [7:0] tx_credits,
    input wire [7:0] rxbuf_used,
    input wire [7:0] rxbuf_count,
    input wire [1:0] rxbuf_pop,
    input wire       fiu_start,     // p_fire && p_first
    input wire       link_en
);
    integer errors = 0;
    integer max_credits_seen = 0, min_credits_seen = 1 << 30, max_used_seen = 0;

    task automatic err(input [8*80-1:0] msg);
        begin
            errors = errors + 1;
            if (errors <= 20) $display("[ERROR] %0t dut_invariants: %0s", $time, msg);
        end
    endtask

    always @(posedge clk) begin
        if (rst_n === 1'b1) begin
            if (tx_credits > DEPTH)                  err("I1 tx_credits above RX_BUF_DEPTH");
            if (rxbuf_used > DEPTH)                  err("I2 rxbuf used above depth");
            if (rxbuf_count > rxbuf_used)            err("I2 committed count above used");
            if (fiu_start && (!link_en || tx_credits < PW)) err("I3 FIU started without credits/link_en");
            if (rxbuf_pop > rxbuf_count)             err("I4 pop exceeds committed entries");
            if (rxbuf_used - rxbuf_count > PW)       err("I5 more speculative words than one FIU");
            if (tx_credits > max_credits_seen) max_credits_seen = tx_credits;
            if (tx_credits < min_credits_seen) min_credits_seen = tx_credits;
            if (rxbuf_used > max_used_seen)    max_used_seen = rxbuf_used;
        end
    end

`ifdef SVA
    a_credit_bound: assert property (@(posedge clk) disable iff (!rst_n) tx_credits <= DEPTH)
                        else err("[SVA] I1 credits above depth");
    a_buf_bound:    assert property (@(posedge clk) disable iff (!rst_n) rxbuf_used <= DEPTH)
                        else err("[SVA] I2 buffer overflow");
    a_fiu_start:    assert property (@(posedge clk) disable iff (!rst_n)
                        fiu_start |-> (link_en && tx_credits >= PW)) else err("[SVA] I3 FIU start without credits");
    a_pop:          assert property (@(posedge clk) disable iff (!rst_n) rxbuf_pop <= rxbuf_count)
                        else err("[SVA] I4 pop exceeds committed");
    c_credit_empty: cover property (@(posedge clk) disable iff (!rst_n) tx_credits < PW);
`endif
endmodule
