`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// link_safety_checker - end-to-end safety properties of the link (black box
// except for the TX/RX sequence taps). Independent of the scoreboard model.
//
//   S1  no output without valid input:
//       S1a every egress packet (>= 4 bytes) carries the identity (32-bit tag in
//           bytes 0..3 and tid) of a packet that was accepted at ingress
//       S1b cumulative egress beats    <= cumulative ingress beats
//       S1c cumulative egress packets  <= cumulative ingress packets started
//           (a packet counts at its first data beat: an aborted packet can be
//           closed at the egress before its own tlast has entered the ingress)
//       S1d a newly presented egress beat requires committed RX-buffer words
//           in the cycle it was loaded
//   S2  no reordering / duplication: egress packets match ingress packets with
//       strictly increasing ingress index (losses allowed, they are reported
//       by the scoreboard); per stream (tid) and globally
//   S3  TX FIU sequence numbers are consecutive (0, 1, 2, ... mod 256 after reset)
//   S4  accepted RX FIUs have strictly increasing sequence numbers (mod 256,
//       window < 128)
//   forge_ok = 1 (set by tests that forge trailers with a valid CRC): a forged
//   sequence number (S4) or a forged tid bit 0 on a first FIU (S1a) is
//   accepted by design and only counted (it cannot be detected by CRC).
// Concurrent SVA versions of S1b/S1c/S3 under `ifdef SVA.
// -----------------------------------------------------------------------------
module link_safety_checker #(
    parameter int KB   = 64,
    parameter int MAXQ = 65536
) (
    input wire          clk,
    input wire          rst_n,
    // ingress
    input wire          s_tvalid, s_tready, s_tlast,
    input wire [KB-1:0] s_tkeep,
    input wire [31:0]   s_tdata32,
    input wire [7:0]    s_tid,
    // egress
    input wire          m_tvalid, m_tready, m_tlast,
    input wire [KB-1:0] m_tkeep,
    input wire [31:0]   m_tdata32,
    input wire [7:0]    m_tid,
    // link taps
    input wire          tx_valid, tx_sof,
    input wire          t_valid, t_sof,
    input wire [7:0]    t_seq,
    input wire          acc_ev,          // RX FIU accepted (commit)
    input wire [7:0]    acc_seq,
    input wire [7:0]    rxbuf_count
);
    integer errors = 0;
    reg     forge_ok = 1'b0;
    integer pkts_checked = 0, fius_accepted = 0, forged_seen = 0;

    task automatic err(input [8*120-1:0] msg);
        begin
            errors = errors + 1;
            if (errors <= 20) $display("[ERROR] %0t link_safety: %0s", $time, msg);
        end
    endtask

    // ingress packet record
    reg [31:0] q_tag [0:MAXQ-1];
    reg [7:0]  q_tid [0:MAXQ-1];
    integer    q_bytes [0:MAXQ-1];
    integer    nq = 0, last_match = -1;
    integer    last_match_tid [0:255];
    // in-progress packets
    reg        i_has = 1'b0, e_open = 1'b0;
    reg [31:0] e_tag;
    reg [7:0]  e_tid;
    integer    i_bytes = 0, e_bytes = 0;
    // cumulative counts
    longint    in_beats = 0, out_beats = 0, in_pkts = 0, out_pkts = 0;
    // sequence state
    integer    tx_exp = 0, rx_last = -1;
    reg        p_mvalid = 1'b0, p_mfire = 1'b0, p_mlast = 1'b0;
    reg [7:0]  p_cnt = 8'd0;
    integer    k, j, found;
    reg [8*120-1:0] msg;

    function automatic integer ones(input [KB-1:0] v);
        integer b;
        begin ones = 0; for (b = 0; b < KB; b = b + 1) ones = ones + v[b]; end
    endfunction

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            nq = 0; last_match = -1; i_has = 0; i_bytes = 0; e_open = 0; e_bytes = 0;
            for (k = 0; k < 256; k = k + 1) last_match_tid[k] = -1;
            in_beats = 0; out_beats = 0; in_pkts = 0; out_pkts = 0;
            tx_exp = 0; rx_last = -1;
            p_mvalid = 0; p_mfire = 0; p_mlast = 0; p_cnt = 0;
        end else begin
            // ---------------- ingress ----------------
            // a packet is recorded at its FIRST data beat: an aborted packet can leave the
            // egress (truncated, tuser=1) before its own tlast has entered the ingress
            if (s_tvalid === 1'b1 && s_tready === 1'b1) begin
                in_beats = in_beats + 1;
                if (s_tkeep != '0) begin
                    if (!i_has) begin
                        i_has = 1;
                        if (nq < MAXQ) begin q_tag[nq] = s_tdata32; q_tid[nq] = s_tid; q_bytes[nq] = -1; nq = nq + 1; end
                        in_pkts = in_pkts + 1;
                    end
                    i_bytes = i_bytes + ones(s_tkeep);
                end
                if (s_tlast === 1'b1) begin
                    if (i_has && nq <= MAXQ) q_bytes[nq-1] = i_bytes;      // final length
                    i_has = 0; i_bytes = 0;
                end
            end
            // ---------------- egress ----------------
            // S1d: a newly presented egress beat was loaded from committed RX data
            if (m_tvalid === 1'b1 && (!p_mvalid || p_mfire) && p_cnt == 0)
                err("S1d new egress beat presented while the RX buffer had no committed word");
            if (m_tvalid === 1'b1 && m_tready === 1'b1) begin
                out_beats = out_beats + 1;
                if (!e_open) begin e_open = 1; e_tag = m_tdata32; e_tid = m_tid; end
                e_bytes = e_bytes + ones(m_tkeep);
                if (out_beats > in_beats) err("S1b more egress beats than ingress beats");
                if (m_tlast === 1'b1) begin
                    out_pkts = out_pkts + 1;
                    if (out_pkts > in_pkts) err("S1c more egress packets than ingress packets");
                    if (e_bytes >= 4) begin
                        found = -1;
                        for (j = last_match + 1; j < nq && found < 0; j = j + 1)
                            if (q_tag[j] == e_tag) found = j;   // illegal-tkeep beats are forwarded whole, so no byte-count condition
                        if (found < 0) begin
                            // not after the last match: reordered/duplicated, or never sent
                            for (j = 0; j <= last_match && found < 0; j = j + 1)
                                if (q_tag[j] == e_tag) found = -2 - j;
                            if (found <= -2) begin
                                $sformat(msg, "S2 egress packet tag %08h matches ingress #%0d at or before the last delivered #%0d (reorder/duplicate)",
                                         e_tag, -2 - found, last_match);
                                err(msg);
                            end else begin
                                $sformat(msg, "S1a egress packet tag %08h tid %0d never entered the link", e_tag, e_tid);
                                err(msg);
                            end
                        end else begin
                            if (q_tid[found] != e_tid) begin
                                if (forge_ok && ((q_tid[found] ^ e_tid) == 8'd1)) forged_seen = forged_seen + 1;
                                else begin
                                    $sformat(msg, "S1a egress tid %0d differs from ingress tid %0d (tag %08h)", e_tid, q_tid[found], e_tag);
                                    err(msg);
                                end
                            end
                            if (found <= last_match_tid[e_tid]) err("S2 per-stream order violated");
                            last_match = found; last_match_tid[e_tid] = found;
                            pkts_checked = pkts_checked + 1;
                        end
                    end
                    e_open = 0; e_bytes = 0;
                end
            end
            p_mvalid = (m_tvalid === 1'b1); p_mfire = (m_tvalid === 1'b1 && m_tready === 1'b1);
            p_mlast = (m_tlast === 1'b1);
            p_cnt   = rxbuf_count;
            // ---------------- S3: TX sequence ----------------
            if (t_valid === 1'b1 && t_sof === 1'b1) begin
                if (t_seq != tx_exp[7:0]) begin
                    $sformat(msg, "S3 TX FIU sequence %0d, expected %0d", t_seq, tx_exp[7:0]); err(msg);
                end
                tx_exp = (t_seq + 1) % 256;
            end
            // ---------------- S4: RX accepted sequence ----------------
            if (acc_ev === 1'b1) begin
                fius_accepted = fius_accepted + 1;
                if (rx_last >= 0) begin
                    k = (acc_seq - rx_last + 256) % 256;
                    if (k == 0 || k >= 128) begin
                        if (forge_ok) forged_seen = forged_seen + 1;
                        else begin
                            $sformat(msg, "S4 accepted FIU sequence %0d after %0d (not increasing)", acc_seq, rx_last); err(msg);
                        end
                    end
                end
                rx_last = acc_seq;
            end
        end
    end

`ifdef SVA
    // counters are maintained above; these restate S1b/S1c/S3 as concurrent assertions
    a_s1b: assert property (@(posedge clk) disable iff (!rst_n) out_beats <= in_beats)
               else err("[SVA] S1b egress beats exceed ingress beats");
    a_s1c: assert property (@(posedge clk) disable iff (!rst_n) out_pkts <= in_pkts)
               else err("[SVA] S1c egress packets exceed ingress packets");
    a_s3:  assert property (@(posedge clk) disable iff (!rst_n)
               (t_valid && t_sof) |-> (t_seq == tx_exp[7:0])) else err("[SVA] S3 TX sequence");
`endif
endmodule
