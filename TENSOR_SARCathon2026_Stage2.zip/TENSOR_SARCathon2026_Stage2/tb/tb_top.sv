`timescale 1ns/1ps
// =============================================================================
// tb_top - self-checking verification environment for axis_pcie_link_top
//
//  Components (tb/env):
//    axis_source_bfm        ingress AXIS driver (random tvalid gaps, abort)
//    axis_sink_bfm          egress tready generator (random / burst stalls)
//    axis_protocol_checker  x2  ingress (DUT slave) and egress (DUT master) rules
//    axil_master_bfm        AXI4-Lite master, AW/W ordering control
//    axil_protocol_checker  AXI4-Lite slave rules
//    link_channel_model     tx->rx loopback, corruption / header forgery plan
//    pkt_scoreboard         packet DB, FIU-level reference model, byte-for-byte check
//    coverage_collector     functional coverage bins + report
//    dut_invariant_checker  white-box invariants (credits, buffer, FIU start)
//    perf_shadow            reference model of the performance counters
//    link_safety_checker    end-to-end safety assertions (no output without
//                           input, no reordering, FIU sequence monotonic)
//
//  Parameters (override: iverilog -Ptb_top.LANES=8 / verilator -GLANES=8)
//    LANES  lane count of the DUT and the channel model (1,2,4,8,16,32)
//    TID_W  stream-ID width; every packet gets a random tid that must be
//           delivered unchanged on m_axis_tid
//
//  Plusargs
//    +seed=<n>          base seed (default 1). test i uses seed*1000+i, so a
//                       single test reproduces exactly as inside the full run
//    +test=<name>       run one test (default: all, see TEST LIST below)
//    +scale=<n>         multiply random packet counts (default 1)
//    +vcd               dump waves for all tests        +vcd_test=<name> one test
//    +vcd_file=<path>   default results/waves.vcd
//    +vcd_scope=dut|all dut (default): DUT ports + main DUT blocks; all: whole TB
//    +vcd_depth=<n>     depth for +vcd_scope=all (0 = unlimited)
//    +fiu_dump=<path>   TX symbol dump for tb/model/check_fiu_stream.py
//    +inj_log=<path>    channel injection log
//    +cov_file=<path>   coverage report file (default results/coverage.txt)
//    +cov_strict        coverage holes fail the run (full suite only)
//    +max_cycles=<n>    global watchdog (default 4,000,000)
//
//  Result markers (grep-able):
//    [TEST-START] <name> ...        [TEST-RESULT] <name> : PASS | FAIL ...
//    [ERROR] ...  [TIMEOUT] ...  [DEADLOCK] ...
//    [SIM-RESULT] PASSED ...        [SIM-RESULT] FAILED ...   (exit code 1 on FAILED)
// =============================================================================
module tb_top;
    // ------------------------------------------------------------------ parameters
    localparam int AXIS_W    = 512;
    localparam int KB        = AXIS_W / 8;
    localparam int LINK_W    = 256;
    localparam int LB        = LINK_W / 8;
    localparam int FIU_BYTES = 256;
    localparam int FIU_WORDS = FIU_BYTES / LB;
    localparam int PW        = FIU_WORDS - 1;
    localparam int PAYLOAD   = PW * LB;            // 224
    parameter  int LANES     = 4;               // overridable
    parameter  int TID_W     = 4;               // overridable
    localparam int DEPTH     = 32;
    localparam int NSYM      = LINK_W / 2;
    localparam int DEADLOCK_CYCLES = 5000;
    localparam int NTESTS    = 17;

    // scoreboard / channel constants (mirrors)
    localparam int F_ZLAST = 1, F_NULLS = 2, F_ILL_MID = 4, F_ILL_SPR = 8, F_EMPTY = 16,
                   F_ILL_HOLE = 32, F_ILL_OFS = 64;
    localparam int MODE_SYM = 1, MODE_LANE_WORD = 2, MODE_LANE_FIU = 3, MODE_CRC_FIELD = 4,
                   MODE_TRAILER_HDR = 5, MODE_FORGE = 6;
    localparam int FK_MAGIC = 1, FK_LEN0 = 2, FK_LENBIG = 3, FK_EOP_CLR = 4, FK_SOP_CLR = 5,
                   FK_SOP_SET = 6, FK_SEQ = 7, FK_ERR_SET = 8, FK_EOP_SET = 9, FK_TID = 10;
    localparam int NCNT = 11;          // event counters checked against the reference model
    localparam int NCNT_ALL = 20;      // + performance counters 11..19 (checked against perf_shadow)
    `include "cov_bins.svh"

    // ------------------------------------------------------------------ clock / reset
    reg clk = 1'b0;
    always #5 clk = ~clk;                       // 100 MHz nominal
    reg rst_n = 1'b1;
    initial #1 rst_n = 1'b0;     // a real falling edge, so async-reset flops reset at power-on
    integer cycle = 0;
    always @(posedge clk) cycle <= cycle + 1;

    // ------------------------------------------------------------------ DUT
    wire [AXIS_W-1:0] s_tdata;  wire [KB-1:0] s_tkeep;  wire s_tlast, s_tvalid, s_tready;
    wire [AXIS_W-1:0] m_tdata;  wire [KB-1:0] m_tkeep;  wire m_tlast, m_tuser, m_tvalid, m_tready;
    wire [LINK_W-1:0] tx_sym, rx_sym;
    wire tx_sym_valid, tx_sym_sof, rx_sym_valid, rx_sym_sof;
    wire [7:0] rx_credit_return, tx_credit_return;
    wire [7:0] awaddr, araddr;  wire awvalid, awready, wvalid, wready, bvalid, bready;
    wire arvalid, arready, rvalid, rready;  wire [31:0] wdata, rdata;  wire [3:0] wstrb;
    wire [1:0] bresp, rresp;
    reg  [7:0]       s_tid = 8'd0;               // driven per packet by send_packet()
    wire [TID_W-1:0] m_tid;
    wire [7:0]       m_tid8 = 8'(m_tid);
    wire             irq;

    axis_pcie_link_top #(
        .AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .LANES(LANES),
        .RX_BUF_DEPTH(DEPTH), .AXIL_ADDR_W(8), .TID_W(TID_W)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .s_axis_tdata(s_tdata), .s_axis_tkeep(s_tkeep), .s_axis_tlast(s_tlast),
        .s_axis_tid(s_tid[TID_W-1:0]), .s_axis_tvalid(s_tvalid), .s_axis_tready(s_tready),
        .m_axis_tdata(m_tdata), .m_axis_tkeep(m_tkeep), .m_axis_tlast(m_tlast),
        .m_axis_tuser(m_tuser), .m_axis_tid(m_tid), .m_axis_tvalid(m_tvalid), .m_axis_tready(m_tready),
        .tx_sym(tx_sym), .tx_sym_valid(tx_sym_valid), .tx_sym_sof(tx_sym_sof),
        .rx_sym(rx_sym), .rx_sym_valid(rx_sym_valid), .rx_sym_sof(rx_sym_sof),
        .rx_credit_return(rx_credit_return), .tx_credit_return(tx_credit_return),
        .s_axil_awaddr(awaddr), .s_axil_awvalid(awvalid), .s_axil_awready(awready),
        .s_axil_wdata(wdata), .s_axil_wstrb(wstrb), .s_axil_wvalid(wvalid), .s_axil_wready(wready),
        .s_axil_bresp(bresp), .s_axil_bvalid(bvalid), .s_axil_bready(bready),
        .s_axil_araddr(araddr), .s_axil_arvalid(arvalid), .s_axil_arready(arready),
        .s_axil_rdata(rdata), .s_axil_rresp(rresp), .s_axil_rvalid(rvalid), .s_axil_rready(rready),
        .irq(irq)
    );

    // ------------------------------------------------------------------ environment
    axis_source_bfm #(.DATA_W(AXIS_W), .NAME("axis_src")) u_src (
        .clk(clk), .rst_n(rst_n), .tdata(s_tdata), .tkeep(s_tkeep), .tlast(s_tlast),
        .tvalid(s_tvalid), .tready(s_tready));

    axis_sink_bfm #(.NAME("axis_sink")) u_sink (.clk(clk), .rst_n(rst_n), .tready(m_tready));

    axis_protocol_checker #(.DATA_W(AXIS_W), .NAME("chk_ingress"), .DUT_IS_MASTER(1'b0),
                            .CHECK_KEEP(1'b0), .HAS_USER(1'b0), .HAS_TID(1'b1)) u_chk_in (
        .clk(clk), .rst_n(rst_n), .tdata(s_tdata), .tkeep(s_tkeep), .tlast(s_tlast),
        .tuser(1'b0), .tid(s_tid), .tvalid(s_tvalid), .tready(s_tready));

    axis_protocol_checker #(.DATA_W(AXIS_W), .NAME("chk_egress"), .DUT_IS_MASTER(1'b1),
                            .CHECK_KEEP(1'b1), .HAS_USER(1'b1), .HAS_TID(1'b1)) u_chk_eg (
        .clk(clk), .rst_n(rst_n), .tdata(m_tdata), .tkeep(m_tkeep), .tlast(m_tlast),
        .tuser(m_tuser), .tid(m_tid8), .tvalid(m_tvalid), .tready(m_tready));

    axil_master_bfm #(.ADDR_W(8), .NAME("axil_master")) u_axil (
        .clk(clk), .rst_n(rst_n), .awaddr(awaddr), .awvalid(awvalid), .awready(awready),
        .wdata(wdata), .wstrb(wstrb), .wvalid(wvalid), .wready(wready), .bresp(bresp),
        .bvalid(bvalid), .bready(bready), .araddr(araddr), .arvalid(arvalid), .arready(arready),
        .rdata(rdata), .rresp(rresp), .rvalid(rvalid), .rready(rready));

    axil_protocol_checker #(.NAME("chk_axil")) u_chk_axil (
        .clk(clk), .rst_n(rst_n), .awvalid(awvalid), .awready(awready), .wvalid(wvalid),
        .wready(wready), .bvalid(bvalid), .bready(bready), .bresp(bresp), .arvalid(arvalid),
        .arready(arready), .rvalid(rvalid), .rready(rready), .rdata(rdata), .rresp(rresp));

    link_channel_model #(.LINK_W(LINK_W), .LANES(LANES), .FIU_WORDS(FIU_WORDS),
                         .CH_DLY(2), .CR_DLY(3)) u_ch (
        .clk(clk), .rst_n(rst_n), .tx_sym(tx_sym), .tx_valid(tx_sym_valid), .tx_sof(tx_sym_sof),
        .rx_sym(rx_sym), .rx_valid(rx_sym_valid), .rx_sof(rx_sym_sof),
        .credit_from_rx(rx_credit_return), .credit_to_tx(tx_credit_return));

    wire        sb_ev_pkt, sb_ev_err;
    wire [31:0] sb_ev_len;
    pkt_scoreboard #(.AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .TID_W(TID_W)) u_sb (
        .clk(clk), .rst_n(rst_n), .m_tdata(m_tdata), .m_tkeep(m_tkeep), .m_tlast(m_tlast),
        .m_tuser(m_tuser), .m_tid(m_tid8), .m_tvalid(m_tvalid), .m_tready(m_tready),
        .ev_pkt(sb_ev_pkt), .ev_pkt_len(sb_ev_len), .ev_pkt_err(sb_ev_err));

    // white-box taps (hierarchical references into the DUT)
    wire [7:0] w_credits    = dut.u_link.credits;
    wire [7:0] w_rxbuf_used = dut.u_rxbuf.used;
    wire [7:0] w_rxbuf_cnt  = dut.u_rxbuf.count;
    wire [1:0] w_rxbuf_pop  = dut.u_rxbuf.pop;
    wire       w_fiu_start  = dut.p_valid && dut.p_ready && dut.p_first;
    wire       w_fiu_pend   = dut.p_valid && dut.p_first;
    wire       w_link_en    = dut.link_en;
    wire       w_rx_discard = dut.u_link.rx_discard;

    coverage_collector #(.AXIS_W(AXIS_W), .PW(PW), .DEPTH(DEPTH)) u_cov (
        .clk(clk), .rst_n(rst_n), .s_tkeep(s_tkeep), .s_tlast(s_tlast), .s_tvalid(s_tvalid),
        .s_tready(s_tready), .m_tlast(m_tlast), .m_tuser(m_tuser), .m_tvalid(m_tvalid),
        .m_tready(m_tready), .tx_sym_valid(tx_sym_valid), .tx_sym_sof(tx_sym_sof),
        .tx_credits(w_credits), .fiu_start_pending(w_fiu_pend), .rxbuf_used(w_rxbuf_used),
        .rx_discard(w_rx_discard), .ev_pkt(sb_ev_pkt), .ev_pkt_len(sb_ev_len), .ev_pkt_err(sb_ev_err));

    dut_invariant_checker #(.DEPTH(DEPTH), .PW(PW)) u_inv (
        .clk(clk), .rst_n(rst_n), .tx_credits(w_credits), .rxbuf_used(w_rxbuf_used),
        .rxbuf_count(w_rxbuf_cnt), .rxbuf_pop(w_rxbuf_pop), .fiu_start(w_fiu_start),
        .link_en(w_link_en));

    // performance-counter reference model (port-level definitions + 3 white-box taps)
    wire w_rst_s     = dut.rst_n_s;
    wire w_cnt_clear = dut.u_csr.clear_req;
    wire w_fiu_wait  = dut.p_valid && dut.p_first && !dut.u_link.tx_in_fiu && !dut.u_link.trl_pend;
    perf_shadow #(.KB(KB), .PW(PW)) u_shadow (
        .clk(clk), .rst_s(w_rst_s), .clear(w_cnt_clear),
        .s_tvalid(s_tvalid), .s_tready(s_tready), .s_tkeep(s_tkeep),
        .m_tvalid(m_tvalid), .m_tready(m_tready), .m_tkeep(m_tkeep),
        .fiu_waiting(w_fiu_wait), .link_en(w_link_en), .credits(w_credits),
        .t_valid(dut.t_valid), .ar_fire(arvalid && arready), .araddr(araddr));

    // end-to-end safety assertions
    link_safety_checker #(.KB(KB)) u_safe (
        .clk(clk), .rst_n(rst_n),
        .s_tvalid(s_tvalid), .s_tready(s_tready), .s_tkeep(s_tkeep), .s_tlast(s_tlast),
        .s_tdata32(s_tdata[31:0]), .s_tid(s_tid),
        .m_tvalid(m_tvalid), .m_tready(m_tready), .m_tkeep(m_tkeep), .m_tlast(m_tlast),
        .m_tdata32(m_tdata[31:0]), .m_tid(m_tid8),
        .tx_valid(tx_sym_valid), .tx_sof(tx_sym_sof),
        .t_valid(dut.t_valid), .t_sof(dut.t_sof), .t_seq(dut.u_link.tx_seq),
        .acc_ev(dut.u_link.b_commit_en), .acc_seq(dut.u_link.rt_seq),
        .rxbuf_count(w_rxbuf_cnt));

    // ------------------------------------------------------------------ error accounting
    integer tb_errors = 0;
    task automatic tb_fail(input [8*120-1:0] msg);
        begin
            tb_errors = tb_errors + 1;
            if (tb_errors <= 40) $display("[ERROR] %0t tb: %0s", $time, msg);
        end
    endtask
    function automatic integer total_errors();
        total_errors = tb_errors + u_src.errors + u_chk_in.errors + u_chk_eg.errors + u_axil.errors +
                       u_chk_axil.errors + u_sb.errors + u_inv.errors + u_safe.errors;
    endfunction

    // outputs must be idle while reset is asserted (beyond the protocol checkers)
    always @(posedge clk) if (rst_n === 1'b0 && tx_sym_valid !== 1'b0) tb_fail("tx_sym_valid high during reset");

    // ------------------------------------------------------------------ deadlock monitor
    reg     dl_en = 1'b1;
    integer dl_idle = 0;
    always @(posedge clk) begin
        if (rst_n !== 1'b1 || !dl_en) dl_idle = 0;
        else begin
            if ((s_tvalid && s_tready) || tx_sym_valid || (m_tvalid && m_tready) || awvalid || arvalid)
                dl_idle = 0;
            else if (u_sb.ep < u_sb.n_exp || s_tvalid)
                dl_idle = dl_idle + 1;
            if (dl_idle == DEADLOCK_CYCLES) begin
                tb_fail("[DEADLOCK] no ingress/link/egress progress while traffic outstanding");
                dump_state();
            end
        end
    end

    task automatic dump_state();
        begin
            $display("[STATE] %0t credits=%0d rxbuf used=%0d committed=%0d | ingress hold=%0d s_tready=%0d | packetizer widx=%0d pad=%0d | link in_fiu=%0d trl=%0d | rx ridx=%0d in_pkt=%0d discard=%0d | egress valid=%0d ready=%0d | sb %0d/%0d pkts",
                     $time, w_credits, w_rxbuf_used, w_rxbuf_cnt, dut.u_ingress.h_valid, s_tready,
                     dut.u_packetizer.widx, dut.u_packetizer.pad, dut.u_link.tx_in_fiu, dut.u_link.trl_pend,
                     dut.u_link.ridx, dut.u_link.rx_in_pkt, dut.u_link.rx_discard, m_tvalid, m_tready,
                     u_sb.ep, u_sb.n_exp);
        end
    endtask

    // ------------------------------------------------------------------ run control
    integer base_seed = 1, scale = 1, max_cycles = 4000000, dummy;
    reg [8*40-1:0]  test_sel = "";
    reg [8*200-1:0] vcd_file = "results/waves.vcd";
    reg [8*200-1:0] fiu_dump_file, inj_log_file;
    reg [8*200-1:0] cov_file = "results/coverage.txt";
    reg [8*40-1:0]  vcd_test = "";
    integer has_sel = 0, vcd_all = 0, vcd_one = 0, vcd_depth = 0, cov_strict = 0, vcd_scope_all = 0;
    reg [8*8-1:0] vcd_scope = "dut";
    integer cur_test_idx = 0;
    reg [8*40-1:0] cur_test;

    // results table
    reg [8*40-1:0] r_name [1:NTESTS];
    integer r_ran [1:NTESTS], r_err [1:NTESTS], r_cyc [1:NTESTS], r_pin [1:NTESTS],
            r_pout [1:NTESTS], r_bytes [1:NTESTS];
    integer err_at_start, cyc_at_start, acc_pin, acc_pout, acc_bytes;

    // ------------------------------------------------------------------ CSR helpers
    localparam [7:0] A_ID = 8'h00, A_VER = 8'h04, A_CTRL = 8'h08, A_STATUS = 8'h0C,
                     A_SCRATCH = 8'h10, A_PARAMS = 8'h14, A_PARAMS2 = 8'h18, A_SEQST = 8'h1C,
                     A_CNT0 = 8'h20, A_ERRST = 8'h70, A_IRQEN = 8'h74, A_LASTERR = 8'h78;
    localparam [31:0] VERSION = 32'h0002_0000;
    // ERR_STATUS bit k is set by event counter err_src(k)
    function automatic integer err_src(input integer k);
        case (k) 0: err_src = 3; 1: err_src = 4; 2: err_src = 5; 3: err_src = 6;
                 4: err_src = 8; 5: err_src = 9; 6: err_src = 10; default: err_src = -1; endcase
    endfunction
    integer errst_base [0:7];     // model counts at the last W1C of each bit (expected bit = count > base)
    integer irqen_model = 0;      // value the TB wrote to ERR_IRQ_EN

    task automatic cov_csr_addr(input [7:0] a);
        begin
            case (a & 8'hFC)
                A_ID:      u_cov.hit(CSR_RD_ID);
                A_VER:     u_cov.hit(CSR_RD_VERSION);
                A_CTRL:    u_cov.hit(CSR_RD_CTRL);
                A_STATUS:  u_cov.hit(CSR_RD_STATUS);
                A_SCRATCH: u_cov.hit(CSR_RD_SCRATCH);
                A_PARAMS:  u_cov.hit(CSR_RD_PARAMS);
                A_PARAMS2: u_cov.hit(CSR_RD_PARAMS2);
                A_SEQST:   u_cov.hit(CSR_RD_SEQ_STATUS);
                default: if ((a & 8'hFC) >= 8'h4C && (a & 8'hFC) <= 8'h6C) u_cov.hit(CSR_RD_PERF);
            endcase
        end
    endtask

    task automatic csr_read(input [7:0] a, output reg [31:0] d, output reg [1:0] r);
        begin u_axil.read(a, d, r); cov_csr_addr(a); end
    endtask

    task automatic csr_expect(input [7:0] a, input [31:0] exp_d, input [1:0] exp_r);
        reg [31:0] d; reg [1:0] r; reg [8*120-1:0] m;
        begin
            csr_read(a, d, r);
            if (d !== exp_d || r !== exp_r) begin
                $sformat(m, "CSR read 0x%02h = %08h/resp %0d, expected %08h/resp %0d", a, d, r, exp_d, exp_r);
                tb_fail(m);
            end
        end
    endtask

    task automatic csr_write(input [7:0] a, input [31:0] d, input [3:0] s, input integer order,
                             input [1:0] exp_r);
        reg [1:0] r; reg [8*120-1:0] m;
        begin
            u_axil.write(a, d, s, order, r);
            case (order) 1: u_cov.hit(CSR_AW_FIRST); 2: u_cov.hit(CSR_W_FIRST);
                         default: u_cov.hit(CSR_AW_W_TOGETHER); endcase
            if (r !== exp_r) begin
                $sformat(m, "CSR write 0x%02h data %08h: resp %0d, expected %0d", a, d, r, exp_r);
                tb_fail(m);
            end
        end
    endtask

    task automatic clear_counters();
        begin csr_write(A_CTRL, 32'h3, 4'hF, 0, 2'b00); u_cov.hit(CSR_CNT_CLEAR); end
    endtask

    task automatic check_counters(input [8*40-1:0] where);
        integer k; reg [31:0] d; reg [1:0] r; reg [8*120-1:0] m;
        reg [31:0] v [0:NCNT_ALL-1];
        begin
            // event counters: reference model
            for (k = 0; k < NCNT; k = k + 1) begin
                csr_read(A_CNT0 + 4*k, d, r);
                if (r !== 2'b00 || d !== u_sb.exp_cnt[k]) begin
                    $sformat(m, "%0s: counter[%0d] (0x%02h) = %0d, expected %0d", where, k, A_CNT0 + 4*k, d, u_sb.exp_cnt[k]);
                    tb_fail(m);
                end
                v[k] = d;
            end
            // performance counters: shadow snapshot taken at the read handshake
            for (k = NCNT; k < NCNT_ALL; k = k + 1) begin
                csr_read(A_CNT0 + 4*k, d, r);
                if (r !== 2'b00 || u_shadow.rd_idx != k || d !== u_shadow.rd_snap) begin
                    $sformat(m, "%0s: perf counter[%0d] (0x%02h) = %0d, shadow %0d", where, k, A_CNT0 + 4*k, d, u_shadow.rd_snap);
                    tb_fail(m);
                end
                v[k] = d;
            end
            // cross-checks against the reference model
            if (v[12] !== u_sb.m_out_bytes) begin
                $sformat(m, "%0s: OUT_BYTES=%0d, model delivered bytes=%0d", where, v[12], u_sb.m_out_bytes); tb_fail(m); end
            if (v[16] !== FIU_WORDS * u_sb.exp_cnt[1]) begin
                $sformat(m, "%0s: TX_WORDS=%0d, expected %0d x TX_FIU", where, v[16], FIU_WORDS); tb_fail(m); end
            if (v[18] !== 0 || v[19] !== 0) tb_fail("FEC counters non-zero with the FEC placeholder");
            if (v[13] > 0) u_cov.hit(PERF_IN_STALL);
            if (v[14] > 0) u_cov.hit(PERF_OUT_STALL);
            if (v[15] > 0) u_cov.hit(PERF_CREDIT_STALL);
            u_cov.hit(CSR_RD_COUNTERS);
        end
    endtask

    // ERR_STATUS / LAST_ERR / SEQ_STATUS / irq against the reference model
    task automatic check_err_seq(input [8*40-1:0] where);
        integer k; reg [31:0] d, e, mask; reg [1:0] r; reg [8*120-1:0] m;
        begin
            e = 0;
            for (k = 0; k < 7; k = k + 1) if (u_sb.exp_cnt[err_src(k)] > errst_base[k]) e[k] = 1'b1;
            csr_read(A_ERRST, d, r);
            if (d !== e || r !== 2'b00) begin $sformat(m, "%0s: ERR_STATUS=%02h expected %02h", where, d, e); tb_fail(m); end
            if (irq !== |(e[7:0] & irqen_model[7:0])) begin
                $sformat(m, "%0s: irq=%0d expected %0d", where, irq, |(e[7:0] & irqen_model[7:0])); tb_fail(m); end
            e = u_sb.m_le_valid ? {1'b1, 12'b0, 3'(u_sb.m_le_reason), 8'(u_sb.m_le_rx), 8'(u_sb.m_le_exp)} : 32'h0;
            mask = (u_sb.m_le_valid && !u_sb.m_le_rx_known) ? 32'hFFFF_00FF : 32'hFFFF_FFFF;
            csr_read(A_LASTERR, d, r);
            if ((d & mask) !== (e & mask) || r !== 2'b00) begin
                $sformat(m, "%0s: LAST_ERR=%08h expected %08h (mask %08h)", where, d, e, mask); tb_fail(m); end
            if (d[31]) case (d[18:16])
                3'd1: u_cov.hit(CSR_LAST_ERR_CRC); 3'd2: u_cov.hit(CSR_LAST_ERR_HDR);
                3'd3: u_cov.hit(CSR_LAST_ERR_SOPIN); 3'd5: u_cov.hit(CSR_LAST_ERR_TID);
                3'd7: u_cov.hit(CSR_LAST_ERR_SEQ); default: ;
            endcase
            e = {7'b0, 1'(u_sb.m_any_acc), 8'(u_sb.m_last_acc_seq), 8'(u_sb.m_rx_exp_seq), 8'(u_ch.fiu_cnt)};
            csr_read(A_SEQST, d, r);
            if (d !== e || r !== 2'b00) begin $sformat(m, "%0s: SEQ_STATUS=%08h expected %08h", where, d, e); tb_fail(m); end
        end
    endtask

    // ------------------------------------------------------------------ reset
    task automatic do_reset(input integer n);
        begin
            u_src.abort = 1'b1;
            @(negedge clk);
            u_src.idle();
            rst_n = 1'b0;
            if (u_ch.dump_fd != 0) $fdisplay(u_ch.dump_fd, "# reset");
            repeat (n) @(negedge clk);
            rst_n = 1'b1;
            u_src.abort = 1'b0;
            repeat (4) @(negedge clk);          // 2-stage reset synchroniser + ready enable
        end
    endtask

    // ------------------------------------------------------------------ AXIS packet driving
    task automatic send_packet(input integer p);
        integer nb, bt, i, L, flg;
        reg ok;
        reg [AXIS_W-1:0] d;
        reg [KB-1:0] kp;
        begin
            L = u_sb.pk_len[p]; flg = u_sb.pk_flg[p];
            s_tid = 8'(u_sb.pk_tid[p]);                 // constant for the whole packet
            if (flg & F_EMPTY) begin
                if (flg & F_NULLS) u_src.send_beat(u_src.rand_data(), '0, 1'b0, ok);
                u_src.send_beat(u_src.rand_data(), '0, 1'b1, ok);
            end else begin
                nb = (L + KB - 1) / KB;
                for (bt = 0; bt < nb; bt = bt + 1) begin
                    if ((flg & F_NULLS) && ($urandom % 100) < 30) u_src.send_beat(u_src.rand_data(), '0, 1'b0, ok);
                    for (i = 0; i < KB; i = i + 1)
                        d[i*8 +: 8] = (bt*KB + i < L) ? u_sb.mem[u_sb.pk_off[p] + bt*KB + i] : $urandom;
                    if (bt*KB + KB <= L) kp = '1;
                    else                 kp = {KB{1'b1}} >> (KB - (L - bt*KB));
                    if ((flg & F_ILL_MID)  && bt == 0)      kp = 64'h0000_0000_0000_FFFF;  // partial, not last
                    if ((flg & F_ILL_HOLE) && bt == 0)      kp = 64'hFFFF_FFFF_FFFF_FFF7;  // hole at byte 3
                    if ((flg & F_ILL_SPR)  && bt == nb - 1) kp = 64'h0000_0000_0000_0005;  // sparse
                    if ((flg & F_ILL_OFS)  && bt == nb - 1) kp = 64'h0000_0000_0000_FF00;  // not from byte 0
                    u_src.send_beat(d, kp, (bt == nb - 1) && !(flg & F_ZLAST), ok);
                end
                if (flg & F_ZLAST) u_src.send_beat(u_src.rand_data(), '0, 1'b1, ok);
            end
        end
    endtask

    task automatic send_range(input integer p0, input integer p1);
        integer p;
        begin
            @(negedge clk);
            for (p = p0; p < p1 && !u_src.abort; p = p + 1) send_packet(p);
            u_src.idle();
        end
    endtask

    task automatic add_pkt(input integer len, input integer flags);
        integer idx;
        begin u_sb.add_packet(len, flags, idx); end
    endtask

    // random corruption plan over FIUs [f0, f1)
    // kinds bitmask: 1=sym 2=lane_word 4=lane_fiu 8=crc_field 16=trailer_hdr
    task automatic plan_random(input integer f0, input integer f1, input integer permille,
                               input integer kinds);
        integer f, k, mode, n;
        begin
            for (f = f0; f < f1; f = f + 1) begin
                if (($urandom % 1000) < permille) begin
                    mode = 0;
                    while (mode == 0) begin
                        k = $urandom % 5;
                        if (kinds & (1 << k)) mode = k + 1;
                    end
                    n = (($urandom % 4) == 0) ? 2 + ($urandom % 15) : 1;
                    plan_fiu(f, mode, $urandom % FIU_WORDS, $urandom % NSYM, n, $urandom % LANES, 0);
                end
            end
        end
    endtask

    task automatic plan_fiu(input integer f, input integer mode, input integer word, input integer pos,
                            input integer n, input integer lane, input integer fk);
        begin
            u_ch.set_plan(f, mode, word, pos, n, lane, fk);
            u_sb.mark_fiu(f, mode, fk);
        end
    endtask

    // wait until every expected packet is delivered, then let the link settle
    task automatic wait_drain(input integer max_wait);
        integer t0; reg [8*120-1:0] m;
        begin
            t0 = cycle;
            while (u_sb.ep < u_sb.n_exp && (cycle - t0) < max_wait) @(posedge clk);
            if (u_sb.ep < u_sb.n_exp) begin
                $sformat(m, "[TIMEOUT] %0s: %0d of %0d packets after %0d cycles", cur_test, u_sb.ep, u_sb.n_exp, max_wait);
                tb_fail(m);
                dump_state();
            end
            repeat (60) @(posedge clk);
        end
    endtask

    // standard end-of-traffic checks: idle, no credit leak, counters, status
    task automatic idle_checks(input [8*40-1:0] where);
        reg [31:0] d; reg [1:0] r; reg [8*120-1:0] m;
        begin
            if (u_sb.model_open_at_end) tb_fail("test plan leaves a packet open (test bug)");
            if (m_tvalid !== 1'b0)      tb_fail("egress still valid at end of traffic");
            if (w_rxbuf_used !== 0)     tb_fail("RX buffer not empty at end of traffic");
            if (w_credits !== DEPTH) begin
                $sformat(m, "%0s: credit leak, tx_credits=%0d expected %0d", where, w_credits, DEPTH);
                tb_fail(m);
            end
            check_counters(where);
            check_err_seq(where);
            csr_read(A_STATUS, d, r);
            if (d[0] !== 1'b0 || d[15:8] !== DEPTH || r !== 2'b00) tb_fail("STATUS not idle at end of traffic");
            if (d[16] !== irq) tb_fail("STATUS.irq differs from the irq output");
        end
    endtask

    // ------------------------------------------------------------------ test framework
    task automatic test_begin(input [8*40-1:0] name, input integer idx);
        integer s;
        begin
            cur_test = name; cur_test_idx = idx;
            s = base_seed * 1000 + idx;
            dummy = $urandom(s);
            $display("");
            $display("[TEST-START] %0s  (test seed %0d)", name, base_seed * 1000 + idx);
            if (vcd_all || (vcd_one && vcd_test == name)) $dumpon;
            if (u_ch.dump_fd != 0) $fdisplay(u_ch.dump_fd, "# test %0s", name);
            u_src.gap_pct = 0; u_sink.ready_pct = 100; u_sink.burst_mode = 0; u_sink.max_off = 40;
            u_sink.rng = s ^ 32'h5EED_5EED; u_sink.burst_left = 0;
            u_sb.mon_en = 1'b1; dl_en = 1'b1; u_safe.forge_ok = 1'b0;
            u_sb.tag_base = 32'hC000_0000 | (idx << 20);
            err_at_start = total_errors(); cyc_at_start = cycle;   // reset window belongs to the test
            do_reset(5);
            u_sb.clear(); u_ch.clear_plan();
            for (s = 0; s < 8; s = s + 1) errst_base[s] = 0;
            irqen_model = 0;
            acc_pin = 0; acc_pout = 0; acc_bytes = 0;
        end
    endtask

    // harvest model statistics into coverage before the scoreboard is cleared
    task automatic cov_harvest();
        begin
            acc_pin = acc_pin + u_sb.np; acc_pout = acc_pout + u_sb.pkts_ok + u_sb.pkts_bad;
            acc_bytes = acc_bytes + u_sb.bytes_checked;
            u_cov.add(RXP_FIRST_FIU_LOST, u_sb.m_first_fiu_lost);
            u_cov.add(RXP_ABORT_MIDPKT,   u_sb.m_aborts);
            u_cov.add(RXP_DISCARD_GOOD,   u_sb.exp_cnt[6]);
            u_cov.add(RXP_SOP_IN_PKT,     u_sb.m_dec_sopin);
            u_cov.add(RXP_CONT_NO_PKT,    u_sb.m_dec_cont);
            u_cov.add(RXP_SEQ_ERR,        u_sb.m_seq_err);
            u_cov.add(RXP_POISON,         u_sb.m_poison);
            u_cov.add(RXP_TID_MISMATCH,   u_sb.m_dec_tid);
            u_cov.add(TID_ZERO_DELIVERED, u_sb.m_tid_zero);
            u_cov.add(TID_MAX_DELIVERED,  u_sb.m_tid_max);
            if (u_sb.pkts_ok >= 1000) u_cov.hit(TR_ORDER_1000);
        end
    endtask

    task automatic test_end();
        integer e;
        begin
            cov_harvest();
            if (vcd_all || vcd_one) $dumpoff;
            e = total_errors() - err_at_start;
            r_name[cur_test_idx] = cur_test; r_ran[cur_test_idx] = 1; r_err[cur_test_idx] = e;
            r_cyc[cur_test_idx] = cycle - cyc_at_start; r_pin[cur_test_idx] = acc_pin;
            r_pout[cur_test_idx] = acc_pout; r_bytes[cur_test_idx] = acc_bytes;
            if (e == 0)
                $display("[TEST-RESULT] %-22s : PASS  (cycles=%0d pkts_in=%0d pkts_out=%0d bytes_checked=%0d)",
                         cur_test, cycle - cyc_at_start, acc_pin, acc_pout, acc_bytes);
            else
                $display("[TEST-RESULT] %-22s : FAIL  (errors=%0d)", cur_test, e);
        end
    endtask

    function automatic bit selected(input [8*40-1:0] name);
        selected = !has_sel || (test_sel == name);
    endfunction

    // one traffic "chunk": model all packets, send packets [p0, np), drain, check
    task automatic run_chunk(input integer p0, input integer final_checks);
        integer f0;
        begin
            u_sb.build_fiu_map();
            u_sb.build_expect();
            send_range(p0, u_sb.np);
            wait_drain(5000 + u_sb.total_fiu * 60 + u_sb.np * 60);
            if (final_checks) idle_checks(cur_test);
        end
    endtask

    function automatic integer rnd(input integer lo, input integer hi);
        rnd = lo + ($urandom % (hi - lo + 1));
    endfunction

    // =========================================================================
    //                                TEST LIST
    // =========================================================================
    // 1 reset_idle  ----------------------------------------------------------
    task automatic t_reset_idle();
        integer i, k;
        begin
            if (s_tready !== 1'b1)     tb_fail("s_axis_tready not high after reset release");
            if (m_tvalid !== 1'b0)     tb_fail("m_axis_tvalid not low after reset");
            if (tx_sym_valid !== 1'b0) tb_fail("tx_sym_valid not low after reset");
            csr_expect(A_ID, 32'h4158_5031, 2'b00);
            csr_expect(A_VER, VERSION, 2'b00);
            csr_expect(A_CTRL, 32'h1, 2'b00);
            csr_expect(A_STATUS, {16'h0, 8'(DEPTH), 8'h04}, 2'b00);
            csr_expect(A_SCRATCH, 32'h0, 2'b00);
            csr_expect(A_PARAMS, {8'(LB), 16'(FIU_BYTES), 8'(LANES)}, 2'b00);
            csr_expect(A_PARAMS2, {16'h0, 4'd0, 4'(TID_W), 8'(DEPTH)}, 2'b00);
            csr_expect(A_SEQST, 32'h0, 2'b00);
            csr_expect(A_ERRST, 32'h0, 2'b00);
            csr_expect(A_IRQEN, 32'h0, 2'b00);
            csr_expect(A_LASTERR, 32'h0, 2'b00);
            if (irq !== 1'b0) tb_fail("irq not low after reset");
            check_counters("after power-on reset");
            // traffic, then modify state, then reset while idle
            for (i = 0; i < 5; i = i + 1) add_pkt(rnd(1, 600), 0);
            run_chunk(0, 1);
            csr_write(A_SCRATCH, 32'hCAFE_F00D, 4'hF, 0, 2'b00);
            csr_write(A_CTRL, 32'h0, 4'hF, 1, 2'b00);
            u_cov.hit(CSR_LINK_EN_OFF);
            repeat (20) @(negedge clk);
            cov_harvest();
            do_reset(3);
            u_cov.hit(RST_IDLE);
            u_sb.clear(); u_ch.clear_plan();
            csr_expect(A_CTRL, 32'h1, 2'b00);
            csr_expect(A_SCRATCH, 32'h0, 2'b00);
            csr_expect(A_STATUS, {16'h0, 8'(DEPTH), 8'h04}, 2'b00);
            check_counters("after idle reset");
            for (i = 0; i < 5; i = i + 1) add_pkt(rnd(1, 600), 0);
            run_chunk(0, 1);
        end
    endtask

    // 2 csr_access ------------------------------------------------------------
    task automatic t_csr_access();
        integer k, o;
        reg [31:0] d; reg [1:0] r;
        begin
            for (o = 0; o < 3; o = o + 1) begin
                csr_write(A_SCRATCH, 32'h1111_1111 * (o + 1), 4'hF, o, 2'b00);
                csr_expect(A_SCRATCH, 32'h1111_1111 * (o + 1), 2'b00);
            end
            csr_write(A_SCRATCH, 32'hA5A5_A5A5, 4'hF, 0, 2'b00);
            csr_write(A_SCRATCH, 32'h1234_5678, 4'b0101, 1, 2'b00); u_cov.hit(CSR_WR_STRB_PARTIAL);
            csr_expect(A_SCRATCH, 32'hA534_A578, 2'b00);
            csr_write(A_SCRATCH, 32'hFFFF_FFFF, 4'b1000, 2, 2'b00);
            csr_expect(A_SCRATCH, 32'hFF34_A578, 2'b00);
            csr_write(A_SCRATCH, 32'h0, 4'b0000, 0, 2'b00);           // no strobes: no change
            csr_expect(A_SCRATCH, 32'hFF34_A578, 2'b00);
            csr_expect(A_SCRATCH | 8'h3, 32'hFF34_A578, 2'b00);         // addr[1:0] ignored
            // read-only registers: SLVERR, no side effect
            csr_write(A_ID, 32'h0, 4'hF, 0, 2'b10);      u_cov.hit(CSR_WR_RO_SLVERR);
            csr_write(A_VER, 32'h0, 4'hF, 1, 2'b10);
            csr_write(A_STATUS, 32'hFFFF_FFFF, 4'hF, 2, 2'b10);
            csr_write(A_PARAMS, 32'h0, 4'hF, 0, 2'b10);
            csr_write(A_CNT0, 32'h5, 4'hF, 0, 2'b10);
            csr_write(A_CNT0 + 4*10, 32'h5, 4'hF, 0, 2'b10);
            csr_write(A_CNT0 + 4*19, 32'h5, 4'hF, 1, 2'b10);     // perf counters are RO too
            csr_write(A_PARAMS2, 32'h0, 4'hF, 2, 2'b10);
            csr_write(A_SEQST, 32'h0, 4'hF, 0, 2'b10);
            csr_write(A_LASTERR, 32'hFFFF_FFFF, 4'hF, 1, 2'b10);
            csr_expect(A_ID, 32'h4158_5031, 2'b00);
            csr_expect(A_PARAMS, {8'(LB), 16'(FIU_BYTES), 8'(LANES)}, 2'b00);
            csr_expect(A_LASTERR, 32'h0, 2'b00);
            // ERR_IRQ_EN: RW with byte strobes (8 implemented bits); ERR_STATUS is W1C
            csr_write(A_IRQEN, 32'h1234_56A5, 4'b0001, 0, 2'b00);
            csr_expect(A_IRQEN, 32'h0000_00A5, 2'b00);
            csr_write(A_IRQEN, 32'hFFFF_FF00, 4'b1110, 1, 2'b00);   // upper bytes: reserved, no effect
            csr_expect(A_IRQEN, 32'h0000_00A5, 2'b00);
            csr_write(A_IRQEN, 32'h0, 4'hF, 2, 2'b00);
            csr_expect(A_IRQEN, 32'h0, 2'b00);
            csr_write(A_ERRST, 32'hFFFF_FFFF, 4'hF, 0, 2'b00);       // W1C on an empty register: OKAY, no effect
            csr_expect(A_ERRST, 32'h0, 2'b00);
            // unmapped
            csr_expect(8'h7C, 32'h0, 2'b10); u_cov.hit(CSR_RD_UNMAPPED_SLVERR);
            csr_expect(8'h80, 32'h0, 2'b10);
            csr_expect(8'hA4, 32'h0, 2'b10);
            csr_expect(8'hFC, 32'h0, 2'b10);
            csr_write(8'h7C, 32'h1, 4'hF, 0, 2'b10); u_cov.hit(CSR_WR_UNMAPPED_SLVERR);
            csr_write(8'hFC, 32'h1, 4'hF, 2, 2'b10);
            // CTRL: link_en toggle and counter clear
            csr_write(A_CTRL, 32'h0, 4'hF, 0, 2'b00);   u_cov.hit(CSR_LINK_EN_OFF);
            csr_expect(A_CTRL, 32'h0, 2'b00);
            csr_write(A_CTRL, 32'h1, 4'hF, 0, 2'b00);
            for (k = 0; k < 4; k = k + 1) add_pkt(rnd(100, 900), 0);
            run_chunk(0, 1);                                            // counters non-zero, checked
            clear_counters();
            csr_expect(A_CTRL, 32'h1, 2'b00);                           // clear bit reads 0
            cov_harvest();
            u_sb.clear();                                               // expected counters now 0
            check_counters("after counter clear");
            // back-to-back reads
            for (k = 0; k < 8; k = k + 1) csr_read(A_ID, d, r);
        end
    endtask

    // 3 sizes_directed --------------------------------------------------------
    task automatic t_sizes_directed();
        integer i, p0, pass;
        integer sz [0:23];
        begin
            sz[0]=1; sz[1]=63; sz[2]=64; sz[3]=65; sz[4]=100; sz[5]=255; sz[6]=256;   // required
            sz[7]=2; sz[8]=31; sz[9]=32; sz[10]=33; sz[11]=127; sz[12]=128; sz[13]=223;
            sz[14]=224; sz[15]=225; sz[16]=447; sz[17]=448; sz[18]=449; sz[19]=672;
            sz[20]=1518; sz[21]=4096; sz[22]=9000; sz[23]=3;
            for (pass = 0; pass < 2; pass = pass + 1) begin
                // pass 0: no stalls (back-to-back); pass 1: stalls on both sides
                u_src.gap_pct   = pass ? 30 : 0;
                u_sink.ready_pct = pass ? 50 : 100;
                p0 = u_sb.np;
                for (i = 0; i < 24; i = i + 1) add_pkt(sz[i], 0);
                run_chunk(p0, pass == 1);
            end
        end
    endtask

    // 4 back_to_back ---------------------------------------------------------------
    task automatic t_back_to_back();
        integer i, p0, t_first, t_last, nfiu, fius_before;
        real occ;
        reg [8*120-1:0] m;
        begin
            u_src.gap_pct = 0; u_sink.ready_pct = 100;
            for (i = 0; i < 150; i = i + 1) add_pkt(rnd(1, 300), 0);
            run_chunk(0, 0);
            // long packets: link must be saturated
            p0 = u_sb.np;
            for (i = 0; i < 24; i = i + 1) add_pkt(4096, 0);
            u_sb.build_fiu_map(); u_sb.build_expect();
            nfiu = 24 * ((4096 + PAYLOAD - 1) / PAYLOAD);
            fius_before = u_ch.fiu_cnt;
            t_first = -1; t_last = 0;
            fork
                send_range(p0, u_sb.np);
                begin
                    while (u_ch.fiu_cnt < fius_before + nfiu) begin
                        @(posedge clk);
                        if (tx_sym_valid && tx_sym_sof && t_first < 0) t_first = cycle;
                    end
                    t_last = cycle + FIU_WORDS - 1;
                end
            join
            wait_drain(20000);
            occ = 100.0 * nfiu * FIU_WORDS / (t_last - t_first + 1);
            $display("[INFO] back_to_back: %0d FIUs in %0d cycles, link occupancy %0.2f%% (pass criterion >= 99%%)",
                     nfiu, t_last - t_first + 1, occ);
            if (occ < 99.0) begin $sformat(m, "link occupancy %0.2f%% below 99%%", occ); tb_fail(m); end
            idle_checks("back_to_back");
        end
    endtask

    // 5 random_stalls ----------------------------------------------------------
    task automatic t_random_stalls();
        integer i;
        begin
            u_src.gap_pct = 35; u_sink.burst_mode = 1; u_sink.ready_pct = 50; u_sink.max_off = 60;
            for (i = 0; i < 300 * scale; i = i + 1)
                add_pkt(rnd(1, 1600), (($urandom % 5) == 0) ? F_NULLS : 0);
            run_chunk(0, 1);
        end
    endtask

    // 6 tkeep_malformed --------------------------------------------------------
    // Unsupported tkeep patterns are an explicit, checked behaviour: the beat is
    // forwarded whole, IN_PROTO_ERR increments, the packet ends with tuser=1, and
    // the next packet is unaffected.
    task automatic t_tkeep_malformed();
        integer i;
        begin
            u_src.gap_pct = 10; u_sink.ready_pct = 70;
            for (i = 0; i < 6; i = i + 1) begin
                add_pkt(rnd(65, 600), F_ILL_MID);              add_pkt(rnd(1, 200), 0);
                add_pkt(64 * rnd(2, 6), F_ILL_HOLE);           add_pkt(rnd(1, 200), 0);
                add_pkt(64 * rnd(1, 6), F_ILL_SPR);            add_pkt(rnd(1, 200), 0);
                add_pkt(64 * rnd(1, 6), F_ILL_OFS);            add_pkt(rnd(1, 200), 0);
                // legal but unusual AXIS
                add_pkt(rnd(1, 700), F_ZLAST);
                add_pkt(rnd(1, 700), F_NULLS);
                add_pkt(rnd(1, 700), F_ZLAST | F_NULLS);
                add_pkt(0, F_EMPTY);
                add_pkt(0, F_EMPTY | F_NULLS);
            end
            add_pkt(224, F_ZLAST); add_pkt(448, F_ZLAST); add_pkt(100, F_ZLAST);   // FIU boundaries
            add_pkt(64, F_ILL_HOLE | F_ZLAST);   // hole in a single full beat, then zero-length tlast
            run_chunk(0, 1);
        end
    endtask

    // 7 crc_corruption ---------------------------------------------------------
    task automatic t_crc_corruption();
        integer i, p0, f0;
        begin
            // directed packets and their FIU numbers
            add_pkt(100, 0);    // FIU 0         : CRC field corrupt  -> dropped
            add_pkt(300, 0);    // FIU 1,2       : FIU1 corrupt       -> packet lost, FIU2 discarded
            add_pkt(600, 0);    // FIU 3,4,5     : FIU4 corrupt       -> 224 B + tuser, FIU5 discarded
            add_pkt(448, 0);    // FIU 6,7       : FIU7 corrupt       -> 224 B + tuser
            add_pkt(1000, 0);   // FIU 8..12     : FIU9,10 corrupt    -> 224 B + tuser
            add_pkt(200, 0);    // FIU 13        : clean (recovery)
            add_pkt(64, 0);     // FIU 14        : trailer header corrupt -> dropped
            add_pkt(64, 0);     // FIU 15        : clean
            u_sb.build_fiu_map();
            plan_fiu(0,  MODE_CRC_FIELD, 7, 0, 1, 0, 0);
            plan_fiu(1,  MODE_CRC_FIELD, 7, 5, 3, 0, 0);
            plan_fiu(4,  MODE_CRC_FIELD, 7, 9, 1, 0, 0);
            plan_fiu(7,  MODE_CRC_FIELD, 7, 15, 2, 0, 0);
            plan_fiu(9,  MODE_CRC_FIELD, 7, 2, 1, 0, 0);
            plan_fiu(10, MODE_CRC_FIELD, 7, 7, 1, 0, 0);
            plan_fiu(14, MODE_TRAILER_HDR, 7, 1, 1, 0, 0);
            run_chunk(0, 0);
            // random CRC-field corruption
            p0 = u_sb.np; f0 = u_sb.total_fiu;
            u_src.gap_pct = 10; u_sink.ready_pct = 80;
            for (i = 0; i < 200 * scale; i = i + 1) add_pkt(rnd(1, 1500), 0);
            u_sb.build_fiu_map();
            plan_random(f0, u_sb.total_fiu, 100, 8 | 16);
            run_chunk(p0, 1);
        end
    endtask

    // 8 symbol_errors ------------------------------------------------------------
    task automatic t_symbol_errors();
        integer i;
        begin
            u_src.gap_pct = 10; u_sink.ready_pct = 75;
            for (i = 0; i < 300 * scale; i = i + 1) add_pkt(rnd(1, 2000), 0);
            u_sb.build_fiu_map();
            plan_random(0, u_sb.total_fiu, 80, 1);
            run_chunk(0, 1);
        end
    endtask

    // 9 lane_corruption ----------------------------------------------------------
    task automatic t_lane_corruption();
        integer lane, i, p0, f0;
        begin
            u_src.gap_pct = 5; u_sink.ready_pct = 90;
            for (lane = 0; lane < LANES; lane = lane + 1) begin
                p0 = u_sb.np;
                for (i = 0; i < 8; i = i + 1) add_pkt(700, 0);     // 4 FIUs each
                add_pkt(30, 0);                                     // 1 FIU, words 1..6 are padding
                u_sb.build_fiu_map();
                f0 = u_sb.pk_fiu0[p0];
                plan_fiu(f0 + 1,  MODE_LANE_WORD, rnd(0, FIU_WORDS - 1), 0, 0, lane, 0);  // mid FIU of pkt 0
                plan_fiu(f0 + 4,  MODE_LANE_WORD, 7, 0, 0, lane, 0);                     // trailer of pkt 1 first FIU
                plan_fiu(f0 + 10, MODE_LANE_FIU, 0, 0, 0, lane, 0);                      // lane failure, whole FIU
                plan_fiu(u_sb.pk_fiu0[u_sb.np - 1], MODE_LANE_WORD, 4, 0, 0, lane, 0);   // padding word
                run_chunk(p0, 0);
            end
            // random lane faults over random traffic
            p0 = u_sb.np; f0 = u_sb.total_fiu;
            for (i = 0; i < 150 * scale; i = i + 1) add_pkt(rnd(1, 1200), 0);
            u_sb.build_fiu_map();
            plan_random(f0, u_sb.total_fiu, 80, 2 | 4);
            run_chunk(p0, 1);
        end
    endtask

    // 10 header_forgery ----------------------------------------------------------
    // Valid-CRC FIUs with bad/unexpected headers exercise the frame, sequence,
    // poison and discard paths that random corruption can never reach.
    task automatic t_header_forgery();
        begin
            u_src.gap_pct = 5; u_sink.ready_pct = 90;
            u_safe.forge_ok = 1'b1;      // forged seq / sop-FIU tid are accepted by design
            add_pkt(600, 0);   //  0: FIU 0,1,2   FIU1 magic        -> frame err, 224 B + tuser
            add_pkt(100, 0);   //  1: FIU 3       len=0             -> frame err, dropped
            add_pkt(300, 0);   //  2: FIU 4,5     FIU4 len>max      -> frame err, lost, FIU5 discarded
            add_pkt(300, 0);   //  3: FIU 6,7     FIU7 eop cleared (len 76 not full) -> frame err, 224 B + tuser
            add_pkt(448, 0);   //  4: FIU 8,9     FIU9 eop cleared (len 224 full) -> stays open
            add_pkt(300, 0);   //  5: FIU 10,11   sop while open    -> pkt4 448 B + tuser, pkt5 lost, FIU11 discarded
            add_pkt(100, 0);   //  6: FIU 12      clean (leaves discard mode)
            add_pkt(300, 0);   //  7: FIU 13,14   FIU13 sop cleared -> cont w/o packet: frame err, FIU14 discarded
            add_pkt(600, 0);   //  8: FIU 15,16,17 FIU16 sop set    -> sop while open: 224 B + tuser, FIU17 discarded
            add_pkt(500, 0);   //  9: FIU 18,19,20 FIU19 seq altered -> 2 seq errors, data intact
            add_pkt(500, 0);   // 10: FIU 21,22,23 FIU22 poison     -> delivered intact with tuser=1
            add_pkt(600, 0);   // 11: FIU 24,25,26 FIU24 eop set    -> 224 B delivered WITHOUT tuser (undetectable
                               //                                     with a valid CRC), FIU25 frame err, FIU26 discarded
            add_pkt(200, 0);   // 12: FIU 27      clean
            add_pkt(600, 0);   // 13: FIU 28,29,30 FIU29 tid flipped -> stream changed mid-packet:
                               //                  frame err (TID), 224 B + tuser, FIU30 discarded
            add_pkt(300, 0);   // 14: FIU 31,32   FIU31 tid flipped (sop FIU) -> undetectable: packet
                               //                  takes the forged tid; FIU32 then mismatches -> 224 B + tuser
            add_pkt(100, 0);   // 15: FIU 33      clean
            u_sb.build_fiu_map();
            plan_fiu(1,  MODE_FORGE, 0, 0, 0, 0, FK_MAGIC);
            plan_fiu(3,  MODE_FORGE, 0, 0, 0, 0, FK_LEN0);
            plan_fiu(4,  MODE_FORGE, 0, 0, 0, 0, FK_LENBIG);
            plan_fiu(7,  MODE_FORGE, 0, 0, 0, 0, FK_EOP_CLR);
            plan_fiu(9,  MODE_FORGE, 0, 0, 0, 0, FK_EOP_CLR);
            plan_fiu(13, MODE_FORGE, 0, 0, 0, 0, FK_SOP_CLR);
            plan_fiu(16, MODE_FORGE, 0, 0, 0, 0, FK_SOP_SET);
            plan_fiu(19, MODE_FORGE, 0, 0, 0, 0, FK_SEQ);
            plan_fiu(22, MODE_FORGE, 0, 0, 0, 0, FK_ERR_SET);
            plan_fiu(24, MODE_FORGE, 0, 0, 0, 0, FK_EOP_SET);
            plan_fiu(29, MODE_FORGE, 0, 0, 0, 0, FK_TID);
            plan_fiu(31, MODE_FORGE, 0, 0, 0, 0, FK_TID);
            run_chunk(0, 1);
        end
    endtask

    // 11 order_preservation --------------------------------------------------------
    task automatic t_order_preservation();
        integer i;
        begin
            u_src.gap_pct = 20; u_sink.burst_mode = 1; u_sink.ready_pct = 60; u_sink.max_off = 30;
            for (i = 0; i < 1200 * scale; i = i + 1) add_pkt(rnd(4, 300), 0);
            u_sb.build_fiu_map();
            plan_random(0, u_sb.total_fiu, 20, 1 | 8);         // some drops/aborts interleaved
            run_chunk(0, 1);
            if (u_sb.order_violations != 0) tb_fail("packet order violations detected");
        end
    endtask

    // 12 link_enable -------------------------------------------------------------
    task automatic t_link_enable();
        integer i, fius;
        reg [31:0] d; reg [1:0] r;
        begin
            csr_write(A_CTRL, 32'h0, 4'hF, 0, 2'b00); u_cov.hit(CSR_LINK_EN_OFF);
            csr_expect(A_STATUS, {16'h0, 8'(DEPTH), 8'h00}, 2'b00);
            for (i = 0; i < 6; i = i + 1) add_pkt(500, 0);
            u_sb.build_fiu_map(); u_sb.build_expect();
            dl_en = 1'b0;
            fius = u_ch.fiu_cnt;
            fork
                send_range(0, u_sb.np);
                begin
                    repeat (500) @(posedge clk);
                    if (u_ch.fiu_cnt != fius)  tb_fail("FIU transmitted while link_en=0");
                    if (s_tready !== 1'b0)      tb_fail("s_axis_tready not backpressured while link_en=0");
                    if (u_sb.ep != 0)           tb_fail("egress packet while link_en=0");
                    csr_write(A_CTRL, 32'h1, 4'hF, 2, 2'b00);
                    dl_en = 1'b1;
                end
            join
            wait_drain(10000);
            idle_checks("link_enable");
        end
    endtask

    // 13 credit_stress ----------------------------------------------------------------
    task automatic t_credit_stress();
        integer i, f_at, used_max;
        begin
            u_src.gap_pct = 0;
            u_sink.ready_pct = 3;                               // very slow consumer
            for (i = 0; i < 10; i = i + 1) add_pkt(3000, 0);
            u_sb.build_fiu_map(); u_sb.build_expect();
            fork
                send_range(0, u_sb.np);
                begin
                    repeat (3000) @(posedge clk);
                    // full stop: consumer never ready -> TX must stop once credits are gone
                    dl_en = 1'b0; u_sink.ready_pct = 0;
                    repeat (300) @(posedge clk);
                    f_at = u_ch.fiu_cnt;
                    repeat (1500) @(posedge clk);
                    if (u_ch.fiu_cnt > f_at + 1) tb_fail("TX kept sending FIUs without credits");
                    if (w_rxbuf_used > DEPTH)    tb_fail("RX buffer overflow");
                    if (w_credits >= PW)         tb_fail("credits not exhausted with stalled consumer");
                    // link disabled while credits are exhausted and an FIU is waiting:
                    // CREDIT_STALL must not count (definition: FIU ready AND link enabled AND credits < 7);
                    // checked exactly by perf_shadow at the end of the test
                    csr_write(A_CTRL, 32'h0, 4'hF, 0, 2'b00); u_cov.hit(CSR_LINK_EN_OFF);
                    repeat (200) @(posedge clk);
                    csr_write(A_CTRL, 32'h1, 4'hF, 1, 2'b00);
                    u_sink.ready_pct = 100; dl_en = 1'b1;
                end
            join
            wait_drain(40000);
            idle_checks("credit_stress");
            $display("[INFO] credit_stress: min credits seen=%0d, max RX buffer occupancy=%0d of %0d",
                     u_inv.min_credits_seen, u_inv.max_used_seen, DEPTH);
        end
    endtask

    // 14 reset_traffic -----------------------------------------------------------------
    task automatic reset_scenario(input integer kind);
        integer i, t0;
        reg hit_cond;
        begin
            u_sb.clear(); u_ch.clear_plan();
            u_sb.mon_en = 1'b0; dl_en = 1'b0;
            u_src.gap_pct = 5;
            u_sink.ready_pct = (kind == 2) ? 0 : 60;
            for (i = 0; i < 30; i = i + 1) add_pkt(rnd(300, 1500), 0);
            u_sb.build_fiu_map(); u_sb.build_expect();
            fork
                send_range(0, u_sb.np);
                begin
                    hit_cond = 0; t0 = cycle;
                    while (!hit_cond && cycle - t0 < 20000) begin
                        @(posedge clk);
                        case (kind)
                            0: hit_cond = (cycle - t0 > 200) && s_tvalid && s_tready && !s_tlast;
                            1: hit_cond = (cycle - t0 > 300) && tx_sym_valid && !tx_sym_sof;
                            default: hit_cond = m_tvalid && !m_tready && (w_rxbuf_cnt > 4);
                        endcase
                    end
                    if (!hit_cond) tb_fail("reset scenario condition never reached");
                    case (kind)
                        0: u_cov.hit(RST_ING_MIDPKT);
                        1: u_cov.hit(RST_LINK_MIDFIU);
                        default: begin u_cov.hit(RST_EG_BACKPRESSURED); u_cov.hit(RST_RXBUF_NONEMPTY); end
                    endcase
                    if (w_rxbuf_used > 0) u_cov.hit(RST_RXBUF_NONEMPTY);
                    do_reset(3);                         // aborts the driver
                end
            join
            // post-reset: everything back to defaults
            if (m_tvalid !== 1'b0 || tx_sym_valid !== 1'b0) tb_fail("outputs active right after reset");
            if (w_rxbuf_used !== 0 || w_credits !== DEPTH) tb_fail("buffer/credits not reset");
            u_sb.clear(); u_ch.clear_plan();
            check_counters("after reset in traffic");
            csr_expect(A_CTRL, 32'h1, 2'b00);
            csr_expect(A_STATUS, {16'h0, 8'(DEPTH), 8'h04}, 2'b00);
            // fresh traffic must be clean
            u_sb.mon_en = 1'b1; dl_en = 1'b1; u_sink.ready_pct = 80;
            for (i = 0; i < 25; i = i + 1) add_pkt(rnd(1, 1200), 0);
            run_chunk(0, 1);
            cov_harvest();
        end
    endtask

    task automatic t_reset_traffic();
        begin
            reset_scenario(0);
            reset_scenario(1);
            reset_scenario(2);
            u_sb.clear();     // already harvested
            u_sb.np = 0;
        end
    endtask

    // 15 random_regression -----------------------------------------------------------
    task automatic t_random_regression();
        integer i, r, len, flg, f, kind;
        begin
            u_src.gap_pct = 15; u_sink.burst_mode = 1; u_sink.ready_pct = 70; u_sink.max_off = 40;
            u_safe.forge_ok = 1'b1;
            for (i = 0; i < 600 * scale; i = i + 1) begin
                r = $urandom % 100;
                if (r < 40) len = rnd(1, 128); else if (r < 70) len = rnd(129, 700);
                else if (r < 90) len = rnd(701, 2000); else len = rnd(2001, 6000);
                r = $urandom % 100; flg = 0;
                if (r < 5)       flg = F_NULLS;
                else if (r < 10) flg = F_ZLAST;
                else if (r < 11) begin flg = F_ILL_MID; if (len < 65) len = 65 + len; end
                else if (r < 12) begin flg = F_ILL_SPR; len = 64 * (1 + len / 64); end
                else if (r < 13) begin flg = F_EMPTY; len = 0; end
                add_pkt(len, flg);
            end
            u_sb.build_fiu_map();
            plan_random(0, u_sb.total_fiu, 30, 1 | 2 | 4 | 8 | 16);
            // a few safe forgeries (cannot leave a packet open at the end)
            for (i = 0; i < 6; i = i + 1) begin
                f = $urandom % (u_sb.total_fiu > 1 ? u_sb.total_fiu - 1 : 1);
                case ($urandom % 6)
                    0: kind = FK_MAGIC; 1: kind = FK_LEN0; 2: kind = FK_SEQ;
                    3: kind = FK_ERR_SET; 4: kind = FK_TID; default: kind = FK_LENBIG;
                endcase
                plan_fiu(f, MODE_FORGE, 0, 0, 0, 0, kind);
            end
            run_chunk(0, 1);
        end
    endtask

    // 16 wave_showcase --------------------------------------------------------------
    // Short, fully deterministic scenario for waveform review (~150 cycles):
    //   P0 100 B (F0) clean | P1 300 B (F1,F2) F2 lane-2 word-1 fault -> abort 224 B + tuser
    //   P2 64 B (F3) 1-symbol fault -> discarded | P3 300 B (F4,F5) F4 CRC-field fault ->
    //   packet lost, F5 dropped in discard mode | P4 64 B (F6) clean -> recovery
    task automatic t_wave_showcase();
        begin
            u_src.gap_pct = 0; u_sink.ready_pct = 100;
            add_pkt(100, 0); add_pkt(300, 0); add_pkt(64, 0); add_pkt(300, 0); add_pkt(64, 0);
            u_sb.build_fiu_map();
            plan_fiu(2, MODE_LANE_WORD, 1, 0, 0, (LANES > 2) ? 2 : LANES - 1, 0);   // lane 2 (last lane if LANES < 3)
            plan_fiu(3, MODE_SYM,       1, 10, 1, 0, 0);
            plan_fiu(4, MODE_CRC_FIELD, 7, 0, 1, 0, 0);
            run_chunk(0, 1);
        end
    endtask

    // 17 err_csr_perf --------------------------------------------------------------
    // Error reporting (ERR_STATUS W1C, ERR_IRQ_EN, irq, LAST_ERR for every reason),
    // SEQ_STATUS and performance counters with hand-derived expected values
    // (independent of the scoreboard model, which idle_checks also applies).
    task automatic w1c(input [7:0] bits);
        integer k;
        begin
            csr_write(A_ERRST, {24'h0, bits}, 4'h1, 0, 2'b00);
            for (k = 0; k < 7; k = k + 1) if (bits[k]) errst_base[k] = u_sb.exp_cnt[err_src(k)];
            u_cov.hit(CSR_ERR_W1C);
        end
    endtask
    task automatic set_irqen(input [7:0] v);
        begin csr_write(A_IRQEN, {24'h0, v}, 4'hF, 1, 2'b00); irqen_model = v; end
    endtask
    task automatic expect_irq(input exp_v, input [8*40-1:0] where);
        reg [31:0] d; reg [1:0] r; reg [8*120-1:0] m;
        begin
            csr_read(A_STATUS, d, r);          // also gives the registered irq time to settle
            if (irq !== exp_v || d[16] !== exp_v) begin
                $sformat(m, "%0s: irq=%0d STATUS.irq=%0d expected %0d", where, irq, d[16], exp_v); tb_fail(m); end
            if (exp_v) u_cov.hit(CSR_IRQ_ASSERT); else u_cov.hit(CSR_IRQ_DEASSERT);
        end
    endtask

    task automatic t_err_csr_perf();
        integer p0, i, t0, t1;
        reg [31:0] d; reg [1:0] r; reg [8*120-1:0] m;
        begin
            u_src.gap_pct = 0; u_sink.ready_pct = 100;
            u_safe.forge_ok = 1'b1;
            set_irqen(8'h01);                                     // interrupt on CRC errors only
            // phase 1: clean traffic, FIU 0 | 1,2 | 3
            add_pkt(100, 0); add_pkt(300, 0); add_pkt(64, 0);
            run_chunk(0, 1);
            csr_expect(A_SEQST, {7'b0, 1'b1, 8'd3, 8'd4, 8'd4}, 2'b00);   // any | last acc 3 | rx exp 4 | tx next 4
            csr_expect(A_ERRST, 32'h0, 2'b00);
            expect_irq(1'b0, "clean traffic");
            // phase 2: CRC error on FIU 5 (single-FIU packet) -> irq, LAST_ERR = CRC, seq 5/5
            p0 = u_sb.np;
            add_pkt(200, 0); add_pkt(150, 0); add_pkt(500, 0);           // FIU 4 | 5 | 6,7,8
            u_sb.build_fiu_map();
            plan_fiu(5, MODE_CRC_FIELD, 7, 0, 1, 0, 0);
            run_chunk(p0, 1);
            csr_expect(A_LASTERR, 32'h8001_0505, 2'b00);
            csr_expect(A_ERRST, 32'h0000_0001, 2'b00);
            expect_irq(1'b1, "after CRC error");
            // W1C: other bits / no strobe do not clear; writing 1 clears; irq follows
            csr_write(A_ERRST, 32'hFFFF_FFFE, 4'hF, 0, 2'b00);
            csr_expect(A_ERRST, 32'h0000_0001, 2'b00);
            csr_write(A_ERRST, 32'h0000_0001, 4'h0, 2, 2'b00);
            csr_expect(A_ERRST, 32'h0000_0001, 2'b00);
            w1c(8'h01);
            csr_expect(A_ERRST, 32'h0, 2'b00);
            expect_irq(1'b0, "after W1C");
            csr_expect(A_LASTERR, 32'h8001_0505, 2'b00);                 // LAST_ERR is not cleared by W1C
            // phase 3: bad magic on FIU 10 (packet FIU 9,10,11) -> HDR, 224 B + tuser, FIU 11 discarded
            p0 = u_sb.np;
            add_pkt(600, 0); add_pkt(64, 0);                              // FIU 9,10,11 | 12
            u_sb.build_fiu_map();
            plan_fiu(10, MODE_FORGE, 0, 0, 0, 0, FK_MAGIC);
            run_chunk(p0, 1);
            csr_expect(A_LASTERR, 32'h8002_0A0A, 2'b00);
            csr_expect(A_ERRST, 32'h0000_001A, 2'b00);                   // FRAME | DISCARD | RX_PKT_ERR
            expect_irq(1'b0, "HDR error, CRC-only enable");
            w1c(8'h12);                                                   // clear FRAME and RX_PKT_ERR only
            csr_expect(A_ERRST, 32'h0000_0008, 2'b00);                   // DISCARD stays set
            // phase 4: sop set on FIU 14 (packet FIU 13,14,15) -> SOP_IN_PKT
            p0 = u_sb.np;
            add_pkt(600, 0); add_pkt(64, 0);                              // FIU 13,14,15 | 16
            u_sb.build_fiu_map();
            plan_fiu(14, MODE_FORGE, 0, 0, 0, 0, FK_SOP_SET);
            run_chunk(p0, 1);
            csr_expect(A_LASTERR, 32'h8003_0E0E, 2'b00);
            // phase 5: tid flipped on FIU 18 (packet FIU 17,18,19) -> TID
            p0 = u_sb.np;
            add_pkt(600, 0); add_pkt(64, 0);                              // FIU 17,18,19 | 20
            u_sb.build_fiu_map();
            plan_fiu(18, MODE_FORGE, 0, 0, 0, 0, FK_TID);
            run_chunk(p0, 1);
            csr_expect(A_LASTERR, 32'h8005_1212, 2'b00);
            // phase 6: sequence forged on FIU 21, FIU 22 then mismatches as well:
            //          last capture: expected (21^0x55)+1 = 0x41, received 22 = 0x16
            set_irqen(8'h04);                                             // interrupt on sequence errors
            p0 = u_sb.np;
            add_pkt(100, 0); add_pkt(100, 0);                             // FIU 21 | 22
            u_sb.build_fiu_map();
            plan_fiu(21, MODE_FORGE, 0, 0, 0, 0, FK_SEQ);
            run_chunk(p0, 1);
            csr_expect(A_LASTERR, 32'h8007_1641, 2'b00);
            expect_irq(1'b1, "sequence error, SEQ enable");
            // phase 7: CTRL.cnt_clear clears counters, ERR_STATUS and LAST_ERR -> irq drops
            clear_counters();
            cov_harvest();
            u_sb.clear(); for (i = 0; i < 8; i = i + 1) errst_base[i] = 0;
            csr_expect(A_ERRST, 32'h0, 2'b00);
            csr_expect(A_LASTERR, 32'h0, 2'b00);
            expect_irq(1'b0, "after counter clear");
            check_counters("after counter clear");
            // phase 8: performance counters with derived values (after a reset):
            //   4 x 1000 B, no stalls: IN_BYTES = OUT_BYTES = 4000, TX_WORDS = 4*5*8 = 160,
            //   IN_STALL counts the cycles the 512-bit source waits for the 256-bit link
            do_reset(3);
            u_sb.clear(); u_ch.clear_plan(); irqen_model = 0;
            for (i = 0; i < 4; i = i + 1) add_pkt(1000, 0);
            t0 = cycle;
            run_chunk(0, 1);
            csr_expect(A_CNT0 + 4*11, 32'd4000, 2'b00);
            csr_expect(A_CNT0 + 4*12, 32'd4000, 2'b00);
            csr_expect(A_CNT0 + 4*16, 32'd160, 2'b00);
            csr_read(A_CNT0 + 4*13, d, r);
            $display("[INFO] err_csr_perf: 4000 B in %0d cycles: IN_STALL=%0d (source waits for the narrower link)",
                     cycle - t0, d);
            if (d == 0) tb_fail("IN_STALL is 0 although a 512-bit source feeds a 256-bit link");
            csr_read(A_CNT0 + 4*17, d, r);
            if (d < cycle - t0 - 100 || d > cycle - t0 + 200) begin
                $sformat(m, "CYCLES=%0d not consistent with %0d elapsed cycles", d, cycle - t0); tb_fail(m); end
        end
    endtask

    // =========================================================================
    //                                   MAIN
    // =========================================================================
    integer t, n_run, n_fail, fd, k;
    reg [8*40-1:0] tname;

    task automatic run_test(input integer idx);
        begin
            case (idx)
                1: tname = "reset_idle";        2: tname = "csr_access";
                3: tname = "sizes_directed";    4: tname = "back_to_back";
                5: tname = "random_stalls";     6: tname = "tkeep_malformed";
                7: tname = "crc_corruption";    8: tname = "symbol_errors";
                9: tname = "lane_corruption";   10: tname = "header_forgery";
                11: tname = "order_preservation"; 12: tname = "link_enable";
                13: tname = "credit_stress";    14: tname = "reset_traffic";
                15: tname = "random_regression"; 16: tname = "wave_showcase";
                default: tname = "err_csr_perf";
            endcase
            r_ran[idx] = 0;
            if (selected(tname)) begin
                test_begin(tname, idx);
                case (idx)
                    1: t_reset_idle();        2: t_csr_access();      3: t_sizes_directed();
                    4: t_back_to_back();      5: t_random_stalls();   6: t_tkeep_malformed();
                    7: t_crc_corruption();    8: t_symbol_errors();   9: t_lane_corruption();
                    10: t_header_forgery();   11: t_order_preservation(); 12: t_link_enable();
                    13: t_credit_stress();    14: t_reset_traffic();  15: t_random_regression();
                    16: t_wave_showcase();
                    default: t_err_csr_perf();
                endcase
                test_end();
            end
        end
    endtask

    initial begin
        if (!$value$plusargs("seed=%d", base_seed)) base_seed = 1;
        if ($value$plusargs("test=%s", test_sel)) has_sel = 1;
        if (!$value$plusargs("scale=%d", scale)) scale = 1;
        if (!$value$plusargs("max_cycles=%d", max_cycles)) max_cycles = 4000000;
        void'($value$plusargs("cov_file=%s", cov_file));
        cov_strict = $test$plusargs("cov_strict");
        $display("==============================================================================");
        $display(" tb_top : axis_pcie_link_top verification   seed=%0d  scale=%0d  test=%0s  LANES=%0d TID_W=%0d",
                 base_seed, scale, has_sel ? test_sel : "ALL", LANES, TID_W);
        $display("==============================================================================");
        // waveform controls
        vcd_all = $test$plusargs("vcd");
        vcd_one = $value$plusargs("vcd_test=%s", vcd_test);
        void'($value$plusargs("vcd_file=%s", vcd_file));
        if (!$value$plusargs("vcd_depth=%d", vcd_depth)) vcd_depth = 0;
        void'($value$plusargs("vcd_scope=%s", vcd_scope));
        vcd_scope_all = (vcd_scope == "all");
        if (vcd_all || vcd_one) begin
            $dumpfile(vcd_file);
            if (vcd_scope_all) begin
                $dumpvars(vcd_depth, tb_top);              // everything (large files)
            end else begin
                $dumpvars(1, tb_top);                      // all DUT ports + white-box taps
                $dumpvars(1, dut);
                $dumpvars(1, dut.u_ingress);
                $dumpvars(1, dut.u_packetizer);
                $dumpvars(1, dut.u_link);
                $dumpvars(1, dut.u_rxbuf);
                $dumpvars(1, dut.u_depacketizer);
                $dumpvars(1, dut.u_csr);
            end
            $dumpoff;
            $display("[INFO] waveform dump: %0s (scope %0s, %0s)", vcd_file,
                     vcd_scope_all ? "all" : "dut", vcd_all ? "all tests" : "selected test only");
        end
        if ($value$plusargs("fiu_dump=%s", fiu_dump_file)) begin
            u_ch.dump_fd = $fopen(fiu_dump_file, "w"); u_ch.dump_en = 1'b1;
        end
        if ($value$plusargs("inj_log=%s", inj_log_file)) u_ch.log_fd = $fopen(inj_log_file, "w");

        for (t = 1; t <= NTESTS; t = t + 1) run_test(t);

        // channel statistics -> coverage
        u_cov.add(ERR_SYM, u_ch.n_mode[1]);       u_cov.add(ERR_SYM_BURST, u_ch.n_sym_burst);
        for (k = 0; k < 4; k = k + 1)              // lane bins beyond LANES do not apply
            if (k < LANES) u_cov.add(ERR_LANE0 + k, u_ch.n_lane[k]); else u_cov.set_na(ERR_LANE0 + k);
        u_cov.add(ERR_LANE_FIU, u_ch.n_mode[3]);  u_cov.add(ERR_CRC_FIELD, u_ch.n_mode[4]);
        u_cov.add(ERR_TRAILER_HDR, u_ch.n_mode[5]);
        u_cov.add(FG_MAGIC, u_ch.n_forge[FK_MAGIC]);     u_cov.add(FG_LEN0, u_ch.n_forge[FK_LEN0]);
        u_cov.add(FG_LENBIG, u_ch.n_forge[FK_LENBIG]);   u_cov.add(FG_EOP_CLR, u_ch.n_forge[FK_EOP_CLR]);
        u_cov.add(FG_SOP_CLR, u_ch.n_forge[FK_SOP_CLR]); u_cov.add(FG_SOP_SET, u_ch.n_forge[FK_SOP_SET]);
        u_cov.add(FG_SEQ, u_ch.n_forge[FK_SEQ]);         u_cov.add(FG_ERR_SET, u_ch.n_forge[FK_ERR_SET]);
        u_cov.add(FG_EOP_SET, u_ch.n_forge[FK_EOP_SET]);
        u_cov.add(FG_TID, u_ch.n_forge[FK_TID]);

        // ---------------- summary ----------------
        n_run = 0; n_fail = 0;
        $display("");
        $display("==================================== REGRESSION SUMMARY (seed=%0d) ====================================", base_seed);
        $display("%-22s %-6s %7s %9s %8s %9s %14s", "TEST", "RESULT", "ERRORS", "CYCLES", "PKTS_IN", "PKTS_OUT", "BYTES_CHECKED");
        for (t = 1; t <= NTESTS; t = t + 1) if (r_ran[t]) begin
            n_run = n_run + 1;
            if (r_err[t] != 0) n_fail = n_fail + 1;
            $display("%-22s %-6s %7d %9d %8d %9d %14d", r_name[t], r_err[t] ? "FAIL" : "PASS",
                     r_err[t], r_cyc[t], r_pin[t], r_pout[t], r_bytes[t]);
        end
        $display("component errors: tb=%0d src=%0d chk_ingress=%0d chk_egress=%0d axil=%0d chk_axil=%0d scoreboard=%0d invariants=%0d safety=%0d",
                 tb_errors, u_src.errors, u_chk_in.errors, u_chk_eg.errors, u_axil.errors,
                 u_chk_axil.errors, u_sb.errors, u_inv.errors, u_safe.errors);
        $display("[INFO] configuration: LANES=%0d TID_W=%0d  safety checks: %0d packets in-order, %0d FIUs accepted in sequence",
                 LANES, TID_W, u_safe.pkts_checked, u_safe.fius_accepted);
        // ---------------- coverage ----------------
        u_cov.report(1);                      // MCD 1 = stdout
        fd = $fopen(cov_file, "w");
        if (fd != 0) begin u_cov.report(fd); $fclose(fd); end
        if (u_ch.dump_fd != 0) $fclose(u_ch.dump_fd);
        if (u_ch.log_fd != 0)  $fclose(u_ch.log_fd);
        if (cov_strict && !has_sel && u_cov.holes() != 0) begin
            $display("[ERROR] coverage holes with +cov_strict: %0d", u_cov.holes());
            n_fail = n_fail + 1;
        end
        if (n_run == 0) begin
            $display("[SIM-RESULT] FAILED  no test matched +test=%0s", test_sel);
            $fatal(1, "no test selected");
        end else if (n_fail == 0 && total_errors() == 0) begin
            $display("[SIM-RESULT] PASSED  tests=%0d passed=%0d failed=0 seed=%0d", n_run, n_run, base_seed);
            $finish;
        end else begin
            $display("[SIM-RESULT] FAILED  tests=%0d passed=%0d failed=%0d seed=%0d", n_run, n_run - n_fail, n_fail, base_seed);
            $fatal(1, "simulation failed");
        end
    end

    // global watchdog
    initial begin
        #1;
        while (cycle < max_cycles) @(posedge clk);
        $display("[TIMEOUT] global watchdog: %0d cycles exceeded in test %0s", max_cycles, cur_test);
        dump_state();
        $display("[SIM-RESULT] FAILED  global watchdog seed=%0d", base_seed);
        $fatal(1, "global watchdog");
    end
endmodule
