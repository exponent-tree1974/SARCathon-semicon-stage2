# Floorplan and pin assumptions

All inputs to this page are tool outputs from the run `build/sky130hd_tt_100MHz`:

- `synth/synth_stat.rpt` for area and cell count;
- `synth/pin_constraint_check.rpt` for pin counts.

The track pitches are from the platform's `make_tracks.tcl`. Arithmetic derived from those numbers is marked *derived*.

## Inputs

| Quantity | Value | Source |
|---|---|---|
| Std-cell area after synthesis (TT lib) | 594,554 µm² (62.08 % sequential) | `synth_stat.rpt` |
| Cells / flip-flops | 44,969 / 12,590 | `synth_stat.rpt` |
| Top-level port bits | 2,374 (1,482 in, 892 out) | `pin_constraint_check.rpt` |
| met2 / met3 track pitch | 0.46 µm / 0.68 µm | `make_tracks.tcl` |

## Pin plan

The edges are assigned in `flow/constraints/io_pins.tcl`, with the same assignment in `flow/librelane/pin_order.cfg`. North and south pins are on met2 (vertical layer); east and west pins are on met3 (horizontal layer). `place_pins` is run with `-min_distance 2 -min_distance_in_tracks -corner_avoidance 15`. That gives 0.92 µm per pin on the north and south edges and 1.36 µm per pin on the east and west edges.

| Edge | Signals | Pins | Capacity at 1300 µm *(derived: (1300−30)/pitch)* | Use |
|---|---|---|---|---|
| N | `s0_axis_*`, `s1_axis_*` | 1,158 | 1,380 | 84 % |
| S | `m_axis_*` | 581 | 1,380 | 42 % |
| E | `tx_sym*`, `rx_sym*`, credits | 532 | 933 | 57 % |
| W | `clk`, `rst_n`, `s_axil_*`, `irq`, `ev_arb_pkt_start` | 103 | 933 | 11 % |

**The block is pin-limited.** The north edge alone needs at least 1,158 × 0.92 + 30 ≈ 1,095 µm of die width *(derived)*. Moving one ingress source to the west edge would relax this. It was kept on one edge so both sources have symmetric wire lengths into the arbiter.

## Die and core

| Item | Value | Note |
|---|---|---|
| Die | 1300 × 1300 µm (`DIE_AREA`) | Absolute sizing, so pin capacity is guaranteed. |
| Core margin | 20 µm all round (`CORE_MARGIN_UM`) | Core is 1260 × 1260 µm = 1,587,600 µm² *(derived)*. |
| Utilisation from synthesis area | 37.57 % (floorplan log: 594,554 / 1,582,713 µm² core) | Before taps, tie cells, buffering, CTS and hold buffers. The floorplan step measures the real value and **fails above 70 %**. |
| Target placement density | 0.55 (`PLACE_DENSITY`) | Low, because of the wide RX-buffer read mux: 14,997 `$_MUX_` in the generic netlist. |
| Rows / site | `unithd` (0.46 × 2.72 µm) | Platform. |
| Macros | none | All storage is flip-flops (see `technology_assumptions.md` T4). |
| Power | met1 follow-pins; met4/met5 straps; met5 straps exported as power pins | ORFS `pdn.tcl`. No core ring: block style. |

## If the die must shrink

1. Spread the ingress pins over the north and west edges. The die can then go down to about 1,100 µm *(derived)*, which is about 52 % utilisation from synthesis area.
2. Replace the flip-flop RX buffer with an SRAM macro (T4). Area is dominated by sequential cells (62.08 %).
3. Re-run the full flow. A smaller die changes congestion and timing, so no number from this run carries over.
