#!/usr/bin/env bash
# =============================================================================
# Build the open-source ASIC toolchain from source at PINNED commits.
#
# Use this only when Nix / Docker / distro packages are unavailable (this is how
# the tools for the recorded run were obtained: the build host allowed `git clone`
# from GitHub and nothing else). With Nix or Docker, prefer LibreLane's own
# environment (see README.md, "Route A").
#
#   PREFIX=/opt/eda/install SRC=/opt/eda/src J=2 bash tools/build_from_source.sh
#
# Needs: gcc/g++ >= 11, cmake >= 3.24, make, bison >= 3.8, m4, autoconf, automake,
#        libexpat + X11 headers (KLayout XML, Tk for Magic),
#        python3, zlib/bz2/readline headers, Ruby >= 3 headers (KLayout), git.
# Resumable: each step leaves $PREFIX/../stamps/<step>.done.
# Wall time on 2 cores (recorded run): yosys ~40 min, opensta ~30 min (incl. its
# unit tests), or-tools ~1.5-2 h, OpenROAD ~2-3 h, KLayout ~1-2 h.
# =============================================================================
set -u
PREFIX=${PREFIX:-/opt/eda/install}
SRC=${SRC:-/opt/eda/src}
J=${J:-2}
STAMPS=$(dirname "$PREFIX")/stamps
LOGS=$(dirname "$PREFIX")/logs
mkdir -p "$PREFIX/bin" "$PREFIX/lib" "$PREFIX/include" "$SRC/deps" "$STAMPS" "$LOGS"
export PATH=$PREFIX/bin:$PATH LD_LIBRARY_PATH=$PREFIX/lib:${LD_LIBRARY_PATH:-} CMAKE_PREFIX_PATH=$PREFIX
P=$PREFIX; S=$SRC/deps

# ---- pinned sources: name url ref commit ------------------------------------------
read -r -d '' SOURCES <<'EOF'
flex        https://github.com/westes/flex.git                           v2.6.4          ab49343b08c933e32de8de78132649f9560a3727
winflexbison https://github.com/lexxmark/winflexbison.git                master          a243a1c618c061624cdf48ac9dbb68de1e08e9a0
yosys       https://github.com/YosysHQ/yosys.git                         main            0ad867ab51111cd5b083b28f934c9a764cca33f3
OpenROAD    https://github.com/The-OpenROAD-Project/OpenROAD.git         master          8c65de59e62f46d34240090df58bc8f961af5c19
deps/tcl    https://github.com/tcltk/tcl.git                             core-8-6-16     874e4fe4264a40c00c4db5115afba9600f9f368d
deps/pcre2  https://github.com/PCRE2Project/pcre2.git                    pcre2-10.42     52c08847921a324c804cabf2814549f50bce1265
deps/swig   https://github.com/swig/swig.git                             v4.3.0          138507624bd1e0de72adff1b12a788e74133f94e
deps/eigen  https://github.com/live-clones/eigen.git                     3.4.0           3147391d946bb4b6c68edd901f2add6ac1f31f8c
deps/cudd   https://github.com/The-OpenROAD-Project/cudd.git             3.0.0           d47718fedea39fa2ef7d4907432b92b032a8ff72
deps/lemon  https://github.com/The-OpenROAD-Project/lemon-graph.git      master          31d79d686f776a62ace1925cb2e40e84a80d1394
deps/spdlog https://github.com/gabime/spdlog.git                         v1.15.0         8e5613379f5140fefb0b60412fbf1f5406e7c7f8
deps/yaml-cpp https://github.com/jbeder/yaml-cpp.git                     0.8.0           f7320141120f720aecc4c32be25586e7da9eb978
deps/abseil https://github.com/abseil/abseil-cpp.git                     20250512.0      bc257a88f7c1939f24e0379f14a3589e926c950c
deps/or-tools https://github.com/google/or-tools.git                     v9.14           0d60e8afe450ec817f510aae965ab8898310cb41
deps/googletest https://github.com/google/googletest.git                 v1.17.0         52eb8108c5bdec04579160ae17225d66034bd723
deps/boost  https://github.com/boostorg/boost.git                        boost-1.89.0    ef7fea34711a189472893b88205b1dd3c275677b
qtbase      https://github.com/qt/qtbase.git                             5.15            c68297f66533200c9ff626b056d096c78b4b94db
klayout     https://github.com/KLayout/klayout.git                       v0.30.4         8b0a8c73175f6d84f841e88914d1a8819201e045
verilator   https://github.com/verilator/verilator.git                   v5.052          ea338be98e1e838d3518809ce8899f85a009963c
deps/zstd   https://github.com/facebook/zstd.git                         v1.5.7          f8745da6ff1ad1e7bab384bd1f9d742439278e99
deps/tk     https://github.com/tcltk/tk.git                              core-8-6-16     9ce7ed45cf35f91e8d77a0d295069f4e9af297f4
magic       https://github.com/RTimothyEdwards/magic.git                 8.3.623         fd12c39c37f26a0fe6e04698b1011e31b8bd3229
netgen      https://github.com/RTimothyEdwards/netgen.git                1.5.316         b76c9a17121f2b93e49889db7114fc6662657411
EOF
# magic 8.3.623 / netgen 1.5.316 are the versions LibreLane 3.0.16 pins
# (nix-eda @8f990fb7: nix/magic.nix, nix/netgen.nix).
# Eigen: the canonical repo is gitlab.com/libeigen/eigen; live-clones/eigen is a
# GitHub mirror whose 3.4.0 tag has the same commit id as the official release.

fetch () {
  echo "$SOURCES" | while read -r name url ref sha; do
    [ -d "$SRC/$name/.git" ] && continue
    case $name in deps/boost) extra="--recurse-submodules --shallow-submodules -j4";; *) extra="";; esac
    git clone -q --depth 1 --branch "$ref" $extra "$url" "$SRC/$name" || { echo "clone failed: $name"; exit 1; }
    got=$(git -C "$SRC/$name" rev-parse HEAD)
    [ "$got" = "$sha" ] || echo "WARNING: $name is at $got, recorded run used $sha"
  done
}

step () {  # step <name> <commands...>
  local n=$1; shift
  [ -f "$STAMPS/$n.done" ] && { echo "SKIP $n"; return 0; }
  echo "=== START $n $(date -u +%FT%TZ)"
  if ( set -e; eval "$@" ) > "$LOGS/$n.log" 2>&1; then
    touch "$STAMPS/$n.done"; echo "=== DONE  $n $(date -u +%FT%TZ)"
  else
    echo "=== FAIL  $n (see $LOGS/$n.log)"; exit 1
  fi
}
CM="cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=$P -DCMAKE_PREFIX_PATH=$P -DCMAKE_POSITION_INDEPENDENT_CODE=ON"

fetch

# flex: git tree needs an existing flex to bootstrap; use winflexbison's
# pre-generated scanner (flex 2.6.4) for stage 1, then flex rebuilds itself.
step flex '
  cd $SRC/flex/src
  printf "%s\n" "#define VERSION \"2.6.4\"" "#define PACKAGE \"flex\"" "#define M4 \"/usr/bin/m4\"" \
    "#define HAVE_STDBOOL_H 1" "#define HAVE_LIMITS_H 1" "#define HAVE_UNISTD_H 1" "#define HAVE_SYS_WAIT_H 1" \
    "#define HAVE_REGEX_H 1" "#define HAVE_INTTYPES_H 1" "#define HAVE_STRING_H 1" "#define HAVE_STDLIB_H 1" \
    "#define HAVE_FORK 1" "#define HAVE_DUP2 1" "#define HAVE_REALLOCARRAY 1" "#define HAVE_NETINET_IN_H 1" \
    "#define HAVE_SYS_STAT_H 1" "#define HAVE_LOCALE_H 1" "#define HAVE_MALLOC_H 1" "#define HAVE_STRCASECMP 1" > config.h
  sh mkskel.sh . m4 2.6.4 > skel.c
  bison -d -o parse.c parse.y
  sed -e "s/#include <io.h>/#include <unistd.h>/" -e "s/_isatty( _fileno(file) )/isatty( fileno(file) )/" \
      $SRC/winflexbison/flex/src/scan.c > stage1scan.c
  SRCS="buf.c ccl.c dfa.c ecs.c filter.c gen.c main.c misc.c nfa.c options.c parse.c regex.c scanflags.c scanopt.c skel.c sym.c tables.c tables_shared.c tblcmp.c yylex.c"
  gcc -O2 -DHAVE_CONFIG_H -I. -w -o stage1flex $SRCS stage1scan.c -lm
  ./stage1flex -o scan.c scan.l
  gcc -O2 -DHAVE_CONFIG_H -I. -w -o flex $SRCS scan.c -lm
  gcc -O2 -DHAVE_CONFIG_H -I. -w -c libmain.c libyywrap.c && ar rcs libfl.a libmain.o libyywrap.o
  install -m755 flex $P/bin/flex && ln -sf flex $P/bin/lex && cp libfl.a $P/lib/ && cp FlexLexer.h $P/include/'

step yosys  "cd $SRC/yosys && git submodule update --init --depth 1 && $CM -S . -B build -DYOSYS_ENABLE_UNIT_TESTS=OFF -DYOSYS_WITHOUT_SLANG=ON -DYOSYS_WITHOUT_TCL=ON -DFLEX_EXECUTABLE=$P/bin/flex -DFLEX_INCLUDE_DIR=$P/include && cmake --build build -j$J && cmake --install build"
step tcl    "cd $S/tcl/unix && ./configure --prefix=$P --enable-shared --enable-threads && make -j$J && make install && ln -sf tclsh8.6 $P/bin/tclsh"
step pcre2  "$CM -S $S/pcre2 -B $S/pcre2/b -DPCRE2_BUILD_TESTS=OFF -DPCRE2_BUILD_PCRE2GREP=OFF && cmake --build $S/pcre2/b -j$J && cmake --install $S/pcre2/b"
step swig   "cd $S/swig && ./autogen.sh && ./configure --prefix=$P --with-pcre2-prefix=$P --without-alllang --with-tcl=$P/lib && make -j$J && make install"
step eigen  "$CM -S $S/eigen -B $S/eigen/b -DBUILD_TESTING=OFF -DEIGEN_BUILD_DOC=OFF && cmake --install $S/eigen/b"
# git checkout gives all files one mtime; re-touch generated autotools files in order
step cudd   "cd $S/cudd && touch aclocal.m4 && sleep 1 && touch configure Makefile.in config.h.in && ./configure --prefix=$P CFLAGS='-O2 -fPIC' CXXFLAGS='-O2 -fPIC' && make -j$J && make install"
# OpenSTA's configure requires GTest
step gtest  "$CM -S $S/googletest -B $S/googletest/b && cmake --build $S/googletest/b -j$J && cmake --install $S/googletest/b"
step opensta "cd $SRC/OpenROAD && git submodule update --init --depth 1 src/sta && $CM -S src/sta -B $S/sta_build -DCUDD_DIR=$P -DTCL_LIBRARY=$P/lib/libtcl8.6.so -DTCL_INCLUDE_PATH=$P/include -DTCL_HEADER=$P/include/tcl.h -DFLEX_EXECUTABLE=$P/bin/flex -DFLEX_INCLUDE_DIR=$P/include -DSWIG_EXECUTABLE=$P/bin/swig && cmake --build $S/sta_build -j$J && install -m755 $S/sta_build/sta $P/bin/sta"
step spdlog "$CM -S $S/spdlog -B $S/spdlog/b -DSPDLOG_BUILD_EXAMPLE=OFF -DSPDLOG_BUILD_TESTS=OFF && cmake --build $S/spdlog/b -j$J && cmake --install $S/spdlog/b"
step yamlcpp "$CM -S $S/yaml-cpp -B $S/yaml-cpp/b -DYAML_CPP_BUILD_TESTS=OFF -DYAML_CPP_BUILD_TOOLS=OFF -DYAML_BUILD_SHARED_LIBS=ON && cmake --build $S/yaml-cpp/b -j$J && cmake --install $S/yaml-cpp/b"
step lemon  "$CM -S $S/lemon -B $S/lemon/b -DLEMON_ENABLE_GLPK=OFF -DLEMON_ENABLE_COIN=OFF -DLEMON_ENABLE_ILOG=OFF -DLEMON_ENABLE_SOPLEX=OFF && cmake --build $S/lemon/b -j$J && cmake --install $S/lemon/b"
step boost  "cd $S/boost && ./bootstrap.sh --prefix=$P --with-libraries=iostreams,serialization,thread,system,filesystem,program_options,regex,chrono,atomic,date_time,container,json && ./b2 -j$J --prefix=$P link=shared,static variant=release cxxflags=-fPIC install"
step abseil "$CM -S $S/abseil -B $S/abseil/b -DCMAKE_CXX_STANDARD=17 -DABSL_PROPAGATE_CXX_STD=ON -DABSL_BUILD_TESTING=OFF -DBUILD_SHARED_LIBS=OFF && cmake --build $S/abseil/b -j$J && cmake --install $S/abseil/b"
# OpenROAD needs only GLOP/CP-SAT (+SCIP in the partitioner, unused by this flow).
# or-tools 9.14 always compiles its Gurobi interface (Gurobi is dlopen()ed at run
# time, not needed to build), and that interface needs BUILD_MATH_OPT=ON.
step ortools "$CM -S $S/or-tools -B $S/or-tools/b -DCMAKE_CXX_STANDARD=17 -DBUILD_DEPS=OFF -DBUILD_Protobuf=ON -DBUILD_re2=ON -DBUILD_absl=OFF -DBUILD_Eigen3=OFF -DBUILD_ZLIB=OFF -DBUILD_BZip2=OFF -DUSE_SCIP=OFF -DUSE_HIGHS=OFF -DUSE_COINOR=OFF -DUSE_GLPK=OFF -DUSE_PDLP=OFF -DUSE_GUROBI=ON -DUSE_CPLEX=OFF -DUSE_XPRESS=OFF -DBUILD_SAMPLES=OFF -DBUILD_EXAMPLES=OFF -DBUILD_FLATZINC=OFF -DBUILD_MATH_OPT=ON -DBUILD_TESTING=OFF -DUSE_fuzztest=OFF -DBUILD_SHARED_LIBS=ON && cmake --build $S/or-tools/b -j$J && cmake --install $S/or-tools/b"
# OpenROAD @8c65de5: src/gui/CMakeLists.txt requires OpenGL even with BUILD_GUI=OFF
# (OpenGL is only linked in the Qt branch) -> made optional for headless hosts.
# ENABLE_TESTS=ON is needed for the build_and_test target that src/stt/test
# references unconditionally; only the `openroad` target is built.
step openroad "cd $SRC/OpenROAD && git submodule update --init --depth 1 src/sta third-party/abc && git submodule update --init --recursive --depth 1 third-party/sv-elab && sed -i 's/^find_package(OpenGL REQUIRED)/find_package(OpenGL)/' src/gui/CMakeLists.txt && $CM -S . -B build -DENABLE_TESTS=ON -DBUILD_GUI=OFF -DBUILD_PYTHON=OFF -DBUILD_TCLX=OFF -DLINK_TIME_OPTIMIZATION=OFF -DTCL_LIBRARY=$P/lib/libtcl8.6.so -DTCL_INCLUDE_PATH=$P/include -DTCL_HEADER=$P/include/tcl.h -Dcudd_ROOT=$P -DCUDD_LIB=$P/lib/libcudd.a -DCUDD_INCLUDE=$P/include -DSWIG_EXECUTABLE=$P/bin/swig -DFLEX_EXECUTABLE=$P/bin/flex -DFLEX_INCLUDE_DIR=$P/include -DBoost_ROOT=$P && cmake --build build --target openroad -j$J && install -m755 build/bin/openroad $P/bin/openroad"
# KLayout without Qt still uses qmake as its build driver; Qt 5.15 configure builds qmake first
step qmake  "cd $SRC/qtbase && (./configure -opensource -confirm-license -release -prefix $P/qt5 -nomake examples -nomake tests -no-gui -no-widgets -no-opengl -no-dbus -no-icu -qt-pcre -qt-zlib -no-feature-sql || true) && test -x bin/qmake && bin/qmake -v"
RB=${RUBY_PREFIX:-/opt/ruby-3.3.6}
# -libexpat is REQUIRED for a Qt-less build: without Qt and without expat the XML
# parser is compiled as stubs (tl_assert(false) in tlXMLParser.cc), so
# Technology.load (.lyt) fails and DEF->GDS stream-out cannot run. Needs libexpat
# headers (e.g. libexpat1-dev). The recorded run hit exactly this
# (build/<tag>_attempt1/logs/8_gds.log) and was rebuilt with -libexpat.
step klayout "cd $SRC/klayout && ./build.sh -without-qt -nolibgit2 -libexpat -qmake $SRC/qtbase/bin/qmake -nopython -rbinc $RB/include/ruby-3.3.0 -rbinc2 $RB/include/ruby-3.3.0/x86_64-linux -rblib $RB/lib/libruby.so -rbvers 30306 -release -j$J -prefix $P/klayout -bin $P/klayout -build $SRC/klayout-build"
# help2man is only needed for man pages; a stub is used when it is not installed
# (the recorded run failed at `make install` without it, see /opt/eda/logs/verilator.log).
if ! command -v help2man >/dev/null; then
  mkdir -p $P/shim
  printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && { shift; : > "$1"; }; shift; done\n' > $P/shim/help2man
  chmod +x $P/shim/help2man; export PATH=$P/shim:$PATH
fi
step verilator "cd $SRC/verilator && autoconf && ./configure --prefix=$P CPPFLAGS=-I$P/include && make -j$J && make install"
# ---- second sign-off (Magic DRC/extraction, Netgen LVS) + zstd for the PDK archives ----
step zstd   "make -C $S/zstd/programs -j$J zstd && install -m755 $S/zstd/programs/zstd $P/bin/zstd"
# Tk needs X11 headers (e.g. libx11-dev); Magic builds its Tcl interface only with Tk.
step tk     "cd $S/tk/unix && ./configure --prefix=$P --with-tcl=$P/lib --enable-shared && make -j$J && make install"
step magic  "cd $SRC/magic && sed -i 's@\`git rev-parse HEAD\`@8.3.623@' scripts/defs.mak.in && ./configure --prefix=$P --with-tcl=$P/lib --with-tk=$P/lib --without-opengl --without-cairo CFLAGS='-O2 -Wno-implicit-function-declaration -Wno-parentheses' && make -j$J && make install"
# netgen's configure finds tclConfig.sh but does not add its include dir to CPPFLAGS
step netgen "cd $SRC/netgen && ./configure --prefix=$P --with-tcl=$P/lib --with-tk=$P/lib CFLAGS='-O2 -Wno-implicit-function-declaration -Wno-parentheses' && sed -i 's@^CPPFLAGS *= -I. -I\${NETGENDIR} *\$@& -I$P/include@' defs.mak && make -j$J && make install"
echo "toolchain ready in $P (add $P/bin to PATH)"
