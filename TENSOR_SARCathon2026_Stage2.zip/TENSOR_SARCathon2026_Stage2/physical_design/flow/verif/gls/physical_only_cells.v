// Empty models for physical-only Sky130 HD cells that appear in the routed
// netlist (OpenROAD write_verilog) but have no logic and no liberty `function`:
// fill and well-tap cells. They have no signal pins (power pins are not written
// without -include_pwr_gnd), so an empty module is an exact model.
// Used only by `make gls-post`.
module sky130_fd_sc_hd__fill_1 (); endmodule
module sky130_fd_sc_hd__fill_2 (); endmodule
module sky130_fd_sc_hd__fill_4 (); endmodule
module sky130_fd_sc_hd__fill_8 (); endmodule
module sky130_fd_sc_hd__tapvpwrvgnd_1 (); endmodule
