#!/usr/bin/env python3
"""Derive the gate-level-simulation bench from the Stage 1 v4 arbiter bench.

    python3 verif/gls/make_gls_tb.py <stage1_v4>/tb/arb/tb_arb.sv verif/gls/tb_arb_gls.sv

Every edit is an exact, asserted text replacement (the script fails if the
Stage 1 file changes), and every edit is guarded by `ifdef GLS, so the output
file still compiles to the original bench without +define+GLS.
Edits:
  1. DUT instantiated without parameter overrides (the netlist has none; the
     bench's values equal the synthesised defaults 512/256/256/4/32).
  2. White-box taps of the arbiter output (dut.a_*) -> constant 0 under GLS.
  3. u_mon  -> gls_egress_grant_counter (grants counted at the egress port).
  4. u_safe -> gls_null_checker (needs link internals).
  5. dut.u_arb.locked: the mid-packet reset trigger waits for both sources to
     be valid (instead of "arbiter locked"); the post-reset check keeps only
     the external part (m_axis_tvalid == 0).
  6. Fairness-timing comparisons on max_wait / max_other are skipped under GLS.
  7. $dumpvars of dut.u_arb removed under GLS; banner marks GLS runs.
"""
import sys

src, dst = sys.argv[1], sys.argv[2]
t = open(src).read()


def rep(old, new, count=1):
    global t
    n = t.count(old)
    if n != count:
        sys.exit("pattern found %d times (expected %d):\n%s" % (n, count, old))
    t = t.replace(old, new)


# 1. DUT parameters
rep("""    axis_pcie_link_mux2_top #(.AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .LANES(LANES),
                              .RX_BUF_DEPTH(DEPTH), .AXIL_ADDR_W(8)) dut (""",
"""`ifdef GLS
    axis_pcie_link_mux2_top dut (     // gate-level netlist: parameters fixed at synthesis
`else
    axis_pcie_link_mux2_top #(.AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .LANES(LANES),
                              .RX_BUF_DEPTH(DEPTH), .AXIL_ADDR_W(8)) dut (
`endif""")

# 2. white-box taps
rep("""    wire [AXIS_W-1:0] a_tdata = dut.a_tdata;
    wire [KB-1:0]     a_tkeep = dut.a_tkeep;
    wire a_tlast = dut.a_tlast, a_tid = dut.a_tid, a_tvalid = dut.a_tvalid, a_tready = dut.a_tready;""",
"""`ifdef GLS
    // GLS: the arbiter output is internal to the flattened netlist (not observable)
    wire [AXIS_W-1:0] a_tdata = '0;
    wire [KB-1:0]     a_tkeep = '0;
    wire a_tlast = 1'b0, a_tid = 1'b0, a_tvalid = 1'b0, a_tready = 1'b0;
`else
    wire [AXIS_W-1:0] a_tdata = dut.a_tdata;
    wire [KB-1:0]     a_tkeep = dut.a_tkeep;
    wire a_tlast = dut.a_tlast, a_tid = dut.a_tid, a_tvalid = dut.a_tvalid, a_tready = dut.a_tready;
`endif""")

# 3. fairness monitor
rep("""    arb_fairness_monitor #(.DATA_W(AXIS_W)) u_mon (.clk(clk), .rst_n(rst_n),""",
"""`ifdef GLS
    gls_egress_grant_counter u_mon (.clk(clk), .rst_n(rst_n), .m_tvalid(m_tvalid), .m_tready(m_tready),
        .m_tlast(m_tlast), .m_tid(m_tid));
`else
    arb_fairness_monitor #(.DATA_W(AXIS_W)) u_mon (.clk(clk), .rst_n(rst_n),""")
rep("""        .a_tvalid(a_tvalid), .a_tready(a_tready));

    link_safety_checker""",
"""        .a_tvalid(a_tvalid), .a_tready(a_tready));
`endif

`ifdef GLS
    gls_null_checker u_safe ();
`else
    link_safety_checker""")
# 4. close the safety-checker guard
rep("""        .rxbuf_count(8'(dut.u_link.u_rxbuf.count)));""",
"""        .rxbuf_count(8'(dut.u_link.u_rxbuf.count)));
`endif""")

# 5. arbiter-locked probes
rep("""                        hit = (cycle - t0 > 300) && s0_tvalid && s1_tvalid && dut.u_arb.locked;""",
"""`ifdef GLS
                        hit = (cycle - t0 > 300) && s0_tvalid && s1_tvalid;
`else
                        hit = (cycle - t0 > 300) && s0_tvalid && s1_tvalid && dut.u_arb.locked;
`endif""")
rep("""            if (dut.u_arb.locked !== 1'b0 || m_tvalid !== 1'b0) tb_fail("arbiter/link not idle after reset");""",
"""`ifdef GLS
            if (m_tvalid !== 1'b0) tb_fail("link not idle after reset");
`else
            if (dut.u_arb.locked !== 1'b0 || m_tvalid !== 1'b0) tb_fail("arbiter/link not idle after reset");
`endif""")

# 6. fairness-timing comparisons (max_wait / max_other)
for old in [
    """            if (u_mon.max_other[0] > 1 || u_mon.max_other[1] > 1) tb_fail("alternation broken");\n""",
    """            if (u_mon.max_other[0] > 1 || u_mon.max_other[1] > 1) tb_fail("starvation bound violated");\n""",
    """            if (u_mon.max_other[1] > 1) tb_fail("sparse source passed by more than one packet");\n""",
]:
    n = t.count(old)
    if n == 0:
        sys.exit("pattern not found:\n" + old)
    t = t.replace(old, "`ifndef GLS\n" + old + "`endif\n")
for old in [
    """            if (u_mon.max_wait[1] > bound) begin
                $sformat(m, "64 B source waited %0d cycles, bound one 4096 B packet = %0d", u_mon.max_wait[1], bound); tb_fail(m); end
""",
    """            if (u_mon.max_wait[1] > bound) begin
                $sformat(m, "sparse source waited %0d cycles, bound %0d", u_mon.max_wait[1], bound); tb_fail(m); end
""",
]:
    rep(old, "`ifndef GLS\n" + old + "`endif\n")

# 7. waves + banner
rep("""            $dumpvars(1, tb_arb); $dumpvars(1, dut); $dumpvars(1, dut.u_arb);""",
"""`ifdef GLS
            $dumpvars(1, tb_arb); $dumpvars(1, dut);
`else
            $dumpvars(1, tb_arb); $dumpvars(1, dut); $dumpvars(1, dut.u_arb);
`endif""")
rep("""        $display(" tb_arb : axis_pcie_link_mux2_top (2 sources, round-robin arbiter)  seed=%0d test=%0s",""",
"""`ifdef GLS
        $display(" tb_arb [GLS: synthesised Sky130 netlist, zero-delay; fairness-timing checks not evaluated]");
`endif
        $display(" tb_arb : axis_pcie_link_mux2_top (2 sources, round-robin arbiter)  seed=%0d test=%0s",""")

hdr = ("// GENERATED by verif/gls/make_gls_tb.py from Stage 1 v4 tb/arb/tb_arb.sv - do not edit.\n"
       "// Compile with +define+GLS for gate-level simulation; without it this is the original bench.\n")
open(dst, "w").write(hdr + t)
print("wrote", dst)
