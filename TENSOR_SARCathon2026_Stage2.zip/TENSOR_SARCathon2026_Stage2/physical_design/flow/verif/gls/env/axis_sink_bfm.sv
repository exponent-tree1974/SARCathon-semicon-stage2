`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// axis_sink_bfm - AXI4-Stream slave tready generator (egress backpressure)
//   ready_pct   : probability (%) that tready is high in a cycle (100 = always)
//   burst_mode  : 1 -> tready alternates between random-length ON/OFF bursts
//                 (OFF bursts 1..max_off cycles) instead of per-cycle coin flips
// tready is updated at the negedge so it is stable around the posedge.
// The sink draws from its OWN random stream (seed `rng`, set per test), so its
// stall pattern does not depend on other processes' use of $urandom: a test
// behaves identically whether it runs alone (+test=) or inside the full suite.
// -----------------------------------------------------------------------------
module axis_sink_bfm #(
    parameter NAME = "axis_sink"
) (
    input  wire  clk,
    input  wire  rst_n,
    output logic tready
);
    integer ready_pct  = 100;
    integer burst_mode = 0;
    integer max_off    = 40;
    integer burst_left = 0;
    reg     burst_on   = 1'b1;
    integer rng        = 1;

    function automatic integer rnd100();
        rnd100 = $unsigned($random(rng)) % 100;
    endfunction
    function automatic integer rndn(input integer n);
        rndn = $unsigned($random(rng)) % n;
    endfunction

    initial tready = 1'b0;

    always @(negedge clk) begin
        if (burst_mode != 0) begin
            if (burst_left <= 0) begin
                burst_on   = rnd100() < ready_pct;
                burst_left = burst_on ? 1 + rndn(64) : 1 + rndn(max_off);
            end
            burst_left = burst_left - 1;
            tready <= burst_on;
        end else begin
            tready <= (rnd100() < ready_pct);
        end
    end
endmodule
