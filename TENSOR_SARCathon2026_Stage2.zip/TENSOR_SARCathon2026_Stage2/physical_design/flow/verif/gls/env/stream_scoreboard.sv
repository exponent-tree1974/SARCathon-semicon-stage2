`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// stream_scoreboard - per-stream (tid) end-to-end checker for tb_arb
//
//  * add_packet(src, len): creates a packet for source src (random bytes,
//    unique 32-bit tag in bytes 0..3 encoding source and index).
//  * Egress: each received packet (m_axis_tid = t) is compared with stream t:
//      allow_loss = 0 : it must be exactly the next expected packet of stream t
//                       (bytes, length, tuser = 0)                -> no loss
//      allow_loss = 1 : it must be packet q >= next of stream t:
//                       tuser = 0 -> exact copy of packet q
//                       tuser = 1 -> a prefix of packet q made of whole FIU
//                                    payloads (k * 224 B, shorter than q)
//                       packets between next and q count as lost
//    In both modes: no packet of a stream is delivered twice or out of order,
//    and nothing is delivered that was not sent (tag lookup), which is the
//    end-to-end "no output without valid input / no reordering" property per
//    stream.
//  * Byte outside tkeep must be 0; tid constant within a packet.
// -----------------------------------------------------------------------------
module stream_scoreboard #(
    parameter int AXIS_W  = 512,
    parameter int PAYLOAD = 224,
    parameter int MAXP    = 8192,
    parameter int MEMSZ   = 1 << 22
) (
    input wire                 clk,
    input wire                 rst_n,
    input wire [AXIS_W-1:0]    m_tdata,
    input wire [AXIS_W/8-1:0]  m_tkeep,
    input wire                 m_tlast,
    input wire                 m_tuser,
    input wire                 m_tid,
    input wire                 m_tvalid,
    input wire                 m_tready
);
    localparam int KB = AXIS_W / 8;

    reg [7:0] mem [0:MEMSZ-1];
    integer   pk_off [0:1][0:MAXP-1];
    integer   pk_len [0:1][0:MAXP-1];
    integer   n [0:1], nxt [0:1];
    integer   mem_ptr = 0;
    integer   tag_base = 0;
    reg       allow_loss = 1'b0;

    // results
    integer errors = 0, delivered [0:1], truncated [0:1], lost [0:1], bytes_out [0:1], bytes_in [0:1];
    integer max_print = 25;

    // egress collection
    reg [7:0] rx [0:65535];
    integer   rx_len = 0;
    reg       rx_open = 1'b0, rx_tid;
    integer   k, b, q, j, L;
    reg       match;
    reg [8*140-1:0] msg;

    task automatic err(input [8*140-1:0] m);
        begin errors = errors + 1; if (errors <= max_print) $display("[ERROR] %0t stream_sb: %0s", $time, m); end
    endtask

    task automatic clear();
        begin
            n[0] = 0; n[1] = 0; nxt[0] = 0; nxt[1] = 0; mem_ptr = 0; rx_len = 0; rx_open = 0;
            delivered[0] = 0; delivered[1] = 0; truncated[0] = 0; truncated[1] = 0;
            lost[0] = 0; lost[1] = 0; bytes_out[0] = 0; bytes_out[1] = 0; bytes_in[0] = 0; bytes_in[1] = 0;
        end
    endtask
    initial clear();

    task automatic add_packet(input integer src, input integer len, output integer idx);
        integer t;
        begin
            if (len < 4) len = 4;
            idx = n[src];
            if (idx >= MAXP || mem_ptr + len >= MEMSZ) $fatal(1, "stream_sb: database full");
            pk_off[src][idx] = mem_ptr; pk_len[src][idx] = len;
            for (t = 0; t < len; t = t + 1) mem[mem_ptr + t] = $urandom;
            t = tag_base | (src << 16) | idx;
            for (b = 0; b < 4; b = b + 1) mem[mem_ptr + b] = t >> (8*b);
            mem_ptr = mem_ptr + len;
            n[src] = n[src] + 1;
            bytes_in[src] = bytes_in[src] + len;
        end
    endtask

    function automatic integer outstanding();
        outstanding = (n[0] - nxt[0]) + (n[1] - nxt[1]);
    endfunction

    function automatic bit same(input integer src, input integer p, input integer cnt);
        integer t;
        begin
            same = 1;
            for (t = 0; t < cnt; t = t + 1) if (rx[t] !== mem[pk_off[src][p] + t]) same = 0;
        end
    endfunction

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            rx_len = 0; rx_open = 0;
        end else if (m_tvalid === 1'b1 && m_tready === 1'b1) begin
            if (!rx_open) begin rx_open = 1; rx_tid = m_tid; end
            else if (m_tid !== rx_tid) err("tid changed inside a packet");
            for (b = 0; b < KB; b = b + 1) begin
                if (m_tkeep[b]) begin rx[rx_len] = m_tdata[b*8 +: 8]; rx_len = rx_len + 1; end
                else if (m_tdata[b*8 +: 8] !== 8'h00) err("data byte outside tkeep not zero");
            end
            if (m_tlast === 1'b1) begin
                // find the matching packet of stream rx_tid
                q = -1;
                for (j = nxt[rx_tid]; j < n[rx_tid] && q < 0; j = j + 1)
                    if (same(rx_tid, j, 4)) q = j;
                if (q < 0) begin
                    // reorder / duplicate / wrong stream / invented?
                    match = 0;
                    for (j = 0; j < nxt[rx_tid] && !match; j = j + 1) if (same(rx_tid, j, 4)) match = 1;
                    if (match) $sformat(msg, "stream %0d: packet tag %02h%02h%02h%02h delivered again or out of order (next expected #%0d)",
                                        rx_tid, rx[3], rx[2], rx[1], rx[0], nxt[rx_tid]);
                    else begin
                        for (j = 0; j < n[!rx_tid] && !match; j = j + 1) if (same(!rx_tid, j, 4)) match = 1;
                        if (match) $sformat(msg, "stream %0d: packet of stream %0d delivered with the wrong tid", rx_tid, !rx_tid);
                    end
                    if (!match)
                        $sformat(msg, "stream %0d: packet tag %02h%02h%02h%02h was never sent", rx_tid, rx[3], rx[2], rx[1], rx[0]);
                    err(msg);
                end else begin
                    L = pk_len[rx_tid][q];
                    if (q != nxt[rx_tid] && !allow_loss) begin
                        $sformat(msg, "stream %0d: expected packet #%0d, received #%0d (loss without errors)", rx_tid, nxt[rx_tid], q);
                        err(msg);
                    end
                    if (m_tuser !== 1'b1) begin
                        if (rx_len != L || !same(rx_tid, q, L)) begin
                            $sformat(msg, "stream %0d packet #%0d: %0d bytes received, %0d sent, or data differs", rx_tid, q, rx_len, L);
                            err(msg);
                        end
                    end else begin
                        if (!allow_loss) begin
                            $sformat(msg, "stream %0d packet #%0d: tuser=1 without injected errors", rx_tid, q); err(msg);
                        end else if (rx_len == 0 || (rx_len % PAYLOAD) != 0 || rx_len >= L || !same(rx_tid, q, rx_len)) begin
                            $sformat(msg, "stream %0d packet #%0d: truncated packet of %0d bytes is not a whole-FIU prefix of %0d bytes",
                                     rx_tid, q, rx_len, L);
                            err(msg);
                        end
                        truncated[rx_tid] = truncated[rx_tid] + 1;
                    end
                    lost[rx_tid] = lost[rx_tid] + (q - nxt[rx_tid]);
                    nxt[rx_tid] = q + 1;
                    delivered[rx_tid] = delivered[rx_tid] + 1;
                    bytes_out[rx_tid] = bytes_out[rx_tid] + rx_len;
                end
                rx_len = 0; rx_open = 0;
            end
        end
    end
endmodule
