`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// axil_protocol_checker - AXI4-Lite slave-side rules (DUT = slave)
//   L1  no X/Z on awready/wready/bvalid/arready/rvalid out of reset
//   L2  bvalid && !bready -> bvalid and bresp held next cycle
//   L3  rvalid && !rready -> rvalid, rdata, rresp held next cycle
//   L4  a B response only after both an AW and a W handshake are outstanding
//   L5  an R response only after an AR handshake is outstanding
//   L6  bvalid / rvalid low during reset
// Concurrent SVA versions of L2/L3 under `ifdef SVA.
// -----------------------------------------------------------------------------
module axil_protocol_checker #(
    parameter NAME = "axil"
) (
    input wire        clk,
    input wire        rst_n,
    input wire        awvalid, awready,
    input wire        wvalid,  wready,
    input wire        bvalid,  bready,
    input wire [1:0]  bresp,
    input wire        arvalid, arready,
    input wire        rvalid,  rready,
    input wire [31:0] rdata,
    input wire [1:0]  rresp
);
    integer errors = 0;
    integer aw_cnt = 0, w_cnt = 0, b_cnt = 0, ar_cnt = 0, r_cnt = 0;
    reg p_bstall = 0, p_rstall = 0;
    reg [1:0]  p_bresp, p_rresp;
    reg [31:0] p_rdata;

    task automatic err(input [8*80-1:0] msg);
        begin
            errors = errors + 1;
            if (errors <= 20) $display("[ERROR] %0t %0s: %0s", $time, NAME, msg);
        end
    endtask

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            if (bvalid !== 1'b0 || rvalid !== 1'b0) err("L6 bvalid/rvalid not low in reset");
            aw_cnt = 0; w_cnt = 0; b_cnt = 0; ar_cnt = 0; r_cnt = 0;
            p_bstall <= 0; p_rstall <= 0;
        end else begin
            if ((^{awready, wready, bvalid, arready, rvalid}) === 1'bx) err("L1 X/Z on AXI-Lite handshake output");
            if (p_bstall && (bvalid !== 1'b1 || bresp !== p_bresp)) err("L2 B channel changed while stalled");
            if (p_rstall && (rvalid !== 1'b1 || rdata !== p_rdata || rresp !== p_rresp))
                err("L3 R channel changed while stalled");
            if (awvalid && awready) aw_cnt = aw_cnt + 1;
            if (wvalid && wready)   w_cnt  = w_cnt + 1;
            if (arvalid && arready) ar_cnt = ar_cnt + 1;
            if (bvalid && bready) begin
                b_cnt = b_cnt + 1;
                if (b_cnt > aw_cnt || b_cnt > w_cnt) err("L4 B response without AW+W");
            end
            if (rvalid && rready) begin
                r_cnt = r_cnt + 1;
                if (r_cnt > ar_cnt) err("L5 R response without AR");
            end
            p_bstall <= bvalid && !bready;  p_bresp <= bresp;
            p_rstall <= rvalid && !rready;  p_rdata <= rdata; p_rresp <= rresp;
        end
    end

`ifdef SVA
    a_b_hold: assert property (@(posedge clk) disable iff (!rst_n)
        (bvalid && !bready) |=> (bvalid && $stable(bresp))) else err("[SVA] L2 B channel changed while stalled");
    a_r_hold: assert property (@(posedge clk) disable iff (!rst_n)
        (rvalid && !rready) |=> (rvalid && $stable(rdata) && $stable(rresp))) else err("[SVA] L3 R channel changed while stalled");
`endif
endmodule
