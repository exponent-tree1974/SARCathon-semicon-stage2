`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// axis_source_bfm - AXI4-Stream master driver (ingress stimulus)
//
// Timing contract: send_beat() is called at a negedge and returns at the negedge
// after the handshake, leaving tvalid HIGH so consecutive calls produce
// back-to-back beats. Call idle() to drop tvalid.
//   gap_pct       : probability (%) of inserting an idle cycle before a beat
//   stall_timeout : cycles to wait for tready before declaring a stall error
//   abort         : set by the test (e.g. reset); pending/future beats return
// -----------------------------------------------------------------------------
module axis_source_bfm #(
    parameter int DATA_W = 512,
    parameter     NAME   = "axis_src"
) (
    input  wire                   clk,
    input  wire                   rst_n,
    output logic [DATA_W-1:0]     tdata,
    output logic [DATA_W/8-1:0]   tkeep,
    output logic                  tlast,
    output logic                  tvalid,
    input  wire                   tready
);
    integer gap_pct       = 0;
    integer stall_timeout = 20000;
    reg     abort         = 1'b0;
    integer errors        = 0;
    integer beats_sent    = 0;
    integer idles_inserted = 0;

    initial begin
        tdata = '0; tkeep = '0; tlast = 1'b0; tvalid = 1'b0;
    end

    function automatic [DATA_W-1:0] rand_data();
        integer i;
        begin
            for (i = 0; i < DATA_W/32; i = i + 1) rand_data[i*32 +: 32] = $urandom;
        end
    endfunction

    task automatic idle();
        begin
            tvalid = 1'b0; tlast = 1'b0; tkeep = '0;
        end
    endtask

    task automatic send_beat(input [DATA_W-1:0] d, input [DATA_W/8-1:0] k, input l,
                             output reg ok);
        integer n;
        begin
            ok = 1'b0;
            if (abort) begin
                idle();
            end else begin
                while (gap_pct > 0 && ($urandom % 100) < gap_pct && !abort) begin
                    tvalid = 1'b0; tdata = rand_data(); tkeep = $urandom; tlast = $urandom;
                    @(negedge clk);
                    idles_inserted = idles_inserted + 1;
                end
                tdata = d; tkeep = k; tlast = l; tvalid = 1'b1;
                n = 0;
                do begin
                    @(posedge clk);
                    n = n + 1;
                end while (!(rst_n === 1'b1 && tready === 1'b1) && !abort && n < stall_timeout);
                if (!abort && n >= stall_timeout) begin
                    errors = errors + 1;
                    $display("[ERROR] %0t %0s: tready stuck low for %0d cycles (driver stall timeout)",
                             $time, NAME, stall_timeout);
                    abort = 1'b1;
                end else if (!abort) begin
                    ok = 1'b1;
                    beats_sent = beats_sent + 1;
                end
                @(negedge clk);
                if (abort) idle();
            end
        end
    endtask
endmodule
