`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// axil_master_bfm - AXI4-Lite master with selectable AW/W ordering
//   write(addr, data, strb, order, resp)  order: 0 = AW and W together
//                                                1 = AW first, W 1..3 cycles later
//                                                2 = W first, AW 1..3 cycles later
//   read(addr, data, resp)
//   Each handshake wait is bounded by `timeout` cycles (error + abort on expiry).
//   bready/rready are asserted with a random 0..2 cycle delay.
// -----------------------------------------------------------------------------
module axil_master_bfm #(
    parameter int ADDR_W = 8,
    parameter     NAME   = "axil_master"
) (
    input  wire               clk,
    input  wire               rst_n,
    output reg  [ADDR_W-1:0]  awaddr,
    output reg                awvalid,
    input  wire               awready,
    output reg  [31:0]        wdata,
    output reg  [3:0]         wstrb,
    output reg                wvalid,
    input  wire               wready,
    input  wire [1:0]         bresp,
    input  wire               bvalid,
    output reg                bready,
    output reg  [ADDR_W-1:0]  araddr,
    output reg                arvalid,
    input  wire               arready,
    input  wire [31:0]        rdata,
    input  wire [1:0]         rresp,
    input  wire               rvalid,
    output reg                rready
);
    integer timeout = 1000;
    integer errors  = 0;
    integer writes  = 0, reads = 0;
    // order statistics (read by coverage)
    integer n_order [0:2];

    initial begin
        awaddr = 0; awvalid = 0; wdata = 0; wstrb = 0; wvalid = 0; bready = 0;
        araddr = 0; arvalid = 0; rready = 0;
        n_order[0] = 0; n_order[1] = 0; n_order[2] = 0;
    end

    task automatic tmo(input [8*32-1:0] what);
        begin
            errors = errors + 1;
            $display("[ERROR] %0t %0s: timeout waiting for %0s", $time, NAME, what);
        end
    endtask

    task automatic do_aw(input [ADDR_W-1:0] a);
        integer n;
        begin
            @(negedge clk); awaddr = a; awvalid = 1'b1; n = 0;
            do begin @(posedge clk); n = n + 1; end while (awready !== 1'b1 && n < timeout);
            if (n >= timeout) tmo("awready");
            @(negedge clk); awvalid = 1'b0;
        end
    endtask

    task automatic do_w(input [31:0] d, input [3:0] s);
        integer n;
        begin
            @(negedge clk); wdata = d; wstrb = s; wvalid = 1'b1; n = 0;
            do begin @(posedge clk); n = n + 1; end while (wready !== 1'b1 && n < timeout);
            if (n >= timeout) tmo("wready");
            @(negedge clk); wvalid = 1'b0;
        end
    endtask

    task automatic write(input [ADDR_W-1:0] addr, input [31:0] data, input [3:0] strb,
                         input integer order, output reg [1:0] resp);
        integer n, dly;
        begin
            dly = 1 + ($urandom % 3);
            n_order[order] = n_order[order] + 1;
            case (order)
                1: begin do_aw(addr); repeat (dly) @(negedge clk); do_w(data, strb); end
                2: begin do_w(data, strb); repeat (dly) @(negedge clk); do_aw(addr); end
                default: fork do_aw(addr); do_w(data, strb); join
            endcase
            repeat ($urandom % 3) @(negedge clk);
            bready = 1'b1; n = 0;
            do begin @(posedge clk); n = n + 1; end while (bvalid !== 1'b1 && n < timeout);
            if (n >= timeout) begin tmo("bvalid"); resp = 2'bxx; end
            else resp = bresp;
            @(negedge clk); bready = 1'b0;
            writes = writes + 1;
        end
    endtask

    task automatic read(input [ADDR_W-1:0] addr, output reg [31:0] data, output reg [1:0] resp);
        integer n;
        begin
            @(negedge clk); araddr = addr; arvalid = 1'b1; n = 0;
            do begin @(posedge clk); n = n + 1; end while (arready !== 1'b1 && n < timeout);
            if (n >= timeout) tmo("arready");
            @(negedge clk); arvalid = 1'b0;
            repeat ($urandom % 3) @(negedge clk);
            rready = 1'b1; n = 0;
            do begin @(posedge clk); n = n + 1; end while (rvalid !== 1'b1 && n < timeout);
            if (n >= timeout) begin tmo("rvalid"); data = 32'hxxxx_xxxx; resp = 2'bxx; end
            else begin data = rdata; resp = rresp; end
            @(negedge clk); rready = 1'b0;
            reads = reads + 1;
        end
    endtask
endmodule
