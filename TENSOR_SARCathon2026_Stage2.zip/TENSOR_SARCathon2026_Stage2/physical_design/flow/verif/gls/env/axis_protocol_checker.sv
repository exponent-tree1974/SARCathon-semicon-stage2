`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// axis_protocol_checker - AXI4-Stream interface rules
//
// Always-on immediate checks (work in Icarus, Verilator and commercial tools):
//   R1  no X/Z on tvalid / tready while out of reset
//   R2  tvalid && !tready  ->  next cycle tvalid still 1          (no retraction)
//   R3  tvalid && !tready  ->  next cycle tdata/tkeep/tlast/tuser unchanged
//   R4  DUT_IS_MASTER: tvalid == 0 while reset is asserted
//   R5  DUT_IS_SLAVE : tready == 0 while reset is asserted (no accept in reset)
//   R6  CHECK_KEEP   : on handshake tkeep != 0 and contiguous from bit 0
//   R7  CHECK_KEEP   : non-last beat has tkeep all ones
//   R8  HAS_USER     : tuser only asserted on a tlast beat
//   R9  HAS_TID      : tid unchanged while stalled (part of R3) and constant
//                      from the first to the tlast beat of a packet
// The same rules are also written as concurrent SVA under `ifdef SVA
// (Icarus does not parse concurrent assertions; Verilator --assert does).
// SVA action blocks call err(): failures are counted and reported with the same
// [ERROR] marker, and never terminate the run before the summary.
// -----------------------------------------------------------------------------
module axis_protocol_checker #(
    parameter int DATA_W        = 512,
    parameter     NAME          = "axis",
    parameter bit DUT_IS_MASTER = 1'b1,
    parameter bit CHECK_KEEP    = 1'b0,
    parameter bit HAS_USER      = 1'b0,
    parameter bit HAS_TID       = 1'b0
) (
    input wire                  clk,
    input wire                  rst_n,
    input wire [DATA_W-1:0]     tdata,
    input wire [DATA_W/8-1:0]   tkeep,
    input wire                  tlast,
    input wire                  tuser,
    input wire [7:0]            tid,
    input wire                  tvalid,
    input wire                  tready
);
    localparam int KW = DATA_W/8;
    integer errors = 0;
    integer handshakes = 0;
    integer stall_cycles = 0;
    integer max_print = 20;

    reg              p_stall = 1'b0;
    reg [DATA_W-1:0] p_data;
    reg [KW-1:0]     p_keep;
    reg              p_last, p_user;
    reg [7:0]        p_tid, pkt_tid;
    reg              in_pkt = 1'b0;

    task automatic err(input [8*80-1:0] msg);
        begin
            errors = errors + 1;
            if (errors <= max_print) $display("[ERROR] %0t %0s: %0s", $time, NAME, msg);
        end
    endtask

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            if (DUT_IS_MASTER  && tvalid !== 1'b0) err("R4 tvalid not low during reset");
            if (!DUT_IS_MASTER && tready !== 1'b0) err("R5 tready not low during reset");
            p_stall <= 1'b0;
            in_pkt  <= 1'b0;
        end else begin
            if (tvalid !== 1'b0 && tvalid !== 1'b1) err("R1 tvalid is X/Z");
            if (tready !== 1'b0 && tready !== 1'b1) err("R1 tready is X/Z");
            if (p_stall) begin
                if (tvalid !== 1'b1) err("R2 tvalid retracted before handshake");
                else if (tdata !== p_data || tkeep !== p_keep || tlast !== p_last ||
                         (HAS_USER && tuser !== p_user) || (HAS_TID && tid !== p_tid))
                    err("R3 payload changed while stalled");
            end
            if (tvalid === 1'b1 && tready === 1'b1) begin
                handshakes = handshakes + 1;
                if (CHECK_KEEP) begin
                    if (tkeep == '0)                         err("R6 tkeep all zero on handshake");
                    else if ((tkeep & (tkeep + 1'b1)) != '0) err("R6 tkeep not contiguous from bit 0");
                    if (tlast !== 1'b1 && tkeep !== {KW{1'b1}}) err("R7 partial tkeep on non-last beat");
                end
                if (HAS_USER && tuser === 1'b1 && tlast !== 1'b1) err("R8 tuser on non-last beat");
                if (HAS_TID) begin
                    if (in_pkt && tid !== pkt_tid) err("R9 tid changed inside a packet");
                    if (!in_pkt) pkt_tid <= tid;
                    in_pkt <= (tlast !== 1'b1);
                end
            end
            if (tvalid === 1'b1 && tready !== 1'b1) stall_cycles = stall_cycles + 1;
            p_stall <= (tvalid === 1'b1) && (tready !== 1'b1);
            p_data  <= tdata;
            p_keep  <= tkeep;
            p_last  <= tlast;
            p_user  <= tuser;
            p_tid   <= tid;
        end
    end

`ifdef SVA
    // ---------------- concurrent assertions (Verilator --assert / commercial) ---
    property p_no_retract;
        @(posedge clk) disable iff (!rst_n) (tvalid && !tready) |=> tvalid;
    endproperty
    property p_stable;
        @(posedge clk) disable iff (!rst_n)
            (tvalid && !tready) |=> ($stable(tdata) && $stable(tkeep) && $stable(tlast));
    endproperty
    a_no_retract: assert property (p_no_retract) else err("[SVA] R2 tvalid retracted");
    a_stable:     assert property (p_stable)     else err("[SVA] R3 payload changed while stalled");
    generate if (CHECK_KEEP) begin : g_keep
        a_keep_contig: assert property (@(posedge clk) disable iff (!rst_n)
            (tvalid && tready) |-> (tkeep != '0) && ((tkeep & (tkeep + 1'b1)) == '0))
            else err("[SVA] R6 tkeep not contiguous / zero");
        a_keep_full: assert property (@(posedge clk) disable iff (!rst_n)
            (tvalid && tready && !tlast) |-> (tkeep == {KW{1'b1}}))
            else err("[SVA] R7 partial tkeep on non-last beat");
    end endgenerate
    generate if (HAS_TID) begin : g_tid
        a_tid_stable: assert property (@(posedge clk) disable iff (!rst_n)
            (tvalid && !tready) |=> $stable(tid)) else err("[SVA] R9 tid changed while stalled");
    end endgenerate
    generate if (HAS_USER) begin : g_user
        a_user_last: assert property (@(posedge clk) disable iff (!rst_n)
            (tvalid && tready && tuser) |-> tlast) else err("[SVA] R8 tuser without tlast");
    end endgenerate
    c_backpressure: cover property (@(posedge clk) disable iff (!rst_n) tvalid && !tready);
    c_back_to_back: cover property (@(posedge clk) disable iff (!rst_n)
        (tvalid && tready && tlast) ##1 (tvalid && tready));
`endif
endmodule
