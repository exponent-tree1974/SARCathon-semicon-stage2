`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// link_channel_model - loopback "wire" between tx_sym* and rx_sym* with a
// per-FIU corruption / forgery plan, plus the credit-return delay line.
//
// Plan (indexed by FIU number since reset, set before traffic starts):
//   MODE_NONE        0  untouched
//   MODE_SYM         1  cor_n adjacent-level symbol errors from symbol cor_pos of word cor_word
//   MODE_LANE_WORD   2  every symbol of lane cor_lane in word cor_word: adjacent-level error
//   MODE_LANE_FIU    3  lane cor_lane inverted (level ^ 2) for all words of the FIU ("lane failure")
//   MODE_CRC_FIELD   4  cor_n symbols inside the CRC field of the trailer word
//   MODE_TRAILER_HDR 5  cor_n symbols inside trailer bytes 0..4 (len/flags/seq/magic)
//   MODE_FORGE       6  trailer field rewritten (forge_kind, incl. FK_TID = stream ID) and CRC RE-COMPUTED so the
//                       FIU passes CRC -> exercises header/framing/sequence checks
// Modes 1..5 are expected to be detected by CRC-32 (the reference model assumes so;
// CRC-32 misses a random corruption with probability 2^-32 and runs are seeded/deterministic).
//
// Symbol bus layout (from the RTL spec): lane l = tx_sym[l*LANE_BITS +: LANE_BITS],
// symbol k of a lane = bits [2k+1:2k] = PAM4 level; lane byte j = symbols 4j..4j+3;
// word byte b -> lane b % LANES, lane byte b / LANES; level = {msb, msb^lsb}.
// -----------------------------------------------------------------------------
module link_channel_model #(
    parameter int LINK_W    = 256,
    parameter int LANES     = 4,
    parameter int FIU_WORDS = 8,
    parameter int CH_DLY    = 2,
    parameter int CR_DLY    = 3,
    parameter int MAXFIU    = 16384
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire [LINK_W-1:0]  tx_sym,
    input  wire               tx_valid,
    input  wire               tx_sof,
    output wire [LINK_W-1:0]  rx_sym,
    output wire               rx_valid,
    output wire               rx_sof,
    input  wire [7:0]         credit_from_rx,
    output wire [7:0]         credit_to_tx
);
    localparam int NSYM      = LINK_W / 2;
    localparam int LANE_BITS = LINK_W / LANES;
    localparam int SPL       = LANE_BITS / 2;      // symbols per lane per word
    localparam int LB        = LINK_W / 8;
    localparam int BPL       = LB / LANES;

    localparam int MODE_NONE = 0, MODE_SYM = 1, MODE_LANE_WORD = 2, MODE_LANE_FIU = 3,
                   MODE_CRC_FIELD = 4, MODE_TRAILER_HDR = 5, MODE_FORGE = 6;
    localparam int FK_MAGIC = 1, FK_LEN0 = 2, FK_LENBIG = 3, FK_EOP_CLR = 4, FK_SOP_CLR = 5,
                   FK_SOP_SET = 6, FK_SEQ = 7, FK_ERR_SET = 8, FK_EOP_SET = 9, FK_TID = 10;

    // ---------------- plan --------------------------------------------------------
    reg [3:0] cor_mode  [0:MAXFIU-1];
    integer   cor_word  [0:MAXFIU-1];
    integer   cor_pos   [0:MAXFIU-1];
    integer   cor_n     [0:MAXFIU-1];
    integer   cor_lane  [0:MAXFIU-1];
    integer   forge_kind[0:MAXFIU-1];
    integer   payload_bytes = (FIU_WORDS - 1) * LB;

    // ---------------- statistics (read by tests / coverage) -----------------------
    integer fiu_cnt = 0, words_seen = 0;
    integer n_fiu_mod = 0, n_sym_mod = 0;
    integer n_mode [0:6];
    integer n_lane [0:LANES-1];
    integer n_sym_burst = 0;
    integer n_forge [0:10];
    integer dump_fd = 0;
    reg     dump_en = 1'b0;
    integer log_fd  = 0;

    integer i;
    initial begin
        for (i = 0; i < MAXFIU; i = i + 1) cor_mode[i] = MODE_NONE;
        for (i = 0; i < 7; i = i + 1) n_mode[i] = 0;
        for (i = 0; i < LANES; i = i + 1) n_lane[i] = 0;
        for (i = 0; i < 11; i = i + 1) n_forge[i] = 0;
    end

    task automatic clear_plan();
        integer k;
        begin
            for (k = 0; k < MAXFIU; k = k + 1) cor_mode[k] = MODE_NONE;
        end
    endtask

    task automatic set_plan(input integer f, input integer mode, input integer word,
                            input integer pos, input integer n, input integer lane,
                            input integer fk);
        begin
            if ((mode == MODE_LANE_WORD || mode == MODE_LANE_FIU) && (lane < 0 || lane >= LANES))
                $fatal(1, "link_channel_model: plan for FIU %0d uses lane %0d, but LANES=%0d (test bug)", f, lane, LANES);
            if (f < MAXFIU) begin
                cor_mode[f] = mode; cor_word[f] = word; cor_pos[f] = pos;
                cor_n[f] = n; cor_lane[f] = lane; forge_kind[f] = fk;
            end
        end
    endtask

    // ---------------- independent spec implementation ------------------------------
    function automatic [LINK_W-1:0] decode_word(input [LINK_W-1:0] sym);
        reg [LINK_W-1:0] lanebits;
        integer k, l, j;
        begin
            for (k = 0; k < NSYM; k = k + 1)
                lanebits[2*k +: 2] = {sym[2*k+1], sym[2*k+1] ^ sym[2*k]};
            for (l = 0; l < LANES; l = l + 1)
                for (j = 0; j < BPL; j = j + 1)
                    decode_word[(j*LANES + l)*8 +: 8] = lanebits[l*LANE_BITS + j*8 +: 8];
        end
    endfunction

    function automatic [LINK_W-1:0] encode_word(input [LINK_W-1:0] w);
        reg [LINK_W-1:0] lanebits;
        integer k, l, j;
        begin
            for (l = 0; l < LANES; l = l + 1)
                for (j = 0; j < BPL; j = j + 1)
                    lanebits[l*LANE_BITS + j*8 +: 8] = w[(j*LANES + l)*8 +: 8];
            for (k = 0; k < NSYM; k = k + 1)
                encode_word[2*k +: 2] = {lanebits[2*k+1], lanebits[2*k+1] ^ lanebits[2*k]};
        end
    endfunction

    function automatic [31:0] crc_upd(input [31:0] c_in, input [LINK_W-1:0] d);
        reg [31:0] c;
        integer k;
        begin
            c = c_in;
            for (k = 0; k < LINK_W; k = k + 1)
                c = (c >> 1) ^ (32'hEDB8_8320 & {32{c[0] ^ d[k]}});
            crc_upd = c;
        end
    endfunction

    // symbol index (0..NSYM-1) carrying bit pair s (0..3) of word byte b
    function automatic integer sym_of_byte(input integer b, input integer s);
        begin
            sym_of_byte = (b % LANES) * SPL + (b / LANES) * 4 + s;
        end
    endfunction

    function automatic [1:0] adj(input [1:0] lv);       // adjacent PAM4 level
        adj = (lv == 2'd3) ? 2'd2 : lv + 2'd1;
    endfunction

    // ---------------- datapath ------------------------------------------------------
    reg [LINK_W-1:0] pipe_sym [0:CH_DLY-1];
    reg              pipe_v   [0:CH_DLY-1];
    reg              pipe_sof [0:CH_DLY-1];
    integer cur_fiu = 0, cur_word = 0, mode, k, b, s, p;
    reg [31:0]       crc_acc;
    reg [LINK_W-1:0] sym_tmp, w;
    reg              touched;

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            for (k = 0; k < CH_DLY; k = k + 1) begin pipe_v[k] <= 1'b0; pipe_sof[k] <= 1'b0; end
            fiu_cnt = 0; cur_fiu = 0; cur_word = 0;
        end else begin
            sym_tmp = tx_sym;
            if (tx_valid === 1'b1) begin
                words_seen = words_seen + 1;
                if (dump_en && dump_fd != 0) $fdisplay(dump_fd, "%0d %h", tx_sof, tx_sym);
                if (tx_sof) begin
                    cur_fiu = fiu_cnt; fiu_cnt = fiu_cnt + 1; cur_word = 0; crc_acc = 32'hFFFF_FFFF;
                end else begin
                    cur_word = cur_word + 1;
                end
                mode = (cur_fiu < MAXFIU) ? cor_mode[cur_fiu] : MODE_NONE;
                touched = 1'b0;
                case (mode)
                    MODE_SYM: if (cur_word == cor_word[cur_fiu]) begin
                        for (k = 0; k < cor_n[cur_fiu]; k = k + 1) begin
                            p = (cor_pos[cur_fiu] + k) % NSYM;
                            sym_tmp[2*p +: 2] = adj(sym_tmp[2*p +: 2]);
                            n_sym_mod = n_sym_mod + 1;
                        end
                        touched = 1'b1;
                    end
                    MODE_LANE_WORD: if (cur_word == cor_word[cur_fiu]) begin
                        for (k = 0; k < SPL; k = k + 1) begin
                            p = cor_lane[cur_fiu] * SPL + k;
                            sym_tmp[2*p +: 2] = adj(sym_tmp[2*p +: 2]);
                        end
                        n_sym_mod = n_sym_mod + SPL;
                        touched = 1'b1;
                    end
                    MODE_LANE_FIU: begin
                        for (k = 0; k < SPL; k = k + 1) begin
                            p = cor_lane[cur_fiu] * SPL + k;
                            sym_tmp[2*p+1] = ~sym_tmp[2*p+1];
                        end
                        n_sym_mod = n_sym_mod + SPL;
                        touched = (cur_word == 0);
                    end
                    MODE_CRC_FIELD: if (cur_word == FIU_WORDS - 1) begin
                        for (k = 0; k < cor_n[cur_fiu]; k = k + 1) begin
                            b = LB - 4 + ((cor_pos[cur_fiu] + k) % 4);
                            s = ((cor_pos[cur_fiu] + k) / 4) % 4;
                            p = sym_of_byte(b, s);
                            sym_tmp[2*p +: 2] = adj(sym_tmp[2*p +: 2]);
                            n_sym_mod = n_sym_mod + 1;
                        end
                        touched = 1'b1;
                    end
                    MODE_TRAILER_HDR: if (cur_word == FIU_WORDS - 1) begin
                        for (k = 0; k < cor_n[cur_fiu]; k = k + 1) begin
                            b = (cor_pos[cur_fiu] + k) % 5;
                            s = ((cor_pos[cur_fiu] + k) / 5) % 4;
                            p = sym_of_byte(b, s);
                            sym_tmp[2*p +: 2] = adj(sym_tmp[2*p +: 2]);
                            n_sym_mod = n_sym_mod + 1;
                        end
                        touched = 1'b1;
                    end
                    MODE_FORGE: begin
                        w = decode_word(tx_sym);
                        if (cur_word < FIU_WORDS - 1) begin
                            crc_acc = crc_upd(crc_acc, w);
                        end else begin
                            case (forge_kind[cur_fiu])
                                FK_MAGIC:   w[39:32] = ~w[39:32];
                                FK_LEN0:    w[15:0]  = 16'd0;
                                FK_LENBIG:  w[15:0]  = payload_bytes + 1;
                                FK_EOP_CLR: w[17]    = 1'b0;
                                FK_SOP_CLR: w[16]    = 1'b0;
                                FK_SOP_SET: w[16]    = 1'b1;
                                FK_SEQ:     w[31:24] = w[31:24] ^ 8'h55;
                                FK_ERR_SET: w[18]    = 1'b1;
                                FK_EOP_SET: w[17]    = 1'b1;
                                FK_TID:     w[40]    = ~w[40];      // stream ID bit 0
                                default: ;
                            endcase
                            w[LINK_W-1 -: 32] = 32'h0;
                            w[LINK_W-1 -: 32] = ~crc_upd(crc_acc, w);
                            sym_tmp = encode_word(w);
                            touched = 1'b1;
                        end
                    end
                    default: ;
                endcase
                if (touched && (mode != MODE_LANE_FIU || cur_word == 0)) begin
                    n_fiu_mod = n_fiu_mod + 1;
                    n_mode[mode] = n_mode[mode] + 1;
                    if (mode == MODE_SYM && cor_n[cur_fiu] > 1) n_sym_burst = n_sym_burst + 1;
                    if (mode == MODE_FORGE) n_forge[forge_kind[cur_fiu]] = n_forge[forge_kind[cur_fiu]] + 1;
                    if (mode == MODE_LANE_WORD || mode == MODE_LANE_FIU)
                        n_lane[cor_lane[cur_fiu]] = n_lane[cor_lane[cur_fiu]] + 1;
                    if (log_fd != 0)
                        $fdisplay(log_fd, "%0t channel: FIU %0d word %0d mode %0d lane %0d pos %0d n %0d forge %0d",
                                  $time, cur_fiu, cur_word, mode, cor_lane[cur_fiu], cor_pos[cur_fiu],
                                  cor_n[cur_fiu], forge_kind[cur_fiu]);
                end
            end
            pipe_sym[0] <= sym_tmp; pipe_v[0] <= (tx_valid === 1'b1); pipe_sof[0] <= (tx_sof === 1'b1);
            for (k = 1; k < CH_DLY; k = k + 1) begin
                pipe_sym[k] <= pipe_sym[k-1]; pipe_v[k] <= pipe_v[k-1]; pipe_sof[k] <= pipe_sof[k-1];
            end
        end
    end

    assign rx_sym   = pipe_sym[CH_DLY-1];
    assign rx_valid = pipe_v[CH_DLY-1];
    assign rx_sof   = pipe_sof[CH_DLY-1];

    // ---------------- credit return delay line ---------------------------------------
    reg [7:0] cr_pipe [0:CR_DLY-1];
    integer m;
    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            for (m = 0; m < CR_DLY; m = m + 1) cr_pipe[m] <= 8'd0;
        end else begin
            cr_pipe[0] <= credit_from_rx;
            for (m = 1; m < CR_DLY; m = m + 1) cr_pipe[m] <= cr_pipe[m-1];
        end
    end
    assign credit_to_tx = cr_pipe[CR_DLY-1];
endmodule
