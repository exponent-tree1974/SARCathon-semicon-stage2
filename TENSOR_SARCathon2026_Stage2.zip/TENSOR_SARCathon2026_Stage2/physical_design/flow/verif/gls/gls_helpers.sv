`timescale 1ns/1ps
// =============================================================================
// Helpers for gate-level simulation (GLS) of the synthesised netlist with the
// Stage 1 arbiter bench (tb_arb_gls.sv).
//
// In a flattened netlist the arbiter output and link internals no longer exist
// as named signals, so the white-box monitors of tb_arb cannot be attached.
//   gls_egress_grant_counter  replaces arb_fairness_monitor (instance u_mon):
//       grants[s] = packets of source s seen at the EGRESS port (tlast accepted
//       with m_axis_tid == s). The bench's "grant count" checks therefore become
//       delivered-packet-count checks. max_wait / max_other (fairness timing)
//       are NOT observable and are held at -1 = "not evaluated"; the bench's
//       fairness-timing comparisons are disabled under `GLS (see make_gls_tb.py).
//   gls_null_checker          replaces link_safety_checker (instance u_safe),
//       which needs internal link signals; it reports 0 errors and checks nothing.
// The end-to-end checks still run unchanged: stream_scoreboard (byte-exact data,
// per-source order, counts), axis/axil protocol checkers on the DUT ports, and
// the CSR counter checks.
// =============================================================================
module gls_egress_grant_counter (
    input wire clk, input wire rst_n,
    input wire m_tvalid, input wire m_tready, input wire m_tlast, input wire m_tid
);
    integer grants [0:1];
    integer max_wait [0:1];
    integer max_other [0:1];
    integer errors = 0;
    task automatic clear_stats();
        begin grants[0] = 0; grants[1] = 0; max_wait[0] = -1; max_wait[1] = -1;
              max_other[0] = -1; max_other[1] = -1; end
    endtask
    initial clear_stats();
    always @(posedge clk)
        if (rst_n && m_tvalid && m_tready && m_tlast) grants[m_tid] = grants[m_tid] + 1;
endmodule

module gls_null_checker;
    integer errors = 0;
endmodule
