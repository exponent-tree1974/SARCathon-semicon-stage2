`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// crc32_engine
// Combinational parallel CRC-32 update (IEEE 802.3 / zlib polynomial, reflected
// form 0xEDB88320). Processes DATA_W bits per call, bit 0 first, which equals
// byte 0 LSB-first, i.e. identical to zlib.crc32() over little-endian bytes.
//
//   crc_out = update(crc_in, data)      (no init / final XOR applied here)
//
// The caller seeds with 32'hFFFF_FFFF and complements the final value.
//
// Implementation: the CRC update is linear over GF(2), so every output bit is
// the XOR of a fixed subset of the (32 + DATA_W) inputs. The subsets are
// computed ONCE at elaboration by symbolically running the bit-serial LFSR
// (constant function crc_matrix), and each output is a single reduction XOR:
//     crc_out[j] = ^({data, crc_in} & MASK_j)
// Synthesis builds balanced XOR trees (depth ~log2(#terms) ~ 8-9 levels),
// instead of the 256-deep chain a naive unrolled loop can leave behind.
// -----------------------------------------------------------------------------
module crc32_engine #(
    parameter int DATA_W = 256
) (
    input  wire [31:0]       crc_in,
    input  wire [DATA_W-1:0] data,
    output wire [31:0]       crc_out
);
    localparam int N = DATA_W + 32;                 // inputs: {data, crc_in}
    localparam logic [31:0] POLY = 32'hEDB8_8320;

    // Symbolic LFSR: state bit k is tracked as an N-bit dependency vector.
    // Returns 32 row masks packed as {row31, ..., row0}, each N bits.
    /* verilator lint_off WIDTHCONCAT */   // 32*N-bit constant vector is intentional
    function automatic [32*N-1:0] crc_matrix();
        reg [32*N-1:0] s;
        reg [N-1:0]    fb;
        integer step, k;
        begin
            s = '0;
            for (k = 0; k < 32; k = k + 1) s[k*N + k] = 1'b1;            // crc_in[k]
            for (step = 0; step < DATA_W; step = step + 1) begin
                fb = s[0 +: N];
                fb[32 + step] = ~fb[32 + step];                          // c[0] ^ d[step]
                for (k = 0; k < 31; k = k + 1)
                    s[k*N +: N] = s[(k+1)*N +: N] ^ (POLY[k] ? fb : {N{1'b0}});
                s[31*N +: N] = POLY[31] ? fb : {N{1'b0}};
            end
            crc_matrix = s;
        end
    endfunction

    localparam logic [32*N-1:0] MAT = crc_matrix();
    /* verilator lint_on WIDTHCONCAT */

    wire [N-1:0] in_vec = {data, crc_in};

    genvar j;
    generate
        for (j = 0; j < 32; j = j + 1) begin : g_out
            assign crc_out[j] = ^(in_vec & MAT[j*N +: N]);
        end
    endgenerate
endmodule
`default_nettype wire
