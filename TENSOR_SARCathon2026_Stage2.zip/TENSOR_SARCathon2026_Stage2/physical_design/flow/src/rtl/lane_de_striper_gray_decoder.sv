`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// lane_de_striper_gray_decoder   (RX, PHY-facing digital layer)
// Exact inverse of lane_striper_gray_mapper:
//   level -> bits : msb = lv[1], lsb = lv[1] ^ lv[0]
//   lane byte j of lane l -> word byte (j*LANES + l)
// Assumes lanes arrive aligned (no lane-to-lane skew; deskew is out of scope).
// Registered output, 1 cycle latency.
// -----------------------------------------------------------------------------
module lane_de_striper_gray_decoder #(
    parameter int LINK_W = 256,
    parameter int LANES  = 4
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire [LINK_W-1:0]    rx_sym,
    input  wire                 rx_sym_valid,
    input  wire                 rx_sym_sof,
    output logic [LINK_W-1:0]   r_data,
    output logic                r_valid,
    output logic                r_sof
);
    localparam int LB        = LINK_W / 8;
    localparam int BPL       = LB / LANES;
    localparam int LANE_BITS = BPL * 8;

    generate
        if ((LB % LANES) != 0 || LANES < 1) begin : g_bad_param
            illegal_parameter_combination u_illegal ();
        end
    endgenerate

    logic [LINK_W-1:0] demapped, word;

    always_comb begin
        for (int k = 0; k < LINK_W/2; k++)
            demapped[2*k +: 2] = {rx_sym[2*k+1], rx_sym[2*k+1] ^ rx_sym[2*k]};
        for (int l = 0; l < LANES; l++)
            for (int j = 0; j < BPL; j++)
                word[(j*LANES + l)*8 +: 8] = demapped[l*LANE_BITS + j*8 +: 8];
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_valid <= 1'b0;
            r_sof   <= 1'b0;
        end else begin
            r_valid <= rx_sym_valid;
            r_sof   <= rx_sym_valid && rx_sym_sof;
        end
    end

    always_ff @(posedge clk) begin
        if (rx_sym_valid) r_data <= word;
    end
endmodule
`default_nettype wire
