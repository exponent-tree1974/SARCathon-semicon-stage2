`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// fiu_rx_buffer
// Receive payload buffer with SPECULATIVE write + COMMIT/ROLLBACK, so that
// payload of an FIU is invisible to the reader until its CRC has been checked.
//
// Pointers (all PTR_W = log2(DEPTH)+1 bits, wrap bit for full/empty):
//   rd_ptr  <= cm_ptr <= wr_ptr
//   [rd_ptr, cm_ptr) : committed, readable entries
//   [cm_ptr, wr_ptr) : speculative entries of the FIU currently being received
//
// Per-entry metadata: nb (valid bytes), last (packet end), err (poison).
// Speculative writes store {nb=FULL, last=0, err=0}; commit patches the final
// committed entry of the FIU and writes the FIU's stream ID (tid) into its
// FIRST entry (a packet always starts on the first word of an FIU, so the
// reader finds the packet's tid on the entry that starts the packet);
// abort patches the newest committed entry to
// {last=1, err=1} so an interrupted packet is closed cleanly on AXIS.
//
// Safety of abort: axis_depacketizer never pops a non-last entry unless a later
// entry is committed, so the newest committed entry of an open packet is
// always still present when an abort arrives.
//
// freed = number of entries released this cycle (pops + rolled-back
// speculative entries); it is returned to the transmitter as credits.
// Writes and commit/rollback/abort are mutually exclusive per cycle (the link
// layer receives payload words and trailers on different cycles).
// -----------------------------------------------------------------------------
module fiu_rx_buffer #(
    parameter int W     = 256,
    parameter int DEPTH = 32,     // power of two
    parameter int R     = 2,      // max pops per cycle
    parameter int NB_W  = 6,
    parameter int FULL_NB = 32,
    parameter int TID_W   = 1
) (
    input  wire                         clk,
    input  wire                         rst_n,
    // speculative write
    input  wire                         wr_en,
    input  wire [W-1:0]                 wr_data,
    // commit current FIU (first commit_words speculative entries)
    input  wire                         commit_en,
    input  wire [$clog2(DEPTH):0]       commit_words,   // >= 1
    input  wire [NB_W-1:0]              commit_last_nb,
    input  wire                         commit_last_eop,
    input  wire                         commit_last_err,
    input  wire [TID_W-1:0]             commit_tid,
    // discard all speculative entries
    input  wire                         rollback_en,
    // close the open packet: newest committed entry gets last=1, err=1
    input  wire                         abort_en,
    // read side (peek R entries)
    output wire [$clog2(DEPTH):0]       count,          // committed entries
    output wire [R*W-1:0]               rd_data,
    output wire [R*NB_W-1:0]            rd_nb,
    output wire [R-1:0]                 rd_last,
    output wire [R-1:0]                 rd_err,
    output wire [TID_W-1:0]             rd_tid,         // tid stored on entry rd_ptr
    input  wire [$clog2(R+1)-1:0]       pop,            // 0..R, must be <= count
    // flow control
    output logic [7:0]                  freed,
    output wire  [$clog2(DEPTH):0]      used            // committed + speculative
);
    localparam int AW    = $clog2(DEPTH);
    localparam int PTR_W = AW + 1;
    localparam logic [NB_W-1:0] FULL = NB_W'(FULL_NB);

    generate
        if ((1 << AW) != DEPTH || DEPTH > 128) begin : g_bad_depth   // freed is 8 bits
            illegal_parameter_combination u_illegal ();
        end
    endgenerate

    logic [W-1:0]    mem   [0:DEPTH-1];
    logic [NB_W-1:0] m_nb  [0:DEPTH-1];
    logic            m_last[0:DEPTH-1];
    logic            m_err [0:DEPTH-1];
    logic [TID_W-1:0] m_tid [0:DEPTH-1];

    logic [PTR_W-1:0] rd_ptr, cm_ptr, wr_ptr;

    assign count = cm_ptr - rd_ptr;
    assign used  = wr_ptr - rd_ptr;

    wire [PTR_W-1:0] cm_next   = cm_ptr + commit_words;
    wire [AW-1:0]    patch_idx = cm_next[AW-1:0] - 1'b1;
    wire [AW-1:0]    abort_idx = cm_ptr[AW-1:0] - 1'b1;
    wire             can_abort = (cm_ptr != rd_ptr);
    // modulo-2^PTR_W differences (always <= DEPTH)
    wire [PTR_W-1:0] spec_after_commit = wr_ptr - cm_next;  // padding entries discarded by commit
    wire [PTR_W-1:0] spec_all          = wr_ptr - cm_ptr;   // entries discarded by rollback

    genvar g;
    generate
        for (g = 0; g < R; g = g + 1) begin : g_rd
            wire [AW-1:0] idx = rd_ptr[AW-1:0] + g;
            assign rd_data[g*W +: W]       = mem[idx];
            assign rd_nb  [g*NB_W +: NB_W] = m_nb[idx];
            assign rd_last[g]              = m_last[idx];
            assign rd_err [g]              = m_err[idx];
        end
    endgenerate
    assign rd_tid = m_tid[rd_ptr[AW-1:0]];

    // payload storage (no reset)
    always_ff @(posedge clk) begin
        if (wr_en) mem[wr_ptr[AW-1:0]] <= wr_data;
    end

    // stream ID of each FIU, on its first entry (no reset: only read after commit)
    always_ff @(posedge clk) begin
        if (commit_en && !wr_en) m_tid[cm_ptr[AW-1:0]] <= commit_tid;
    end

    // metadata + pointers
    integer i;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr <= '0;
            cm_ptr <= '0;
            wr_ptr <= '0;
            freed  <= '0;
            for (i = 0; i < DEPTH; i = i + 1) begin
                m_nb[i]   <= '0;
                m_last[i] <= 1'b0;
                m_err[i]  <= 1'b0;
            end
        end else begin
            rd_ptr <= rd_ptr + PTR_W'(pop);
            freed  <= 8'(pop)
                    + (commit_en   ? 8'(spec_after_commit) : 8'd0)
                    + (rollback_en ? 8'(spec_all)          : 8'd0);
            if (wr_en) begin
                m_nb  [wr_ptr[AW-1:0]] <= FULL;
                m_last[wr_ptr[AW-1:0]] <= 1'b0;
                m_err [wr_ptr[AW-1:0]] <= 1'b0;
                wr_ptr <= wr_ptr + 1'b1;
            end else if (commit_en) begin
                m_nb  [patch_idx] <= commit_last_nb;
                m_last[patch_idx] <= commit_last_eop;
                m_err [patch_idx] <= commit_last_err;
                cm_ptr <= cm_next;
                wr_ptr <= cm_next;
            end else begin
                if (rollback_en) wr_ptr <= cm_ptr;
                if (abort_en && can_abort) begin
                    m_last[abort_idx] <= 1'b1;
                    m_err [abort_idx] <= 1'b1;
                end
            end
        end
    end

`ifndef SYNTHESIS
    // simulation-only interface checks
    always @(posedge clk) begin
        if (rst_n) begin
            if (wr_en && (commit_en || rollback_en || abort_en))
                $error("fiu_rx_buffer: write and commit/rollback/abort in same cycle");
            if (commit_en && (rollback_en || abort_en))
                $error("fiu_rx_buffer: commit with rollback/abort");
            if (PTR_W'(pop) > count)
                $error("fiu_rx_buffer: pop %0d > count %0d", pop, count);
            if (wr_en && (used == PTR_W'(DEPTH)))
                $error("fiu_rx_buffer: overflow (credit protocol violated)");
        end
    end
`endif
endmodule
`default_nettype wire
