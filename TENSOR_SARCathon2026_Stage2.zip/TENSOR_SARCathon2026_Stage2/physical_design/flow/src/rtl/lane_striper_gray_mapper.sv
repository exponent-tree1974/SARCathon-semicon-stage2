`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// lane_striper_gray_mapper   (TX, PHY-facing digital layer)
//  1. Byte striping: word byte b goes to lane (b % LANES), lane byte (b / LANES)
//     (round-robin byte striping, as used by multi-lane PCIe links).
//  2. PAM4 Gray mapping, 2 bits -> 1 symbol. For lane byte x, symbol s (0..3)
//     carries bit pair {x[2s+1], x[2s]} (MSB, LSB). Symbol s = 0 is sent first.
//        bits 00 -> level 0, 01 -> level 1, 11 -> level 2, 10 -> level 3
//     i.e. level = {msb, msb ^ lsb}; adjacent levels differ in exactly one bit.
//     Level code 0..3 represents the four PAM4 amplitudes (-3,-1,+1,+3).
//
// Output bus: tx_sym[l*LANE_BITS + 2*k +: 2] = level of symbol k on lane l,
// LANE_BITS = LINK_W/LANES, SYMS_PER_LANE = LANE_BITS/2 per clock.
// Registered output, 1 cycle latency. No scrambling/precoding (see report).
// -----------------------------------------------------------------------------
module lane_striper_gray_mapper #(
    parameter int LINK_W = 256,
    parameter int LANES  = 4
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire [LINK_W-1:0]    t_data,
    input  wire                 t_valid,
    input  wire                 t_sof,
    output logic [LINK_W-1:0]   tx_sym,
    output logic                tx_sym_valid,
    output logic                tx_sym_sof
);
    localparam int LB        = LINK_W / 8;
    localparam int BPL       = LB / LANES;     // bytes per lane per clock
    localparam int LANE_BITS = BPL * 8;

    generate
        if ((LB % LANES) != 0 || LANES < 1) begin : g_bad_param
            illegal_parameter_combination u_illegal ();
        end
    endgenerate

    logic [LINK_W-1:0] striped, mapped;

    always_comb begin
        for (int l = 0; l < LANES; l++)
            for (int j = 0; j < BPL; j++)
                striped[l*LANE_BITS + j*8 +: 8] = t_data[(j*LANES + l)*8 +: 8];
        for (int k = 0; k < LINK_W/2; k++)
            mapped[2*k +: 2] = {striped[2*k+1], striped[2*k+1] ^ striped[2*k]};
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_sym_valid <= 1'b0;
            tx_sym_sof   <= 1'b0;
        end else begin
            tx_sym_valid <= t_valid;
            tx_sym_sof   <= t_valid && t_sof;
        end
    end

    always_ff @(posedge clk) begin
        if (t_valid) tx_sym <= mapped;
    end
endmodule
`default_nettype wire
