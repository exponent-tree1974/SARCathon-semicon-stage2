`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_packet_ingress
// AXI4-Stream slave front end.
//  1. Registered skid buffer: s_axis_tready is a flop output.
//  2. tkeep classification -> byte count (o_nbytes) + protocol-error flag.
//  3. One-beat "hold" stage that implements packet-boundary rules:
//       - null beat   (tkeep==0, tlast==0) : legal AXIS null beat, dropped.
//       - zero-length tlast (tkeep==0, tlast==1):
//             packet in progress -> tlast merged into the held beat
//             no packet in progress -> empty packet, dropped + counted.
//       - a non-last beat is only released once the next data beat (or a
//         merging zero-length tlast) is known, so o_last is always exact.
//
// Supported tkeep subset ("packed stream", common for DMA/NIC traffic):
//   - every non-last data beat has tkeep all ones
//   - the last data beat has contiguous tkeep starting at bit 0
// s_axis_tid (stream ID) travels with every beat; the packetizer samples it on
// the first beat of a packet (AXIS requires TID to be constant per packet).
// Any other pattern is a protocol error: the beat is forwarded WHOLE
// (o_nbytes = KEEP_W, bytes never compacted), o_err=1, ev_proto_err pulses.
// The error propagates to m_axis_tuser[0] on the egress tlast beat.
// -----------------------------------------------------------------------------
module axis_packet_ingress #(
    parameter int DATA_W = 512,
    parameter int KEEP_W = DATA_W / 8,
    parameter int TID_W  = 1
) (
    input  wire                           clk,
    input  wire                           rst_n,
    // AXI4-Stream slave
    input  wire [DATA_W-1:0]              s_axis_tdata,
    input  wire [KEEP_W-1:0]              s_axis_tkeep,
    input  wire                           s_axis_tlast,
    input  wire [TID_W-1:0]               s_axis_tid,
    input  wire                           s_axis_tvalid,
    output wire                           s_axis_tready,
    // Normalised beat stream (valid/ready)
    output wire [DATA_W-1:0]              o_data,
    output wire [$clog2(KEEP_W+1)-1:0]    o_nbytes,   // 1..KEEP_W
    output wire                           o_last,
    output wire                           o_err,
    output wire [TID_W-1:0]               o_tid,
    output wire                           o_valid,
    input  wire                           o_ready,
    // Status events (1-cycle pulses)
    output logic                          ev_proto_err,
    output logic                          ev_empty_drop
);
    localparam int NB_W = $clog2(KEEP_W + 1);
    localparam logic [NB_W-1:0] FULL_NB = NB_W'(KEEP_W);

    // ---------------- skid buffer -------------------------------------------
    wire [DATA_W-1:0] sk_data;
    wire [KEEP_W-1:0] sk_keep;
    wire [TID_W-1:0]  sk_tid;
    wire              sk_last, sk_valid;
    logic             sk_ready;

    axis_skid_buffer #(.W(TID_W + DATA_W + KEEP_W + 1)) u_skid (
        .clk     (clk),
        .rst_n   (rst_n),
        .s_data  ({s_axis_tid, s_axis_tlast, s_axis_tkeep, s_axis_tdata}),
        .s_valid (s_axis_tvalid),
        .s_ready (s_axis_tready),
        .m_data  ({sk_tid, sk_last, sk_keep, sk_data}),
        .m_valid (sk_valid),
        .m_ready (sk_ready)
    );

    // ---------------- tkeep classification ----------------------------------
    // Legal tkeep is a thermometer code (0...01...1). Contiguity check: k & (k+1) == 0
    // without a carry chain: bit i may be 1 only if bit i-1 is 1.
    wire [KEEP_W-1:0] keep_shl   = {sk_keep[KEEP_W-2:0], 1'b1};
    wire              keep_contig = ~|(sk_keep & ~keep_shl);
    wire              keep_zero   = ~|sk_keep;
    // Sparse / non-LSB-aligned tkeep is illegal on arrival. A partial (but
    // contiguous) beat is only illegal if it turns out NOT to be the last data
    // beat - that is decided at release time, because a following zero-length
    // tlast beat legally terminates the packet after a partial beat.
    wire              illegal     = !keep_contig;

    // Byte count of a thermometer code without an adder chain:
    // edge[m] = 1 exactly when the count is m (m = 0..KEEP_W); then each count
    // bit is an OR over the edge positions whose index has that bit set.
    wire [KEEP_W:0] keep_ext = {1'b0, sk_keep};
    logic [NB_W-1:0] therm_nb;
    always_comb begin
        // edge at m (m>=1): keep[m-1]=1 & keep[m]=0 ; count 0 (no edge) gives 0
        for (int b = 0; b < NB_W; b++) begin
            therm_nb[b] = 1'b0;
            for (int m = 1; m <= KEEP_W; m++)
                if (((m >> b) & 1) != 0) therm_nb[b] = therm_nb[b] | (keep_ext[m-1] & ~keep_ext[m]);
        end
    end
    wire [NB_W-1:0]   in_nb       = illegal ? FULL_NB : therm_nb;

    // Handshake-path decisions use only |tkeep (shallow logic).
    wire in_null  = keep_zero && !sk_last;
    wire in_zlast = keep_zero &&  sk_last;
    wire in_data  = !keep_zero;

    // ---------------- hold stage ---------------------------------------------
    logic              h_valid, h_last, h_err;
    logic [NB_W-1:0]   h_nb;
    logic [DATA_W-1:0] h_data;
    logic [TID_W-1:0]  h_tid;

    // A non-last held beat is released only together with the next data beat.
    // sk_valid comes from the skid buffer, which is AXIS-stable, and sk_ready is
    // low until the release handshake, so o_valid cannot drop without o_ready.
    assign o_valid  = h_valid && (h_last || (sk_valid && in_data));
    // partial beat released as non-last -> protocol error, forwarded whole
    wire   h_partial_mid = (h_nb != FULL_NB) && !h_last;
    assign o_data   = h_data;
    assign o_nbytes = h_partial_mid ? FULL_NB : h_nb;
    assign o_last   = h_last;
    assign o_err    = h_err || h_partial_mid;
    assign o_tid    = h_tid;

    wire o_fire = o_valid && o_ready;

    always_comb begin
        if (in_null || in_zlast) sk_ready = 1'b1;             // always absorbable
        else                     sk_ready = !h_valid || o_fire; // load when free/releasing
    end

    wire sk_fire = sk_valid && sk_ready;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            h_valid       <= 1'b0;
            h_last        <= 1'b0;
            h_err         <= 1'b0;
            h_nb          <= '0;
            ev_proto_err  <= 1'b0;
            ev_empty_drop <= 1'b0;
        end else begin
            ev_proto_err  <= (sk_fire && illegal) || (o_fire && h_partial_mid);
            ev_empty_drop <= sk_fire && in_zlast && (!h_valid || h_last);
            if (sk_fire && in_data) begin
                h_valid <= 1'b1;
                h_last  <= sk_last;
                h_err   <= illegal;
                h_nb    <= in_nb;
            end else if (sk_fire && in_zlast && h_valid && !h_last) begin
                h_last  <= 1'b1;                    // merge zero-length tlast
            end else if (o_fire) begin
                h_valid <= 1'b0;
            end
        end
    end

    always_ff @(posedge clk) begin
        if (sk_fire && in_data) begin
            h_data <= sk_data;
            h_tid  <= sk_tid;
        end
    end
endmodule
`default_nettype wire
