`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_pcie_link_top
// AXI4-Stream (512b) <-> FIU link layer <-> 4-lane PAM4-Gray symbol interface.
// "PCIe 6.0-inspired" educational datapath. NOT a PCIe-compliant controller:
// no TLP/DLLP layer, no LTSSM, no FEC (bypass placeholder only), no replay in
// the datapath (storage component only, see fiu_replay_buffer), no PIPE, no SerDes.
//
//  TX: s_axis -> axis_packet_ingress -> axis_packetizer -> fiu_link_layer(TX)
//          -> fec_encoder_stub (bypass) -> lane_striper_gray_mapper -> tx_sym[*]
//  RX: rx_sym[*] -> lane_de_striper_gray_decoder -> fec_decoder_stub (bypass)
//          -> fiu_link_layer(RX) -> fiu_rx_buffer -> axis_depacketizer -> m_axis
//  Stream ID: s_axis_tid is carried in the FIU trailer and delivered on
//          m_axis_tid (used by axis_pcie_link_mux2_top for 2 sources).
//  Credits: rx_credit_return (to link partner) / tx_credit_return (from partner)
//  CSR: AXI4-Lite csr_status
// For a single-device loopback test, connect tx_sym* -> rx_sym* and
// rx_credit_return -> tx_credit_return (optionally through delay stages).
// -----------------------------------------------------------------------------
module axis_pcie_link_top #(
    parameter int AXIS_W       = 512,
    parameter int LINK_W       = 256,
    parameter int FIU_BYTES    = 256,
    parameter int LANES        = 4,
    parameter int RX_BUF_DEPTH = 32,
    parameter int AXIL_ADDR_W  = 8,
    parameter int TID_W        = 1,     // stream ID width (1..8)
    parameter int FEC_MODE     = 0      // 0 = bypass (only legal value)
) (
    input  wire                       clk,
    input  wire                       rst_n,            // async assert, synchronised release
    // AXI4-Stream slave (device -> link)
    input  wire [AXIS_W-1:0]          s_axis_tdata,
    input  wire [AXIS_W/8-1:0]        s_axis_tkeep,
    input  wire                       s_axis_tlast,
    input  wire [TID_W-1:0]           s_axis_tid,       // stream ID, constant per packet
    input  wire                       s_axis_tvalid,
    output wire                       s_axis_tready,
    // AXI4-Stream master (link -> device)
    output wire [AXIS_W-1:0]          m_axis_tdata,
    output wire [AXIS_W/8-1:0]        m_axis_tkeep,
    output wire                       m_axis_tlast,
    output wire                       m_axis_tuser,     // 1 on tlast beat = errored/aborted packet
    output wire [TID_W-1:0]           m_axis_tid,
    output wire                       m_axis_tvalid,
    input  wire                       m_axis_tready,
    // PHY-facing symbol interface (LANES lanes, LINK_W/(2*LANES) PAM4 symbols per lane per clock)
    output wire [LINK_W-1:0]          tx_sym,
    output wire                       tx_sym_valid,
    output wire                       tx_sym_sof,
    input  wire [LINK_W-1:0]          rx_sym,
    input  wire                       rx_sym_valid,
    input  wire                       rx_sym_sof,
    // Link-level credit exchange (receive-buffer words)
    output wire [7:0]                 rx_credit_return,
    input  wire [7:0]                 tx_credit_return,
    // AXI4-Lite CSR slave
    input  wire [AXIL_ADDR_W-1:0]     s_axil_awaddr,
    input  wire                       s_axil_awvalid,
    output wire                       s_axil_awready,
    input  wire [31:0]                s_axil_wdata,
    input  wire [3:0]                 s_axil_wstrb,
    input  wire                       s_axil_wvalid,
    output wire                       s_axil_wready,
    output wire [1:0]                 s_axil_bresp,
    output wire                       s_axil_bvalid,
    input  wire                       s_axil_bready,
    input  wire [AXIL_ADDR_W-1:0]     s_axil_araddr,
    input  wire                       s_axil_arvalid,
    output wire                       s_axil_arready,
    output wire [31:0]                s_axil_rdata,
    output wire [1:0]                 s_axil_rresp,
    output wire                       s_axil_rvalid,
    input  wire                       s_axil_rready,
    // interrupt: |(ERR_STATUS & ERR_IRQ_EN), level, registered
    output wire                       irq
);
    localparam int R      = AXIS_W / LINK_W;
    localparam int LB     = LINK_W / 8;
    localparam int ANB_W  = $clog2(AXIS_W/8 + 1);
    localparam int LNB_W  = $clog2(LB + 1);
    localparam int PTR_W  = $clog2(RX_BUF_DEPTH) + 1;
    localparam int CW     = $clog2(RX_BUF_DEPTH + 1) + 1;
    localparam int NUM_CNT = 20;

    // ---------------- reset ----------------------------------------------------
    wire rst_n_s;
    reset_sync #(.STAGES(2)) u_rst (.clk(clk), .rst_n_in(rst_n), .rst_n_out(rst_n_s));

    // ---------------- CSR ---------------------------------------------------------
    wire              link_en;
    wire [NUM_CNT*8-1:0] cnt_inc;
    wire [CW-1:0]     tx_credits;
    wire              rx_in_pkt, rx_discard;

    // ---------------- ingress -----------------------------------------------------
    wire [AXIS_W-1:0] ig_data;
    wire [ANB_W-1:0]  ig_nb;
    wire              ig_last, ig_err, ig_valid, ig_ready;
    wire [TID_W-1:0]  ig_tid;
    wire              ev_proto_err, ev_empty_drop;

    axis_packet_ingress #(.DATA_W(AXIS_W), .TID_W(TID_W)) u_ingress (
        .clk(clk), .rst_n(rst_n_s),
        .s_axis_tdata(s_axis_tdata), .s_axis_tkeep(s_axis_tkeep),
        .s_axis_tlast(s_axis_tlast), .s_axis_tid(s_axis_tid), .s_axis_tvalid(s_axis_tvalid),
        .s_axis_tready(s_axis_tready),
        .o_data(ig_data), .o_nbytes(ig_nb), .o_last(ig_last), .o_err(ig_err), .o_tid(ig_tid),
        .o_valid(ig_valid), .o_ready(ig_ready),
        .ev_proto_err(ev_proto_err), .ev_empty_drop(ev_empty_drop)
    );

    /* verilator lint_off PINCONNECTEMPTY */   // intentionally unconnected outputs below
    // ---------------- packetizer ----------------------------------------------------
    wire [LINK_W-1:0] p_data;
    wire              p_valid, p_ready, p_first, p_end, p_sop, p_eop, p_err;
    wire [15:0]       p_len;
    wire [TID_W-1:0]  p_tid;
    wire              ev_tx_pkt;

    axis_packetizer #(.AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .TID_W(TID_W)) u_packetizer (
        .clk(clk), .rst_n(rst_n_s),
        .i_data(ig_data), .i_nbytes(ig_nb), .i_last(ig_last), .i_err(ig_err), .i_tid(ig_tid),
        .i_valid(ig_valid), .i_ready(ig_ready),
        .p_data(p_data), /* p_nbytes unused: count carried in p_len */ .p_nbytes(), .p_valid(p_valid), .p_ready(p_ready),
        .p_first(p_first), .p_end(p_end), .p_sop(p_sop), .p_eop(p_eop), .p_err(p_err),
        .p_len(p_len), .p_tid(p_tid), .ev_tx_pkt(ev_tx_pkt)
    );

    // ---------------- link layer -------------------------------------------------------
    wire [LINK_W-1:0] t_data, r_data, ft_data, fr_data;
    wire              t_valid, t_sof, r_valid, r_sof, ft_valid, ft_sof, fr_valid, fr_sof;
    wire              b_wr_en, b_commit_en, b_commit_eop, b_commit_err, b_rollback_en, b_abort_en;
    wire [LINK_W-1:0] b_wr_data;
    wire [PTR_W-1:0]  b_commit_words;
    wire [LNB_W-1:0]  b_commit_nb;
    wire [TID_W-1:0]  b_commit_tid;
    wire              ev_tx_fiu, ev_rx_good, ev_rx_crc, ev_rx_frame, ev_rx_seq, ev_rx_disc;
    wire              ev_credit_stall, err_valid;
    wire [2:0]        err_reason;
    wire [7:0]        err_exp_seq, err_rx_seq, tx_next_seq, rx_exp_seq, rx_last_acc_seq;
    wire              rx_any_acc;

    fiu_link_layer #(.LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .RX_BUF_DEPTH(RX_BUF_DEPTH),
                     .TID_W(TID_W)) u_link (
        .clk(clk), .rst_n(rst_n_s), .link_en(link_en),
        .p_data(p_data), .p_valid(p_valid), .p_ready(p_ready),
        .p_first(p_first), .p_end(p_end), .p_sop(p_sop), .p_eop(p_eop), .p_err(p_err), .p_len(p_len),
        .p_tid(p_tid),
        .t_data(t_data), .t_valid(t_valid), .t_sof(t_sof),
        .tx_credit_return(tx_credit_return),
        .r_data(fr_data), .r_valid(fr_valid), .r_sof(fr_sof),
        .b_wr_en(b_wr_en), .b_wr_data(b_wr_data),
        .b_commit_en(b_commit_en), .b_commit_words(b_commit_words),
        .b_commit_last_nb(b_commit_nb), .b_commit_last_eop(b_commit_eop),
        .b_commit_last_err(b_commit_err), .b_commit_tid(b_commit_tid),
        .b_rollback_en(b_rollback_en), .b_abort_en(b_abort_en),
        .tx_credits(tx_credits), .rx_in_pkt_o(rx_in_pkt), .rx_discard_o(rx_discard),
        .ev_tx_fiu(ev_tx_fiu), .ev_rx_fiu_good(ev_rx_good), .ev_rx_crc_err(ev_rx_crc),
        .ev_rx_frame_err(ev_rx_frame), .ev_rx_seq_err(ev_rx_seq), .ev_rx_discard(ev_rx_disc),
        .ev_credit_stall(ev_credit_stall),
        .err_valid(err_valid), .err_reason(err_reason), .err_exp_seq(err_exp_seq), .err_rx_seq(err_rx_seq),
        .tx_next_seq(tx_next_seq), .rx_exp_seq_o(rx_exp_seq), .rx_last_acc_seq(rx_last_acc_seq),
        .rx_any_acc(rx_any_acc)
    );

    // ---------------- FEC placeholders (bypass, 0 latency) ------------------------------------
    wire ev_fec_corr, ev_fec_uncorr;
    fec_encoder_stub #(.LINK_W(LINK_W), .FEC_MODE(FEC_MODE)) u_fec_enc (
        .clk(clk), .rst_n(rst_n_s),
        .i_data(t_data), .i_valid(t_valid), .i_sof(t_sof),
        .o_data(ft_data), .o_valid(ft_valid), .o_sof(ft_sof)
    );
    fec_decoder_stub #(.LINK_W(LINK_W), .FEC_MODE(FEC_MODE)) u_fec_dec (
        .clk(clk), .rst_n(rst_n_s),
        .i_data(r_data), .i_valid(r_valid), .i_sof(r_sof),
        .o_data(fr_data), .o_valid(fr_valid), .o_sof(fr_sof),
        .ev_corrected(ev_fec_corr), .ev_uncorrectable(ev_fec_uncorr)
    );

    // ---------------- PHY-facing digital layer ----------------------------------------------
    lane_striper_gray_mapper #(.LINK_W(LINK_W), .LANES(LANES)) u_tx_phy (
        .clk(clk), .rst_n(rst_n_s),
        .t_data(ft_data), .t_valid(ft_valid), .t_sof(ft_sof),
        .tx_sym(tx_sym), .tx_sym_valid(tx_sym_valid), .tx_sym_sof(tx_sym_sof)
    );

    lane_de_striper_gray_decoder #(.LINK_W(LINK_W), .LANES(LANES)) u_rx_phy (
        .clk(clk), .rst_n(rst_n_s),
        .rx_sym(rx_sym), .rx_sym_valid(rx_sym_valid), .rx_sym_sof(rx_sym_sof),
        .r_data(r_data), .r_valid(r_valid), .r_sof(r_sof)
    );

    // ---------------- RX buffer + depacketizer -----------------------------------------------
    wire [PTR_W-1:0]      b_count;
    wire [AXIS_W-1:0]     b_rd_data;
    wire [R*LNB_W-1:0]    b_rd_nb;
    wire [R-1:0]          b_rd_last, b_rd_err;
    wire [TID_W-1:0]      b_rd_tid;
    wire [$clog2(R+1)-1:0] b_pop;
    wire                  ev_rx_pkt, ev_rx_pkt_err;

    fiu_rx_buffer #(.W(LINK_W), .DEPTH(RX_BUF_DEPTH), .R(R), .NB_W(LNB_W), .FULL_NB(LB),
                    .TID_W(TID_W)) u_rxbuf (
        .clk(clk), .rst_n(rst_n_s),
        .wr_en(b_wr_en), .wr_data(b_wr_data),
        .commit_en(b_commit_en), .commit_words(b_commit_words),
        .commit_last_nb(b_commit_nb), .commit_last_eop(b_commit_eop), .commit_last_err(b_commit_err),
        .commit_tid(b_commit_tid),
        .rollback_en(b_rollback_en), .abort_en(b_abort_en),
        .count(b_count), .rd_data(b_rd_data), .rd_nb(b_rd_nb), .rd_last(b_rd_last), .rd_err(b_rd_err),
        .rd_tid(b_rd_tid),
        .pop(b_pop), .freed(rx_credit_return), .used()
    );

    axis_depacketizer #(.AXIS_W(AXIS_W), .LINK_W(LINK_W), .PTR_W(PTR_W), .TID_W(TID_W)) u_depacketizer (
        .clk(clk), .rst_n(rst_n_s),
        .b_count(b_count), .b_data(b_rd_data), .b_nb(b_rd_nb), .b_last(b_rd_last), .b_err(b_rd_err),
        .b_tid(b_rd_tid),
        .b_pop(b_pop),
        .m_axis_tdata(m_axis_tdata), .m_axis_tkeep(m_axis_tkeep), .m_axis_tlast(m_axis_tlast),
        .m_axis_tuser(m_axis_tuser), .m_axis_tid(m_axis_tid),
        .m_axis_tvalid(m_axis_tvalid), .m_axis_tready(m_axis_tready),
        .ev_rx_pkt(ev_rx_pkt), .ev_rx_pkt_err(ev_rx_pkt_err)
    );

    /* verilator lint_on PINCONNECTEMPTY */
    // ---------------- CSR -----------------------------------------------------------------------
    // ---------------- performance events (registered, off the handshake paths) -----------------
    logic [AXIS_W/8-1:0] in_keep_q, out_keep_q;
    logic                in_stall_q, out_stall_q;
    always_ff @(posedge clk or negedge rst_n_s) begin
        if (!rst_n_s) begin
            in_keep_q   <= '0;
            out_keep_q  <= '0;
            in_stall_q  <= 1'b0;
            out_stall_q <= 1'b0;
        end else begin
            in_keep_q   <= (s_axis_tvalid && s_axis_tready) ? s_axis_tkeep : '0;
            out_keep_q  <= (m_axis_tvalid && m_axis_tready) ? m_axis_tkeep : '0;
            in_stall_q  <= s_axis_tvalid && !s_axis_tready;
            out_stall_q <= m_axis_tvalid && !m_axis_tready;
        end
    end

    function automatic [7:0] popcount(input [AXIS_W/8-1:0] v);
        integer b;
        begin
            popcount = 8'd0;
            for (b = 0; b < AXIS_W/8; b = b + 1) popcount = popcount + 8'(v[b]);
        end
    endfunction

    wire [10:0] ev1 = {ev_empty_drop, ev_proto_err, ev_rx_pkt_err, ev_rx_pkt, ev_rx_disc,
                       ev_rx_seq, ev_rx_frame, ev_rx_crc, ev_rx_good, ev_tx_fiu, ev_tx_pkt};
    genvar gi;
    generate
        for (gi = 0; gi < 11; gi = gi + 1) begin : g_ev1
            assign cnt_inc[gi*8 +: 8] = {7'b0, ev1[gi]};
        end
    endgenerate
    assign cnt_inc[11*8 +: 8] = popcount(in_keep_q);      // IN_BYTES
    assign cnt_inc[12*8 +: 8] = popcount(out_keep_q);     // OUT_BYTES
    assign cnt_inc[13*8 +: 8] = {7'b0, in_stall_q};       // IN_STALL
    assign cnt_inc[14*8 +: 8] = {7'b0, out_stall_q};      // OUT_STALL
    assign cnt_inc[15*8 +: 8] = {7'b0, ev_credit_stall};  // CREDIT_STALL
    assign cnt_inc[16*8 +: 8] = {7'b0, t_valid};          // TX_WORDS
    assign cnt_inc[17*8 +: 8] = 8'd1;                     // CYCLES
    assign cnt_inc[18*8 +: 8] = {7'b0, ev_fec_corr};      // FEC_CORR   (placeholder: 0)
    assign cnt_inc[19*8 +: 8] = {7'b0, ev_fec_uncorr};    // FEC_UNCORR (placeholder: 0)

    csr_status #(.ADDR_W(AXIL_ADDR_W), .NUM_CNT(NUM_CNT), .LANES(LANES),
                 .FIU_BYTES(FIU_BYTES), .LINK_W(LINK_W), .RX_BUF_DEPTH(RX_BUF_DEPTH),
                 .TID_W(TID_W), .FEC_MODE(FEC_MODE)) u_csr (
        .clk(clk), .rst_n(rst_n_s),
        .s_axil_awaddr(s_axil_awaddr), .s_axil_awvalid(s_axil_awvalid), .s_axil_awready(s_axil_awready),
        .s_axil_wdata(s_axil_wdata), .s_axil_wstrb(s_axil_wstrb), .s_axil_wvalid(s_axil_wvalid),
        .s_axil_wready(s_axil_wready), .s_axil_bresp(s_axil_bresp), .s_axil_bvalid(s_axil_bvalid),
        .s_axil_bready(s_axil_bready), .s_axil_araddr(s_axil_araddr), .s_axil_arvalid(s_axil_arvalid),
        .s_axil_arready(s_axil_arready), .s_axil_rdata(s_axil_rdata), .s_axil_rresp(s_axil_rresp),
        .s_axil_rvalid(s_axil_rvalid), .s_axil_rready(s_axil_rready),
        .link_en(link_en), .irq(irq), .st_rx_in_pkt(rx_in_pkt), .st_rx_discard(rx_discard),
        .st_tx_credits(8'(tx_credits)), .st_tx_next_seq(tx_next_seq), .st_rx_exp_seq(rx_exp_seq),
        .st_rx_last_acc_seq(rx_last_acc_seq), .st_rx_any_acc(rx_any_acc),
        .cnt_inc(cnt_inc),
        .err_valid(err_valid), .err_reason(err_reason), .err_exp_seq(err_exp_seq), .err_rx_seq(err_rx_seq)
    );
endmodule
`default_nettype wire
