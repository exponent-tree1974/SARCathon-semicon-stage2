`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// fiu_link_layer
// FIU (Flow Information Unit) framing, CRC protection, sequence numbering and
// credit-based flow control. Single clock domain.
//
// FIU format (FIU_BYTES = FIU_WORDS * LINK_W/8; default 256 B = 8 x 256-bit):
//   words 0 .. PW-1 : payload (PW = FIU_WORDS-1; 224 B by default), zero padded
//   word  PW        : trailer
//      [15:0]   len   payload bytes in this FIU (1..PAYLOAD_BYTES)
//      [16]     sop   FIU starts a packet
//      [17]     eop   FIU ends a packet (if 0, len must equal PAYLOAD_BYTES)
//      [18]     err   poison: packet carried an ingress protocol error
//      [23:19]  reserved (0)
//      [31:24]  seq   FIU sequence number (mod 256)
//      [39:32]  magic 8'h5A
//      [47:40]  tid   stream ID of the packet (TID_W LSBs used, rest 0)
//      [LINK_W-33:48] reserved (0) - space reserved for future FEC/link control
//      [LINK_W-1:LINK_W-32] CRC-32 over all FIU bytes with this field = 0
//   CRC-32: zlib polynomial, init 0xFFFFFFFF, final XOR 0xFFFFFFFF, bytes in
//   order 0..FIU_BYTES-1, LSB first  ->  equals zlib.crc32(fiu_with_crc_zeroed).
//
// TX: forwards payload words, accumulates CRC, appends the trailer; a new FIU
//     is started only if link_en=1 and >= PW receive-buffer credits are held.
// RX: speculatively stores payload words, checks CRC/trailer on the trailer
//     word, then commits (good) or rolls back (bad). Recovery policy:
//       - bad FIU while a packet is open  -> open packet is closed with
//         tlast + tuser error (abort), receiver discards until next sop FIU
//       - bad FIU otherwise               -> dropped, discard until next sop FIU
//     Corrupted data is never delivered.
//     Decision order on a trailer word (first match wins):
//       1 CRC        CRC mismatch
//       2 HDR        bad magic or illegal length
//       3 SOP_IN_PKT sop FIU while a packet is open
//       5 TID        continuation FIU whose tid differs from the open packet
//       4 CONT       continuation FIU with no open packet (discard mode or framing)
//       0 ACCEPT
//     Error capture (err_*): reason code (above, 6 = FIU alignment / sof error,
//     7 = sequence error only), expected and received sequence numbers.
// Not implemented (Stage 2): replay/ACK-NAK (see fiu_replay_buffer for the
// storage component), FEC (fec_*_stub placeholders), DLLP credits, multi-packet FIUs.
// -----------------------------------------------------------------------------
module fiu_link_layer #(
    parameter int LINK_W       = 256,
    parameter int FIU_BYTES    = 256,
    parameter int RX_BUF_DEPTH = 32,
    parameter int TID_W        = 1
) (
    input  wire                              clk,
    input  wire                              rst_n,
    input  wire                              link_en,
    // ---------------- TX: from axis_packetizer -------------------------------
    input  wire [LINK_W-1:0]                 p_data,
    input  wire                              p_valid,
    output wire                              p_ready,
    input  wire                              p_first,
    input  wire                              p_end,
    input  wire                              p_sop,
    input  wire                              p_eop,
    input  wire                              p_err,
    input  wire [15:0]                       p_len,
    input  wire [TID_W-1:0]                  p_tid,
    // ---------------- TX: to lane_striper_gray_mapper ------------------------
    output logic [LINK_W-1:0]                t_data,
    output logic                             t_valid,
    output logic                             t_sof,       // first word of an FIU
    input  wire  [7:0]                       tx_credit_return,
    // ---------------- RX: from lane_de_striper_gray_decoder ------------------
    input  wire  [LINK_W-1:0]                r_data,
    input  wire                              r_valid,
    input  wire                              r_sof,
    // ---------------- RX: to fiu_rx_buffer ----------------------------------
    output wire                              b_wr_en,
    output wire  [LINK_W-1:0]                b_wr_data,
    output logic                             b_commit_en,
    output logic [$clog2(RX_BUF_DEPTH):0]    b_commit_words,
    output logic [$clog2(LINK_W/8+1)-1:0]    b_commit_last_nb,
    output logic                             b_commit_last_eop,
    output logic                             b_commit_last_err,
    output wire  [TID_W-1:0]                 b_commit_tid,
    output logic                             b_rollback_en,
    output logic                             b_abort_en,
    // ---------------- status --------------------------------------------------
    output wire  [$clog2(RX_BUF_DEPTH+1):0]  tx_credits,
    output wire                              rx_in_pkt_o,
    output wire                              rx_discard_o,
    output logic                             ev_tx_fiu,
    output logic                             ev_rx_fiu_good,
    output logic                             ev_rx_crc_err,
    output logic                             ev_rx_frame_err,
    output logic                             ev_rx_seq_err,
    output logic                             ev_rx_discard,
    output logic                             ev_credit_stall,  // FIU ready, link enabled, no credits
    // error capture (registered, valid with err_valid; same cycle as ev_rx_*)
    output logic                             err_valid,
    output logic [2:0]                       err_reason,
    output logic [7:0]                       err_exp_seq,
    output logic [7:0]                       err_rx_seq,
    // sequence status
    output wire  [7:0]                       tx_next_seq,
    output wire  [7:0]                       rx_exp_seq_o,
    output logic [7:0]                       rx_last_acc_seq,
    output logic                             rx_any_acc
);
    localparam int LB            = LINK_W / 8;
    localparam int LB_SH         = $clog2(LB);
    localparam int FIU_WORDS     = FIU_BYTES / LB;
    localparam int PW            = FIU_WORDS - 1;
    localparam int PAYLOAD_BYTES = PW * LB;
    localparam int CW            = $clog2(RX_BUF_DEPTH + 1) + 1;
    localparam int RIDX_W        = $clog2(FIU_WORDS);
    localparam int LNB_W         = $clog2(LB + 1);
    localparam int CMW           = $clog2(RX_BUF_DEPTH) + 1;
    localparam logic [7:0]  MAGIC = 8'h5A;
    localparam logic [31:0] CRC_INIT = 32'hFFFF_FFFF;

    generate
        if (LINK_W < 128 || (1 << LB_SH) != LB || (1 << RIDX_W) != FIU_WORDS ||
            RX_BUF_DEPTH < PW || PAYLOAD_BYTES > 65535 || TID_W < 1 || TID_W > 8)
            begin : g_bad_param
                illegal_parameter_combination u_illegal ();
            end
    endgenerate

    function automatic [LINK_W-1:0] build_trailer(input [15:0] len, input sop, input eop,
                                                  input err, input [7:0] seq,
                                                  input [TID_W-1:0] tid);
        begin
            build_trailer        = '0;
            build_trailer[15:0]  = len;
            build_trailer[16]    = sop;
            build_trailer[17]    = eop;
            build_trailer[18]    = err;
            build_trailer[31:24] = seq;
            build_trailer[39:32] = MAGIC;
            build_trailer[40 +: TID_W] = tid;
        end
    endfunction

    // =========================================================================
    // TX
    // =========================================================================
    logic [CW-1:0] credits;
    logic          tx_in_fiu, trl_pend;
    logic [31:0]   tx_crc;
    logic [7:0]    tx_seq;
    logic [15:0]   trl_len;
    logic          trl_sop, trl_eop, trl_err;
    logic [TID_W-1:0] trl_tid;

    wire credit_ok = (credits >= CW'(PW));
    assign p_ready    = !trl_pend && (tx_in_fiu || (link_en && credit_ok));
    assign tx_credits = credits;
    wire p_fire = p_valid && p_ready;

    wire [LINK_W-1:0] trl_nocrc   = build_trailer(trl_len, trl_sop, trl_eop, trl_err, tx_seq, trl_tid);
    assign tx_next_seq = tx_seq;
    wire [LINK_W-1:0] tx_crc_data = trl_pend ? trl_nocrc : p_data;
    wire [31:0]       tx_crc_seed = (!trl_pend && p_first) ? CRC_INIT : tx_crc;
    wire [31:0]       tx_crc_next;

    crc32_engine #(.DATA_W(LINK_W)) u_tx_crc (
        .crc_in (tx_crc_seed),
        .data   (tx_crc_data),
        .crc_out(tx_crc_next)
    );

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            credits   <= CW'(RX_BUF_DEPTH);
            tx_in_fiu <= 1'b0;
            trl_pend  <= 1'b0;
            tx_crc    <= CRC_INIT;
            tx_seq    <= '0;
            trl_len   <= '0;
            trl_sop   <= 1'b0;
            trl_eop   <= 1'b0;
            trl_err   <= 1'b0;
            trl_tid   <= '0;
            t_valid   <= 1'b0;
            t_sof     <= 1'b0;
            ev_tx_fiu <= 1'b0;
            ev_credit_stall <= 1'b0;
        end else begin
            ev_credit_stall <= p_valid && p_first && !tx_in_fiu && !trl_pend && link_en && !credit_ok;
            credits   <= CW'({1'b0, credits} + tx_credit_return - ((p_fire && p_first) ? 8'(PW) : 8'd0));
            t_valid   <= trl_pend || p_fire;
            t_sof     <= !trl_pend && p_fire && p_first;
            ev_tx_fiu <= trl_pend;
            if (trl_pend) begin
                trl_pend <= 1'b0;
                tx_seq   <= tx_seq + 1'b1;
            end else if (p_fire) begin
                tx_crc <= tx_crc_next;
                if (p_first) tx_in_fiu <= 1'b1;
                if (p_end) begin
                    tx_in_fiu <= 1'b0;
                    trl_pend  <= 1'b1;
                    trl_len   <= p_len;
                    trl_sop   <= p_sop;
                    trl_eop   <= p_eop;
                    trl_err   <= p_err;
                    trl_tid   <= p_tid;
                end
            end
        end
    end

    always_ff @(posedge clk) begin
        if (trl_pend)     t_data <= {~tx_crc_next, trl_nocrc[LINK_W-33:0]};
        else if (p_fire)  t_data <= p_data;
    end

    // =========================================================================
    // RX
    // =========================================================================
    logic [RIDX_W-1:0] ridx;
    logic [31:0]       rx_crc;
    logic              rx_in_pkt, rx_discard;
    logic [7:0]        rx_exp_seq;
    logic [TID_W-1:0]  rx_tid;          // tid of the open packet

    wire is_trl    = (ridx == RIDX_W'(PW));
    wire sof_bad   = r_valid && (r_sof != (ridx == '0));
    wire word_ok   = r_valid && !sof_bad;
    wire pay_word  = word_ok && !is_trl;
    wire trl_word  = word_ok &&  is_trl;

    wire [LINK_W-1:0] rx_crc_data = is_trl ? {32'b0, r_data[LINK_W-33:0]} : r_data;
    wire [31:0]       rx_crc_seed = (ridx == '0) ? CRC_INIT : rx_crc;
    wire [31:0]       rx_crc_next;

    crc32_engine #(.DATA_W(LINK_W)) u_rx_crc (
        .crc_in (rx_crc_seed),
        .data   (rx_crc_data),
        .crc_out(rx_crc_next)
    );

    // trailer fields
    wire [15:0] rt_len   = r_data[15:0];
    wire        rt_sop   = r_data[16];
    wire        rt_eop   = r_data[17];
    wire        rt_err   = r_data[18];
    wire [7:0]  rt_seq   = r_data[31:24];
    wire [7:0]  rt_magic = r_data[39:32];
    wire [31:0] rt_crc   = r_data[LINK_W-1 -: 32];
    wire [TID_W-1:0] rt_tid = r_data[40 +: TID_W];

    wire crc_ok = (~rx_crc_next == rt_crc);
    wire len_ok = (rt_len != 16'd0) && (rt_len <= 16'(PAYLOAD_BYTES)) &&
                  (rt_eop || (rt_len == 16'(PAYLOAD_BYTES)));
    wire hdr_ok = (rt_magic == MAGIC) && len_ok;

    // commit geometry
    wire [15:0] words_w  = (rt_len + 16'(LB - 1)) >> LB_SH;     // ceil(len/LB) >= 1
    wire [15:0] last_nb16 = rt_len - ((words_w - 16'd1) << LB_SH);   // 1..LB
    wire [LNB_W-1:0] last_nb = LNB_W'(last_nb16);
    wire unused_last_nb_hi = |last_nb16[15:LNB_W];   // value <= LB, upper bits always 0

    assign b_wr_en   = pay_word;
    assign b_wr_data = r_data;
    assign rx_in_pkt_o  = rx_in_pkt;
    assign rx_discard_o = rx_discard;
    assign rx_exp_seq_o = rx_exp_seq;
    assign b_commit_tid = rt_tid;

    // decision for a trailer word
    typedef enum logic [2:0] {
        D_ACCEPT, D_CRC, D_HDR, D_SOP_IN_PKT, D_CONT_NO_PKT, D_TID
    } dec_t;
    dec_t dec;
    always_comb begin
        if (!crc_ok)                           dec = D_CRC;
        else if (!hdr_ok)                      dec = D_HDR;
        else if (rt_sop && rx_in_pkt)          dec = D_SOP_IN_PKT;
        else if (!rt_sop && rx_in_pkt && (rt_tid != rx_tid)) dec = D_TID;   // stream changed mid-packet
        else if (!rt_sop && !rx_in_pkt)        dec = D_CONT_NO_PKT;   // incl. discard mode
        else                                   dec = D_ACCEPT;
    end

    always_comb begin
        b_commit_en       = trl_word && (dec == D_ACCEPT);
        b_commit_words    = CMW'(words_w);
        b_commit_last_nb  = last_nb;
        b_commit_last_eop = rt_eop;
        b_commit_last_err = rt_err;
        // drop paths: discard speculative words of this FIU
        b_rollback_en     = (trl_word && (dec != D_ACCEPT)) || (sof_bad && ridx != '0);
        // close an open packet when its continuation is lost
        b_abort_en        = rx_in_pkt &&
                            ((trl_word && (dec == D_CRC || dec == D_HDR || dec == D_SOP_IN_PKT ||
                                           dec == D_TID)) ||
                             (sof_bad && ridx != '0));
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ridx            <= '0;
            rx_crc          <= CRC_INIT;
            rx_in_pkt       <= 1'b0;
            rx_discard      <= 1'b0;
            rx_exp_seq      <= '0;
            ev_rx_fiu_good  <= 1'b0;
            ev_rx_crc_err   <= 1'b0;
            ev_rx_frame_err <= 1'b0;
            ev_rx_seq_err   <= 1'b0;
            ev_rx_discard   <= 1'b0;
            rx_tid          <= '0;
            err_valid       <= 1'b0;
            err_reason      <= 3'd0;
            err_exp_seq     <= 8'd0;
            err_rx_seq      <= 8'd0;
            rx_last_acc_seq <= 8'd0;
            rx_any_acc      <= 1'b0;
        end else begin
            ev_rx_fiu_good  <= trl_word && (dec == D_ACCEPT);
            ev_rx_crc_err   <= trl_word && (dec == D_CRC);
            ev_rx_frame_err <= sof_bad || (trl_word && (dec == D_HDR || dec == D_SOP_IN_PKT ||
                                                        dec == D_TID ||
                                                        (dec == D_CONT_NO_PKT && !rx_discard)));
            ev_rx_discard   <= trl_word && (dec == D_CONT_NO_PKT) && rx_discard;
            ev_rx_seq_err   <= trl_word && crc_ok && (rt_seq != rx_exp_seq);

            // error capture: trailer decision errors take priority over a sequence error
            err_valid <= 1'b0;
            if (sof_bad) begin
                err_valid <= 1'b1; err_reason <= 3'd6;
                err_exp_seq <= rx_exp_seq; err_rx_seq <= 8'd0;
            end else if (trl_word && (dec != D_ACCEPT) &&
                         !(dec == D_CONT_NO_PKT && rx_discard)) begin
                err_valid <= 1'b1; err_reason <= 3'(dec);
                err_exp_seq <= rx_exp_seq; err_rx_seq <= rt_seq;
            end else if (trl_word && crc_ok && (rt_seq != rx_exp_seq)) begin
                err_valid <= 1'b1; err_reason <= 3'd7;
                err_exp_seq <= rx_exp_seq; err_rx_seq <= rt_seq;
            end

            if (sof_bad) begin
                // lost FIU alignment: drop partial FIU, hunt for next sof
                ridx <= '0;
                if (ridx != '0) begin
                    rx_in_pkt  <= 1'b0;
                    rx_discard <= 1'b1;
                    rx_exp_seq <= rx_exp_seq + 1'b1;
                end
            end else if (pay_word) begin
                ridx   <= ridx + 1'b1;
                rx_crc <= rx_crc_next;
            end else if (trl_word) begin
                ridx       <= '0;
                rx_exp_seq <= crc_ok ? rt_seq + 1'b1 : rx_exp_seq + 1'b1;
                if (dec == D_ACCEPT) begin
                    rx_in_pkt  <= !rt_eop;
                    rx_discard <= 1'b0;
                    if (rt_sop) rx_tid <= rt_tid;
                    rx_last_acc_seq <= rt_seq;
                    rx_any_acc      <= 1'b1;
                end else begin
                    rx_in_pkt  <= 1'b0;
                    rx_discard <= 1'b1;
                end
            end
        end
    end
endmodule
`default_nettype wire
