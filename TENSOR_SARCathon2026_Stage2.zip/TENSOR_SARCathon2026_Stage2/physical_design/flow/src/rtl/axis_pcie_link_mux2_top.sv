`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_pcie_link_mux2_top
// Two AXI4-Stream sources share one link:
//
//   s0_axis --\
//              axis_rr_arbiter (packet-atomic round robin) --> axis_pcie_link_top
//   s1_axis --/        m_tid = source index                      (tid carried in the
//                                                                 FIU trailer)
//   m_axis_tid on the receive side identifies the source of every packet, so a
//   1:2 demultiplexer on m_axis_tid restores the two streams (left to the user;
//   with tid the link behaves as a 2-channel virtual-channel mux).
//
// All link, PHY-facing, credit and CSR ports are those of axis_pcie_link_top.
// Per-source packet start events are exported for performance monitoring.
// -----------------------------------------------------------------------------
module axis_pcie_link_mux2_top #(
    parameter int AXIS_W       = 512,
    parameter int LINK_W       = 256,
    parameter int FIU_BYTES    = 256,
    parameter int LANES        = 4,
    parameter int RX_BUF_DEPTH = 32,
    parameter int AXIL_ADDR_W  = 8
) (
    input  wire                       clk,
    input  wire                       rst_n,
    // source 0
    input  wire [AXIS_W-1:0]          s0_axis_tdata,
    input  wire [AXIS_W/8-1:0]        s0_axis_tkeep,
    input  wire                       s0_axis_tlast,
    input  wire                       s0_axis_tvalid,
    output wire                       s0_axis_tready,
    // source 1
    input  wire [AXIS_W-1:0]          s1_axis_tdata,
    input  wire [AXIS_W/8-1:0]        s1_axis_tkeep,
    input  wire                       s1_axis_tlast,
    input  wire                       s1_axis_tvalid,
    output wire                       s1_axis_tready,
    // received stream (m_axis_tid = source index)
    output wire [AXIS_W-1:0]          m_axis_tdata,
    output wire [AXIS_W/8-1:0]        m_axis_tkeep,
    output wire                       m_axis_tlast,
    output wire                       m_axis_tuser,
    output wire                       m_axis_tid,
    output wire                       m_axis_tvalid,
    input  wire                       m_axis_tready,
    // PHY-facing symbols and credits
    output wire [LINK_W-1:0]          tx_sym,
    output wire                       tx_sym_valid,
    output wire                       tx_sym_sof,
    input  wire [LINK_W-1:0]          rx_sym,
    input  wire                       rx_sym_valid,
    input  wire                       rx_sym_sof,
    output wire [7:0]                 rx_credit_return,
    input  wire [7:0]                 tx_credit_return,
    // AXI4-Lite CSR
    input  wire [AXIL_ADDR_W-1:0]     s_axil_awaddr,
    input  wire                       s_axil_awvalid,
    output wire                       s_axil_awready,
    input  wire [31:0]                s_axil_wdata,
    input  wire [3:0]                 s_axil_wstrb,
    input  wire                       s_axil_wvalid,
    output wire                       s_axil_wready,
    output wire [1:0]                 s_axil_bresp,
    output wire                       s_axil_bvalid,
    input  wire                       s_axil_bready,
    input  wire [AXIL_ADDR_W-1:0]     s_axil_araddr,
    input  wire                       s_axil_arvalid,
    output wire                       s_axil_arready,
    output wire [31:0]                s_axil_rdata,
    output wire [1:0]                 s_axil_rresp,
    output wire                       s_axil_rvalid,
    input  wire                       s_axil_rready,
    output wire                       irq,
    // per-source packet-start pulses (arbiter grants)
    output wire [1:0]                 ev_arb_pkt_start
);
    // the arbiter shares the link's reset domain: use the same synchroniser
    wire rst_n_s;
    reset_sync #(.STAGES(2)) u_rst (.clk(clk), .rst_n_in(rst_n), .rst_n_out(rst_n_s));

    wire [AXIS_W-1:0]   a_tdata;
    wire [AXIS_W/8-1:0] a_tkeep;
    wire                a_tlast, a_tvalid, a_tready;
    wire                a_tid;
    wire [1:0]          s_tready;

    axis_rr_arbiter #(.N(2), .DATA_W(AXIS_W), .ID_W(1)) u_arb (
        .clk(clk), .rst_n(rst_n_s),
        .s_tdata ({s1_axis_tdata,  s0_axis_tdata}),
        .s_tkeep ({s1_axis_tkeep,  s0_axis_tkeep}),
        .s_tlast ({s1_axis_tlast,  s0_axis_tlast}),
        .s_tvalid({s1_axis_tvalid, s0_axis_tvalid}),
        .s_tready(s_tready),
        .m_tdata(a_tdata), .m_tkeep(a_tkeep), .m_tlast(a_tlast), .m_tid(a_tid),
        .m_tvalid(a_tvalid), .m_tready(a_tready),
        .ev_pkt_start(ev_arb_pkt_start)
    );
    assign s0_axis_tready = s_tready[0];
    assign s1_axis_tready = s_tready[1];

    axis_pcie_link_top #(
        .AXIS_W(AXIS_W), .LINK_W(LINK_W), .FIU_BYTES(FIU_BYTES), .LANES(LANES),
        .RX_BUF_DEPTH(RX_BUF_DEPTH), .AXIL_ADDR_W(AXIL_ADDR_W), .TID_W(1)
    ) u_link (
        .clk(clk), .rst_n(rst_n),
        .s_axis_tdata(a_tdata), .s_axis_tkeep(a_tkeep), .s_axis_tlast(a_tlast),
        .s_axis_tid(a_tid), .s_axis_tvalid(a_tvalid), .s_axis_tready(a_tready),
        .m_axis_tdata(m_axis_tdata), .m_axis_tkeep(m_axis_tkeep), .m_axis_tlast(m_axis_tlast),
        .m_axis_tuser(m_axis_tuser), .m_axis_tid(m_axis_tid),
        .m_axis_tvalid(m_axis_tvalid), .m_axis_tready(m_axis_tready),
        .tx_sym(tx_sym), .tx_sym_valid(tx_sym_valid), .tx_sym_sof(tx_sym_sof),
        .rx_sym(rx_sym), .rx_sym_valid(rx_sym_valid), .rx_sym_sof(rx_sym_sof),
        .rx_credit_return(rx_credit_return), .tx_credit_return(tx_credit_return),
        .s_axil_awaddr(s_axil_awaddr), .s_axil_awvalid(s_axil_awvalid), .s_axil_awready(s_axil_awready),
        .s_axil_wdata(s_axil_wdata), .s_axil_wstrb(s_axil_wstrb), .s_axil_wvalid(s_axil_wvalid),
        .s_axil_wready(s_axil_wready), .s_axil_bresp(s_axil_bresp), .s_axil_bvalid(s_axil_bvalid),
        .s_axil_bready(s_axil_bready), .s_axil_araddr(s_axil_araddr), .s_axil_arvalid(s_axil_arvalid),
        .s_axil_arready(s_axil_arready), .s_axil_rdata(s_axil_rdata), .s_axil_rresp(s_axil_rresp),
        .s_axil_rvalid(s_axil_rvalid), .s_axil_rready(s_axil_rready),
        .irq(irq)
    );
endmodule
`default_nettype wire
