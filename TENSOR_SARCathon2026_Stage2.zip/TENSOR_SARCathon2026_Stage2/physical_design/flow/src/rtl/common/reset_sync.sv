`timescale 1ns/1ps
`default_nettype none
// Asynchronous-assert / synchronous-deassert reset synchronizer (active low).
module reset_sync #(
    parameter int STAGES = 2
) (
    input  wire clk,
    input  wire rst_n_in,
    output wire rst_n_out
);
    // The synchroniser flops are asynchronously reset and their output is used as an
    // asynchronous reset downstream - this is the intended structure.
    /* verilator lint_off SYNCASYNCNET */
    logic [STAGES-1:0] sync;
    /* verilator lint_on SYNCASYNCNET */
    always_ff @(posedge clk or negedge rst_n_in) begin
        if (!rst_n_in) sync <= '0;
        else           sync <= {sync[STAGES-2:0], 1'b1};
    end
    assign rst_n_out = sync[STAGES-1];
endmodule
`default_nettype wire
