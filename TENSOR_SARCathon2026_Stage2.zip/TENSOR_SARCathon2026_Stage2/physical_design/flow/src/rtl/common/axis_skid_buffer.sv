`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_skid_buffer
// Two-entry, fully registered valid/ready pipeline stage ("skid buffer").
//  * s_ready is a flop output (no combinational path from m_ready to s_ready),
//    and is held low while reset is asserted and for the first cycle after it.
//  * Full throughput: one transfer per cycle in steady state.
//  * AXI4-Stream compliant: m_valid/m_data are held stable while m_ready is low.
// Control flops are reset; data flops are not (saves area, no functional effect).
// -----------------------------------------------------------------------------
module axis_skid_buffer #(
    parameter int W = 8
) (
    input  wire          clk,
    input  wire          rst_n,
    input  wire [W-1:0]  s_data,
    input  wire          s_valid,
    output wire          s_ready,
    output wire [W-1:0]  m_data,
    output wire          m_valid,
    input  wire          m_ready
);
    logic [W-1:0] out_data, skid_data;
    logic         out_valid, skid_valid;
    logic         rdy_en;          // 0 in reset -> no transfer accepted during reset

    wire s_fire   = s_valid & s_ready;
    wire out_load = m_ready | ~out_valid;   // output register may take new data

    assign s_ready = rdy_en & ~skid_valid;
    assign m_valid = out_valid;
    assign m_data  = out_data;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_valid  <= 1'b0;
            skid_valid <= 1'b0;
            rdy_en     <= 1'b0;
        end else begin
            rdy_en <= 1'b1;
            if (out_load) begin
                if (skid_valid) begin
                    out_valid  <= 1'b1;    // drain parked beat (s_ready was 0)
                    skid_valid <= 1'b0;
                end else begin
                    out_valid  <= s_fire;
                end
            end else if (s_fire) begin
                skid_valid <= 1'b1;        // output stalled: park incoming beat
            end
        end
    end

    always_ff @(posedge clk) begin
        if (out_load) begin
            if (skid_valid)  out_data <= skid_data;
            else if (s_fire) out_data <= s_data;
        end else if (s_fire) begin
            skid_data <= s_data;
        end
    end
endmodule
`default_nettype wire
