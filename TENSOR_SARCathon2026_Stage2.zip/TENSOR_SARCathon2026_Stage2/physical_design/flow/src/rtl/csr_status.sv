`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// csr_status   AXI4-Lite slave: control, status, error reporting and
//              saturating event / performance counters
//
// Address map (byte offsets, 32-bit registers, addr[1:0] ignored):
//   0x00 ID          RO  32'h4158_5031 ("AXP1")
//   0x04 VERSION     RO  32'h0002_0000
//   0x08 CTRL        RW  [0] link_en (reset 1)
//                        [1] cnt_clear (write 1, self-clearing, reads 0):
//                            clears all counters, ERR_STATUS and LAST_ERR
//   0x0C STATUS      RO  [0] rx_in_pkt [1] rx_discard [2] link_en [15:8] tx_credits
//                        [16] irq (level of the irq output)
//   0x10 SCRATCH     RW  free 32-bit register (reset 0)
//   0x14 PARAMS      RO  [7:0] LANES [23:8] FIU_BYTES [31:24] LINK_W/8
//   0x18 PARAMS2     RO  [7:0] RX_BUF_DEPTH [11:8] TID_W [15:12] FEC_MODE (0 = none)
//                        [16] replay integrated (0: not implemented in the datapath)
//   0x1C SEQ_STATUS  RO  [7:0] TX next sequence number [15:8] RX expected sequence
//                        [23:16] RX last accepted sequence [24] RX accepted any FIU
//   0x20..0x6C       RO  counters 0..19, 32-bit saturating (see COUNTERS below)
//   0x70 ERR_STATUS  W1C sticky error flags (bit set by the event, cleared by
//                        writing 1; an event in the same cycle wins over the clear)
//                        [0] RX_CRC_ERR  [1] RX_FRAME_ERR  [2] RX_SEQ_ERR
//                        [3] RX_DISCARD  [4] RX_PKT_ERR    [5] IN_PROTO_ERR
//                        [6] IN_EMPTY_DROP  [7] FEC_UNCORR
//   0x74 ERR_IRQ_EN  RW  [7:0] interrupt enable per ERR_STATUS bit (reset 0)
//                        irq = |(ERR_STATUS & ERR_IRQ_EN), registered
//   0x78 LAST_ERR    RO  most recent RX error: [7:0] expected sequence number,
//                        [15:8] received sequence field, [18:16] reason
//                        (1 CRC, 2 HDR, 3 SOP_IN_PKT, 4 CONT_NO_PKT, 5 TID,
//                        6 ALIGN, 7 SEQ), [31] valid
//
// COUNTERS (index: address name)
//    0 0x20 TX_PKT        1 0x24 TX_FIU        2 0x28 RX_FIU_GOOD   3 0x2C RX_CRC_ERR
//    4 0x30 RX_FRAME_ERR  5 0x34 RX_SEQ_ERR    6 0x38 RX_DISCARD    7 0x3C RX_PKT
//    8 0x40 RX_PKT_ERR    9 0x44 IN_PROTO_ERR 10 0x48 IN_EMPTY_DROP
//   11 0x4C IN_BYTES     (tkeep bytes accepted on s_axis)
//   12 0x50 OUT_BYTES    (tkeep bytes delivered on m_axis)
//   13 0x54 IN_STALL     (cycles s_axis_tvalid=1, s_axis_tready=0)
//   14 0x58 OUT_STALL    (cycles m_axis_tvalid=1, m_axis_tready=0)
//   15 0x5C CREDIT_STALL (cycles an FIU is ready, link enabled, credits < 7)
//   16 0x60 TX_WORDS     (link words transmitted; utilisation = TX_WORDS/CYCLES)
//   17 0x64 CYCLES       (clock cycles since reset or last clear)
//   18 0x68 FEC_CORR     19 0x6C FEC_UNCORR   (FEC placeholder: always 0)
// Each counter adds an 8-bit increment per cycle (cnt_inc) with saturation.
//
// Responses: OKAY; SLVERR for unmapped addresses and for writes to RO registers
// (a write with SLVERR has no effect). WSTRB honoured on RW/W1C registers.
// AW and W may arrive in any order or together; one outstanding write and one
// outstanding read; B and R are registered. AxPROT not used.
// -----------------------------------------------------------------------------
module csr_status #(
    parameter int ADDR_W       = 8,
    parameter int NUM_CNT      = 20,
    parameter int LANES        = 4,
    parameter int FIU_BYTES    = 256,
    parameter int LINK_W       = 256,
    parameter int RX_BUF_DEPTH = 32,
    parameter int TID_W        = 1,
    parameter int FEC_MODE     = 0
) (
    input  wire                 clk,
    input  wire                 rst_n,
    // AXI4-Lite slave
    input  wire [ADDR_W-1:0]    s_axil_awaddr,
    input  wire                 s_axil_awvalid,
    output wire                 s_axil_awready,
    input  wire [31:0]          s_axil_wdata,
    input  wire [3:0]           s_axil_wstrb,
    input  wire                 s_axil_wvalid,
    output wire                 s_axil_wready,
    output logic [1:0]          s_axil_bresp,
    output logic                s_axil_bvalid,
    input  wire                 s_axil_bready,
    input  wire [ADDR_W-1:0]    s_axil_araddr,
    input  wire                 s_axil_arvalid,
    output wire                 s_axil_arready,
    output logic [31:0]         s_axil_rdata,
    output logic [1:0]          s_axil_rresp,
    output logic                s_axil_rvalid,
    input  wire                 s_axil_rready,
    // control / status
    output wire                 link_en,
    output logic                irq,
    input  wire                 st_rx_in_pkt,
    input  wire                 st_rx_discard,
    input  wire [7:0]           st_tx_credits,
    input  wire [7:0]           st_tx_next_seq,
    input  wire [7:0]           st_rx_exp_seq,
    input  wire [7:0]           st_rx_last_acc_seq,
    input  wire                 st_rx_any_acc,
    input  wire [NUM_CNT*8-1:0] cnt_inc,        // per-counter increment this cycle
    // RX error capture
    input  wire                 err_valid,
    input  wire [2:0]           err_reason,
    input  wire [7:0]           err_exp_seq,
    input  wire [7:0]           err_rx_seq
);
    localparam logic [1:0] OKAY = 2'b00, SLVERR = 2'b10;
    localparam logic [31:0] ID_VAL  = 32'h4158_5031;
    localparam logic [31:0] VER_VAL = 32'h0002_0000;
    localparam int CNT_BASE = 8;    // word index of first counter (0x20)
    localparam int W_ERRST  = 28;   // 0x70
    localparam int W_IRQEN  = 29;   // 0x74
    localparam int W_LASTER = 30;   // 0x78
    localparam int NERR     = 8;
    // counter index feeding each ERR_STATUS bit
    function automatic int err_src(input int k);
        case (k)
            0: err_src = 3;   1: err_src = 4;   2: err_src = 5;   3: err_src = 6;
            4: err_src = 8;   5: err_src = 9;   6: err_src = 10;  default: err_src = 19;
        endcase
    endfunction

    generate
        if (NUM_CNT != 20 || ADDR_W < 8) begin : g_bad_param
            illegal_parameter_combination u_illegal ();
        end
    endgenerate

    logic        ctrl_link_en;
    logic [31:0] scratch;
    logic [31:0] cnt [0:NUM_CNT-1];
    logic [NERR-1:0] err_status, irq_en;
    logic [31:0] last_err;
    assign link_en = ctrl_link_en;

    // ---------------- write channel ------------------------------------------
    logic              aw_hold, w_hold;
    logic [ADDR_W-1:0] aw_addr;
    logic [31:0]       w_data;
    logic [3:0]        w_strb;

    assign s_axil_awready = !aw_hold;
    assign s_axil_wready  = !w_hold;

    wire              do_write = aw_hold && w_hold && !s_axil_bvalid;
    wire [ADDR_W-3:0] wr_idx   = aw_addr[ADDR_W-1:2];

    function automatic [31:0] apply_strb(input [31:0] old, input [31:0] d, input [3:0] s);
        integer b;
        begin
            for (b = 0; b < 4; b = b + 1)
                apply_strb[b*8 +: 8] = s[b] ? d[b*8 +: 8] : old[b*8 +: 8];
        end
    endfunction

    // write decode: CTRL, SCRATCH, ERR_STATUS (W1C) and ERR_IRQ_EN are writable
    wire wr_is_ctrl    = (wr_idx == 2);
    wire wr_is_scratch = (wr_idx == 4);
    wire wr_is_errst   = (32'(wr_idx) == W_ERRST);
    wire wr_is_irqen   = (32'(wr_idx) == W_IRQEN);

    wire [31:0] ctrl_new  = apply_strb({30'b0, 1'b0, ctrl_link_en}, w_data, w_strb);
    wire        clear_req = do_write && wr_is_ctrl && ctrl_new[1];
    wire [31:0] w1c_mask  = apply_strb(32'h0, w_data, w_strb);      // bytes without strobe clear nothing
    wire [31:0] irqen_new = apply_strb({24'b0, irq_en}, w_data, w_strb);
    wire        unused_wr_hi = |{ctrl_new[31:2], w1c_mask[31:NERR], irqen_new[31:NERR]};  // reserved bits

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            aw_hold       <= 1'b0;
            w_hold        <= 1'b0;
            aw_addr       <= '0;
            w_data        <= '0;
            w_strb        <= '0;
            s_axil_bvalid <= 1'b0;
            s_axil_bresp  <= OKAY;
            ctrl_link_en  <= 1'b1;
            scratch       <= '0;
            irq_en        <= '0;
        end else begin
            if (s_axil_awvalid && s_axil_awready) begin aw_hold <= 1'b1; aw_addr <= s_axil_awaddr; end
            if (s_axil_wvalid  && s_axil_wready)  begin w_hold  <= 1'b1; w_data <= s_axil_wdata; w_strb <= s_axil_wstrb; end
            if (s_axil_bvalid && s_axil_bready) s_axil_bvalid <= 1'b0;
            if (do_write) begin
                aw_hold       <= 1'b0;
                w_hold        <= 1'b0;
                s_axil_bvalid <= 1'b1;
                s_axil_bresp  <= OKAY;
                if (wr_is_ctrl)          ctrl_link_en <= ctrl_new[0];
                else if (wr_is_scratch)  scratch      <= apply_strb(scratch, w_data, w_strb);
                else if (wr_is_irqen)    irq_en       <= irqen_new[NERR-1:0];
                else if (!wr_is_errst)   s_axil_bresp <= SLVERR;          // RO or unmapped
            end
        end
    end

    // ---------------- counters -------------------------------------------------
    integer c;
    logic [32:0] sum [0:NUM_CNT-1];
    always_comb begin
        for (int k = 0; k < NUM_CNT; k++) sum[k] = {1'b0, cnt[k]} + 33'(cnt_inc[k*8 +: 8]);
    end
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (c = 0; c < NUM_CNT; c = c + 1) cnt[c] <= '0;
        end else begin
            for (c = 0; c < NUM_CNT; c = c + 1) begin
                if (clear_req)      cnt[c] <= '0;
                else if (sum[c][32]) cnt[c] <= '1;              // saturate
                else                cnt[c] <= sum[c][31:0];
            end
        end
    end

    // ---------------- error status / irq / last error ----------------------------
    logic [NERR-1:0] err_set;
    always_comb begin
        for (int k = 0; k < NERR; k++) err_set[k] = |cnt_inc[err_src(k)*8 +: 8];
    end
    wire [NERR-1:0] err_clr = (do_write && wr_is_errst) ? w1c_mask[NERR-1:0] : '0;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            err_status <= '0;
            irq        <= 1'b0;
            last_err   <= '0;
        end else begin
            if (clear_req) err_status <= '0;                    // like the counters: clear wins
            else           err_status <= (err_status & ~err_clr) | err_set;
            irq        <= |(err_status & irq_en);
            if (clear_req)      last_err <= '0;
            else if (err_valid) last_err <= {1'b1, 12'b0, err_reason, err_rx_seq, err_exp_seq};
        end
    end

    // ---------------- read channel ---------------------------------------------
    wire [ADDR_W-3:0] rd_idx  = s_axil_araddr[ADDR_W-1:2];
    wire [31:0]       rd_i32  = 32'(rd_idx);
    // addr[1:0] are ignored by design (32-bit registers)
    wire unused_addr_lsb = |{s_axil_araddr[1:0], aw_addr[1:0]};
    assign s_axil_arready = !s_axil_rvalid;

    logic [31:0] rd_val;
    logic        rd_ok;
    always_comb begin
        rd_ok  = 1'b1;
        rd_val = 32'h0;
        case (rd_i32)
            0: rd_val = ID_VAL;
            1: rd_val = VER_VAL;
            2: rd_val = {30'b0, 1'b0, ctrl_link_en};
            3: rd_val = {15'b0, irq, st_tx_credits, 5'b0, ctrl_link_en, st_rx_discard, st_rx_in_pkt};
            4: rd_val = scratch;
            5: rd_val = {8'(LINK_W/8), 16'(FIU_BYTES), 8'(LANES)};
            6: rd_val = {15'b0, 1'b0, 4'(FEC_MODE), 4'(TID_W), 8'(RX_BUF_DEPTH)};
            7: rd_val = {7'b0, st_rx_any_acc, st_rx_last_acc_seq, st_rx_exp_seq, st_tx_next_seq};
            W_ERRST:  rd_val = {24'b0, err_status};
            W_IRQEN:  rd_val = {24'b0, irq_en};
            W_LASTER: rd_val = last_err;
            default: begin
                if ((rd_i32 >= CNT_BASE) && (rd_i32 < CNT_BASE + NUM_CNT))
                    rd_val = cnt[rd_i32 - CNT_BASE];
                else
                    rd_ok = 1'b0;
            end
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s_axil_rvalid <= 1'b0;
            s_axil_rdata  <= '0;
            s_axil_rresp  <= OKAY;
        end else begin
            if (s_axil_arvalid && s_axil_arready) begin
                s_axil_rvalid <= 1'b1;
                s_axil_rdata  <= rd_ok ? rd_val : 32'h0;
                s_axil_rresp  <= rd_ok ? OKAY : SLVERR;
            end else if (s_axil_rvalid && s_axil_rready) begin
                s_axil_rvalid <= 1'b0;
            end
        end
    end
endmodule
`default_nettype wire
