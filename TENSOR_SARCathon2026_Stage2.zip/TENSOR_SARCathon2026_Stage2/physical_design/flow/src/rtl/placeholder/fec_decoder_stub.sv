`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// fec_decoder_stub   (RX, between lane_de_striper_gray_decoder and fiu_link_layer)
//
// ARCHITECTURE PLACEHOLDER - NO FORWARD ERROR CORRECTION IS IMPLEMENTED.
// FEC_MODE = 0 (bypass) is the only legal value: output = input, 0 latency,
// ev_corrected = ev_uncorrectable = 0 (the CSR counters FEC_CORR / FEC_UNCORR
// therefore always read 0, which the testbench checks).
//
// Interface a real decoder must implement:
//   * o_* : corrected FIU word stream, same framing as the input
//   * ev_corrected     : 1-cycle pulse per FIU in which errors were corrected
//   * ev_uncorrectable : 1-cycle pulse per FIU with a detected uncorrectable
//                        error; the CRC check downstream still decides
//                        whether the FIU is accepted
// A real decoder needs the whole FIU before it can correct word 0, i.e. it
// adds about FIU_WORDS cycles of latency (or the RX buffer must accept a late
// correction write). See docs/fec_architecture.md.
// -----------------------------------------------------------------------------
module fec_decoder_stub #(
    parameter int LINK_W   = 256,
    parameter int FEC_MODE = 0          // 0 = bypass (only legal value)
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire [LINK_W-1:0]  i_data,
    input  wire               i_valid,
    input  wire               i_sof,
    output wire [LINK_W-1:0]  o_data,
    output wire               o_valid,
    output wire               o_sof,
    output wire               ev_corrected,
    output wire               ev_uncorrectable
);
    generate
        if (FEC_MODE != 0) begin : g_not_implemented
            fec_mode_not_implemented u_illegal ();
        end
    endgenerate

    assign o_data           = i_data;
    assign o_valid          = i_valid;
    assign o_sof            = i_sof;
    assign ev_corrected     = 1'b0;
    assign ev_uncorrectable = 1'b0;
    wire unused_clk_rst = clk | rst_n;     // reserved for a pipelined decoder
endmodule
`default_nettype wire
