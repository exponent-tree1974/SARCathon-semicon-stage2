`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// fec_encoder_stub   (TX, between fiu_link_layer and lane_striper_gray_mapper)
//
// ARCHITECTURE PLACEHOLDER - NO FORWARD ERROR CORRECTION IS IMPLEMENTED.
// FEC_MODE = 0 (bypass) is the only legal value: output = input, 0 latency.
// Any other FEC_MODE stops elaboration, so a build cannot silently claim FEC.
//
// The module fixes the interface a real encoder must implement:
//   * input  : one FIU word per cycle, i_sof marks word 0 of an FIU
//   * output : same word stream; a real encoder writes its check bytes into
//              the FIU before the CRC/FEC-protected word leaves the block
//              (the FIU trailer has 22 reserved bytes, bits [LINK_W-33:48])
//   * latency: 0 cycles for bypass (a real encoder may add a fixed latency); flow control is the caller's
//              (the link layer never stalls a started FIU)
// See docs/fec_architecture.md for the intended code and the verification plan.
// -----------------------------------------------------------------------------
module fec_encoder_stub #(
    parameter int LINK_W   = 256,
    parameter int FEC_MODE = 0          // 0 = bypass (only legal value)
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire [LINK_W-1:0]  i_data,
    input  wire               i_valid,
    input  wire               i_sof,
    output wire [LINK_W-1:0]  o_data,
    output wire               o_valid,
    output wire               o_sof
);
    generate
        if (FEC_MODE != 0) begin : g_not_implemented
            fec_mode_not_implemented u_illegal ();
        end
    endgenerate

    assign o_data  = i_data;
    assign o_valid = i_valid;
    assign o_sof   = i_sof;
    wire unused_clk_rst = clk | rst_n;     // reserved for a pipelined encoder
endmodule
`default_nettype wire
