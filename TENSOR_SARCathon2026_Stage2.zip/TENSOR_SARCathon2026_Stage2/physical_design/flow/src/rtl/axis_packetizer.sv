`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_packetizer
// Segments the normalised AXIS beat stream (AXIS_W bits/beat) into FIU payload
// words of LINK_W bits. Each FIU carries PW = FIU_WORDS-1 payload words; the
// final FIU word (the trailer) is added by fiu_link_layer.
//
//  * Width conversion AXIS_W -> LINK_W (R = AXIS_W/LINK_W words per beat).
//  * A packet larger than one FIU payload spans consecutive FIUs (no clipping).
//  * A new packet always starts a new FIU. After a packet ends inside an FIU the
//    remaining payload slots are zero-padded (p_nbytes = 0).
//  * Per-FIU metadata (sop/eop/len/err/tid) is valid on the p_end word.
//  * p_tid is the stream ID of the packet carried by the FIU: sampled from
//    i_tid on the packet's first beat and held for all its FIUs.
//
// Throughput: one LINK_W word per cycle whenever p_ready is high; ingress
// supplies up to R words per cycle, so the link side is the bottleneck.
// -----------------------------------------------------------------------------
module axis_packetizer #(
    parameter int AXIS_W    = 512,
    parameter int LINK_W    = 256,
    parameter int FIU_BYTES = 256,
    parameter int TID_W     = 1
) (
    input  wire                                clk,
    input  wire                                rst_n,
    // Normalised beats from axis_packet_ingress
    input  wire [AXIS_W-1:0]                   i_data,
    input  wire [$clog2(AXIS_W/8+1)-1:0]       i_nbytes,
    input  wire                                i_last,
    input  wire                                i_err,
    input  wire [TID_W-1:0]                    i_tid,
    input  wire                                i_valid,
    output wire                                i_ready,
    // FIU payload word stream to fiu_link_layer
    output wire [LINK_W-1:0]                   p_data,
    output wire [$clog2(LINK_W/8+1)-1:0]       p_nbytes,  // valid bytes in this word
    output wire                                p_valid,
    input  wire                                p_ready,
    output wire                                p_first,   // FIU payload word 0
    output wire                                p_end,     // FIU payload word PW-1
    output wire                                p_sop,     // FIU starts a packet   (valid with p_end)
    output wire                                p_eop,     // FIU ends a packet     (valid with p_end)
    output wire                                p_err,     // poison flag           (valid with p_end)
    output wire [15:0]                         p_len,     // payload bytes in FIU  (valid with p_end)
    output wire [TID_W-1:0]                    p_tid,     // stream ID of the FIU  (valid with p_end)
    // Status event
    output logic                               ev_tx_pkt
);
    localparam int LB        = LINK_W / 8;
    localparam int AB        = AXIS_W / 8;
    localparam int R         = AXIS_W / LINK_W;
    localparam int FIU_WORDS = FIU_BYTES / LB;
    localparam int PW        = FIU_WORDS - 1;
    localparam int SUB_W     = (R  > 1) ? $clog2(R)  : 1;
    localparam int WIDX_W    = (PW > 1) ? $clog2(PW) : 1;
    localparam int ANB_W     = $clog2(AB + 1);
    localparam int LNB_W     = $clog2(LB + 1);
    localparam int BW     = ANB_W + 1;
    localparam logic [LNB_W-1:0] LB_NB = LNB_W'(LB);
    localparam logic [BW-1:0]    LB_BW = BW'(LB);

    // ---- parameter legality (elaboration fails on an illegal set) ------------
    generate
        if ((AXIS_W % LINK_W) != 0 || (FIU_BYTES % LB) != 0 || FIU_WORDS < 2)
            begin : g_bad_param
                illegal_parameter_combination u_illegal ();
            end
    endgenerate

    logic [SUB_W-1:0]  sub;        // which LINK_W slice of the current beat
    logic [WIDX_W-1:0] widx;       // payload word index inside the FIU
    logic              pad;        // padding remainder of FIU after packet end
    logic              in_pkt;     // a packet is open (words sent, no eop yet)
    logic              fiu_sop_r, fiu_err_r;
    logic [15:0]       fiu_len_r;
    logic [TID_W-1:0]  pkt_tid_r, fiu_tid_r;   // tid of open packet / of current FIU

    // bytes remaining in the beat from this slice onward
    logic [ANB_W:0]    base_b, rem_b;
    logic [LNB_W-1:0]  word_nb;
    logic              beat_done;  // this slice is the last one of the beat

    always_comb begin
        base_b    = BW'(sub) * LB_BW;
        rem_b     = ({1'b0, i_nbytes} > base_b) ? ({1'b0, i_nbytes} - base_b) : '0;
        word_nb   = (rem_b >= LB_BW) ? LB_NB : LNB_W'(rem_b);
        beat_done = (sub == SUB_W'(R - 1)) || ({1'b0, i_nbytes} <= base_b + LB_BW);
    end

    wire pkt_end_here = !pad && i_last && beat_done;

    // bytes beyond word_nb (outside the source tkeep) are zeroed so FIU content
    // is deterministic and no stale source bytes are sent on the link
    logic [LINK_W-1:0] slice, byte_mask;
    always_comb begin
        slice = i_data[sub*LINK_W +: LINK_W];                     // sub < R by construction
        for (int b = 0; b < LB; b++) byte_mask[b*8 +: 8] = {8{LNB_W'(b) < word_nb}};
    end

    assign p_valid  = pad || i_valid;
    assign p_data   = pad ? '0 : (slice & byte_mask);
    assign p_nbytes = pad ? '0 : word_nb;
    assign p_first  = (widx == '0);
    assign p_end    = (widx == WIDX_W'(PW - 1));
    assign p_sop    = p_first ? !in_pkt : fiu_sop_r;
    assign p_eop    = pad || pkt_end_here;
    assign p_err    = fiu_err_r || (!pad && i_err);
    assign p_len    = fiu_len_r + 16'(p_nbytes);
    wire [TID_W-1:0] cur_tid = in_pkt ? pkt_tid_r : i_tid;   // used on the FIU's first word
    assign p_tid    = p_first ? cur_tid : fiu_tid_r;

    wire p_fire = p_valid && p_ready;
    assign i_ready = p_fire && !pad && beat_done;   // consume beat after its last slice

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sub       <= '0;
            widx      <= '0;
            pad       <= 1'b0;
            in_pkt    <= 1'b0;
            fiu_sop_r <= 1'b0;
            fiu_err_r <= 1'b0;
            fiu_len_r <= '0;
            pkt_tid_r <= '0;
            fiu_tid_r <= '0;
            ev_tx_pkt <= 1'b0;
        end else begin
            ev_tx_pkt <= p_fire && pkt_end_here;
            if (p_fire) begin
                if (p_first) begin
                    fiu_sop_r <= !in_pkt;
                    fiu_tid_r <= cur_tid;
                end
                if (!pad && !in_pkt) pkt_tid_r <= i_tid;     // first word of a packet
                if (!pad) begin
                    sub    <= beat_done ? '0 : sub + 1'b1;
                    in_pkt <= !pkt_end_here;
                end
                if (p_end) begin
                    widx      <= '0;
                    pad       <= 1'b0;
                    fiu_len_r <= '0;
                    fiu_err_r <= 1'b0;
                end else begin
                    widx      <= widx + 1'b1;
                    fiu_len_r <= p_len;
                    fiu_err_r <= p_err;
                    if (pkt_end_here) pad <= 1'b1;
                end
            end
        end
    end
endmodule
`default_nettype wire
