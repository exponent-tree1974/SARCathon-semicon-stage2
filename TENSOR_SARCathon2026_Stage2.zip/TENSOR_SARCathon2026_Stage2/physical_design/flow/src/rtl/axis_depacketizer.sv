`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_depacketizer
// Reads committed LINK_W words from fiu_rx_buffer and rebuilds AXI4-Stream
// beats of AXIS_W bits (R = AXIS_W/LINK_W words per beat).
//
// Beat formation (lookahead rule):
//   * scan the first R committed entries for the first entry with last=1;
//     if found at k -> emit a tlast beat of k+1 words.
//   * else emit R full words, but ONLY if at least R+1 entries are committed,
//     i.e. the word following the beat is already known. This guarantees an
//     abort (fiu_rx_buffer patches the newest committed entry) can still turn
//     the final word of an interrupted packet into a tlast beat.
//
// Output: registered AXIS master. tkeep is contiguous from bit 0; tuser[0]=1
// on the tlast beat marks a packet that was aborted or carried an ingress
// protocol error. Data bytes outside tkeep are driven to zero.
// m_axis_tid: stream ID of the packet, taken from the buffer entry that starts
// the packet and held constant for all its beats.
// -----------------------------------------------------------------------------
module axis_depacketizer #(
    parameter int AXIS_W = 512,
    parameter int LINK_W = 256,
    parameter int PTR_W  = 6,
    parameter int TID_W  = 1
) (
    input  wire                                         clk,
    input  wire                                         rst_n,
    // fiu_rx_buffer read port
    input  wire [PTR_W-1:0]                             b_count,
    input  wire [AXIS_W-1:0]                            b_data,   // R entries
    input  wire [(AXIS_W/LINK_W)*$clog2(LINK_W/8+1)-1:0] b_nb,
    input  wire [AXIS_W/LINK_W-1:0]                     b_last,
    input  wire [AXIS_W/LINK_W-1:0]                     b_err,
    input  wire [TID_W-1:0]                             b_tid,    // tid on entry 0
    output wire [$clog2(AXIS_W/LINK_W+1)-1:0]           b_pop,
    // AXI4-Stream master
    output wire [AXIS_W-1:0]                            m_axis_tdata,
    output wire [AXIS_W/8-1:0]                          m_axis_tkeep,
    output wire                                         m_axis_tlast,
    output wire                                         m_axis_tuser,
    output wire [TID_W-1:0]                             m_axis_tid,
    output wire                                         m_axis_tvalid,
    input  wire                                         m_axis_tready,
    // status events
    output logic                                        ev_rx_pkt,
    output logic                                        ev_rx_pkt_err
);
    localparam int R      = AXIS_W / LINK_W;
    localparam int LB     = LINK_W / 8;
    localparam int LNB_W  = $clog2(LB + 1);
    localparam int POP_W  = $clog2(R + 1);

    // ---------------- beat formation -----------------------------------------
    logic [POP_W-1:0]    take;
    logic                beat_last, beat_err, found;
    logic [AXIS_W-1:0]   beat_data;
    logic [AXIS_W/8-1:0] beat_keep;

    always_comb begin
        found     = 1'b0;
        take      = '0;
        beat_last = 1'b0;
        for (int k = 0; k < R; k++) begin
            if (!found && (b_count > PTR_W'(k)) && b_last[k]) begin
                found     = 1'b1;
                take      = POP_W'(k + 1);
                beat_last = 1'b1;
            end
        end
        if (!found && (b_count > PTR_W'(R))) take = POP_W'(R);

        beat_err  = 1'b0;
        beat_data = '0;
        beat_keep = '0;
        for (int k = 0; k < R; k++) begin
            if (POP_W'(k) < take) begin
                beat_data[k*LINK_W +: LINK_W] = b_data[k*LINK_W +: LINK_W];
                beat_err = beat_err | b_err[k];
                for (int b = 0; b < LB; b++)
                    beat_keep[k*LB + b] = (LNB_W'(b) < b_nb[k*LNB_W +: LNB_W]);
            end
        end
        // zero data bytes outside tkeep
        for (int b = 0; b < AXIS_W/8; b++)
            if (!beat_keep[b]) beat_data[b*8 +: 8] = 8'h00;
    end

    // ---------------- output register -----------------------------------------
    logic                out_valid, out_last, out_user, pkt_err;
    logic                in_pkt;           // a beat of the current packet has been loaded
    logic [TID_W-1:0]    out_tid, pkt_tid;
    wire  [TID_W-1:0]    beat_tid = in_pkt ? pkt_tid : b_tid;
    logic [AXIS_W-1:0]   out_data;
    logic [AXIS_W/8-1:0] out_keep;

    wire load   = (take != '0) && (!out_valid || m_axis_tready);
    wire m_fire = out_valid && m_axis_tready;
    assign b_pop = load ? take : '0;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_valid     <= 1'b0;
            out_last      <= 1'b0;
            out_user      <= 1'b0;
            out_keep      <= '0;
            pkt_err       <= 1'b0;
            in_pkt        <= 1'b0;
            pkt_tid       <= '0;
            out_tid       <= '0;
            ev_rx_pkt     <= 1'b0;
            ev_rx_pkt_err <= 1'b0;
        end else begin
            ev_rx_pkt     <= m_fire && out_last;
            ev_rx_pkt_err <= m_fire && out_last && out_user;
            if (load) begin
                out_valid <= 1'b1;
                out_last  <= beat_last;
                out_user  <= beat_last && (pkt_err || beat_err);
                out_keep  <= beat_keep;
                pkt_err   <= beat_last ? 1'b0 : (pkt_err || beat_err);
                out_tid   <= beat_tid;
                pkt_tid   <= beat_tid;
                in_pkt    <= !beat_last;
            end else if (m_fire) begin
                out_valid <= 1'b0;
            end
        end
    end

    always_ff @(posedge clk) begin
        if (load) out_data <= beat_data;
    end

    assign m_axis_tdata  = out_data;
    assign m_axis_tkeep  = out_keep;
    assign m_axis_tlast  = out_last;
    assign m_axis_tuser  = out_user;
    assign m_axis_tid    = out_tid;
    assign m_axis_tvalid = out_valid;
endmodule
`default_nettype wire
