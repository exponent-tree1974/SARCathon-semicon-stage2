`timescale 1ns/1ps
`default_nettype none
// -----------------------------------------------------------------------------
// axis_rr_arbiter   N-input AXI4-Stream packet arbiter, round robin
//
//  * Packet atomicity: once a source is selected, the selection is held from
//    the first presented beat until its tlast beat is accepted. Packets from
//    different sources are never interleaved on the output.
//  * Output stability: the selection is also frozen while the output beat is
//    presented and not yet accepted (tvalid/tdata never change without a
//    handshake, provided every source obeys AXI4-Stream).
//  * Round robin, per packet: after a packet from source k ends, sources are
//    searched in the order k+1, k+2, ... k. With all sources busy, every source
//    gets one packet in every N packets; a requesting source waits for at most
//    N-1 packets of other sources (starvation-free for finite packets).
//    Fairness is per packet, not per byte (documented trade-off).
//  * Zero-bubble: a newly selected source passes its first beat in the same
//    cycle; consecutive packets from different sources need no idle cycle.
//  * m_tid = index of the source that owns the current packet.
//  * Purely combinational datapath (mux); the only state is lock/grant/last.
//    s_tready[i] is m_tready gated by the selection, so the downstream ready
//    should be a register output (axis_pcie_link_top's s_axis_tready is).
//
// Formal properties (sim/formal/axis_rr_arbiter_props.sv, proved with Yosys
// k-induction) and simulation checks (tb/arb) cover atomicity, no output
// without a valid input, beat conservation, output stability and the
// round-robin hand-over.
// -----------------------------------------------------------------------------
module axis_rr_arbiter #(
    parameter int N      = 2,
    parameter int DATA_W = 512,
    parameter int KEEP_W = DATA_W / 8,
    parameter int ID_W   = (N > 1) ? $clog2(N) : 1
) (
    input  wire                     clk,
    input  wire                     rst_n,
    // N slave ports, flattened: port i = bits [i*W +: W]
    input  wire [N*DATA_W-1:0]      s_tdata,
    input  wire [N*KEEP_W-1:0]      s_tkeep,
    input  wire [N-1:0]             s_tlast,
    input  wire [N-1:0]             s_tvalid,
    output logic [N-1:0]            s_tready,
    // master port
    output wire [DATA_W-1:0]        m_tdata,
    output wire [KEEP_W-1:0]        m_tkeep,
    output wire                     m_tlast,
    output wire [ID_W-1:0]          m_tid,
    output wire                     m_tvalid,
    input  wire                     m_tready,
    // observability: 1-cycle pulse when source i starts a packet (first beat accepted)
    output logic [N-1:0]            ev_pkt_start
);
    generate
        if (N < 2 || (1 << ID_W) < N) begin : g_bad_param
            illegal_parameter_combination u_illegal ();
        end
    endgenerate

    logic            locked;        // selection frozen (packet in progress or beat presented)
    logic [ID_W-1:0] grant;         // selected source while locked
    logic [ID_W-1:0] last;          // source of the most recently completed packet
    logic [ID_W-1:0] pick, sel;
    logic            found;

    // round-robin search starting after 'last'
    always_comb begin
        pick  = last;
        found = 1'b0;
        for (int k = 1; k <= N; k++) begin
            logic [ID_W-1:0] cand;
            cand = ID_W'((32'(last) + k) % N);
            if (!found && s_tvalid[cand]) begin
                pick  = cand;
                found = 1'b1;
            end
        end
        sel = locked ? grant : pick;
    end

    assign m_tvalid = s_tvalid[sel];      // unlocked: pick is a valid source whenever any is valid
    assign m_tdata  = s_tdata[sel*DATA_W +: DATA_W];
    assign m_tkeep  = s_tkeep[sel*KEEP_W +: KEEP_W];
    assign m_tlast  = s_tlast[sel];
    assign m_tid    = sel;

    always_comb begin
        for (int i = 0; i < N; i++) s_tready[i] = m_tready && (sel == ID_W'(i));
    end

    wire m_fire = m_tvalid && m_tready;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            locked <= 1'b0;
            grant  <= '0;
            last   <= ID_W'(N - 1);           // first search starts at source 0
        end else if (!locked) begin
            if (m_tvalid) begin
                grant <= pick;
                if (m_fire && m_tlast) last   <= pick;     // single-beat packet done
                else                   locked <= 1'b1;     // hold until tlast accepted
            end
        end else if (m_fire && m_tlast) begin
            locked <= 1'b0;
            last   <= grant;
        end
    end

    // packet-start events: first accepted beat of every packet
    logic mid_pkt;                            // a beat of the current packet was accepted
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mid_pkt      <= 1'b0;
            ev_pkt_start <= '0;
        end else begin
            ev_pkt_start <= '0;
            if (m_fire) begin
                mid_pkt <= !m_tlast;
                if (!mid_pkt) ev_pkt_start[sel] <= 1'b1;
            end
        end
    end

`ifdef FORMAL
    // ---------------- embedded formal properties (see sim/formal) -------------
    // mid_pkt is the port-level "packet in progress" state: set by an accepted
    // non-tlast beat, cleared by an accepted tlast beat.
    reg              f_past = 1'b0;
    reg [ID_W-1:0]   f_src;               // source of the packet in progress
    always @(posedge clk) begin
        f_past <= 1'b1;
        if (m_fire && !mid_pkt) f_src <= sel;
    end
    always @(*) if (f_past && rst_n) begin
        // P4 packet atomicity: inside a packet the selection is the packet's source
        if (mid_pkt) assert (locked && grant == f_src);
        if (m_fire && mid_pkt) assert (sel == f_src);
        // a frozen selection outside a packet always belongs to a presented beat
        if (locked && !mid_pkt) assert (s_tvalid[grant]);
        // P6 work conservation: outside a packet any valid input is presented
        if (!mid_pkt && (s_tvalid != '0)) assert (m_tvalid);
    end
`endif
endmodule
`default_nettype wire
