# Netgen LVS: Magic-extracted layout SPICE vs OpenROAD powered Verilog netlist.
# Mirrors LibreLane 3.0.16 Netgen.LVS (steps/netgen.py, Apache-2.0):
#   circuit1 = layout spice; circuit2 = cell spice + powered verilog;
#   setup = PDK sky130A_setup.tcl; `lvs ... -blackbox -json`.
# Run: netgen -batch source flow/netgen/lvs.tcl
# Env: LAYOUT_SPICE PG_NETLIST CELL_SPICE NETGEN_SETUP DESIGN_NAME OUT_DIR
set circuit1 [readnet spice $::env(LAYOUT_SPICE)]
set circuit2 [readnet verilog /dev/null]
foreach f $::env(CELL_SPICE) { readnet spice $f $circuit2 }
readnet verilog $::env(PG_NETLIST) $circuit2
lvs "$circuit1 $::env(DESIGN_NAME)" "$circuit2 $::env(DESIGN_NAME)" \
    $::env(NETGEN_SETUP) $::env(OUT_DIR)/netgen_lvs.rpt -blackbox -json
quit
