# Netgen setup wrapper (adapted from LibreLane 3.0.16 scripts/netgen/setup.tcl,
# Apache-2.0). Sources the PDK setup (device classes, ignores fill/tap cells),
# then equates Magic's prefixed cell names with the netlist names.
source $::env(PDK_NETGEN_SETUP)

foreach cell $cells1 {
    set layout $cell
    while {[regexp {([A-Z][A-Z0-9]_)(.*)} $layout match prefix cellname]} {
        if {([lsearch $cells2 $cell] < 0) && ([lsearch $cells2 $cellname] >= 0)} {
            equate classes "-circuit2 $cellname" "-circuit1 $cell"
            puts stdout "Custom: Equating $cell in circuit 1 and $cellname in circuit 2"
        }
        set layout $cellname
    }
}
