# Step 3 - clock tree synthesis + setup/hold repair with propagated clock.
source [file join [file dirname [info script]] common.tcl]
load_step 2_place.odb

repair_clock_inverters
clock_tree_synthesis -root_buf [env_req CTS_ROOT_BUF] -buf_list [env_req CTS_BUF_LIST] \
    -sink_clustering_enable -repair_clock_nets
set_propagated_clock [all_clocks]
estimate_parasitics -placement
detailed_placement

report_clock_skew > $::PNR_RPT/cts_skew.rpt
report_clock_min_period > $::PNR_RPT/cts_min_period.rpt

repair_timing -setup -hold -hold_margin 0.05 -verbose
detailed_placement
check_placement -verbose
estimate_parasitics -placement
timing_snapshot cts
save_step 3_cts
puts "FLOW_STEP_OK cts"
