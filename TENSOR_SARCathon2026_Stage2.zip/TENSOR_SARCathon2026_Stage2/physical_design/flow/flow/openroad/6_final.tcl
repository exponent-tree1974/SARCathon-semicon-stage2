# Step 6 - parasitic extraction (OpenRCX), sign-off-style reports, final outputs.
source [file join [file dirname [info script]] common.tcl]
load_step 5c_antenna_cleanup.odb
set_propagated_clock [all_clocks]

# ---- extraction (single nominal RC corner from the platform rules file) -----
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file [env_req RCX_RULES]
write_spef $::PNR_DIR/6_final.spef
read_spef $::PNR_DIR/6_final.spef
timing_snapshot final

# ---- power grid IR drop (static, vectorless current estimate) ----------------
set_pdnsim_net_voltage -net VDD -voltage 1.8
analyze_power_grid -net VDD -error_file $::PNR_RPT/irdrop_VDD.rpt
set_pdnsim_net_voltage -net VSS -voltage 0.0
analyze_power_grid -net VSS -error_file $::PNR_RPT/irdrop_VSS.rpt

report_power > $::PNR_RPT/final_power_vectorless.rpt
# report_cell_usage is an OpenROAD command: no "> file" redirection (OpenSTA reports only)
sta::redirect_file_begin $::PNR_RPT/final_cell_usage.rpt
report_cell_usage -verbose
sta::redirect_file_end

# ---- final views ---------------------------------------------------------------
save_step 6_final
write_def $::PNR_DIR/6_final.def
# logical netlist without physical-only cells (taps/fill/decap) - for STA / GLS
write_verilog $::PNR_DIR/6_final.v
# netlist with power pins - for LVS
write_verilog -include_pwr_gnd $::PNR_DIR/6_final_pg.v
puts "FLOW_STEP_OK finish"
