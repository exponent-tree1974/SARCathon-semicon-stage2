# Step 1 - floorplan: die/core, rows, tracks, pins, tie cells, taps, PDN.
source [file join [file dirname [info script]] common.tcl]

read_lef [env_req TECH_LEF]
read_lef [env_req SC_LEF]
read_liberty [env_req LIB_TT]
read_verilog [env_req SYNTH_NETLIST]
link_design [env_req DESIGN_NAME]
read_sdc [env_req SDC_FILE]
source [env_req PLATFORM_DIR]/setRC.tcl
set_dont_use [env_req DONT_USE_CELLS]

puts "== check_setup (synthesised netlist + SDC)"
check_setup -verbose

# ---- die / core (absolute; see docs/floorplan_assumptions.md) ----------------
lassign [env_req DIE_AREA] x0 y0 x1 y1
set m [env_req CORE_MARGIN_UM]
initialize_floorplan -die_area [list $x0 $y0 $x1 $y1] \
    -core_area [list [expr {$x0+$m}] [expr {$y0+$m}] [expr {$x1-$m}] [expr {$y1-$m}]] \
    -site [env_req PLACE_SITE]
source [env_req PLATFORM_DIR]/make_tracks.tcl

# routing layer ranges used by GRT/DRT (platform defaults: met1..met5, clock met3..met5)
source [env_req PLATFORM_DIR]/fastroute.tcl

# ---- utilisation gate --------------------------------------------------------
set cell_a [inst_area_um2]
set core_a [core_area_um2]
set util [expr {100.0 * $cell_a / $core_a}]
metric floorplan synth_cell_area_um2 [format %.1f $cell_a]
metric floorplan core_area_um2 [format %.1f $core_a]
metric floorplan die_area_um2 [format %.1f [die_area_um2]]
metric floorplan core_util_pct [format %.2f $util]
puts [format "FLOORPLAN: cell area %.1f um^2, core %.1f um^2, utilisation %.2f %%" $cell_a $core_a $util]
if {$util > 70.0} {
  utl::error FLW 2 [format "core utilisation %.1f %% > 70 %% - enlarge DIE_AREA in design.mk" $util]
}

# ---- tie cells: one per fanout cluster instead of one global tie -------------
repair_tie_fanout -separation 5 "sky130_fd_sc_hd__tt_025C_1v80/[env_req TIELO_CELL]/[env_req TIELO_PORT]"
repair_tie_fanout -separation 5 "sky130_fd_sc_hd__tt_025C_1v80/[env_req TIEHI_CELL]/[env_req TIEHI_PORT]"

# ---- pins ---------------------------------------------------------------------
source [file join [file dirname [info script]] .. constraints io_pins.tcl]
place_pins -hor_layers [env_req IO_H_LAYER] -ver_layers [env_req IO_V_LAYER] \
    -corner_avoidance 15 -min_distance 2 -min_distance_in_tracks
write_pin_placement $::PNR_RPT/pin_placement.tcl

# ---- well taps + power grid (platform scripts) --------------------------------
tapcell -distance 14 -tapcell_master [env_req TAP_CELL]
source [env_req PLATFORM_DIR]/pdn.tcl
pdngen
check_placement -fixed -verbose

report_design_area
save_step 1_floorplan
write_def $::PNR_DIR/1_floorplan.def
puts "FLOW_STEP_OK floorplan"
