# Step 4 - global routing, post-GRT repair, antenna repair.
source [file join [file dirname [info script]] common.tcl]
load_step 3_cts.odb
set_propagated_clock [all_clocks]
source [env_req PLATFORM_DIR]/fastroute.tcl

pin_access
global_route -congestion_iterations 30 \
    -congestion_report_file $::PNR_RPT/grt_congestion.rpt -verbose
estimate_parasitics -global_routing
timing_snapshot grt_pre_repair

# incremental repair with global-route parasitics
repair_design -verbose -slew_margin [env_req SLEW_MARGIN_PCT] -cap_margin [env_req CAP_MARGIN_PCT]
repair_timing -setup -hold -hold_margin 0.05 -verbose
global_route -start_incremental
detailed_placement
global_route -end_incremental -congestion_report_file $::PNR_RPT/grt_congestion_post_repair.rpt
estimate_parasitics -global_routing

# antenna repair with diodes (sky130_fd_sc_hd__diode_2)
repair_antennas sky130_fd_sc_hd__diode_2 -iterations 3
check_antennas -report_file $::PNR_RPT/grt_antennas.rpt
check_placement -verbose
timing_snapshot grt
save_step 4_grt
puts "FLOW_STEP_OK grt"
