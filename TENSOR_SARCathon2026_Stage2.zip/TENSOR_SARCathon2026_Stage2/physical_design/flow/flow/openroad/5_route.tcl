# Step 5 - detailed routing, fill, antenna check.
source [file join [file dirname [info script]] common.tcl]
load_step 4_grt.odb
set_propagated_clock [all_clocks]
set_thread_count [env_req NUM_CORES]
# routing layer ranges (signal met1..met5, clock met3..met5) from the platform
source [env_req PLATFORM_DIR]/fastroute.tcl

detailed_route \
    -output_drc $::PNR_RPT/drt_drc.rpt \
    -output_maze $::PNR_DIR/drt_maze.log \
    -droute_end_iter 64 -drc_report_iter_step 8 -verbose 1

check_antennas -report_file $::PNR_RPT/drt_antennas.rpt
filler_placement [env_req FILL_CELLS]
check_placement -verbose
if {![grt::have_routes]} { utl::error FLW 3 "no routes after detailed routing" }
save_step 5_route
write_def $::PNR_DIR/5_route.def
puts "FLOW_STEP_OK drt"
