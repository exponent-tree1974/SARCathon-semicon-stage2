# Step 2 - placement: global placement, electrical repair, detailed placement.
source [file join [file dirname [info script]] common.tcl]
load_step 1_floorplan.odb

# Port buffering (ORFS default, global_place.tcl): one buffer per input and
# output port, so port nets can be repaired like any other net. Without it,
# repair_design cannot fix fanout on nets driven straight from input ports
# (attempt 1: 26 input ports with fanout 17-29 > 16 left after routing).
# The buffer cell is given explicitly: left to choose, buffer_ports picked
# sky130_fd_sc_hd__clkdlybuf4s50_1 (a clock DELAY buffer; LibreLane lists all
# clkdlybuf4* cells in no_synth.cells) - logs/2_place_attempt_clkdlybuf_ABORTED.log.
buffer_ports -buffer_cell [env_req PORT_BUFFER_CELL]

# timing-driven + routability-driven global placement
global_placement -density [env_req PLACE_DENSITY] -timing_driven -routability_driven \
    -pad_left 0 -pad_right 0
estimate_parasitics -placement
timing_snapshot place_gp

# buffer long nets, fix max slew / cap / fanout, resize
repair_design -verbose -slew_margin [env_req SLEW_MARGIN_PCT] -cap_margin [env_req CAP_MARGIN_PCT]
# setup repair at placement (hold is repaired after CTS)
repair_timing -setup -verbose
detailed_placement
optimize_mirroring
check_placement -verbose
estimate_parasitics -placement
report_floating_nets -verbose
timing_snapshot place
save_step 2_place
puts "FLOW_STEP_OK place"
