# Step 5c - targeted antenna ECO; runs only if step 5b left violations.
#
# Step 5b stops after MAX_REPAIR_ANTENNAS_ITER_DRT (5) diode rounds, as ORFS does.
# In attempt 1 (build/<tag>_attempt1) it left one net: net8366 -> ff_12401/D,
# met1 side-area ratio 460 vs 400. That net already had 5 diodes, placed to
# the RIGHT of the flop. The D pin is at the flop's left edge and the driver is
# 265 um to the left, so the violating met1 island never reaches them. In the
# recorded run 5b left 2 nets; one of them, on met5, needed several diodes.
#
# Attempts in attempt 1 that did NOT remove the violation (logs in build/<tag>_attempt1/logs/):
#  1. repair_antennas -ratio_margin 30 (5c_attempt1_ratio_margin30_ABORTED.log):
#     the margin applies to EVERY net - 2,036 diodes, and the re-route raised
#     the count to 30 violating nets; stopped.
#  2. repair_antennas -jumper_only, then 2 default rounds
#     (5c_attempt2_jumper_default.log): no jumper inserted, and each default
#     round added a diode with no effect; still 1 net.
# This step instead places diodes immediately LEFT of each violating gate
# (flow/openroad/lib/eco_antenna_diode.tcl), then legalises and re-routes
# incrementally: up to 4 rounds of 1, 2, 4 and 8 diodes per still-violating net.
source [file join [file dirname [info script]] common.tcl]
source [file join [file dirname [info script]] lib eco_antenna_diode.tcl]
load_step 5b_antenna.odb
set_propagated_clock [all_clocks]
set_thread_count [env_req NUM_CORES]
source [env_req PLATFORM_DIR]/fastroute.tcl

set rpt0 $::PNR_RPT/drt_antennas_before_cleanup.rpt
set before [check_antennas -report_file $rpt0]
puts "ANTENNA_NETS_BEFORE_CLEANUP $before"
metric antenna_cleanup nets_before $before
# rounds of 1, 2, 4, 8 diodes per still-violating net (one diode was not
# enough for a met5 net in the recorded run: side-area ratio 3519 vs 3126)
set added 0
set round 0
set rpt $rpt0
set n $before
while {$n > 0 && $round < 4} {
  incr round
  set per [expr {1 << ($round - 1)}]
  puts "ANTENNA_CLEANUP_ROUND $round ($per diode(s) per violating net)"
  remove_fillers
  global_route -start_incremental
  incr added [eco_antenna_diodes $rpt sky130_fd_sc_hd__diode_2 $per $round]
  detailed_placement
  check_placement -verbose
  global_route -end_incremental
  detailed_route -output_drc $::PNR_RPT/drt_drc_post_cleanup.rpt -droute_end_iter 64 -verbose 1
  filler_placement [env_req FILL_CELLS]
  check_placement -verbose
  set rpt $::PNR_RPT/drt_antennas_cleanup_round$round.rpt
  set n [check_antennas -report_file $rpt]
  puts "ANTENNA_NETS_AFTER_ROUND $round: $n"
}
set after [check_antennas -report_file $::PNR_RPT/drt_antennas.rpt]
puts "ANTENNA_NETS_AFTER_CLEANUP $after (rounds: $round, eco diodes: $added)"
metric antenna_cleanup rounds $round
metric antenna_cleanup eco_diodes $added
metric antenna_cleanup nets_after $after
if {![grt::have_routes]} { utl::error FLW 5 "no routes after antenna clean-up" }
save_step 5c_antenna_cleanup
puts "FLOW_STEP_OK antenna_cleanup"
