# Step 5b - post-detailed-route antenna repair (same loop as ORFS detail_route.tcl,
# MAX_REPAIR_ANTENNAS_ITER_DRT = 5): insert diodes, re-route incrementally,
# repeat while check_antennas still reports violations. Then filler cells.
#
# Added after the recorded run's step 5 reported 295 antenna nets / 348 pins
# after detailed routing (logs/5_route.log, ANT-0002/ANT-0001). Step 5 places
# fillers; they are removed here first so diodes can be legalised.
source [file join [file dirname [info script]] common.tcl]
load_step 5_route.odb
set_propagated_clock [all_clocks]
set_thread_count [env_req NUM_CORES]
source [env_req PLATFORM_DIR]/fastroute.tcl

set max_iter 5
if {[info exists ::env(MAX_REPAIR_ANTENNAS_ITER_DRT)]} { set max_iter $::env(MAX_REPAIR_ANTENNAS_ITER_DRT) }
set drt_args [list -output_drc $::PNR_RPT/drt_drc_post_antenna.rpt \
                   -droute_end_iter 64 -verbose 1]

remove_fillers
set before [check_antennas -report_file $::PNR_RPT/drt_antennas_before_repair.rpt]
puts "ANTENNA_NETS_BEFORE $before"
metric antenna nets_before_repair $before
set diodes_before [llength [lsearch -all -inline [lmap i [[ord::get_db_block] getInsts] {[$i getMaster] getName}] sky130_fd_sc_hd__diode_2]]

set it 0
while {$it < $max_iter && [check_antennas]} {
  incr it
  puts "ANTENNA_REPAIR_ITER $it"
  repair_antennas sky130_fd_sc_hd__diode_2
  detailed_route {*}$drt_args
}
set after [check_antennas -report_file $::PNR_RPT/drt_antennas.rpt]
set diodes_after [llength [lsearch -all -inline [lmap i [[ord::get_db_block] getInsts] {[$i getMaster] getName}] sky130_fd_sc_hd__diode_2]]
puts "ANTENNA_NETS_AFTER $after (repair iterations: $it, diodes added: [expr {$diodes_after - $diodes_before}])"
metric antenna repair_iterations $it
metric antenna nets_after_repair $after
metric antenna diodes_added [expr {$diodes_after - $diodes_before}]

filler_placement [env_req FILL_CELLS]
check_placement -verbose
if {![grt::have_routes]} { utl::error FLW 4 "no routes after antenna repair" }
save_step 5b_antenna
puts "FLOW_STEP_OK antenna"
