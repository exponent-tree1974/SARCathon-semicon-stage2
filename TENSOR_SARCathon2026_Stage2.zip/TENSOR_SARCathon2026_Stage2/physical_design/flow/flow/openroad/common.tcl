# =============================================================================
# Shared helpers for the OpenROAD steps (flow/openroad/*.tcl).
# Environment comes from the Makefile (flow/config/design.mk).
#   PNR_DIR   build/<RUN_TAG>/pnr      (ODB / DEF / netlists per step)
#   PNR_RPT   build/<RUN_TAG>/pnr/reports
# =============================================================================
proc env_req {name} {
  if {![info exists ::env($name)] || $::env($name) eq ""} {
    utl::error FLW 1 "required environment variable $name is not set"
  }
  return $::env($name)
}
set ::PNR_DIR [env_req PNR_DIR]
set ::PNR_RPT [env_req PNR_RPT]
file mkdir $::PNR_DIR $::PNR_RPT

# Machine-readable metrics: one "key value" line per metric, per step.
proc metric {step key value} {
  set fh [open $::PNR_RPT/metrics_$step.txt a]
  puts $fh "$key $value"
  close $fh
}

# Load a previous step's database plus the timing view.
proc load_step {odb} {
  read_liberty [env_req LIB_TT]
  read_db $::PNR_DIR/$odb
  read_sdc [env_req SDC_FILE]
  source [env_req PLATFORM_DIR]/setRC.tcl
  set_dont_use [env_req DONT_USE_CELLS]
}

# Area of all placed instances (std cells incl. taps/fill), um^2, from LEF sizes.
proc inst_area_um2 {{skip_physical 0}} {
  set block [ord::get_db_block]
  set dbu [$block getDbUnitsPerMicron]
  set a 0.0
  foreach inst [$block getInsts] {
    set m [$inst getMaster]
    if {$skip_physical && [string match "*fill*" [$m getName]]} { continue }
    if {$skip_physical && [string match "*tapvpwrvgnd*" [$m getName]]} { continue }
    if {$skip_physical && [string match "*decap*" [$m getName]]} { continue }
    set a [expr {$a + double([$m getWidth]) * [$m getHeight]}]
  }
  return [expr {$a / ($dbu * $dbu)}]
}
proc core_area_um2 {} {
  set block [ord::get_db_block]
  set dbu [$block getDbUnitsPerMicron]
  set r [$block getCoreArea]
  return [expr {double([$r dx]) * [$r dy] / ($dbu * $dbu)}]
}
proc die_area_um2 {} {
  set block [ord::get_db_block]
  set dbu [$block getDbUnitsPerMicron]
  set r [$block getDieArea]
  return [expr {double([$r dx]) * [$r dy] / ($dbu * $dbu)}]
}

# Timing snapshot after a step: worst paths + WNS/TNS into reports/, metrics file.
proc timing_snapshot {step} {
  report_checks -path_delay max -group_path_count 5 -fields {slew cap fanout} \
      -digits 3 > $::PNR_RPT/${step}_setup.rpt
  report_checks -path_delay min -group_path_count 5 -fields {slew cap fanout} \
      -digits 3 > $::PNR_RPT/${step}_hold.rpt
  report_check_types -max_slew -max_capacitance -max_fanout -violators \
      > $::PNR_RPT/${step}_drv.rpt
  metric $step setup_ws_ns  [format %.3f [sta::worst_slack -max]]
  metric $step setup_tns_ns [format %.3f [sta::total_negative_slack -max]]
  metric $step hold_ws_ns   [format %.3f [sta::worst_slack -min]]
  metric $step hold_tns_ns  [format %.3f [sta::total_negative_slack -min]]
  metric $step std_cell_area_um2 [format %.1f [inst_area_um2 1]]
  metric $step core_area_um2     [format %.1f [core_area_um2]]
  metric $step instance_count    [llength [[ord::get_db_block] getInsts]]
  report_design_area
}

proc save_step {step} {
  write_db  $::PNR_DIR/$step.odb
  write_sdc $::PNR_DIR/$step.sdc
}
