# eco_antenna_diodes <antenna_report> <diode_master> [count] [tag]
# For every violating net in an OpenROAD check_antennas report, place <count>
# diodes directly LEFT of the first violating gate's instance (same row and
# orientation) and connect them to the net, so the diodes land on the metal
# island at that pin. More diodes = more diffusion area = a higher allowed
# side-area ratio (ANTENNADIFFSIDEAREARATIO PWL in the tech LEF).
# Returns the number of diodes created. Caller must legalise (detailed_placement)
# and re-route (global_route -start/-end_incremental, detailed_route).
proc eco_antenna_diodes {rpt master_name {count 1} {tag 0}} {
  set block [ord::get_db_block]
  set m [[ord::get_db] findMaster $master_name]
  if {$m eq "NULL"} { utl::error FLW 6 "diode master $master_name not found" }
  set fh [open $rpt]
  set net ""; set done {}; set k 0
  while {[gets $fh line] >= 0} {
    if {[regexp {^Net:\s+(\S+)} $line -> net]} { continue }
    if {$net ne "" && [lsearch -exact $done $net] < 0 &&
        [regexp {^\s+Pin:\s+(\S+)/(\S+)} $line -> iname pname]} {
      lappend done $net
      set g [$block findInst $iname]
      set dbnet [$block findNet $net]
      if {$g eq "NULL" || $dbnet eq "NULL"} { continue }
      set loc [$g getLocation]
      for {set j 1} {$j <= $count} {incr j} {
        set d [odb::dbInst_create $block $m ANTENNA_ECO_${tag}_$k]
        $d setOrient [$g getOrient]
        $d setLocation [expr {[lindex $loc 0] - $j * [$m getWidth]}] [lindex $loc 1]
        $d setPlacementStatus PLACED
        odb::dbITerm_connect [$d findITerm DIODE] $dbnet
        puts "ECO_DIODE [$d getName] net=$net gate=$iname/$pname at [$d getLocation]"
        incr k
      }
    }
  }
  close $fh
  global_connect
  return $k
}
