# OpenROAD-flow-scripts (ORFS) design config - alternative to the Makefile flow.
# Copy this directory to  <ORFS>/flow/designs/sky130hd/axis_pcie_link_mux2_top/
# and set STAGE2 to the absolute path of the stage2_asic directory, then:
#   make -C <ORFS>/flow DESIGN_CONFIG=./designs/sky130hd/axis_pcie_link_mux2_top/config.mk STAGE2=/abs/path/stage2_asic
# Same RTL, SDC, die and pin constraints as the stage2_asic Makefile flow.
export DESIGN_NAME     = axis_pcie_link_mux2_top
export DESIGN_NICKNAME = axis_pcie_link_mux2_top
export PLATFORM        = sky130hd

export VERILOG_FILES   = $(addprefix $(STAGE2)/,$(shell cat $(STAGE2)/flow/config/rtl_files.f))
export VERILOG_DEFINES = -D SYNTHESIS
export SDC_FILE        = $(STAGE2)/flow/constraints/axis_pcie_link_mux2_top.sdc
export IO_CONSTRAINTS  = $(STAGE2)/flow/constraints/io_pins.tcl

export DIE_AREA        = 0 0 1300 1300
export CORE_AREA       = 20 20 1280 1280
export PLACE_DENSITY   = 0.55

# Same PnR choices as flow/config/pnr.mk (see that file for the reasons):
#  - port buffers with an explicit cell (ORFS buffers ports by default; left to
#    choose, OpenROAD picked the clock-delay cell clkdlybuf4s50_1 in this design)
#  - 20 % slew / capacitance margins in repair_design
export BUFFER_PORTS_ARGS = -buffer_cell sky130_fd_sc_hd__buf_2
export SLEW_MARGIN       = 20
export CAP_MARGIN        = 20
export MAX_REPAIR_ANTENNAS_ITER_DRT = 5
