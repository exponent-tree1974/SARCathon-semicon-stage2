#!/usr/bin/env bash
# Print the version of every tool the flow uses. Exit 1 if a REQUIRED tool is missing.
# Required for synthesis + STA: yosys, sta (or openroad), python3
# Required for PnR:             openroad
# Required for GDS/DRC/LVS:     klayout (full, or the Qt-less `strmrun` build)
# Optional:                     verilator (gls), magic + netgen + PDK (signoff-magic)
YOSYS=${YOSYS:-yosys}; STA=${STA:-sta}; OPENROAD=${OPENROAD:-openroad}; KLAYOUT=${KLAYOUT:-klayout}
VERILATOR=${VERILATOR:-verilator}; MAGIC=${MAGIC:-magic}; NETGEN=${NETGEN:-netgen}
KLAYOUT_HOME=${KLAYOUT_HOME:-/opt/eda/install/klayout}
missing=0
ver () { # name cmd...
  local n=$1; shift
  if command -v "$1" >/dev/null 2>&1; then
    printf "%-9s %s\n" "$n" "$("$@" 2>&1 | grep -v '^$' | head -1)"
  else
    printf "%-9s MISSING (%s)\n" "$n" "$1"; return 1
  fi
}
ver yosys    "$YOSYS" -V            || missing=1
ver sta      "$STA" -version        || echo "          (sta optional if openroad is present)"
ver openroad "$OPENROAD" -version   || missing=1
if command -v "$KLAYOUT" >/dev/null 2>&1; then
  ver klayout "$KLAYOUT" -v
elif [ -x "$KLAYOUT_HOME/strmrun" ]; then
  printf "%-9s %s\n" klayout "Qt-less build: $KLAYOUT_HOME/strmrun ($(ls $KLAYOUT_HOME/libklayout_db.so.*.*.* 2>/dev/null | sed 's/.*so\.//' | head -1))"
else
  echo "klayout   MISSING (needed only for gds/drc/lvs)"
fi
ver verilator "$VERILATOR" --version || echo "          (verilator needed only for gls)"
if command -v "$MAGIC" >/dev/null 2>&1; then
  printf "%-9s %s\n" magic "$(t=$(mktemp --suffix=.tcl); echo 'quit -noprompt' > $t; timeout 60 "$MAGIC" -dnull -noconsole $t </dev/null 2>&1 | grep -m1 '^Magic' | sed 's/ - Compiled.*//'; rm -f $t)"
else echo "magic     MISSING (needed only for signoff-magic)"; fi
if command -v "$NETGEN" >/dev/null 2>&1; then
  printf "%-9s %s\n" netgen "$("$NETGEN" -batch quit 2>&1 | grep -m1 '^Netgen')"
else echo "netgen    MISSING (needed only for signoff-magic)"; fi
ver python3  python3 --version      || missing=1
if [ -f platform/sky130hd/MANIFEST.sha256 ]; then
  (cd platform/sky130hd && sha256sum -c --quiet MANIFEST.sha256) && echo "platform  sky130hd OK ($(head -2 platform/sky130hd/PROVENANCE.txt | tail -1))"
else
  echo "platform  MISSING - run: make platform"; missing=1
fi
if [ -n "${PDK_ROOT:-}" ] && [ -f "$PDK_ROOT/PROVENANCE.txt" ]; then
  echo "pdk       $(cat "$PDK_ROOT/PROVENANCE.txt")"
else
  echo "pdk       not fetched (needed only for signoff-magic): make pdk"
fi
exit $missing
