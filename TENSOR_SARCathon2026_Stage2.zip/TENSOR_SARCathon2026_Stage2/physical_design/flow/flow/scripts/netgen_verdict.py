#!/usr/bin/env python3
"""Netgen LVS verdict from netgen_lvs.rpt (+ netgen_lvs.json if present).

Prints NETGEN_LVS_RESULT MATCH|MISMATCH|UNKNOWN and the counts LibreLane's
Netgen.LVS step reports (device/net/pin differences of the top cell).
Exit 0 only on MATCH.
"""
import json, os, re, sys

js = sys.argv[1]
rpt = re.sub(r"\.json$", ".rpt", js)
final = None
if os.path.exists(rpt):
    for line in open(rpt, errors="replace"):
        if line.startswith("Final result"):
            final = line.strip()
print("final line:", final)

counts = {}
if os.path.exists(js):
    data = json.load(open(js))
    top = data[-1] if isinstance(data, list) and data else {}
    for k in ("devices", "nets", "pins"):
        v = top.get(k)
        if isinstance(v, list) and len(v) == 2:
            counts[k + "_layout"], counts[k + "_schematic"] = v
    counts["badnets"] = len(top.get("badnets", []))
    counts["badelements"] = len(top.get("badelements", []))
    pins = top.get("pins")
    for k, v in counts.items():
        print(f"{k} {v}")

if final and "Circuits match uniquely" in final:
    r = "MATCH"
elif final and ("do not match" in final or "mismatch" in final.lower()):
    r = "MISMATCH"
elif final is None:
    r = "UNKNOWN"
else:
    r = "MISMATCH"
print("NETGEN_LVS_RESULT", r)
sys.exit(0 if r == "MATCH" else 1)
