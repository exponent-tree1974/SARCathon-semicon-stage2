#!/usr/bin/env python3
"""Check the register correspondence assumed by the mapping equivalence check:
every flop instance (ff_<n>) has the same cell type in the pre-ABC netlist and
in the final netlist, and the two sets of instance names are identical.

    lec_flops_match.py <pre_abc.netlist.v> <final.netlist.v>
"""
import re, sys

PAT = re.compile(r"^\s*(sky130_fd_sc_hd__\w+)\s+(ff_\d+)\s*\(", re.M)


def flops(path):
    return {inst: cell for cell, inst in PAT.findall(open(path).read())}


a, b = flops(sys.argv[1]), flops(sys.argv[2])
only_a, only_b = sorted(set(a) - set(b)), sorted(set(b) - set(a))
diff = sorted(k for k in set(a) & set(b) if a[k] != b[k])
print("flops: pre_abc %d, final %d, common %d" % (len(a), len(b), len(set(a) & set(b))))
for k in only_a[:10]:
    print("only in pre_abc:", k)
for k in only_b[:10]:
    print("only in final:", k)
for k in diff[:10]:
    print("cell type differs: %s %s -> %s" % (k, a[k], b[k]))
ok = a and not only_a and not only_b and not diff
print("FLOP_CORRESPONDENCE", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
