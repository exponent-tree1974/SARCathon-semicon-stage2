#!/usr/bin/env bash
# Stream out: final DEF + Sky130 HD cell GDS -> merged GDS.
#   klayout_gds.sh <final.def> <out.gds>
set -euo pipefail
DEF=$1; OUT=$2
source flow/scripts/klayout_common.sh
d=$(dirname "$OUT"); mkdir -p "$d"
# KLayout technology with absolute LEF paths (same as ORFS generate_klayout_tech.py)
python3 - "$KLAYOUT_LYT" "$d/klayout.lyt" "$TECH_LEF" "$SC_LEF" <<'PY'
import os, re, sys
tpl, out, *lefs = sys.argv[1:]
s = open(tpl).read()
s = re.sub(r"<lef-files>.*?</lef-files>",
           "".join("<lef-files>%s</lef-files>" % os.path.abspath(f) for f in lefs), s)
open(out, "w").write(s)
PY
kl_script flow/klayout/def2gds.rb tech_file="$d/klayout.lyt" in_def="$DEF" \
    design_name="$DESIGN_NAME" in_files="$SC_GDS" out_file="$OUT"
ls -la "$OUT"
