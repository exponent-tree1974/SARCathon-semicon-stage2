#!/usr/bin/env bash
# Render a flow template (@VAR@ placeholders) using the environment exported by
# the Makefile from flow/config/design.mk.
# Usage: render.sh <template> <output>
set -euo pipefail
tpl=$1; out=$2
outdir=$(dirname "$out")
mkdir -p "$outdir"

read_rtl=""
while read -r f; do
  [ -z "$f" ] && continue
  case "$f" in \#*) continue ;; esac
  defs=""
  for d in $VERILOG_DEFINES; do defs="$defs -D$d"; done
  read_rtl+="read_verilog -sv${defs} $f"$'\n'
done < "$RTL_FILELIST"

dont_use=""
for c in $DONT_USE_CELLS; do dont_use="$dont_use -dont_use $c"; done

period_ps=$(python3 -c "print(int(round(float('$CLOCK_PERIOD_NS')*1000)))")

# ABC timing constraints: driver cell + internal load (fF)
printf 'set_driving_cell %s\nset_load %s\n' "$ABC_DRIVER_CELL" "$ABC_LOAD_FF" > "$outdir/abc.constr"

python3 - "$tpl" "$out" <<PY
import os, sys
tpl, out = sys.argv[1], sys.argv[2]
s = open(tpl).read()
subst = {
  "READ_RTL": """$read_rtl""".rstrip("\n"),
  "DONT_USE_ARGS": "$dont_use".strip(),
  "CLOCK_PERIOD_PS": "$period_ps",
  "OUT": "$outdir",
}
for k in ["DESIGN_NAME","LIB_TT","TIEHI_CELL","TIEHI_PORT","TIELO_CELL","TIELO_PORT","BUF_CELL"]:
    subst[k] = os.environ[k]
for k, v in subst.items():
    s = s.replace("@%s@" % k, v)
import re
left = re.findall(r"@[A-Z_]+@", s)
if left:
    sys.exit("unrendered placeholders: %s" % sorted(set(left)))
open(out, "w").write(s)
PY
echo "rendered $out"
