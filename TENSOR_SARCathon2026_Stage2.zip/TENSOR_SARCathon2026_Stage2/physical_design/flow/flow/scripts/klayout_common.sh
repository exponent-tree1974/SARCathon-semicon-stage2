# Shared KLayout invocation (sourced by klayout_gds.sh / klayout_lvs.sh / Makefile drc).
# Two supported installations:
#   * full KLayout (`klayout` on PATH):    klayout -b -rd k=v ... -r <script>
#   * Qt-less build (`strmrun`, recorded run): strmrun -v k=v ... <script>; DRC/LVS decks go
#     through flow/klayout/run_dsl.rb, which needs KLAYOUT_SRC = <klayout source>/src
KLAYOUT_HOME=${KLAYOUT_HOME:-/opt/eda/install/klayout}
KLAYOUT_SRC=${KLAYOUT_SRC:-/opt/eda/src/klayout/src}
RUBY_LIB=${RUBY_LIB:-/opt/ruby-3.3.6/lib}
if command -v klayout >/dev/null 2>&1; then
  KL_MODE=full
else
  KL_MODE=strmrun
  export LD_LIBRARY_PATH=$KLAYOUT_HOME:$RUBY_LIB:${LD_LIBRARY_PATH:-}
fi

# kl_script <script.rb> k=v ...      run a Ruby script
kl_script () {
  local s=$1; shift; local a=()
  for kv in "$@"; do if [ $KL_MODE = full ]; then a+=(-rd "$kv"); else a+=(-v "$kv"); fi; done
  if [ $KL_MODE = full ]; then klayout -b "${a[@]}" -r "$s"; else "$KLAYOUT_HOME/strmrun" "${a[@]}" "$s"; fi
}
# kl_deck drc|lvs <deck> k=v ...     run a DRC/LVS deck
kl_deck () {
  local kind=$1 deck=$2; shift 2
  if [ $KL_MODE = full ]; then
    local a=(); for kv in "$@"; do a+=(-rd "$kv"); done
    klayout -b "${a[@]}" -r "$deck"
  else
    kl_script flow/klayout/run_dsl.rb kind=$kind deck=$deck klayout_src=$KLAYOUT_SRC "$@"
  fi
}
