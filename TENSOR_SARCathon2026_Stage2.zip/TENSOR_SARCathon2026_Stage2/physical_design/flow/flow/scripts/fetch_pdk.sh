#!/usr/bin/env bash
# Fetch the SKY130A PDK subset needed for Magic DRC / extraction and Netgen LVS
# (the LibreLane sign-off tools) at the version LibreLane 3.0.16 pins
# (librelane/pdk_hashes.yaml: sky130 8afc8346a57fe1ab7934ba5a6056ea8b43078e71).
#
# Source: ciel PDK releases on GitHub (pre-built open_pdks output). Only two
# archives are needed:
#   common.tar.zst           libs.tech (magic tech + magicrc, netgen setup, ...)
#   sky130_fd_sc_hd.tar.zst  libs.ref/sky130_fd_sc_hd (spice, gds, lef, ...)
# Archive SHA-256 values are pinned; a mismatch aborts.
#
# Usage (from the stage2_asic root):  bash flow/scripts/fetch_pdk.sh [PDK_ROOT]
#   needs: curl, tar, zstd
set -euo pipefail
REV=${SKY130_PDK_REV:-8afc8346a57fe1ab7934ba5a6056ea8b43078e71}
ROOT=${1:-platform/pdk/sky130-$REV}
DL=$(dirname "$ROOT")/dl
URL=https://github.com/fossi-foundation/ciel-releases/releases/download/sky130-$REV
declare -A SHA=(
  [common.tar.zst]=be8a548341fd9177af9e461ad7b4fdd89afbe03dba68dc42d155321fdc3f86bf
  [sky130_fd_sc_hd.tar.zst]=17047505cfff30841bf53960b8cbf9e7c79b2a3bbb2ebec0bb254eb441e4ce1e
)
command -v zstd >/dev/null || { echo "zstd not found (build it: tools/build_from_source.sh)"; exit 1; }
mkdir -p "$DL" "$ROOT"
for a in common.tar.zst sky130_fd_sc_hd.tar.zst; do
  if [ ! -f "$DL/$a" ] || ! echo "${SHA[$a]}  $DL/$a" | sha256sum -c --quiet; then
    curl -sSL --fail -o "$DL/$a" "$URL/$a"
  fi
  echo "${SHA[$a]}  $DL/$a" | sha256sum -c
  zstd -dc "$DL/$a" | tar -x -C "$ROOT"
done
test -f "$ROOT/sky130A/libs.tech/magic/sky130A.tech"
test -f "$ROOT/sky130A/libs.tech/netgen/sky130A_setup.tcl"
test -f "$ROOT/sky130A/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice"
echo "sky130 $REV from $URL" > "$ROOT/PROVENANCE.txt"
echo "PDK ready: $ROOT"
