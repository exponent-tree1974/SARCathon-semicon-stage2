#!/usr/bin/env bash
# Mapping equivalence check + negative control.  Called by `make lec`.
#   run_lec.sh <synth_dir> <log_dir>
# 1. register correspondence (same ff_<n> names and cell types)  -> lec_flops.rpt
# 2. Yosys builds the cut-point miter (flow/yosys/lec_mapping.ys.in)
# 3. ABC `iprove` on the miter: UNSAT = equivalent                -> lec_mapping.rpt
# 4. negative control: one nand2_1 in a COPY of the final netlist becomes nor2_1;
#    the same check must report NOT EQUIVALENT                     -> lec_negative.rpt
set -euo pipefail
SYN=$1; LOG=$2
YOSYS=${YOSYS:-yosys}; ABC=${ABC:-yosys-abc}
NET=$SYN/$DESIGN_NAME.netlist.v

prove () {  # prove <gate netlist> <tag> -> prints EQUIVALENT / NOT_EQUIVALENT / UNKNOWN
  local gate=$1 tag=$2 d=$SYN/lec_$2
  mkdir -p "$d"
  cp "$SYN/pre_abc.netlist.v" "$d/pre_abc.netlist.v"
  cp "$gate" "$d/$DESIGN_NAME.netlist.v"
  sed "s#@OUT@#$d#g; s#@LIB_TT@#$LIB_TT#g; s#@DESIGN_NAME@#$DESIGN_NAME#g" \
      flow/yosys/lec_mapping.ys.in > "$d/lec_mapping.ys"
  "$YOSYS" -q -l "$LOG/1b_lec_${tag}_yosys.log" -s "$d/lec_mapping.ys"
  "$ABC" -c "read_aiger $d/lec_miter.aig; print_stats; iprove -v" > "$LOG/1b_lec_${tag}_abc.log" 2>&1 || true
  if grep -q "^UNSATISFIABLE" "$LOG/1b_lec_${tag}_abc.log"; then echo EQUIVALENT
  elif grep -q "^SATISFIABLE" "$LOG/1b_lec_${tag}_abc.log"; then echo NOT_EQUIVALENT
  else echo UNKNOWN; fi
  rm -f "$d/pre_abc.netlist.v" "$d/$DESIGN_NAME.netlist.v"
}

python3 flow/scripts/lec_flops_match.py "$SYN/pre_abc.netlist.v" "$NET" | tee "$SYN/lec_flops.rpt"

r=$(prove "$NET" main)
{ echo "# Mapping equivalence: pre-ABC netlist vs final netlist (register cut points, ABC iprove)"
  echo "abc_log $LOG/1b_lec_main_abc.log"
  grep -E "i/o =" "$LOG/1b_lec_main_abc.log" | head -1 | sed "s/\x1b\[[0-9;]*m//g"
  echo "LEC_RESULT $r"; } | tee "$SYN/lec_mapping.rpt"

# negative control: mutate the 100th nand2_1 instance into nor2_1 (same pins A,B,Y)
python3 - "$NET" "$SYN/lec_negative.netlist.v" <<'PY'
import re, sys
src, dst = sys.argv[1], sys.argv[2]
t = open(src).read()
hits = [m for m in re.finditer(r"^(\s*)sky130_fd_sc_hd__nand2_1(\s+\S+\s*\()", t, re.M)]
m = hits[min(99, len(hits) - 1)]
inst = m.group(2).split()[0]
t = t[:m.start()] + m.group(1) + "sky130_fd_sc_hd__nor2_1" + m.group(2) + t[m.end():]
open(dst, "w").write(t)
print("negative control: instance %s nand2_1 -> nor2_1" % inst)
PY
n=$(prove "$SYN/lec_negative.netlist.v" negative)
{ echo "# Negative control: one nand2_1 -> nor2_1 in a copy of the final netlist"
  echo "LEC_NEGATIVE_RESULT $n (expected NOT_EQUIVALENT)"; } | tee "$SYN/lec_negative.rpt"
rm -f "$SYN/lec_negative.netlist.v"

[ "$r" = EQUIVALENT ] && [ "$n" = NOT_EQUIVALENT ]
