#!/usr/bin/env python3
"""Check that both pin-constraint files cover every top-level port exactly once.

Inputs
  --netlist-json  Yosys write_json output (gives the real port list + widths)
  --openroad      flow/constraints/io_pins.tcl   (glob patterns, -region side:*)
  --librelane     flow/librelane/pin_order.cfg   (#N/#S/#E/#W + anchored regexes)

Also prints the pin count per edge, which docs/floorplan_assumptions.md uses
for the pin-capacity check. Exit code 1 on any uncovered/double-covered port
or any edge disagreement between the two files.
"""
import argparse, fnmatch, json, re, sys

SIDE = {"top": "N", "bottom": "S", "right": "E", "left": "W"}


def ports(netlist_json):
    d = json.load(open(netlist_json))
    mods = [m for m in d["modules"].values() if m.get("attributes", {}).get("top")]
    if len(mods) != 1:
        sys.exit("cannot identify the top module in %s" % netlist_json)
    out = {}
    for name, p in mods[0]["ports"].items():
        w = len(p["bits"])
        bits = [name] if w == 1 else ["%s[%d]" % (name, i) for i in range(w)]
        for b in bits:
            out[b] = (name, p["direction"])
    return out


def openroad_rules(path):
    rules = []
    for line in open(path):
        line = line.split("#", 1)[0]
        m = re.search(r"-region\s+(\w+):\S+\s+-pin_names\s+\{([^}]*)\}", line)
        if m:
            for pat in m.group(2).split():
                rules.append((SIDE[m.group(1)], pat))
    return rules


def librelane_rules(path):
    rules, side = [], None
    for line in open(path):
        line = line.strip()
        if not line:
            continue
        if line.startswith("#"):
            side = line[1]
            continue
        rules.append((side, line))
    return rules


def assign(bits, rules, match):
    res, errs = {}, []
    for b, (base, _) in bits.items():
        hits = [(s, p) for s, p in rules if match(p, b, base)]
        if len(hits) != 1:
            errs.append("%s matched %d rules %s" % (b, len(hits), hits))
        else:
            res[b] = hits[0][0]
    return res, errs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--netlist-json", required=True)
    ap.add_argument("--openroad", required=True)
    ap.add_argument("--librelane", required=True)
    a = ap.parse_args()
    bits = ports(a.netlist_json)
    # OpenROAD get_ports globs match the bus name (e.g. s0_axis_*)
    o, oe = assign(bits, openroad_rules(a.openroad),
                   lambda p, b, base: fnmatch.fnmatchcase(base, p))
    # LibreLane regexes are anchored and match the bit-blasted name
    l, le = assign(bits, librelane_rules(a.librelane),
                   lambda p, b, base: re.match("^%s$" % p, b) is not None)
    diff = [b for b in bits if b in o and b in l and o[b] != l[b]]
    print("top-level port bits: %d (inputs %d, outputs %d)" % (
        len(bits), sum(1 for v in bits.values() if v[1] == "input"),
        sum(1 for v in bits.values() if v[1] == "output")))
    for s in "NSEW":
        print("edge %s: %d pins" % (s, sum(1 for v in o.values() if v == s)))
    for e in oe:
        print("OPENROAD ERROR:", e)
    for e in le:
        print("LIBRELANE ERROR:", e)
    for b in diff:
        print("EDGE MISMATCH: %s openroad=%s librelane=%s" % (b, o[b], l[b]))
    ok = not (oe or le or diff)
    print("PIN_CONSTRAINTS", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
