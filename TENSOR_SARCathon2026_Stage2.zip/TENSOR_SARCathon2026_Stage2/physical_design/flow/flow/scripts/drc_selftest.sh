#!/usr/bin/env bash
# DRC deck self-test (negative control) for both DRC engines.
# Takes one standard cell (sky130_fd_sc_hd__dfrtp_1) from the platform GDS,
# makes a copy with a planted 50 nm x 50 nm met1 square (min width is 140 nm),
# and runs KLayout and Magic DRC on both. PASS requires the planted copy to
# report met1 width (m1.1 / met1.1) violations that the clean copy does not.
# (A lone cell is not DRC-clean in Magic - no well taps - so the test compares
#  the two runs rather than expecting zero.)
#   drc_selftest.sh <out_dir>
set -euo pipefail
OUT=$1; mkdir -p "$OUT"; OUT=$(cd "$OUT" && pwd)
source flow/scripts/klayout_common.sh
cat > "$OUT/mk.rb" <<'RB'
ly = RBA::Layout.new
ly.read($src)
c = ly.cell("sky130_fd_sc_hd__dfrtp_1")
o = RBA::SaveLayoutOptions.new; o.select_cell(c.cell_index)
ly.write($clean, o)
ly2 = RBA::Layout.new; ly2.read($clean)
ly2.top_cell.shapes(ly2.layer(68, 20)).insert(RBA::Box.new(-2000, -2000, -1950, -1950))
ly2.write($bad)
RB
kl_script "$OUT/mk.rb" src="$SC_GDS" clean="$OUT/clean.gds" bad="$OUT/bad.gds"
res=PASS
for v in clean bad; do
  kl_deck drc "$KLAYOUT_DRC_DECK" in_gds="$OUT/$v.gds" report_file="$OUT/kl_$v.lyrdb" > "$OUT/kl_$v.log" 2>&1
  python3 flow/scripts/count_lyrdb.py "$OUT/kl_$v.lyrdb" > "$OUT/kl_$v.rpt" || true
  n=$(awk '$1=="m1.1"{print $2}' "$OUT/kl_$v.rpt"); n=${n:-0}
  echo "klayout $v m1.1=$n total=$(awk '/DRC_VIOLATIONS/{print $2}' "$OUT/kl_$v.rpt")"
  eval "kl_$v=$n"
  if command -v "${MAGIC:-magic}" >/dev/null && [ -n "${PDK_ROOT:-}" ]; then
    mkdir -p "$OUT/mg_$v"
    IN_GDS="$OUT/$v.gds" DESIGN_NAME=sky130_fd_sc_hd__dfrtp_1 OUT_DIR="$OUT/mg_$v" \
      ${MAGIC:-magic} -dnull -noconsole -rcfile "$PDK_ROOT/sky130A/libs.tech/magic/sky130A.magicrc" \
      flow/magic/drc.tcl < /dev/null > "$OUT/mg_$v.log" 2>&1
    m=$(python3 -c "
import sys; cur=None; n=0
for l in open(sys.argv[1]):
    l=l.rstrip()
    if l.startswith(' ') and l.endswith('um'): n += cur is not None and '(met1.1)' in cur
    elif l and not l.startswith('-') and not l.startswith('['): cur=l
print(n)" "$OUT/mg_$v/magic_drc.rpt")
    echo "magic   $v met1.1=$m total=$(grep -o 'COUNT: [0-9]*' "$OUT/mg_$v/magic_drc.rpt" | cut -d' ' -f2)"
    eval "mg_$v=$m"
  else
    echo "magic   $v NOT RUN (magic or PDK_ROOT missing)"; eval "mg_$v=skip"
  fi
done
[ "$kl_clean" -eq 0 ] && [ "$kl_bad" -gt 0 ] || res=FAIL
if [ "$mg_clean" != skip ]; then [ "$mg_clean" -eq 0 ] && [ "$mg_bad" -gt 0 ] || res=FAIL; fi
echo "DRC_SELFTEST $res"
[ $res = PASS ]
