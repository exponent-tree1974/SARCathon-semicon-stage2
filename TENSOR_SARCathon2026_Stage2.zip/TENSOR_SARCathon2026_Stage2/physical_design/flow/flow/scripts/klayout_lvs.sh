#!/usr/bin/env bash
# LVS: layout (merged GDS) vs schematic (CDL written by OpenROAD from the final
# database + the platform cell CDL), ORFS KLayout deck sky130hd.lylvs.
#   klayout_lvs.sh <final.gds> <out.lvsdb>
set -euo pipefail
GDS=$1; OUT=$2
source flow/scripts/klayout_common.sh
d=$(dirname "$OUT"); mkdir -p "$d"; d=$(cd "$d" && pwd)
# absolute paths: the LVS deck resolves relative paths against the layout directory
GDS=$(realpath "$GDS"); OUT=$d/$(basename "$OUT")
# 1. design CDL from the routed database (fill cells excluded, as in ORFS)
cat > "$d/write_cdl.tcl" <<EOF
read_db $PNR_DIR/6_final.odb
write_cdl -masters $SC_CDL $d/$DESIGN_NAME.cdl
EOF
${OPENROAD:-openroad} -exit -no_init "$d/write_cdl.tcl"
cat "$d/$DESIGN_NAME.cdl" "$SC_CDL" > "$d/${DESIGN_NAME}_concat.cdl"
# 2. LVS
kl_deck lvs "$KLAYOUT_LVS_DECK" in_gds="$GDS" cdl_file="$d/${DESIGN_NAME}_concat.cdl" \
    top_cell="$DESIGN_NAME" report_file="$OUT" target_netlist="$d/${DESIGN_NAME}_extracted.cir" \
    | tee "$d/lvs_run.log"
# 3. verdict from the deck's log (KLayout prints "Congratulations! Netlists match." on success)
if grep -q "Netlists match" "$d/lvs_run.log"; then r=MATCH
elif grep -qi "Netlists don't match\|do not match\|mismatch" "$d/lvs_run.log"; then r=MISMATCH
else r=UNKNOWN; fi
echo "LVS_RESULT $r" | tee "$d/lvs_result.rpt"
[ "$r" = MATCH ]
