#!/usr/bin/env python3
"""Collect the results of one flow run into reports/<RUN_TAG>/.

    python3 flow/scripts/collect_reports.py --run build/<RUN_TAG> --out reports/<RUN_TAG>

Rules (the point of this script):
  * every number comes from a tool-written file; the source path is recorded
    next to it in summary.md and metrics.json;
  * a step whose output is missing is reported as NOT RUN, and a step whose
    log has no FLOW_STEP_OK marker is FAILED - nothing is estimated or filled in;
  * the raw reports are copied to reports/<RUN_TAG>/raw/ so the summary can be
    checked without the (large) build directory.
"""
import argparse, datetime, glob, json, os, re, shutil, sys

NOT_RUN = "NOT RUN"


class Collector:
    def __init__(self, run, out):
        self.run, self.out = run, out
        self.metrics = {}     # name -> {"value", "source"}
        self.steps = []       # (step, status, evidence)
        self.notes = []

    def p(self, *parts):
        return os.path.join(self.run, *parts)

    def put(self, name, value, source):
        self.metrics[name] = {"value": value, "source": os.path.relpath(source)}

    def step(self, name, status, evidence):
        self.steps.append((name, status, evidence))

    # ---------------------------------------------------------------- synthesis
    def synth(self):
        log, stat = self.p("logs", "1_synth.log"), self.p("synth", "synth_stat.rpt")
        if not os.path.exists(log):
            self.step("synthesis (Yosys)", NOT_RUN, "-")
            return
        ok = os.path.exists(stat) and os.path.exists(glob.glob(self.p("synth", "*.netlist.v"))[0]) \
            if glob.glob(self.p("synth", "*.netlist.v")) else False
        errs = [l for l in open(log, errors="replace") if l.startswith("ERROR")]
        self.step("synthesis (Yosys)", "PASS" if ok and not errs else "FAILED",
                  os.path.relpath(log))
        if not os.path.exists(stat):
            return
        s = open(stat).read()
        m = re.search(r"Chip area for (?:top )?module '\\?(\S+)':\s*([0-9.]+)", s)
        if m:
            self.put("synth.chip_area_um2", float(m.group(2)), stat)
        cells = self._yosys_cells(s)
        if cells:
            total = sum(cells.values())
            flops = sum(v for k, v in cells.items() if re.match(r"sky130_fd_sc_hd__(dfr|dfs|dfx|dfb|edf|sdf|dfst|dfrb|dfrt)", k))
            self.put("synth.cell_count", total, stat)
            self.put("synth.flop_count", flops, stat)
            self.put("synth.distinct_cell_types", len(cells), stat)
        chk = self.p("synth", "check.rpt")
        if os.path.exists(chk):
            c = open(chk).read()
            m = re.search(r"Found and reported (\d+) problems", c)
            self.put("synth.check_problems", int(m.group(1)) if m else 0, chk)
        for f, key, pat in [("lec_flops.rpt", "lec.flop_correspondence", r"FLOP_CORRESPONDENCE (\w+)"),
                            ("lec_mapping.rpt", "lec.mapping_result", r"LEC_RESULT (\w+)"),
                            ("lec_negative.rpt", "lec.negative_control_result", r"LEC_NEGATIVE_RESULT (\w+)")]:
            fp = self.p("synth", f)
            if os.path.exists(fp):
                m = re.search(pat, open(fp).read())
                if m:
                    self.put(key, m.group(1), fp)
        lm, ln = self.metrics.get("lec.mapping_result"), self.metrics.get("lec.negative_control_result")
        if lm:
            ok = lm["value"] == "EQUIVALENT" and ln and ln["value"] == "NOT_EQUIVALENT"
            self.step("mapping equivalence (Yosys + ABC) + negative control", "PASS" if ok else "FAILED",
                      lm["source"])
        else:
            self.step("mapping equivalence (Yosys + ABC) + negative control", NOT_RUN, "-")
        pin = self.p("synth", "pin_constraint_check.rpt")
        if os.path.exists(pin):
            t = open(pin).read()
            m = re.search(r"top-level port bits: (\d+)", t)
            if m:
                self.put("design.port_bits", int(m.group(1)), pin)
            for side in "NSEW":
                m = re.search(r"edge %s: (\d+) pins" % side, t)
                if m:
                    self.put("design.pins_edge_%s" % side, int(m.group(1)), pin)
            self.put("pin_constraints", "PASS" if "PIN_CONSTRAINTS PASS" in t else "FAIL", pin)

    @staticmethod
    def _yosys_cells(text):
        """Cell-type counts from the LAST statistics block (the top module)."""
        blocks = re.split(r"\n=== ", text)
        last = blocks[-1]
        cells = {}
        for m in re.finditer(r"^\s+(\d+)\s+(?:[0-9.eE+-]+\s+)?(sky130_fd_sc_hd__\w+)\s*$", last, re.M):
            cells[m.group(2)] = cells.get(m.group(2), 0) + int(m.group(1))
        if not cells:  # older 'stat' layout: "  sky130_... 12"
            for m in re.finditer(r"^\s+(sky130_fd_sc_hd__\w+)\s+(\d+)\s*$", last, re.M):
                cells[m.group(1)] = cells.get(m.group(1), 0) + int(m.group(2))
        return cells

    # --------------------------------------------------------------------- STA
    def sta(self, tag, label):
        summ = self.p(tag, "summary.rpt")
        if not os.path.exists(summ):
            self.step(label, NOT_RUN, "-")
            return
        txt = open(summ).read()
        mode = re.search(r"# mode: (.*)", txt)
        parts = []
        for m in re.finditer(r"corner (\w+)\s+setup_ws_ns (\S+) setup_tns_ns \S+ hold_ws_ns (\S+)", txt):
            c, su, ho = m.group(1), float(m.group(2)), float(m.group(3))
            parts.append("%s setup %s / hold %s" % (c, "MET" if su >= 0 else "VIOLATED %.3f ns" % su,
                                                  "MET" if ho >= 0 else "VIOLATED %.3f ns" % ho))
        self.step(label, "RAN: " + "; ".join(parts), os.path.relpath(summ))
        if mode:
            self.put("%s.mode" % tag, mode.group(1), summ)
        for m in re.finditer(r"corner (\w+)\s+setup_ws_ns (\S+) setup_tns_ns (\S+) hold_ws_ns (\S+) hold_tns_ns (\S+)", txt):
            c = m.group(1)
            for i, k in enumerate(["setup_ws_ns", "setup_tns_ns", "hold_ws_ns", "hold_tns_ns"]):
                self.put("%s.%s.%s" % (tag, c, k), float(m.group(i + 2)), summ)
        for m in re.finditer(r"^drv (\w+)_violations (\S+)", txt, re.M):
            v = m.group(2)
            self.put("%s.drv_%s_violations" % (tag, m.group(1)), int(v) if v.isdigit() else v, summ)
        drv = self.p(tag, "drv.rpt")
        if os.path.exists(drv):
            t = open(drv).read()
            pass
        cs = self.p(tag, "check_setup.rpt")
        if os.path.exists(cs):
            t = open(cs).read().strip()
            self.put("%s.check_setup_warnings" % tag, len([l for l in t.splitlines() if l.strip()]), cs)
        pw = self.p(tag, "power_tt.rpt")
        if os.path.exists(pw):
            m = re.search(r"^Total\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)", open(pw).read(), re.M)
            if m:
                self.put("%s.power_total_W_vectorless" % tag, float(m.group(4)), pw)

    # --------------------------------------------------------------------- PnR
    def pnr(self):
        names = [("1_floorplan", "floorplan"), ("2_place", "place"), ("3_cts", "cts"),
                 ("4_grt", "grt"), ("5_route", "drt"), ("5b_antenna", "antenna"), ("5c_antenna_cleanup", "antenna_cleanup"),
                 ("6_final", "finish")]
        for f, marker in names:
            log = self.p("logs", f + ".log")
            if not os.path.exists(log):
                self.step("PnR %s (OpenROAD)" % f, NOT_RUN, "-")
                continue
            t = open(log, errors="replace").read()
            ok = ("FLOW_STEP_OK %s" % marker) in t
            err = re.findall(r"^\[ERROR [^\n]*", t, re.M)
            self.step("PnR %s (OpenROAD)" % f, "PASS" if ok else "FAILED",
                      os.path.relpath(log) + ("" if ok else " :: " + (err[-1] if err else "no FLOW_STEP_OK marker")))
        for mf in sorted(glob.glob(self.p("pnr", "reports", "metrics_*.txt"))):
            st = os.path.basename(mf)[len("metrics_"):-4]
            for line in open(mf):
                k, _, v = line.strip().partition(" ")
                try:
                    v = float(v)
                except ValueError:
                    pass
                self.put("pnr.%s.%s" % (st, k), v, mf)
        for tag, f in [("drt", "drt_drc.rpt"), ("antenna", "drt_drc_post_antenna.rpt"),
                          ("antenna_cleanup", "drt_drc_post_cleanup.rpt")]:
            drc = self.p("pnr", "reports", f)
            if os.path.exists(drc):
                self.put("pnr.%s.drc_violations" % tag,
                         len(re.findall(r"^\s*violation type", open(drc).read(), re.M | re.I)), drc)
        rl = self.p("logs", "5_route.log")
        if os.path.exists(rl):
            t = open(rl, errors="replace").read()
            wl = re.findall(r"^Total wire length = (\d+) um", t, re.M)
            vi = re.findall(r"^Total number of vias = (\d+)", t, re.M)
            nv = re.findall(r"Number of violations = (\d+)", t)
            if wl:
                self.put("pnr.drt.total_wirelength_um", int(wl[-1]), rl)
            if vi:
                self.put("pnr.drt.total_vias", int(vi[-1]), rl)
            if nv:
                self.put("pnr.drt.violations_per_iteration", " > ".join(nv), rl)
        fl = self.p("logs", "6_final.log")
        if os.path.exists(fl):
            t = open(fl, errors="replace").read()
            # analyze_power_grid prints one block per net (VDD first, then VSS)
            for net, wv, av, wir in re.findall(
                    r"Net\s*:\s*(\w+).*?Worstcase voltage\s*:\s*(\S+\s*\w+).*?Average IR drop\s*:\s*(\S+\s*\w+).*?Worstcase IR drop\s*:\s*(\S+\s*\w+)",
                    t, re.S):
                self.put("pnr.final.irdrop_%s_worst_voltage" % net, wv.strip(), fl)
                self.put("pnr.final.irdrop_%s_average" % net, av.strip(), fl)
                self.put("pnr.final.irdrop_%s_worst" % net, wir.strip(), fl)
        pw = self.p("pnr", "reports", "final_power_vectorless.rpt")
        if os.path.exists(pw):
            m = re.search(r"^Total\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)", open(pw).read(), re.M)
            if m:
                self.put("pnr.final.power_total_W_vectorless_tt", float(m.group(4)), pw)
        for f, tag in [("4_grt", "grt"), ("5_route", "drt"), ("5b_antenna", "antenna"),
                                ("5c_antenna_cleanup", "antenna_cleanup")]:
            lg = self.p("logs", f + ".log")
            if os.path.exists(lg):
                t = open(lg, errors="replace").read()
                nets = re.findall(r"ANT-0002\]\s+Found (\d+) net violations", t)
                pins = re.findall(r"ANT-0001\]\s+Found (\d+) pin violations", t)
                if nets:
                    self.put("pnr.%s.antenna_violating_nets_last_check" % tag, int(nets[-1]), lg)
                if pins:
                    self.put("pnr.%s.antenna_violating_pins_last_check" % tag, int(pins[-1]), lg)
        for tag in ["grt_antennas", "drt_antennas_before_repair", "drt_antennas"]:
            f = self.p("pnr", "reports", tag + ".rpt")
            if os.path.exists(f):
                t = open(f).read()
                m = re.search(r"violated pins:\s*(\d+)", t, re.I)
                n = re.search(r"violated nets:\s*(\d+)", t, re.I)
                if m:
                    self.put("pnr.%s.violated_pins" % tag, int(m.group(1)), f)
                if n:
                    self.put("pnr.%s.violated_nets" % tag, int(n.group(1)), f)

    # ----------------------------------------------------------------- signoff
    def signoff(self):
        gds = [g for g in glob.glob(self.p("signoff", "*.gds")) if not g.endswith((".magic.gds", "xor_diff.gds"))]
        self.step("GDS stream-out (KLayout)", "PASS" if gds else NOT_RUN,
                  os.path.relpath(gds[0]) if gds else "-")
        dc = self.p("signoff", "drc_count.rpt")
        if os.path.exists(dc):
            m = re.search(r"DRC_VIOLATIONS (\d+)", open(dc).read())
            self.step("DRC (KLayout, ORFS sky130hd deck)", "PASS" if m and m.group(1) == "0" else "FAILED",
                      os.path.relpath(dc))
            if m:
                self.put("signoff.klayout_drc_violations", int(m.group(1)), dc)
        else:
            self.step("DRC (KLayout, ORFS sky130hd deck)", NOT_RUN, "-")
        lv = self.p("signoff", "lvs_result.rpt")
        if os.path.exists(lv):
            t = open(lv).read()
            self.step("LVS (KLayout)", "PASS" if "LVS_RESULT MATCH" in t else "FAILED", os.path.relpath(lv))
        else:
            self.step("LVS (KLayout)", NOT_RUN, "-")

    def signoff_magic(self):
        mg = self.p("signoff", "%s.magic.gds" % self.design())
        self.step("GDS stream-out (Magic, second independent stream-out)", "PASS" if os.path.exists(mg) else NOT_RUN,
                  os.path.relpath(mg) if os.path.exists(mg) else "-")
        xr = self.p("signoff", "xor.rpt")
        if os.path.exists(xr):
            t = open(xr).read()
            m = re.search(r"XOR_DIFFERENCES (\d+)", t)
            self.step("GDS XOR KLayout vs Magic (81/14 ignored)", "PASS" if "XOR_RESULT PASS" in t else "FAILED",
                      os.path.relpath(xr))
            if m:
                self.put("signoff.xor_difference_shapes", int(m.group(1)), xr)
        else:
            self.step("GDS XOR KLayout vs Magic (81/14 ignored)", NOT_RUN, "-")
        st = self.p("logs", "9b_drc_selftest.log")
        if os.path.exists(st):
            t = open(st).read()
            self.step("DRC deck self-test (planted met1 error must be flagged; KLayout + Magic)",
                      "PASS" if "DRC_SELFTEST PASS" in t else "FAILED", os.path.relpath(st))
        else:
            self.step("DRC deck self-test (planted met1 error must be flagged; KLayout + Magic)", NOT_RUN, "-")
        md = self.p("signoff", "magic_drc.rpt")
        if os.path.exists(md):
            m = re.search(r"COUNT: (\d+)", open(md).read())
            n = int(m.group(1)) if m else None
            self.step("DRC (Magic, full sky130A deck, drc(full))",
                      "PASS" if n == 0 else ("FAILED" if n is not None else "FAILED (no count)"), os.path.relpath(md))
            if n is not None:
                self.put("signoff.magic_drc_count", n, md)
        else:
            self.step("DRC (Magic, full sky130A deck, drc(full))", NOT_RUN, "-")
        nl = self.p("signoff", "netgen_lvs_result.rpt")
        if os.path.exists(nl):
            t = open(nl).read()
            m = re.search(r"NETGEN_LVS_RESULT (\w+)", t)
            self.step("LVS (Magic extraction + Netgen)", "PASS" if m and m.group(1) == "MATCH" else "FAILED",
                      os.path.relpath(nl))
            if m:
                self.put("signoff.netgen_lvs_result", m.group(1), nl)
            for k, v in re.findall(r"^(devices_layout|devices_schematic|nets_layout|nets_schematic|pins_layout|pins_schematic|badnets|badelements) (\S+)", t, re.M):
                self.put("signoff.netgen_%s" % k, v, nl)
        else:
            self.step("LVS (Magic extraction + Netgen)", NOT_RUN, "-")

    def design(self):
        n = glob.glob(self.p("synth", "*.netlist.v"))
        return os.path.basename(n[0])[:-len(".netlist.v")] if n else "design"

    def gls(self, sub="gls", label="gate-level simulation (Verilator, synthesised netlist)"):
        g = self.p(sub, "gls_summary.rpt")
        if not os.path.exists(g):
            self.step(label, NOT_RUN, "-")
            return
        t = open(g).read()
        seeds = re.findall(r"^seed (\S+): (.*)$", t, re.M)
        tests = re.findall(r"\[TEST-RESULT\][^\n]*", t)
        fails = [l for l in tests if "PASS" not in l] + [r for _, r in seeds if "PASS" not in r]
        self.step(label, "PASS" if seeds and not fails else "FAILED", os.path.relpath(g))
        self.put("%s.seeds" % sub, len(seeds), g)
        self.put("%s.test_results" % sub, len(tests), g)
        self.put("%s.test_results_pass" % sub, len([l for l in tests if "PASS" in l]), g)

    # ------------------------------------------------------------------ output
    def tool_versions(self):
        f = self.p("logs", "tool_versions_collect.txt")
        if not os.path.exists(f):
            f = self.p("logs", "tool_versions.txt")
        return open(f).read().strip() if os.path.exists(f) else "(no tool_versions.txt in this run)"

    def copy_raw(self):
        raw = os.path.join(self.out, "raw")
        os.makedirs(raw, exist_ok=True)
        pats = ["synth/*.rpt", "synth/synth.ys", "sta_pre/*.rpt", "sta_post/*.rpt",
                "pnr/reports/*", "signoff/*.rpt", "signoff/*.json", "gls/*.rpt", "gls_post/*.rpt",
                "drc_selftest/*.rpt", "logs/*.log", "logs/*.txt"]
        n = 0
        for pat in pats:
            for f in glob.glob(self.p(pat)):
                if os.path.isfile(f) and os.path.getsize(f) < 20_000_000:
                    dst = os.path.join(raw, os.path.relpath(f, self.run))
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy2(f, dst)
                    n += 1
        return n

    def write(self):
        os.makedirs(self.out, exist_ok=True)
        n = self.copy_raw()
        # sources are re-pointed to the copies under raw/ when present
        for k, v in self.metrics.items():
            rel = os.path.relpath(os.path.join(os.getcwd(), v["source"]), os.path.abspath(self.run))
            if os.path.exists(os.path.join(self.out, "raw", rel)):
                v["copy"] = os.path.join("raw", rel)
        json.dump({"run": self.run, "collected_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                   "steps": [{"step": a, "status": b, "evidence": c} for a, b, c in self.steps],
                   "metrics": self.metrics}, open(os.path.join(self.out, "metrics.json"), "w"), indent=1)
        L = ["# Flow results - `%s`" % os.path.basename(self.run.rstrip("/")), "",
             "Generated by `flow/scripts/collect_reports.py` from tool outputs in `%s`." % self.run,
             "Every value below is copied from the file named next to it (copies in `raw/`).",
             "Steps marked NOT RUN produced no output in this run; no value is shown for them.", "",
             "## Tool versions", "", "```", self.tool_versions(), "```", "",
             "## Step status", "", "| Step | Status | Evidence |", "|---|---|---|"]
        for a, b, c in self.steps:
            L.append("| %s | **%s** | `%s` |" % (a, b, c))
        L += ["", "## Metrics", "", "| Metric | Value | Source |", "|---|---|---|"]
        for k in sorted(self.metrics):
            v = self.metrics[k]
            L.append("| `%s` | %s | `%s` |" % (k, v["value"], v.get("copy", v["source"])))
        L += ["", "Raw files copied: %d" % n, ""]
        open(os.path.join(self.out, "summary.md"), "w").write("\n".join(L))
        print("wrote %s/summary.md and metrics.json (%d metrics, %d raw files)" % (self.out, len(self.metrics), n))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if not os.path.isdir(a.run):
        sys.exit("run directory %s does not exist" % a.run)
    c = Collector(a.run, a.out)
    c.synth()
    c.gls()
    c.sta("sta_pre", "pre-layout STA (OpenSTA, 3 corners)")
    c.pnr()
    c.sta("sta_post", "post-route STA (OpenSTA + SPEF, 3 corners)")
    c.gls("gls_post", "gate-level simulation (Verilator, routed netlist)")
    c.signoff()
    c.signoff_magic()
    c.write()


if __name__ == "__main__":
    main()
