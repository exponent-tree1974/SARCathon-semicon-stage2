#!/usr/bin/env bash
# Geometric XOR of two independent stream-outs of the same layout
# (KLayout def2gds vs Magic), like LibreLane's KLayout.XOR step.
#   gds_xor.sh <a.gds> <b.gds> <out.rpt>
# Ignored layers: 81/14 (areaid.lowTapDensity), LibreLane's sky130 default
# (KLAYOUT_XOR_IGNORE_LAYERS in open_pdks libs.tech/openlane/config.tcl).
# PASS = no difference shapes on any other layer.
set -euo pipefail
A=$1; B=$2; RPT=$3
source flow/scripts/klayout_common.sh
d=$(dirname "$RPT"); X=$d/xor_diff.gds
"$KLAYOUT_HOME/strmxor" -u -n ${NUM_CORES:-2} -l -ta "$DESIGN_NAME" -tb "$DESIGN_NAME" "$A" "$B" "$X" || true
cat > "$d/xor_count.rb" <<'RB'
ly = RBA::Layout.new
ly.read($x)
ignore = $ignore.split(",")
total = 0
rows = []
ly.layer_indexes.each do |li|
  info = ly.get_info(li)
  key = "#{info.layer}/#{info.datatype}"
  n = 0
  ly.top_cells.each { |t| n += t.begin_shapes_rec(li).each.count }
  next if n == 0
  rows << [key, n, ignore.include?(key)]
  total += n unless ignore.include?(key)
end
rows.sort_by { |r| -r[1] }.each { |k, n, ig| puts "layer %-8s %10d%s" % [k, n, ig ? "  (ignored)" : ""] }
puts "XOR_DIFFERENCES #{total}"
RB
kl_script "$d/xor_count.rb" x="$X" ignore="81/14" | tee "$RPT"
grep -q "^XOR_DIFFERENCES 0$" "$RPT" && echo "XOR_RESULT PASS" | tee -a "$RPT" || { echo "XOR_RESULT FAIL" | tee -a "$RPT"; exit 1; }
