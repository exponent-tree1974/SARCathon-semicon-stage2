#!/usr/bin/env python3
"""Count DRC violations in a KLayout report database (.lyrdb) per category.
    count_lyrdb.py <report.lyrdb>
Prints one line per category and a final 'DRC_VIOLATIONS <n>' line.
"""
import collections, sys
import xml.etree.ElementTree as ET

root = ET.parse(sys.argv[1]).getroot()
per_cat = collections.Counter()
items = root.find("items")
if items is not None:
    for it in items.findall("item"):
        cat = (it.findtext("category") or "?").strip().strip("'")
        per_cat[cat] += 1
for cat, n in sorted(per_cat.items(), key=lambda x: -x[1]):
    print("%-40s %d" % (cat, n))
print("DRC_VIOLATIONS %d" % sum(per_cat.values()))
