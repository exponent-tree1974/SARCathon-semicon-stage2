# =============================================================================
# Run a KLayout DRC (.lydrc) or LVS (.lylvs) deck with a Qt-less KLayout build.
#
# A Qt-less build (`build.sh -without-qt`) ships `strmrun`, which runs Ruby with
# the db/rdb API but registers no DRC/LVS DSL interpreter (that registration
# lives in drc_interpreters.lym / lvs_interpreters.lym, loaded only by the GUI
# application). This wrapper does what those macros do: it loads KLayout's own
# DSL implementation (built-in-macros/_drc_*.rb, _lvs_*.rb from the KLayout
# source tree of the SAME version) and evaluates the deck text inside a
# DRCEngine / LVSEngine.
#
#   strmrun -v kind=drc|lvs -v deck=<file> -v klayout_src=<klayout>/src \
#           -v in_gds=... -v report_file=... [-v cdl_file=... -v top_cell=...] run_dsl.rb
# With a full (Qt) KLayout use `klayout -b -rd ... -r <deck>` instead.
# =============================================================================
src = $klayout_src
# GUI-only classes referenced by the engine; in batch mode there is no active
# view, so they report "none" (the engine handles nil views).
module RBA
  class CellView;   def self.active; nil; end;  end unless RBA.const_defined?(:CellView)
  class LayoutView; def self.current; nil; end; end unless RBA.const_defined?(:LayoutView)
end
drc_dir = File.join(src, "drc", "drc", "built-in-macros")
lvs_dir = File.join(src, "lvs", "lvs", "built-in-macros")
# load order: alphabetical (as KLayout's macro collection does) - _drc_complex_ops
# defines DRCComparable, which _drc_tags uses
Dir.glob(File.join(drc_dir, "_drc_*.rb")).sort.each { |p| load(p) }
Dir.glob(File.join(lvs_dir, "_lvs_*.rb")).sort.each { |p| load(p) } if $kind == "lvs"

xml = File.read($deck, encoding: "UTF-8")
m = xml.match(/<text>(.*)<\/text>/m)
raise "no <text> element in #{$deck}" unless m
text = m[1].gsub("&lt;", "<").gsub("&gt;", ">").gsub("&quot;", '"').gsub("&apos;", "'").gsub("&amp;", "&")

# Optional low-memory DRC mode (-v drc_mode=tiled [-v tile_um=500]): the deck's
# hierarchical `deep` mode is replaced by flat tiled evaluation, which bounds
# memory by tile size. The rules are unchanged. Used only if `deep` exceeds the
# host's memory (the recorded host's limit is 6.27 GB, docs/flow_debug_log.md E6).
if $kind == "drc" && $drc_mode == "tiled"
  tile = ($tile_um || "500").to_s
  text = text.sub(/^\s*deep\s*$/, "# deep (disabled by run_dsl.rb drc_mode=tiled)")
  text = text.sub(/^\s*tiles\(.*\)\s*$/, "tiles(#{tile}.um)")
  puts "run_dsl.rb: DRC in flat tiled mode, tile #{tile} um"
end

engine = ($kind == "lvs") ? LVS::LVSEngine.new : DRC::DRCEngine.new
engine._start("#{$kind.upcase}: #{$deck}")
begin
  engine.instance_eval(text, $deck)
ensure
  engine._finish
end
puts "#{$kind.upcase}_DECK_COMPLETED"
