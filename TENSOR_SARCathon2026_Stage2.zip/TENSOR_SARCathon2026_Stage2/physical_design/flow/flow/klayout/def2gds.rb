# =============================================================================
# DEF + cell GDS -> merged GDS (KLayout Ruby API). Ruby port of the merge logic
# in ORFS flow/util/def2stream.py (which needs KLayout's Python); used because
# the recorded run's KLayout was built without Python.
#   variables (klayout/strmrun -rd): tech_file in_def design_name in_files out_file
# Exit code = number of errors (missing GDS for a LEF cell, orphan cells).
# =============================================================================
tech = RBA::Technology.new
tech.load($tech_file)
opts = tech.load_layout_options

main = RBA::Layout.new
main.read($in_def, opts)
top_idx = main.cell($design_name).cell_index

# drop the LEF abstracts (keep vias and DEF fill), real cells come from the GDS
main.each_cell do |c|
  next if c.cell_index == top_idx
  next if c.name.start_with?("VIA_") || c.name.end_with?("_DEF_FILL")
  c.clear
end
$in_files.split.each do |f|
  puts "[INFO] reading #{f}"
  main.read(f)
end

out = RBA::Layout.new
out.dbu = main.dbu
top = out.create_cell($design_name)
top.copy_tree(main.cell($design_name))

errors = 0
out.each_cell do |c|
  if c.is_empty?
    puts "[ERROR] LEF cell '#{c.name}' has no matching GDS cell (empty)"
    errors += 1
  end
end
out.each_cell do |c|
  if c.name != $design_name && c.parent_cells == 0
    puts "[ERROR] orphan cell '#{c.name}'"
    errors += 1
  end
end
puts "[INFO] cells in merged layout: #{out.cells}"
out.write($out_file)
puts "[INFO] wrote #{$out_file} (errors=#{errors})"
exit(errors)
