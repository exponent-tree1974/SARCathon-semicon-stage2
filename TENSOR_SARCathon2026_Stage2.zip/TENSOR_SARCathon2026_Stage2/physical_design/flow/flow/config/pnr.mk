# =============================================================================
# PnR-only settings (kept out of design.mk so changing them does not trigger
# re-synthesis; design.mk is a synthesis prerequisite).
# =============================================================================

# Electrical repair margins (OpenROAD repair_design -slew_margin/-cap_margin, %).
# Placement- and GRT-stage repair aims below max_transition / max_capacitance
# by this much, so load added later (antenna diodes after detailed routing,
# extracted wiring) still fits. ORFS has the same knobs (SLEW_MARGIN/CAP_MARGIN,
# unset by default). Attempt 1 ran with 0 and ended with 147 slew / 19 cap
# violations at TT after antenna repair (build/sky130hd_tt_100MHz_attempt1).
export SLEW_MARGIN_PCT  := 20
export CAP_MARGIN_PCT   := 20
# post-detailed-route antenna repair rounds (ORFS MAX_REPAIR_ANTENNAS_ITER_DRT)
export MAX_REPAIR_ANTENNAS_ITER_DRT := 5
# buffer inserted on every input and output port (buffer_ports -buffer_cell)
export PORT_BUFFER_CELL := sky130_fd_sc_hd__buf_2
