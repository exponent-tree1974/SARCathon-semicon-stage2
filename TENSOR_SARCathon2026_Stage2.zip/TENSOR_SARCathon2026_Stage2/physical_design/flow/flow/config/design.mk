# =============================================================================
# Stage 2 ASIC flow - single source of truth for design + technology settings.
# Every script in flow/ reads these values (Make exports them as environment
# variables). Change a value here, not in the individual scripts.
# =============================================================================

# ---- design -----------------------------------------------------------------
export DESIGN_NAME      := axis_pcie_link_mux2_top
# RTL parameters = the defaults the Stage 1 v4 regression verified
# (AXIS_W=512 LINK_W=256 FIU_BYTES=256 LANES=4 RX_BUF_DEPTH=32 TID_W=1 FEC_MODE=0).
# Any other value is UNVERIFIED in simulation - re-run the Stage 1 regression first.
export RTL_FILELIST     := flow/config/rtl_files.f
export VERILOG_DEFINES  := SYNTHESIS

# ---- clock (technology-independent intent) ----------------------------------
export CLOCK_PORT       := clk
# 10.0 ns = 100 MHz, the reference clock used in the Stage 1 spec
# (reports/stage1_rtl_review_and_spec.md: 256 bit x 100 MHz = 25.6 Gb/s raw).
export CLOCK_PERIOD_NS  := 10.0

# ---- technology (TECHNOLOGY-DEPENDENT - see docs/technology_assumptions.md) --
export PDK              := sky130
export PLATFORM         := sky130hd
export PLATFORM_DIR     := platform/sky130hd
# synthesis + primary STA corner
export LIB_TT           := $(PLATFORM_DIR)/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
# extra STA corners (from OpenROAD test data, see fetch_platform.sh)
export LIB_SS           := $(PLATFORM_DIR)/lib/sky130_fd_sc_hd__ss_n40C_1v40.lib
export LIB_FF           := $(PLATFORM_DIR)/lib/sky130_fd_sc_hd__ff_n40C_1v95.lib
export TECH_LEF         := $(PLATFORM_DIR)/lef/sky130_fd_sc_hd.tlef
export SC_LEF           := $(PLATFORM_DIR)/lef/sky130_fd_sc_hd_merged.lef
export SC_GDS           := $(PLATFORM_DIR)/gds/sky130_fd_sc_hd.gds
export SC_CDL           := $(PLATFORM_DIR)/cdl/sky130hd.cdl
export RCX_RULES        := $(PLATFORM_DIR)/rcx_patterns.rules
export KLAYOUT_DRC_DECK := $(PLATFORM_DIR)/drc/sky130hd.lydrc
export KLAYOUT_LVS_DECK := $(PLATFORM_DIR)/lvs/sky130hd.lylvs
export KLAYOUT_LYT      := $(PLATFORM_DIR)/sky130hd.lyt
export KLAYOUT_LYP      := $(PLATFORM_DIR)/sky130hd.lyp

# cells used by synthesis / PnR
export TIEHI_CELL       := sky130_fd_sc_hd__conb_1
export TIEHI_PORT       := HI
export TIELO_CELL       := sky130_fd_sc_hd__conb_1
export TIELO_PORT       := LO
export BUF_CELL         := sky130_fd_sc_hd__buf_4
export ABC_DRIVER_CELL  := sky130_fd_sc_hd__buf_1
# ABC internal load assumption (fF), ORFS sky130hd default
export ABC_LOAD_FF      := 5
export PLACE_SITE       := unithd
export TAP_CELL         := sky130_fd_sc_hd__tapvpwrvgnd_1
export FILL_CELLS       := sky130_fd_sc_hd__fill_1 sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_4 sky130_fd_sc_hd__fill_8
export DECAP_CELLS      := sky130_fd_sc_hd__decap_3 sky130_fd_sc_hd__decap_4 sky130_fd_sc_hd__decap_6 sky130_fd_sc_hd__decap_8 sky130_fd_sc_hd__decap_12
export CTS_ROOT_BUF     := sky130_fd_sc_hd__clkbuf_16
export CTS_BUF_LIST     := sky130_fd_sc_hd__clkbuf_4 sky130_fd_sc_hd__clkbuf_8 sky130_fd_sc_hd__clkbuf_16
# Excluded from mapping/sizing: probe cells (metal on every layer) and
# low-power-flow (lpflow) cells, which need multiple power domains.
export DONT_USE_CELLS   := sky130_fd_sc_hd__probe_p_8 sky130_fd_sc_hd__probec_p_8 sky130_fd_sc_hd__lpflow_*

# ---- floorplan (see docs/floorplan_assumptions.md) ---------------------------
# Die is fixed (absolute) so pin capacity is guaranteed; core utilisation is
# checked by the floorplan step and reported, never assumed.
export DIE_AREA         := 0 0 1300 1300
export CORE_MARGIN_UM   := 20
export PLACE_DENSITY    := 0.55
export IO_H_LAYER       := met3
export IO_V_LAYER       := met2
export MIN_ROUTING_LAYER := met1
export MAX_ROUTING_LAYER := met5
export MIN_CLK_ROUTING_LAYER := met3

# ---- run bookkeeping --------------------------------------------------------
export RUN_TAG          ?= sky130hd_tt_100MHz
export NUM_CORES        ?= 2
