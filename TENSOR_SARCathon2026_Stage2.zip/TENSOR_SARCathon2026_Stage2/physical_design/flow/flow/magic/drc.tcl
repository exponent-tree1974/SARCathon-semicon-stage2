# Magic DRC on the final GDS (full SKY130 rule deck, style drc(full)).
# Adapted from LibreLane 3.0.16 scripts/magic/drc.tcl (Apache-2.0,
# (c) LibreLane Contributors, Efabless Corporation). Same settings as LibreLane's
# Magic.DRC step with MAGIC_DRC_USE_GDS=1.
# Run: magic -dnull -noconsole -rcfile <sky130A.magicrc> flow/magic/drc.tcl
# Env: IN_GDS DESIGN_NAME OUT_DIR
crashbackups disable
locking disable
units internal
gds noduplicates true
gds readonly true
gds read $::env(IN_GDS)

set rpt [open $::env(OUT_DIR)/magic_drc.rpt w]
set oscale [cif scale out]
set cell_name $::env(DESIGN_NAME)
magic::suspendall
load $cell_name
select top cell
drc euclidean on
drc style drc(full)
drc check
set drcresult [drc listall why]

set count 0
puts $rpt "$cell_name"
puts $rpt "----------------------------------------"
foreach {errtype coordlist} $drcresult {
    puts $rpt $errtype
    puts $rpt "----------------------------------------"
    foreach coord $coordlist {
        set c [lmap v $coord {expr {$oscale * $v}}]
        puts $rpt [format " %.3fum %.3fum %.3fum %.3fum" {*}$c]
        incr count
    }
    puts $rpt "----------------------------------------"
}
puts $rpt "\[INFO\] COUNT: $count"
close $rpt
puts stdout "MAGIC_DRC_COUNT $count"
quit -noprompt
