# Magic extraction of the final GDS to a SPICE netlist for Netgen LVS.
# Adapted from LibreLane 3.0.16 scripts/magic/extract_spice.tcl (Apache-2.0,
# (c) LibreLane Contributors, Efabless Corporation): MAGIC_EXT_USE_GDS=1,
# no parasitics, standard-cell port order annotated from the cell SPICE.
# Run: magic -dnull -noconsole -rcfile <sky130A.magicrc> flow/magic/extract_spice.tcl
# Env: IN_GDS DESIGN_NAME OUT_DIR CELL_SPICE
drc off
crashbackups disable
locking disable
gds read $::env(IN_GDS)
foreach f $::env(CELL_SPICE) { readspice $f }
load $::env(DESIGN_NAME) -dereference

set extdir $::env(OUT_DIR)/extraction
file mkdir $extdir
cd $extdir
extract do local
extract no capacitance
extract no coupling
extract no resistance
extract no adjust
extract
ext2spice lvs
ext2spice -o $::env(OUT_DIR)/$::env(DESIGN_NAME).spice $::env(DESIGN_NAME).ext
feedback save $::env(OUT_DIR)/magic_ext_feedback.txt
puts stdout "MAGIC_EXTRACT_DONE"
quit -noprompt
