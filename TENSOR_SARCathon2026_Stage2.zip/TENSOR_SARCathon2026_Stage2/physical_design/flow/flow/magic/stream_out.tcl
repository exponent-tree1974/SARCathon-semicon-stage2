# Magic stream-out: final DEF + standard-cell GDS -> GDS.
# Adapted from LibreLane 3.0.16 scripts/magic/def/mag_gds.tcl (Apache-2.0,
# (c) LibreLane Contributors, Efabless Corporation) with LibreLane's default
# options: DEF read with -noblockage -labels, origin from DIEAREA,
# no CIF hierarchy/array info, no datestamp.
# Uses the SAME LEF/GDS views as PnR (ORFS platform), so DEF vias and cell
# names match exactly.
# Run: magic -dnull -noconsole -rcfile <sky130A.magicrc> flow/magic/stream_out.tcl
# Env: IN_DEF SC_GDS SC_LEF TECH_LEF DESIGN_NAME DIE_AREA OUT_GDS
drc off
crashbackups disable
locking disable
gds noduplicates true
gds readonly true

set old_rescale [gds rescale]
gds rescale false
gds read $::env(SC_GDS)
gds rescale $old_rescale
lef read $::env(SC_LEF)

load (NEWCELL)
lef read $::env(TECH_LEF)
def read $::env(IN_DEF) -noblockage -labels

load $::env(DESIGN_NAME)
select top cell
units microns
set da $::env(DIE_AREA)
property FIXED_BBOX "[lindex $da 0]um [lindex $da 1]um [lindex $da 2]um [lindex $da 3]um"
select top cell
cif *hier write disable
cif *array write disable
gds nodatestamp yes
gds write $::env(OUT_GDS)
puts stdout "MAGIC_GDS_WRITTEN $::env(OUT_GDS)"
quit -noprompt
