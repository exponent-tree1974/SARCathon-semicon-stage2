// Functional models for Sky130 HD cells whose liberty entry has no `function`
// (used only by the mapping equivalence check, flow/yosys/lec_mapping.ys).
module sky130_fd_sc_hd__conb_1 (output HI, output LO);
  assign HI = 1'b1;
  assign LO = 1'b0;
endmodule
