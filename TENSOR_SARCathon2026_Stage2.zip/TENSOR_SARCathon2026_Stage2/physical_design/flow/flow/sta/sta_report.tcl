# =============================================================================
# Multi-corner static timing analysis - OpenSTA (`sta`) or OpenROAD (`openroad`).
#
# Environment (exported by the Makefile from flow/config/design.mk):
#   DESIGN_NAME LIB_TT LIB_SS LIB_FF SDC_FILE
#   STA_NETLIST  gate-level netlist (Verilog)
#   STA_OUT      output directory for reports
#   STA_SPEF     optional - parasitics from extraction (post-route); if absent
#                the analysis has NO wire parasitics (pre-layout, optimistic)
#   STA_PROPAGATED  1 = propagated clock (after CTS), else ideal clock
#
# Reports written to $STA_OUT:
#   summary.rpt           worst setup/hold slack + TNS per corner (parsed by collect_reports.py)
#   setup_<corner>.rpt    10 worst setup paths       hold_<corner>.rpt  10 worst hold paths
#   drv.rpt               max slew / cap / fanout violators
#   check_setup.rpt       unclocked / unconstrained / loop checks
#   power_tt.rpt          VECTORLESS power estimate (default activity) - not a sign-off number
# =============================================================================
set out $::env(STA_OUT)
file mkdir $out

define_corners tt ss ff
read_liberty -corner tt $::env(LIB_TT)
read_liberty -corner ss $::env(LIB_SS)
read_liberty -corner ff $::env(LIB_FF)
read_verilog $::env(STA_NETLIST)
link_design $::env(DESIGN_NAME)
read_sdc $::env(SDC_FILE)

set mode "pre-layout (no parasitics, ideal clock)"
if {[info exists ::env(STA_SPEF)] && $::env(STA_SPEF) ne ""} {
  # one extraction (nominal RC) applied to all three cell corners
  foreach c {tt ss ff} { read_spef -corner $c $::env(STA_SPEF) }
  set mode "post-route (SPEF: $::env(STA_SPEF))"
}
if {[info exists ::env(STA_PROPAGATED)] && $::env(STA_PROPAGATED) eq "1"} {
  set_propagated_clock [all_clocks]
  append mode ", propagated clock"
}

set fields {slew cap input_pins fanout}
foreach c {tt ss ff} {
  report_checks -corner $c -path_delay max -group_path_count 10 -fields $fields \
      -digits 3 -format full_clock_expanded > $out/setup_$c.rpt
  report_checks -corner $c -path_delay min -group_path_count 10 -fields $fields \
      -digits 3 -format full_clock_expanded > $out/hold_$c.rpt
}

set fh [open $out/summary.rpt w]
puts $fh "# STA summary - $::env(DESIGN_NAME)"
puts $fh "# mode: $mode"
puts $fh "# clock period (ns): [get_property [get_clocks clk] period]"
foreach c {tt ss ff} {
  # worst slack (may be positive) and total negative slack, in ns (library time unit)
  set ws  [sta::worst_slack -corner $c -max]
  set wh  [sta::worst_slack -corner $c -min]
  set tns [sta::total_negative_slack -corner $c -max]
  set thn [sta::total_negative_slack -corner $c -min]
  puts $fh [format "corner %-2s setup_ws_ns %.3f setup_tns_ns %.3f hold_ws_ns %.3f hold_tns_ns %.3f" \
      $c $ws $tns $wh $thn]
}
# design-rule (electrical) violations - worst over all corners (OpenSTA counters)
foreach {k cmd} {max_slew sta::max_slew_violation_count max_cap sta::max_capacitance_violation_count \
                 max_fanout sta::max_fanout_violation_count} {
  if {[catch {set n [$cmd]}]} { set n "n/a" }
  puts $fh "drv ${k}_violations $n"
}
# ... and per corner: violating pins counted from report_check_types -corner
foreach c {tt ss ff} {
  report_check_types -corner $c -max_slew -max_capacitance -max_fanout -violators > $out/drv_$c.rpt
  set cnt [dict create max_slew 0 max_capacitance 0 max_fanout 0]
  set sec ""
  set rf [open $out/drv_$c.rpt]
  while {[gets $rf line] >= 0} {
    if {[regexp {^max (slew|capacitance|fanout)} $line -> k]} { set sec max_$k; continue }
    if {$sec ne "" && [string match "*(VIOLATED)*" $line]} { dict incr cnt $sec }
  }
  close $rf
  puts $fh [format "drv_corner %s max_slew_violations %d max_cap_violations %d max_fanout_violations %d" \
      $c [dict get $cnt max_slew] [dict get $cnt max_capacitance] [dict get $cnt max_fanout]]
}
close $fh

report_check_types -max_slew -max_capacitance -max_fanout -violators > $out/drv.rpt
check_setup -verbose > $out/check_setup.rpt
report_clock_properties > $out/clocks.rpt
report_power -corner tt > $out/power_tt.rpt
puts "STA done: $mode"
