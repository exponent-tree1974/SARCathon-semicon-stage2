# =============================================================================
# Timing constraints - axis_pcie_link_mux2_top (Stage 2, Sky130 HD)
#
# One clock domain: every flop is clocked by `clk` (checked in RTL: no other
# clock inputs, no negedge flops, no generated clocks, no clock gating).
# Reset: rst_n is asynchronous and enters ONLY the 2-flop reset_sync
# (async assert / sync de-assert). The synchroniser output drives all other
# async resets and IS timed (recovery/removal) because it starts at a flop.
#
# Values marked [TECH] depend on Sky130 HD and on the unknown SoC context;
# they are budgets, not measurements. See docs/technology_assumptions.md.
# This file is used unchanged by: OpenSTA (pre-layout), OpenROAD (PnR),
# LibreLane (PNR_SDC_FILE / SIGNOFF_SDC_FILE) and ORFS (SDC_FILE).
# =============================================================================

# ---- clock ------------------------------------------------------------------
set clk_period 10.0
if {[info exists ::env(CLOCK_PERIOD_NS)]} { set clk_period $::env(CLOCK_PERIOD_NS) }
create_clock -name clk -period $clk_period [get_ports clk]

# Uncertainty: jitter + (pre-CTS) skew allowance.            [TECH]
set_clock_uncertainty -setup 0.25 [get_clocks clk]
set_clock_uncertainty -hold  0.10 [get_clocks clk]
# Ideal clock transition before CTS (replaced by propagated clock after CTS).
set_clock_transition 0.15 [get_clocks clk]

# ---- I/O budget -------------------------------------------------------------
# The block sits inside an unknown SoC: assume 30 % of the period is consumed
# outside the block on every I/O path (input arrival / output required).
set io_frac 0.30
set in_ports  [lsearch -inline -all -not -exact [all_inputs] [get_ports clk]]
set in_ports  [lsearch -inline -all -not -exact $in_ports [get_ports rst_n]]
set_input_delay  [expr {$io_frac * $clk_period}] -clock clk $in_ports
set_output_delay [expr {$io_frac * $clk_period}] -clock clk [all_outputs]

# Driver / load seen at the block boundary.                     [TECH]
# (sky130_fd_sc_hd__inv_2 driver and 33.4 fF load are the LibreLane sky130 defaults)
set_driving_cell -lib_cell sky130_fd_sc_hd__inv_2 -pin Y $in_ports
set_load 0.0334 [all_outputs]

# ---- reset ------------------------------------------------------------------
# Asynchronous assert into the synchroniser only; de-assert is re-timed inside.
set_false_path -from [get_ports rst_n]
set_driving_cell -lib_cell sky130_fd_sc_hd__inv_2 -pin Y [get_ports rst_n]

# ---- design rules -------------------------------------------------------------[TECH]
set_max_transition 1.5 [current_design]
set_max_fanout 16 [current_design]
