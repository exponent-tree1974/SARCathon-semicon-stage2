# =============================================================================
# Pin constraints for OpenROAD place_pins (the same edge assignment is in
# flow/librelane/pin_order.cfg; flow/scripts/check_pin_constraints.py verifies
# that both files cover every top-level port exactly once).
#
#  North (top)    : AXI4-Stream ingress, source 0 and source 1   (1158 pins)
#  South (bottom) : AXI4-Stream egress m_axis_*                  ( 581 pins)
#  East  (right)  : PHY-facing symbols and credits               ( 532 pins)
#  West  (left)   : clk, rst_n, AXI4-Lite CSR, irq, arbiter events (103 pins)
#
# Rationale: data flows north -> core -> east (TX) and east -> core -> south
# (RX); the slow control interface gets the remaining edge. Pin capacity per
# edge is checked in docs/floorplan_assumptions.md.
# =============================================================================
set_io_pin_constraint -region top:*    -pin_names {s0_axis_* s1_axis_*}
set_io_pin_constraint -region bottom:* -pin_names {m_axis_*}
set_io_pin_constraint -region right:*  -pin_names {tx_sym* rx_sym* rx_credit_return* tx_credit_return*}
set_io_pin_constraint -region left:*   -pin_names {clk rst_n s_axil_* irq ev_arb_pkt_start*}
