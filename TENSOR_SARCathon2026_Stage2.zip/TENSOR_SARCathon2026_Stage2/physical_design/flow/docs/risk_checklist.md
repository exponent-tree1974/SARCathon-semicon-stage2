# Stage 2 risk checklist — synthesis, timing, routing, DRC, LVS

**Status values:**

- **CLOSED** — checked by a tool in the recorded run (`build/sky130hd_tt_100MHz`). The evidence file is named.
- **OPEN** — a known risk that is not resolved, with the next action.
- **ACCEPTED** — a deliberate limitation of a block-level hackathon flow, documented in `technology_assumptions.md`.
- **NOT RUN** — the check exists in the flow but did not run in the recorded environment.

Numbers are copied from tool reports; the collected copy of each report is in `reports/sky130hd_tt_100MHz/raw/`.

## 1. Synthesis

| # | Risk | Check in this flow | Status / evidence |
|---|---|---|---|
| S1 | Latches inferred | `select -assert-none` on all latch cell types (fails the run) | CLOSED: 0 latches (`logs/1_synth.log`) |
| S2 | Undriven or multi-driven nets, combinational loops | `check -assert` on the generic netlist and again on the mapped netlist (needs the liberty cells loaded as black boxes) | CLOSED: 0 problems (`synth/check.rpt`) |
| S3 | Unmapped (non-library) cells left in the netlist | `select -assert-none t:$*` after mapping | CLOSED: 0 |
| S4 | Excluded cells used (probe, lpflow) | `-dont_use` on `dfflibmap` and `abc`; netlist grep | CLOSED: 0 instances |
| S5 | **Technology mapping changed the logic** (ABC, tie cells, `insbuf`) | `make lec`: register cut-point miter of the pre-ABC netlist against the final netlist, proved by ABC `iprove`; flop correspondence check; negative control (one `nand2_1`→`nor2_1` must fail) | CLOSED: 12,590/12,590 flops correspond, `LEC_RESULT EQUIVALENT`, negative control `NOT_EQUIVALENT` (`synth/lec_*.rpt`) |
| S6 | **Yosys elaborated the SystemVerilog differently from the simulators** used in Stage 1 (Icarus, Verilator) | Gate-level simulation of the Stage 1 benches on the netlist. The arbiter bench reads internal hierarchy (`dut.u_arb.locked`, …) and needs a GLS variant without internal probes. | OPEN — see §6 for status |
| S7 | Simulation-only code reaching synthesis | `-DSYNTHESIS` on every file; the `ifndef SYNTHESIS` block in `fiu_rx_buffer` and the `ifdef FORMAL` invariants in `axis_rr_arbiter` are excluded | CLOSED by construction (`synth/synth.ys`) |
| S8 | Unverified parameter set synthesised | Only the defaults verified by the Stage 1 v4 regression are used | CLOSED (`design.mk`) |
| S9 | Storage built from flip-flops instead of SRAM | 12,590 flops = 61.85 % of cell area | ACCEPTED (T4) |
| S10 | Tool drift: Yosys `main` is not a release | Commit pinned (0ad867ab); a rerun with another version gives a different netlist | ACCEPTED: pinned in `tools/build_from_source.sh` |

## 2. Timing

| # | Risk | Check | Status / evidence |
|---|---|---|---|
| T1 | High-fanout nets left unbuffered by synthesis | Pre-layout STA DRV counts | Measured: 296 fanout, 25,782 slew, 40 cap violations. Worst: reset synchroniser → 1,415 `RESET_B` pins; write enables → 578 `DE` pins. **Result after placement-stage repair: see §6.** |
| T2 | Real logic depth vs 10 ns | Worst register-to-register path without fanout effects | Pre-layout: about 0.84 ns of logic (input at 3.03 ns, last gate at 3.84 ns) before the 578-fanout net. Meets 10 ns once buffered; confirm post-route (§6). |
| T3 | Reset de-assertion (recovery/removal) across 1,415 flops | SDC times the synchroniser output (async group) | Pre-layout −32.0 ns at TT is fanout-only. Post-CTS/post-route result: §6. |
| T4 | Hold after CTS, especially at the FF corner | Post-CTS `repair_timing -hold`, post-route 3-corner STA | §6 |
| T5 | I/O budgets (30 % of the period) differ from the real SoC | Assumption | ACCEPTED (T3): re-run with the SoC's real I/O constraints |
| T6 | Single-corner optimisation; the slow corner is `ss_n40C_1v40`, harsher than LibreLane's `ss_100C_1v60` | 3-corner analysis | ACCEPTED (T2): SS results are a stress check, not pass/fail |
| T7 | No crosstalk/SI analysis, no OCV derates | Not available in OpenSTA as configured | OPEN: add `set_timing_derate` margins, or run SI-aware sign-off STA before tape-out |
| T8 | Unconstrained or unclocked paths | `check_setup -verbose` | CLOSED: only `rst_n` lacks an input delay, which is intentional (false path) (`sta_pre/check_setup.rpt`) |
| T9 | Vectorless power is not a power number | `report_power` with default activity | ACCEPTED: labelled vectorless; a sign-off number needs SAIF/VCD activity from simulation |

## 3. Routing

| # | Risk | Check | Status / evidence |
|---|---|---|---|
| R1 | Pin-limited die: north edge 84 % full | Pin plan + `place_pins` | §6 |
| R2 | Congestion at the RX-buffer read mux (32:1 × 256 bit) | GRT congestion report, low placement density (0.55) | §6 |
| R3 | Antenna violations | `repair_antennas` (diode_2) after GRT; `check_antennas` after DRT | §6 |
| R4 | Detailed-route DRC (OpenROAD's DRC engine) | `detailed_route -output_drc` | §6 |
| R5 | IR drop on a met4/met5 strap grid sized for generic blocks | `analyze_power_grid` (static) | §6 |
| R6 | Runtime and memory of PnR on small hosts | Wall clock per step in logs | §6 |

## 4. DRC

| # | Risk | Check | Status / evidence |
|---|---|---|---|
| D1 | KLayout deck is a subset of SKY130 rules | `make drc` with ORFS `sky130hd.lydrc` | §6 |
| D2 | Magic DRC (LibreLane sign-off) not run | — | OPEN: run LibreLane (Route A in `README.md`) |
| D3 | No metal density fill | — | ACCEPTED for a macro; the top-level SoC flow must fill and check density |
| D4 | Off-grid pins / min-area on pins | DRT DRC + KLayout DRC | §6 |

## 5. LVS

| # | Risk | Check | Status / evidence |
|---|---|---|---|
| L1 | Layout ≠ netlist | `make lvs` with ORFS `sky130hd.lylvs` | §6 |
| L2 | Physical-only cells (tap, fill, decap, diode) in LVS | Platform CDL contains them; netlist written with power pins | §6 |
| L3 | Netgen LVS (LibreLane sign-off) not run | — | OPEN: run LibreLane |

## 6. Results of the recorded run

Filled in from `reports/sky130hd_tt_100MHz/summary.md` after the flow finished. See that file for the full table.
