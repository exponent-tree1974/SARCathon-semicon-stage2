# Technology-dependent assumptions

Everything in this list is a **choice or an assumption**, not a result. Most items would change for another PDK, standard-cell library or SoC context. Where a value is set, its file is named.

The RTL itself is technology-independent: `src/rtl/` is the Stage 1 v4 RTL, byte-identical, with checksums in `src/rtl/MANIFEST.sha256`. It contains no vendor primitives, no memory macros, no clock gating, no latches and no analog content.

## T1. PDK and standard-cell library

| Item | Value | Where set | Note |
|---|---|---|---|
| PDK | SkyWater SKY130 (130 nm, open) | `flow/config/design.mk` | Assumed foundry target. |
| Standard cells | `sky130_fd_sc_hd` (high density, 2.72 µm rows, `unithd` site) | `design.mk` | HD is the default library in LibreLane and ORFS. HS/MS/LS/HDLL would change area, timing and the cell names in the SDC and scripts. |
| Platform files | ORFS `flow/platforms/sky130hd` @ `eda8e55` | `flow/scripts/fetch_platform.sh` | Tech LEF, merged cell LEF, GDS, CDL, TT liberty, KLayout DRC/LVS decks, RCX rules, PDN/tapcell scripts. **LibreLane instead uses an open_pdks `sky130A` build.** The two are derived from the same SkyWater sources but are not byte-identical; the ORFS tech LEF and merged LEF are ORFS-maintained. |
| PDK for Magic / Netgen sign-off | open_pdks `sky130A` @ `8afc8346` (ciel release; SHA-256 pinned) | `flow/scripts/fetch_pdk.sh`, `Makefile` (`SKY130_PDK_REV`) | The version LibreLane 3.0.16 pins (`librelane/pdk_hashes.yaml`). It provides the Magic tech file and magicrc, the Netgen setup, and the `sky130_fd_sc_hd` SPICE netlists. Magic stream-out uses the **ORFS** LEF/GDS (the same views as PnR), so the DEF matches exactly; only rules and devices come from `sky130A`. |
| Supply | single 1.8 V domain (VDD/VSS) | ORFS `pdn.tcl` | No UPF, no level shifters, no power gating. |

## T2. Timing corners

| Use | Liberty | Source |
|---|---|---|
| Synthesis mapping, PnR optimisation, primary STA | `sky130_fd_sc_hd__tt_025C_1v80` | ORFS platform |
| Extra STA corner, "slow" | `sky130_fd_sc_hd__ss_n40C_1v40` | OpenROAD test data @ `8c65de5` |
| Extra STA corner, "fast" (hold) | `sky130_fd_sc_hd__ff_n40C_1v95` | OpenROAD test data @ `8c65de5` |

- **The slow corner is not a standard sign-off corner.** LibreLane's default slow corner is `ss_100C_1v60`. `ss_n40C_1v40` (1.40 V, cold) is much slower. It is the only pre-built SS liberty that could be fetched in this environment. Treat its result as a stress check, not as pass or fail. With an open_pdks install, use `ss_100C_1v60` instead.
- Optimisation is single-corner (TT). The SS and FF corners are analysed, not optimised for.
- **Parasitic extraction has one RC corner:** the nominal `rcx_patterns.rules` from the platform. Min and max RC corners are not modelled.

## T3. Clock, I/O and design-rule constraints

All of these are in `flow/constraints/axis_pcie_link_mux2_top.sdc`.

| Constraint | Value | Basis |
|---|---|---|
| Clock | 10.0 ns (100 MHz) | The reference clock of the Stage 1 spec (256 bit × 100 MHz = 25.6 Gb/s raw). It is not a PCIe 6.0 rate. |
| Setup / hold uncertainty | 0.25 ns / 0.10 ns | Allowance for jitter, plus skew before CTS. |
| Clock transition before CTS | 0.15 ns | Replaced by the propagated clock after CTS. |
| Input and output delay | 30 % of the period (3.0 ns) | Unknown SoC context; this is a budget, not a measurement. |
| Driver / load | `sky130_fd_sc_hd__inv_2` / 33.4 fF | LibreLane sky130 defaults. |
| Max transition / fanout | 1.5 ns / 16 | Design-rule limits for HD cells. |
| `rst_n` | false path | Asynchronous assert into a 2-flop synchroniser. The synchronised reset is timed for recovery and removal. |

## T4. Storage implemented as flip-flops

The RX buffer (`fiu_rx_buffer`, `RX_BUF_DEPTH = 32` FIU words of 256 bits plus side bits) and all other storage map to standard-cell flip-flops. Sky130 HD has no generic RAM compiler in this flow.

- **Effect:** flip-flops dominate area and clock-tree load, and leakage and dynamic power are higher than with an SRAM macro.
- **Alternative for a real tape-out:** an SRAM macro (OpenRAM `sky130_sram_*`, or DFFRAM). This changes the floorplan (macro placement and halos, PDN macro grid) and needs the macro's LEF, GDS and liberty.

## T5. Block-level (hard-macro) style

- No pad ring, ESD or seal ring. The result is a hard macro meant to be instanced inside a larger SoC.
- Signal pins are on `met2` (north and south edges) and `met3` (east and west edges). Power is a `met4`/`met5` strap grid, with `met5` straps exported as power pins (ORFS `pdn.tcl`).
- The parent SoC must route 2,374 signal pins to this macro. Pin count is the main physical risk; see `floorplan_assumptions.md`.

## T6. Physical rules taken from the platform

- **Tracks** (`make_tracks.tcl`): met2 pitch 0.46 µm, met3 0.68 µm, met4 0.92 µm, met5 3.40 µm.
- **Taps:** `tapvpwrvgnd_1` every 14 µm.
- **Fill:** `fill_1/2/4/8`.
- **Antenna diode:** `diode_2`.
- **Tie cell:** `conb_1`. Excluded from mapping: `probe_p_8`, `probec_p_8` and all `lpflow_*` cells.
- **Routing layers:** signals met1–met5, clock met3–met5. Global-routing capacity is reduced 20 % on every layer (`fastroute.tcl`). This is the ORFS sky130hd value; LibreLane's sky130 default instead blocks li1 and leaves met1–met5 unadjusted.
- **Port buffers:** `sky130_fd_sc_hd__buf_2` on every input and output port (`flow/config/pnr.mk`, `PORT_BUFFER_CELL`). Left to choose, OpenROAD picked the clock-delay cell `clkdlybuf4s50_1` (`docs/flow_debug_log.md` D5).
- **Electrical repair margins:** `repair_design` aims 20 % below `max_transition` and `max_capacitance` at placement and after global routing (`SLEW_MARGIN_PCT`, `CAP_MARGIN_PCT`), so diodes and extracted wiring added later still fit. LibreLane's default is 20 % at placement and 10 % after GRT.
- **Antenna repair:** `diode_2` diodes after global routing (3 rounds), then up to 5 rounds after detailed routing (ORFS loop). Any net that survives gets a diode placed next to the violating gate pin (step 5c, `flow/openroad/lib/eco_antenna_diode.tcl`).
- **PDN:** met1 follow-pins (0.48 µm wide); met4 straps 1.6 µm wide at a 27.14 µm pitch; met5 straps 1.6 µm wide at a 27.2 µm pitch.
- **Metal density fill is not inserted** by this flow. ORFS ships a `fill.json`, but foundry tape-out needs density fill and its checks.

## T7. DRC and LVS decks

The flow has two independent sign-off paths.

| Path | DRC | LVS | GDS |
|---|---|---|---|
| KLayout | ORFS `sky130hd.lydrc`: a **subset** of the SKY130 rules; `deep` mode, or `KLAYOUT_DRC_MODE=tiled` | ORFS `sky130hd.lylvs`: the layout vs the CDL written from the routed database plus the platform cell CDL | `flow/klayout/def2gds.rb` (Ruby port of ORFS `def2stream.py`) |
| Magic + Netgen (LibreLane's sign-off tools) | Magic 8.3.623, `sky130A.tech`, style `drc(full)`: the full Magic rule deck LibreLane runs (`flow/magic/drc.tcl`) | Magic extraction → Netgen 1.5.316 against the OpenROAD powered netlist, using the PDK `sky130A_setup.tcl` (`flow/magic/extract_spice.tcl`, `flow/netgen/lvs.tcl`) | `flow/magic/stream_out.tcl` |

- The two GDS files are compared with a geometric XOR (KLayout `strmxor`). Layer 81/14 is ignored, as in LibreLane.
- Both DRC engines are checked with a negative control (`make drc-selftest`): a planted 50 nm met1 square must be flagged.
- **Not covered by either path:** metal density and fill (T6), the foundry's own (Calibre) decks, and the OpenRCX corner spread (T2).
- A clean result is **necessary but not sufficient** for tape-out.

## T8. Tool builds (recorded environment)

- All tools were built from source at pinned commits (`tools/build_from_source.sh`), because the host had no package manager access beyond GitHub.
- **KLayout 0.30.4** is built **without Qt**, so the batch tools are `strmrun`, `strmxor` and the other `strm*` buddies.
  - It **must** be built with `-libexpat`; otherwise the XML parser is a stub and technology files cannot be loaded (`docs/flow_debug_log.md` E5).
  - DRC/LVS decks are run through `flow/klayout/run_dsl.rb`, which loads KLayout's DSL from the source tree of the same version.
  - A full KLayout (`klayout -b`) is used automatically when it is on `PATH`.
- **Magic** is built with Tcl/Tk (X11 headers needed at build time) and runs with `-dnull`.
- **Yosys** is built from `main` (`0ad867ab`), which is not a release; see risk S10.
