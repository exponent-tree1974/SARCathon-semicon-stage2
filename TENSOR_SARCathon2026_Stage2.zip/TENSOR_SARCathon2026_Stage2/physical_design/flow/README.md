# Stage 2: open-source ASIC flow for `axis_pcie_link_mux2_top` (SKY130)

This directory turns the Stage 1 v4 RTL into a reproducible, open-source ASIC flow. The target is the SkyWater **SKY130** PDK with the `sky130_fd_sc_hd` standard cells. The flow runs RTL to GDS:

| Stage | Tools |
|---|---|
| Synthesis and mapping check | Yosys + ABC: mapping equivalence check with a negative control |
| Gate-level simulation | Verilator: synthesised **and** routed netlists, Stage 1 bench |
| Timing | OpenSTA: three corners, pre-layout and with extracted parasitics |
| Place and route | OpenROAD: floorplan → place → CTS → global route → detailed route → antenna repair → RC extraction / IR drop |
| Sign-off | **Two independent sign-off paths**: KLayout (GDS, DRC, LVS) and Magic + Netgen, the tools and scripts LibreLane signs off with (GDS, DRC, extraction, LVS). Also a geometric XOR of the two GDS stream-outs. |
| Reporting | One script collects every result into a reviewable report |

The same constraints are packaged for **LibreLane** (the maintained successor of OpenLane 2) and for **OpenROAD-flow-scripts (ORFS)**.

> **Rules this flow follows**
> * **No number is estimated.** Every area, timing, power or physical figure in this repository is copied from a tool report, and the report is named. A step that did not run is reported as **NOT RUN**.
> * **No PCIe compliance is claimed.** The design is the Stage 1 link layer inspired by PCIe 6.0 (FIU framing, CRC, credits, 2-source arbiter). It is not a PCIe controller.
> * **Technology dependencies are listed.** Every technology-dependent choice is in [`docs/technology_assumptions.md`](docs/technology_assumptions.md).

## Results of the recorded run

See `../STATUS.md` and `../results_run2/summary.md`. In brief:

- Sky130 HD at 100 MHz: routed with 0 router violations and 0 antenna violations.
- Timing met at TT (setup +0.026 ns, hold +0.096 ns) and FF; the SS stress corner is violated.
- Gate-level simulation passes on the synthesised and the routed netlist (16/16 each).
- **Open:** KLayout DRC reports 1,520 met3 minimum-area violations at stacked vias (root cause identified); LVS not completed.


## Directory structure

```
stage2_asic/
├── README.md                     this file
├── Makefile                      every step of the flow (run from this directory)
├── src/rtl/                      SOURCE    Stage 1 v4 RTL, frozen copy + MANIFEST.sha256
├── flow/                         SOURCE    flow inputs
│   ├── config/design.mk            design, clock, PDK/cell choices, floorplan (synthesis prerequisite)
│   ├── config/pnr.mk               PnR-only knobs: port buffer, repair margins, antenna rounds
│   ├── config/rtl_files.f          RTL file list (same order as the Stage 1 regression)
│   ├── constraints/*.sdc           timing constraints (shared by every tool)
│   ├── constraints/io_pins.tcl     pin constraints (OpenROAD)
│   ├── yosys/                      synthesis + mapping-equivalence templates
│   ├── sta/sta_report.tcl          3-corner STA (pre- and post-layout), per-corner DRV
│   ├── openroad/                   1_floorplan 2_place 3_cts 4_grt 5_route 5b_antenna
│   │                               5c_antenna_cleanup 6_final (+ common.tcl, lib/)
│   ├── klayout/                    DEF->GDS, DSL runner for the Qt-less KLayout
│   ├── magic/  netgen/             Magic stream-out / DRC / extraction, Netgen LVS
│   │                               (adapted from LibreLane 3.0.16, Apache-2.0)
│   ├── librelane/                  LibreLane config.json + pin_order.cfg
│   ├── orfs/                       ORFS design config.mk
│   └── scripts/                    fetch (platform, PDK), checks, report collection
├── verif/gls/                    SOURCE    gate-level-simulation bench (derived from Stage 1)
├── tools/build_from_source.sh    SOURCE    pinned toolchain build (used for the recorded run)
├── docs/                         SOURCE    assumptions, floorplan, risk checklist, debug log
├── platform/sky130hd/            FETCHED   ORFS platform files, pinned commit (`make platform`)
├── platform/pdk/                 FETCHED   SKY130A for Magic/Netgen, pinned (`make pdk`)
├── build/<RUN_TAG>/              GENERATED raw tool output, logs, databases, GDS (not committed)
└── reports/<RUN_TAG>/            GENERATED collected results: summary.md, metrics.json, raw/
```

The flow never writes into `src/`, `flow/`, `verif/`, `docs/` or `tools/`. Generated data goes only to `build/` (raw) and `reports/` (collected). `platform/` and `build/` are in `.gitignore`; `reports/` is meant to be committed.

## Exact commands

Run everything from this directory. `RUN_TAG` defaults to `sky130hd_tt_100MHz`.

### Route B: Makefile flow with locally built tools (this is what was run)

```bash
# 0. tools (pinned commits; about 8-10 h on 2 cores), then put them on PATH
PREFIX=/opt/eda/install SRC=/opt/eda/src J=$(nproc) bash tools/build_from_source.sh
export PATH=/opt/eda/install/bin:$PATH
export LD_LIBRARY_PATH=/opt/eda/install/lib:$LD_LIBRARY_PATH   # Tcl/Tk for Magic and Netgen

# 1. platform files + PDK (both pinned, SHA-256 checked) and a tool check
make platform          # ORFS sky130hd platform @ eda8e55 (git sparse checkout)
make pdk               # SKY130A @ 8afc8346 (ciel release; the version LibreLane 3.0.16 pins)
make check-env

# 2. front end
make synth             # Yosys -> build/<tag>/synth/axis_pcie_link_mux2_top.netlist.v
make lec               # mapping equivalence (Yosys + ABC) with a negative control
make gls               # gate-level simulation of the synthesised netlist (Verilator)
make sta-pre           # OpenSTA, tt/ss/ff, no parasitics

# 3. back end (OpenROAD) - run alone, see "Host requirements"
make floorplan place cts grt route antenna finish      # = make pnr
make sta-post          # OpenSTA, tt/ss/ff, SPEF from OpenRCX, propagated clock
make gls-post          # same bench on the routed netlist

# 4. sign-off, two independent tool sets - run one at a time
make gds drc lvs       # KLayout: DEF->GDS, ORFS sky130hd DRC deck, LVS
make signoff-magic     # Magic GDS, KLayout-vs-Magic XOR, Magic DRC, Magic extraction + Netgen LVS
make drc-selftest      # negative control: both DRC engines must flag a planted met1 error

# 5. collect
make collect           # reports/<tag>/summary.md + metrics.json + raw/
```

`make all` runs the whole sequence in this order. To change the clock, die or corners, edit `flow/config/design.mk` and use a new `RUN_TAG`, for example `make all RUN_TAG=sky130hd_tt_80MHz CLOCK_PERIOD_NS=12.5`. If full-chip KLayout DRC does not fit in memory, add `KLAYOUT_DRC_MODE=tiled` (flat tiled evaluation, same rules).

**Host requirements (measured in the recorded run):**

- **Memory:** detailed routing peaks at about 4.4 GB, and full-chip KLayout DRC needs more than 4.4 GB. On the recorded host (6.27 GB memory limit) these steps had to run one at a time.
- **Wall time on 2 cores:**
  - detailed routing: about 2 h;
  - antenna repair: about 1.5 h;
  - global routing with repair: about 30–40 min;
  - every other step: 15 min or less.

### Route A: LibreLane (recommended where Nix or Docker is available)

LibreLane bundles Yosys, OpenROAD, Magic, Netgen and KLayout, and signs off with Magic and KLayout DRC plus Netgen LVS.

```bash
pip3 install --upgrade librelane            # LibreLane 3.x (OpenLane 2 successor)
librelane --dockerized --smoke-test         # one-time check of the container + PDK download
librelane --dockerized flow/librelane/config.json
```

The configuration is in [`flow/librelane/config.json`](flow/librelane/config.json). It uses the same RTL, SDC, die and pin plan as the Makefile flow, and all 18 variable names were checked against the LibreLane 3.0.16 source. LibreLane's own defaults already include what this flow had to add: port buffering and 20 % slew/cap repair margins. **It was not executed** (see Blockers), so treat its first run as untested.

### Route C: OpenROAD-flow-scripts

Copy `flow/orfs/sky130hd/axis_pcie_link_mux2_top/` into `<ORFS>/flow/designs/sky130hd/`, then run:

```bash
make -C <ORFS>/flow DESIGN_CONFIG=./designs/sky130hd/axis_pcie_link_mux2_top/config.mk STAGE2=$PWD
```

The ORFS config sets the same port-buffer cell, repair margins and antenna rounds as `flow/config/pnr.mk`. It was not executed either.

## Blockers and next steps

| Blocker (recorded environment) | Effect | Next step |
|---|---|---|
| No PyPI, no Docker daemon, Nix cache refused by the proxy | LibreLane (Route A) cannot be installed or run | On a workstation with Docker: `pip3 install librelane && librelane --dockerized flow/librelane/config.json`. Compare its `final/metrics.json` with `reports/<tag>/metrics.json`. |
| apt mirrors unreachable | Magic, Netgen, Tk and zstd had to be built from source | None needed; `tools/build_from_source.sh` builds them at LibreLane's pinned versions. |

Open technical items (timing corners, design-rule residues, density fill and so on) are tracked with their evidence in [`docs/risk_checklist.md`](docs/risk_checklist.md). Every failure met while bringing up the flow is in [`docs/flow_debug_log.md`](docs/flow_debug_log.md).

## Documents

- [`docs/technology_assumptions.md`](docs/technology_assumptions.md): PDK, corners, SDC budgets, flip-flop storage, decks and tool builds.
- [`docs/floorplan_assumptions.md`](docs/floorplan_assumptions.md): pin plan, pin-capacity arithmetic, die and core.
- [`docs/risk_checklist.md`](docs/risk_checklist.md): synthesis, timing, routing, DRC and LVS risks, each with its check, status and evidence.
- [`docs/flow_debug_log.md`](docs/flow_debug_log.md): failures, root causes and fixes (toolchain, scripts, physical design).
- [`reports/sky130hd_tt_100MHz/summary.md`](reports/sky130hd_tt_100MHz/summary.md): the collected results of the recorded run, every value with its source file.
